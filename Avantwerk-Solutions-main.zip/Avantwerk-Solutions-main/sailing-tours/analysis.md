# Sailing Tour Project — Competitive Analysis & Site Architecture

## Source: Vertical Sailing Tour (verticalsailingtour.com)

### What They Are
Premium adventure sailing tour operator based in Italy (S.r.l.), operating since 2013. Combines sailing with climbing and trekking across Mediterranean destinations. Licensed Tour Operator #153. IFMGA-certified mountain guides + professional skippers.

### Brand Positioning
- "Vertical experience at sea level" — mountain mindset meets sailing
- Small-group, immersive, community-oriented (not mass tourism)
- "Presence over intensity" philosophy
- Heritage story (memorial to lost co-founders)
- 500+ guests, 30+ nationalities, 10,500 nautical miles

### Site Architecture (13 pages + taxonomy)

```
Homepage (/)
├── About (/about-vertical-sailing-tour/)
├── Adventures
│   ├── Sailing & Climbing (/book-sailing-climbing-tours/)
│   │   ├── Sardinia (/destinations/sardinia-sailing-climbing/)
│   │   ├── Kalymnos (/destinations/kalymnos-sailing-climbing/)
│   │   ├── Amalfi Coast (/destinations/amalfi-coast-sailing-climbing/)
│   │   └── Mallorca DWS (/destinations/mallorca-deep-water-soloing/)
│   └── Sailing & Trekking (/upcoming-tours-trekking/)
│       ├── Aeolian Islands (/destinations/aeolian-islands-sailing-trekking/)
│       ├── Tuscany & Corsica (/destinations/tuscany-corsica/)
│       └── Amalfi Coast (/destinations/amalfi-coast-sailing-trekking/)
├── Blog (/blog/) — 9 articles
│   ├── Italy sailing guide
│   ├── Founder profile
│   ├── Kalymnos climbing guide
│   ├── Why climbers love sailing
│   ├── Amalfi Coast guide
│   ├── Solo climbing trips
│   ├── Fall climbing season
│   ├── Guest reviews/stories
│   └── Dodecanese exploration
├── FAQ (/faq/)
├── Secret Tour (/secret-tour-2025/) — exclusive/invitation-only
├── Partnership (/partnership/) — currently just team page
├── Captain Tips (4 destination-specific tips pages)
├── Terms & Conditions (/terms-conditions/)
└── Team (10 individual profiles)
```

### Content Strategy

**Destination pages** are the core — each includes:
- Coordinates + seasonal info (when to go)
- Activity specifics (climbing grades, rock types, trail difficulty)
- Location highlights (6+ specific crags/spots with interactive map)
- Tour options/variants
- Atmospheric storytelling over transactional details
- NO pricing on destination pages (inquiry-based)

**Blog** = SEO + authority building:
- Destination guides ("Italy Sailing Tours: Sail & Climb Guide")
- Activity guides ("Kalymnos Climbing Guide")
- Lifestyle/philosophy ("Why Climbers Love Sailing")
- Guest stories/social proof
- Seasonal content ("Fall Climbing Mediterranean")

**Secret Tour** = exclusivity play:
- "Invitation-only expedition" framing
- €900/person + meals — positioned as cost-sharing, not commercial pricing
- "No clients, no hosts — just an unforgettable journey"
- Creates FOMO + VIP community

### Booking Flow (Their Weakness)
VST has NO real booking engine. Their flow is:
1. Browse destination → 2. Submit inquiry form → 3. Talk with guide → 4. Receive proposal → 5. Confirm

**What they're missing:**
- No real-time availability calendar
- No pricing on website (hidden until inquiry)
- No online booking/payment
- No automated booking confirmation
- No guest portal for pre-trip docs
- No agent/partner distribution
- No capacity/berth management

This is where INSEANQ fits in (they use it) and where our GHL approach improves.

### Pricing Model
- Dynamic: Early Bird (60+ days out) → Standard → Last Availability (30 days / limited spots)
- €500 deposit secures spot, balance due 90 days before
- €300 onboard cash fee for pantry/fuel
- 8-11 guests per boat (45-55ft, 4-5 cabins)
- Group size: couples get priority for private cabins

### Team Structure
10 team members:
- Founder/Skipper (Lorenzo Pernigotti)
- Technical Director/Skipper (Alberto Broggi)
- 5 IFMGA-certified Mountain Guides
- 2 Additional Skippers
- 1 Social Media Manager
Each with individual profile pages, languages, certs, personal descriptions.

### FAQ Categories (for our chatbot)
1. Booking & payments (deposit, balance, cancellation policy)
2. Life onboard (cabins, bathrooms, food, seasickness, connectivity)
3. Climbing specifics (gear, grades, guides, DWS requirements)
4. Solo travelers & groups
5. Families & non-climbers
6. Private tours (minimum 6 guests, fully custom)

---

## Source: INSEANQ (inseanq.com) — Booking Platform

### What It Is
SaaS booking & distribution platform for small ship cruises and liveaboard cabin charter operators. Think "Booking.com backend for sailing operators."

### Key Features We Need to Replicate in GHL

| INSEANQ Feature | GHL Equivalent | Gap / Custom Build Needed |
|----------------|---------------|--------------------------|
| Schedule & availability | GHL Calendar + custom fields | Need trip-level (not slot-level) availability |
| Online booking engine | GHL Forms + Pipelines | Need multi-step form: trip → cabin → guests → payment |
| Dynamic pricing (early/standard/late) | GHL Products or custom fields | Manual price tiers per trip in pipeline |
| Agent/partner portal | GHL Sub-accounts or external page | Limited — may need custom partner dashboard |
| Guest forms & doc upload | GHL Forms + file upload fields | Works but no manifest auto-generation |
| Automated notifications | GHL Workflows | Strong fit — our core strength |
| Guest manifest | GHL Contacts + custom fields export | Need custom report/export workflow |
| Multi-channel distribution | GHL API + custom integrations | Basic — no marketplace distribution |
| Cabin/berth visualization | Not native in GHL | Custom HTML deck plan (website-builder) |
| Waiting list | GHL Tags + Pipeline stage | Simple implementation |
| Credit notes / invoicing | GHL Payments or external (Stripe) | Basic invoicing; credit notes need workaround |
| Commission management | GHL custom fields + reports | Manual tracking or Stripe Connect |
| Multi-currency | GHL supports multiple currencies | Per-market sub-account approach |

### INSEANQ Pricing Tiers (for reference)
- **Basic (Free)**: 1 vessel, 8 spaces max, 20 weeks/year, 1.5% booking fee
- **Pro**: Unlimited vessels, advanced promotions, deck plans, integrations
- **Pro+**: Multi-currency, customer database, agency controls, assigned manager

### GHL Architecture for Sailing Tours

```
GHL Agency Account
└── Sub-account: "TEMPLATE — Sailing Tours UK"
    ├── Calendar: Trip Calendar (custom fields: destination, capacity, price, status)
    ├── Pipeline: Booking Pipeline
    │   ├── Stage 1: Inquiry Received
    │   ├── Stage 2: Trip Selected
    │   ├── Stage 3: Deposit Paid (£500)
    │   ├── Stage 4: Balance Due (90 days before)
    │   ├── Stage 5: Pre-Trip (guest forms, docs)
    │   ├── Stage 6: Confirmed (manifest ready)
    │   ├── Stage 7: Completed (post-trip)
    │   └── Lost / Cancelled
    ├── Pipeline: Partner Referrals
    │   ├── Stage 1: Lead from Partner
    │   ├── Stage 2: Booked
    │   ├── Stage 3: Commission Due
    │   └── Stage 4: Commission Paid
    ├── Forms
    │   ├── Trip Inquiry (destination, dates, group size, activity level)
    │   ├── Guest Registration (passport, emergency contact, medical, dietary)
    │   ├── Private Tour Request (custom destination, dates, budget)
    │   └── Partner Application
    ├── Custom Fields (Contact)
    │   ├── trip_destination, trip_dates, cabin_type
    │   ├── sailing_experience, climbing_grade, dietary_needs
    │   ├── passport_number, emergency_contact
    │   ├── deposit_paid, balance_paid, total_price
    │   └── partner_source, commission_rate, commission_amount
    ├── Tags
    │   ├── trip:{destination}-{date}
    │   ├── status:{deposit|paid|confirmed|completed}
    │   ├── type:{climbing|trekking|private|secret}
    │   └── partner:{partner-name}
    └── Workflows (see deliverables.md)
```

---

## How Our Version Will Be Better

### 1. Real Booking Engine (vs VST's inquiry-only approach)
- Visible pricing with early bird / standard / last-minute tiers
- Real-time availability per trip (GHL calendar integration)
- Online deposit payment + automatic balance reminders
- Guest registration portal (pre-trip forms, document upload)
- Automated confirmation + pre-trip info sequence

### 2. Richer Destination Content
- Day-by-day itinerary for each trip
- Interactive maps with activity points
- Difficulty ratings + gear checklists
- Photo/video galleries per destination
- Weather/season guide
- "Captain's Tips" integrated into destination pages

### 3. Guest Journey Automation (GHL workflows)
- Pre-booking: inquiry → proposal → follow-up nurture
- Booking: deposit confirmation → balance reminder → payment confirmation
- Pre-trip: guest forms → packing list → meeting point → crew intro
- On-trip: (manual — skipper/guide handles)
- Post-trip: thank you → photo sharing → review request → early bird for next trip

### 4. Partner/Agent Channel
- Partner application form + approval workflow
- Partner dashboard (GHL sub-account or custom page)
- Automated commission tracking
- Partner-specific booking links with attribution

### 5. Community & Repeat Business
- Secret/exclusive trips for returning guests
- Loyalty program (repeat booker discounts)
- Photo gallery from past trips (community building)
- Blog with SEO-optimized destination + activity guides
- Newsletter with upcoming season calendar

### 6. Multi-Market from Day 1
- UK market (£ GBP, English)
- PL market (zł PLN, Polish)
- Expandable to EUR markets

---

## Proposed Site Architecture (Extended vs VST)

```
Homepage
├── Destinations (hub page with map)
│   ├── {destination-1}/ (full detail page per destination)
│   │   ├── Overview + hero gallery
│   │   ├── Day-by-day itinerary
│   │   ├── Activities + difficulty
│   │   ├── What's included / excluded
│   │   ├── Gear checklist
│   │   ├── Pricing (early bird / standard / last-minute)
│   │   ├── Available dates (linked to GHL calendar)
│   │   ├── Captain's tips
│   │   ├── Photo gallery
│   │   └── Reviews from this destination
│   ├── {destination-2}/
│   └── ... (expandable)
├── Adventures (by type)
│   ├── Sailing & Climbing
│   ├── Sailing & Trekking
│   ├── Private Tours
│   └── Secret Expeditions (VIP / invite-only)
├── About
│   ├── Our Story
│   ├── The Team (with individual profiles)
│   ├── Our Boats
│   └── Safety & Certifications
├── Blog / Journal
│   ├── Destination guides (SEO)
│   ├── Trip reports / stories
│   ├── Gear & preparation
│   └── Guest stories
├── Book Now
│   ├── Upcoming trips calendar
│   ├── Trip selector + booking form
│   └── Private tour inquiry
├── Guest Portal (post-booking)
│   ├── Your trip details
│   ├── Guest registration form
│   ├── Packing list
│   ├── Meeting point & logistics
│   └── Document upload
├── Partners
│   ├── Become a Partner
│   ├── Partner login (GHL sub-account)
│   └── Commission structure
├── FAQ
├── Contact
└── Legal
    ├── Privacy Policy
    ├── Terms & Conditions
    ├── Cookie Policy
    ├── Booking & Cancellation Policy
    └── Legal Entity / Impressum
```

**Total: ~25-30 page types** (vs VST's ~13)

---

## GHL-Specific Considerations

### What GHL Handles Natively
- Navigation / header / footer
- Booking forms (wired to pipelines)
- Calendar widget (trip availability)
- Chat widget (AI chatbot)
- Payment collection (Stripe integration)
- Email/SMS automation
- CRM / contact management
- Pipeline / deal tracking
- Popups and modals (exit intent, scroll)

### What We Build as Custom HTML Sections
- Hero sections (destination imagery, parallax)
- Destination detail pages (itineraries, maps, galleries)
- Team profile cards
- Trip comparison tables
- Pricing tier displays (early bird / standard / late)
- Testimonial carousels
- Interactive deck plans (boat cabin layout)
- Gear checklist components
- Blog article layouts
- FAQ accordions

### Unique Custom Components Needed
1. **Trip Calendar View** — visual month-by-month with trip blocks, capacity indicators, pricing tiers
2. **Deck Plan Widget** — interactive boat layout showing cabin types, availability, pricing
3. **Destination Map** — interactive map with clickable destination pins (leaflet.js or static SVG)
4. **Itinerary Timeline** — day-by-day vertical timeline with activities, photos, distances
5. **Weather/Season Guide** — month-by-month climate chart per destination
6. **Gear Checklist** — interactive checkbox list guests can use pre-trip
7. **Photo Gallery** — lightbox gallery with trip/destination filtering
8. **Difficulty Rating** — visual rating system for sailing/climbing/trekking difficulty

---

## Next Steps

1. ~~Analyze VST + INSEANQ~~ (done)
2. ~~Set up project structure~~ (done)
3. Complete INDUSTRY.md with full domain research
4. Define deliverables.md (package tiers for sailing tour operators)
5. Create color palette (sailing-tours.json)
6. Build custom components (trip calendar, deck plan, itinerary timeline)
7. Design GHL pipeline + workflows
8. Build website sections per tier
9. Create email/SMS sequences for guest journey
10. Design AI chatbot for trip inquiries + guest support
