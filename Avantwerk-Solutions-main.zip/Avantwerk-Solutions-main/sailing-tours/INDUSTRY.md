# Sailing Tours Industry Brief

## Overview
Adventure sailing tour operators offer multi-day sailing experiences combined with activities (climbing, trekking, diving, cultural exploration) across coastal and island destinations. The industry is fragmented — mostly small operators (1-5 boats) relying on word-of-mouth, Instagram, and manual booking via email/phone. AI automation addresses the high-touch booking process, guest communication complexity (pre-trip logistics, safety briefings, itinerary changes), and the challenge of filling capacity across seasonal schedules. Post-COVID demand for outdoor, small-group, experience-led travel is at an all-time high.

## Target Niches
- Adventure sailing (sailing + climbing / trekking / diving)
- Luxury yacht charters (crewed, all-inclusive)
- Bareboat charter operators (fleet management + guest onboarding)
- Sailing schools & RYA/ICC certification courses
- Corporate / team-building sailing events
- Family sailing holidays
- Liveaboard diving + sailing
- Regatta & racing tour operators

## Common Pain Points
| Pain Point | Impact | Avantwerk Solution |
|-----------|--------|-------------------|
| Manual inquiry-to-booking process | 24-72h response time, lost leads to faster competitors | AI chatbot for instant availability + booking form pipeline |
| No real-time availability | Guests can't see what's open; staff manually check spreadsheets | GHL calendar with trip capacity tracking |
| Complex guest logistics | Meeting points, packing lists, dietary needs, docs — all handled via email threads | Automated pre-trip sequence: forms → docs → reminders |
| No-shows / late cancellations | Empty berths = lost revenue (avg £500-2,000 per berth/trip) | Deposit collection + automated balance reminders + cancellation recovery |
| Seasonal feast/famine | May-Oct peak → zero income Nov-Apr | Early bird campaigns, off-season trip promotion, nurture sequences |
| No post-trip engagement | One-time guests, no repeat business | Post-trip: review request → photo sharing → early bird for next season |
| Agent/partner management | Manual commission tracking, no partner portal | GHL partner pipeline + automated commission workflow |
| No guest reviews system | Social proof scattered across TripAdvisor, Google, Instagram | Automated review request → aggregation on website |
| Weather-dependent changes | Itinerary changes cause confusion + complaints | Automated notifications for changes + alternative plans |
| Multi-language guests | International clientele, limited multilingual capacity | AI chatbot with multi-language support |

## Key Services (for website/chatbot)

### UK (GBP)
- Group sailing trip (7 days, shared cabin): £900-1,800/person
- Group sailing trip (7 days, private cabin): £1,400-2,800/person
- Private charter (per day, full boat): £500-2,000/day
- Weekend sailing experience (2-3 days): £350-750/person
- Sailing + climbing week: £1,200-2,200/person
- Sailing + trekking week: £1,000-1,800/person
- Sailing school (5-day RYA course): £600-1,200/person
- Corporate team-building (per day): £200-500/person
- Secret/exclusive expedition: £800-1,500/person

### Poland (PLN)
- Rejs grupowy (7 dni, kabina dzielona): 2,500-5,000 zł/osoba
- Rejs grupowy (7 dni, kabina prywatna): 4,000-8,000 zł/osoba
- Czarter prywatny (za dzień, cały jacht): 1,500-6,000 zł/dzień
- Weekend żeglarski (2-3 dni): 1,000-2,500 zł/osoba
- Żegle + wspinaczka tydzień: 3,500-6,500 zł/osoba
- Żegle + trekking tydzień: 3,000-5,500 zł/osoba
- Kurs żeglarski (5 dni, patent): 1,800-3,500 zł/osoba
- Team-building korporacyjny (za dzień): 600-1,500 zł/osoba
- Ekspedycja tajna/ekskluzywna: 2,500-4,500 zł/osoba

## Industry Terminology

### UK English
| Term | Usage |
|------|-------|
| Charter | Renting a boat (with or without crew) |
| Berth / Cabin | Sleeping spot / room on the boat |
| Skipper | Captain / boat driver (certified) |
| Crew | Skipper + guide + any support staff on board |
| Liveaboard | Living on the boat for the trip duration |
| Passage / Leg | Sailing section between destinations |
| Port / Marina | Where the boat docks |
| Embarkation / Disembarkation | Getting on / off the boat (start/end of trip) |
| Manifest | Official list of guests + crew for port authorities |
| RYA | Royal Yachting Association (UK sailing certification body) |
| ICC | International Certificate of Competence (sailing license) |
| NM / Nautical Mile | Distance unit at sea (~1.15 land miles) |
| Knots | Speed at sea (1 knot = 1 NM/hour) |
| VHF | Radio communication system on boats |
| DWS | Deep Water Soloing (climbing above water, no rope) |
| Crag | Rock climbing area/wall |
| Multi-pitch | Multi-section climbing route |

### Polish
| Term | Usage |
|------|-------|
| Czarter | Wynajem jachtu |
| Koja / Kabina | Miejsce do spania / pokój na jachcie |
| Skipper / Kapitan | Osoba prowadząca jacht |
| Załoga | Skipper + przewodnik + obsługa |
| Rejs | Podróż żeglarska |
| Odcinek / Etap | Sekcja żeglowania między portami |
| Port / Marina | Miejsce cumowania |
| Zaokrętowanie / Wyokrętowanie | Rozpoczęcie / zakończenie rejsu |
| Manifest | Lista pasażerów i załogi |
| PZŻ | Polski Związek Żeglarski |
| Patent żeglarski | Uprawnienia żeglarskie |
| Mm / Mila morska | Jednostka odległości na morzu |
| Węzły | Prędkość na morzu |
| VHF | System komunikacji radiowej |
| DWS | Deep Water Soloing (wspinaczka nad wodą) |
| Skała / Sektor | Miejsce wspinaczkowe |

## Compliance Notes

### UK
- Maritime and Coastguard Agency (MCA) requirements for commercial vessels
- RYA certification for skippers operating commercially
- Marine insurance mandatory (P&I + hull)
- ATOL/ABTA protection if selling as a package holiday (flight + accommodation + activity)
- Package Travel Regulations 2018 — if combining transport + accommodation
- GDPR for guest data (passport numbers, medical conditions = special category data)
- Health & Safety at Work Act extends to vessels
- Life jackets, safety briefing, emergency procedures mandatory
- DBS checks may apply for family/youth trips

### Poland
- PZŻ (Polski Związek Żeglarski) certification requirements
- Urząd Morski (Maritime Office) registration for commercial vessels
- Insurance requirements per Polish maritime law
- RODO (Polish GDPR) — guest data including passport, health conditions
- Ustawa o usługach turystycznych (Tourism Services Act)
- TFG/TFP (Turystyczny Fundusz Gwarancyjny/Pomocowy) — tourism guarantee fund
- Inspektorat Żeglugi Śródlądowej (for inland waterway operations)
- Safety equipment requirements per Polish maritime regulations

## Competitive Landscape

### Booking / Management Software
- **INSEANQ**: Purpose-built for liveaboards/small ships. Free tier available. Agent portal + distribution
- **Booking Manager (MMK)**: Dominant in charter industry. Complex, expensive, legacy feel
- **Sedna System**: Yacht charter management. Calendar + CRM + invoicing
- **NauSYS**: Charter booking system. Real-time availability across fleets
- **Sailogy / Click&Boat**: Marketplace platforms (not management tools)
- **General tools**: Checkfront, FareHarbor, Rezdy (activity booking, not sailing-specific)

### Gaps We Fill
- Most operators use email + spreadsheets — no automation at all
- INSEANQ is booking-focused but weak on marketing automation + guest communication sequences
- No existing tool combines booking + CRM + email automation + chatbot + website in one platform
- GHL provides the all-in-one that sailing operators don't know they need
- Partner/agent channel is underserved — most operators do direct only
- Post-trip engagement (reviews, repeat bookings, referrals) is almost non-existent in the industry

### Differentiation
- Full guest journey automation (inquiry → booking → pre-trip → post-trip → repeat)
- AI chatbot that handles availability, FAQ, and trip recommendations in multiple languages
- Built-in partner/agent management with automated commission tracking
- Website + CRM + automation in one platform (vs 4-5 tools stitched together)
- Industry-specific templates ready to deploy (not generic SaaS)
