# Sailing Tours — Deliverables by Package Tier

## Ignite AI — £1,999 / 8,999 zł
**Delivery: 14 days | Hypercare: 7 days**

### Website (3 pages)
- Homepage (hero with destination showcase, trip highlights, upcoming dates, testimonials, booking CTA)
- Destinations hub (grid of available destinations with season/pricing overview)
- Booking page (embedded GHL calendar + inquiry form)

### Workflows (2)
- **Booking inquiry follow-up**: inquiry received → instant confirmation → 2h personal email from skipper → 48h follow-up if no response → 7-day final offer
- **Review request**: trip completed → 24h thank you email with photo link → 5-day review request (Google/TripAdvisor)

### Emails/SMS (3)
- Inquiry confirmation with trip details (email)
- Skipper personal follow-up (email)
- Post-trip review request (email)

### AI Chatbot
- FAQ bot: destinations, dates, pricing overview, what's included, gear requirements
- Booking redirect: "interested in [destination]?" → guides to booking form
- Basic availability: "when is the next trip to [destination]?"

---

## Elevate AI — £2,499 / 11,499 zł
**Delivery: 21 days | Hypercare: 14 days**

### Website (5 pages)
- Everything in Ignite AI, plus:
- About page (story, team profiles, boats, certifications, safety approach)
- Contact page (form, phone, WhatsApp, social links, office location)

### Workflows (4)
- Everything in Ignite AI, plus:
- **Deposit & payment sequence**: deposit confirmed → receipt → balance due reminder (90 days before) → 60-day reminder → 30-day final → payment confirmed
- **Pre-trip logistics**: 14 days before → packing list + meeting point email → 7 days → guest form reminder → 3 days → final logistics + crew intro → 1 day → "see you tomorrow" SMS

### Emails/SMS (8)
- Everything in Ignite AI, plus:
- Deposit confirmation (email)
- Balance reminder sequence (2 emails + 1 SMS)
- Pre-trip logistics (email with packing list)
- Meeting point / final details (email + SMS)

### AI Chatbot
- Everything in Ignite AI, plus:
- Trip details: "what's included in Sardinia trip?", "what climbing grade?"
- Guest prep: packing list, what to bring, dietary requirements process
- Payment info: deposit amount, payment schedule, cancellation policy

---

## Momentum AI ★ — £2,999 / 13,999 zł (Most Popular)
**Delivery: 30 days | Hypercare: 21 days**

### Website (7+ pages)
- Everything in Elevate AI, plus:
- Individual destination pages (2-3 destinations, each with itinerary, gallery, pricing, reviews)
- Guest stories / testimonials page (with trip photos)
- Blog/journal (3 seed articles: destination guide, gear prep guide, trip report)

### Workflows (7)
- Everything in Elevate AI, plus:
- **New lead nurture**: website visit → lead capture → 1h email with upcoming trips → 3-day destination guide → 7-day early bird offer → 14-day "spots filling up"
- **Cancellation recovery**: cancelled → 2h "sorry to see you go" + rebooking incentive → 24h alternative dates email
- **Post-trip engagement**: trip completed → review request → 14-day photo gallery share → 30-day early bird for next season → 90-day newsletter opt-in

### Emails/SMS (14)
- Everything in Elevate AI, plus:
- Lead nurture sequence (3 emails)
- Cancellation recovery (1 email + 1 SMS)
- Post-trip engagement (3 emails)

### AI Chatbot
- Everything in Elevate AI, plus:
- Full trip comparison: "which trip is best for beginners?", "Sardinia vs Kalymnos?"
- Group booking: handles multiple guests, cabin preferences
- Itinerary preview: day-by-day overview for each destination
- Weather/season advisor: "when is best to visit [destination]?"

---

## Apex AI — £3,999 / 17,999 zł
**Delivery: 45-60 days | Hypercare: 30 days**

### Website (10+ pages)
- Everything in Momentum AI, plus:
- All destination pages (full catalog, each with detailed itinerary + interactive map)
- Individual crew/guide profile pages
- Boats page (deck plans, specs, photos per vessel)
- FAQ page (structured for SEO with 30+ questions)
- Partners page (become a partner + partner login)
- Photo gallery hub (filterable by destination/year)
- Trip type category pages (sailing+climbing, sailing+trekking, private, corporate)

### Workflows (10+)
- Everything in Momentum AI, plus:
- **Partner management**: application → review → approval → welcome kit → first referral tracking
- **Agent booking**: partner submits booking → confirmation → commission tracking → quarterly payout
- **Early bird campaign**: season planning → 120 days before → email to past guests → social proof → limited spots → countdown
- **Birthday / anniversary**: guest birthday → greeting + discount code → partner anniversary → commission bonus

### Emails/SMS (20+)
- Everything in Momentum AI, plus:
- Partner welcome kit (email)
- Partner commission notifications (email)
- Early bird campaign (3 emails)
- Birthday greeting (email)
- Seasonal campaign templates (4 emails: spring launch, summer peak, autumn deals, winter planning)

### AI Chatbot
- Everything in Momentum AI, plus:
- Multi-language support (EN, PL, DE, IT, ES based on guest location)
- Partner inquiries: commission rates, how to refer, tracking bookings
- Advanced trip planning: custom itinerary suggestions based on interests + skill level
- Crew matchmaking: suggest specific guides/skippers based on guest preferences
- Handoff to specific team member based on inquiry type

### Additional
- Custom GHL reporting dashboard (occupancy rates, revenue per trip, conversion funnel)
- Interactive deck plan component (visual cabin selector)
- Trip calendar widget (monthly view with availability + pricing)
- Partner portal setup in GHL
- Staff training session (1h video call)

---

## Standard Legal Pages (ALL tiers)

The following 4 legal/footer pages are included with EVERY package tier at no additional page count. Required for GDPR/RODO compliance and proper business disclosure.

### Pages
1. **Privacy Policy** / **Polityka Prywatności** (`/privacy-policy/` or `/polityka-prywatnosci/`)
   - Covers guest data: passport numbers, medical conditions (special category data), payment details
   - Maritime-specific: manifest data shared with port authorities (legal obligation)
   - Photo/video consent for marketing use
2. **Terms & Conditions** / **Warunki Użytkowania** (`/terms/` or `/warunki-uzytkowania/`)
   - Booking terms, cancellation policy, refund schedule
   - Liability limitations for weather-dependent changes
   - Safety responsibilities (guest + operator)
   - Package Travel Regulations compliance (UK) / Ustawa o usługach turystycznych (PL)
3. **Cookie Policy** / **Polityka Cookies** (`/cookies/` or `/polityka-cookies/`)
   - Standard cookie inventory: essential, analytics, functional, marketing
   - Consent mechanism
4. **Legal Entity** / **Podmiot Odpowiedzialny** (`/legal/` or `/podmiot-odpowiedzialny/`)
   - Business registration, maritime licenses, insurance details
   - Avantwerk credit (copyright section) + GHL hosting disclosure
   - Tourism guarantee fund registration (PL: TFG/TFP)

### Notes
- These pages are NOT counted toward the package page quota
- All pages cross-link to each other
- Set to `noindex, follow` in meta robots (except legal entity which can be indexed)
- Maritime-specific clauses required: manifest data sharing, safety liability, weather-dependent changes
- Placeholder fields: [BUSINESS_NAME], [LICENSE_NUMBER], [INSURANCE_PROVIDER], [POLICY_NUMBER], [REGISTRATION_NUMBER]
