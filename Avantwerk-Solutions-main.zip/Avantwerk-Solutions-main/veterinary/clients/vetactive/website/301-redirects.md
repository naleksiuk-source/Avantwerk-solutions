# VetActive — 301 Redirect Mapping

## Migration: WordPress → GHL

### Strategy
- **Primary goal:** Zero URL changes for indexed pages
- **Secondary goal:** 301 redirect any URLs that cannot be preserved exactly
- **Implementation:** GHL URL redirects or Cloudflare page rules (if domain uses CF)

---

## Pages — PRESERVE EXACTLY (no redirect needed)

These URLs must exist in GHL with the exact same slug:

| Old URL | New GHL Page | Status |
|---------|-------------|--------|
| `/` | Homepage | ✅ Same |
| `/uslugi/` | Services page | ✅ Same |
| `/rehabilitacja/` | Rehabilitation page | ✅ Same |
| `/bank-krwi/` | Blood Bank page | ✅ Same |
| `/personel/` | Team page | ✅ Same |
| `/kontakt/` | Contact page | ✅ Same |
| `/informacje-dla-wlascicieli/` | Owner Info / FAQ page | ✅ Same |
| `/polityka-prywatnosci/` | Privacy Policy | ✅ Same |
| `/blog/` | Blog listing | ✅ Same |

## Rehab Service Pages — PRESERVE EXACTLY

| Old URL | New GHL Page | Status |
|---------|-------------|--------|
| `/services/laser-wysokoenergetyczny/` | Rehab service detail | ✅ Same |
| `/services/laser-niskoenergetyczny/` | Rehab service detail | ✅ Same |
| `/services/bieznia-sucha/` | Rehab service detail | ✅ Same |
| `/services/bieznia-wodna/` | Rehab service detail | ✅ Same |
| `/services/pole-magnetyczne/` | Rehab service detail | ✅ Same |
| `/services/ultradzwieki/` | Rehab service detail | ✅ Same |
| `/services/elektrostymulacja/` | Rehab service detail | ✅ Same |
| `/services/neurorehabiltacja-funkcjonalna/` | Rehab service detail | ✅ Same |
| `/services/masaze/` | Rehab service detail | ✅ Same |
| `/services/terapia-blizny/` | Rehab service detail | ✅ Same |

> **Note:** The original URL has a typo: `neurorehabiltacja` (missing 'i'). We MUST keep this exact typo in the URL slug to preserve SEO. The page content/title can use the correct spelling.

## Blog Posts — PRESERVE EXACTLY

| Old URL | New GHL Blog Post | Status |
|---------|------------------|--------|
| `/co-powinienes-wiedziec-przed-wizyta-w-przychodni-weterynaryjnej/` | Blog post | ✅ Same |
| `/przygotowanie-zwierzaka-do-wizyty-u-weterynarza/` | Blog post | ✅ Same |

## Team Member Pages — 301 REDIRECT

These individual team pages will NOT be recreated. Redirect to the team section:

| Old URL | Redirect To | Type |
|---------|------------|------|
| `/team/` | `/personel/` | 301 |
| `/team/ewa-andrzejczak/` | `/personel/#ewa-andrzejczak` | 301 |
| `/team/beata-markowska/` | `/personel/#beata-markowska` | 301 |
| `/team/ewelina-romanska/` | `/personel/#ewelina-romanska` | 301 |
| `/team/edyta-mlynarczyk/` | `/personel/#edyta-mlynarczyk` | 301 |
| `/team/agata-lamus/` | `/personel/#agata-lamus` | 301 |
| `/team/katarzyna-kubiak/` | `/personel/#katarzyna-kubiak` | 301 |
| `/team/kinga-michalak/` | `/personel/#kinga-michalak` | 301 |

## WordPress Artifacts — BLOCK or REDIRECT

| Old URL Pattern | Action |
|-----------------|--------|
| `/services/` (index page) | 301 → `/rehabilitacja/` |
| `/wp-admin/` | Block (won't exist) |
| `/wp-content/*` | Block (won't exist) |
| `/wp-json/*` | Block (won't exist) |
| `/author/*` | Block or 301 → `/personel/` |
| `/category/*` | 301 → `/blog/` |
| `/tag/*` | 301 → `/blog/` |
| `/feed/` | Block (GHL doesn't have RSS) |

## New Pages (no redirect needed — net new)

| New URL | Page |
|---------|------|
| `/rezerwacja/` | Booking page (replaces `/latepoint-booking/`) |
| `/polityka-cookies/` | Cookie Policy (new) |
| `/warunki-uzytkowania/` | Terms of Use (new) |

> **Note:** `/latepoint-booking/` → 301 redirect to `/rezerwacja/`

---

## Implementation Checklist

- [ ] Set up all GHL pages with exact URL slugs
- [ ] Configure 301 redirects in GHL for team member pages
- [ ] Configure 301 redirects for WordPress artifact URLs
- [ ] Update Google Search Console with new sitemap
- [ ] Submit sitemap.xml to Google
- [ ] Monitor Search Console for crawl errors for 30 days post-migration
- [ ] Check Google cache for all key pages within 2 weeks
- [ ] Verify no 404s on previously indexed URLs
