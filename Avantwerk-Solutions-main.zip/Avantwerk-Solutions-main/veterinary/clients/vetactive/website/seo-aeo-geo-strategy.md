# VetActive — SEO / AEO / GEO Improvement Strategy

**Practice:** Vet-Active, ul. Batalionow Chlopskich 12, Lodz (Retkinia), Poland
**Domain:** vetactive.pl
**Prepared:** February 2026
**Migration:** WordPress + Elementor + Yoast SEO --> GoHighLevel (GHL)

---

## Table of Contents

1. [SEO — Search Engine Optimization](#1-seo--search-engine-optimization)
   - 1.1 Technical SEO
   - 1.2 On-Page SEO
   - 1.3 Local SEO
   - 1.4 Content SEO
   - 1.5 Schema Markup Strategy
   - 1.6 WordPress-to-GHL Migration Checklist
2. [AEO — Answer Engine Optimization](#2-aeo--answer-engine-optimization)
   - 2.1 FAQ Strategy
   - 2.2 Speakable Markup
   - 2.3 Conversational Content
   - 2.4 Featured Snippet Optimization
   - 2.5 Entity-First Content
   - 2.6 Direct Answer Blocks
   - 2.7 "People Also Ask" Targeting
3. [GEO — Generative Engine Optimization](#3-geo--generative-engine-optimization)
   - 3.1 E-E-A-T Signals
   - 3.2 Citation-Worthy Content
   - 3.3 Source Authority
   - 3.4 Content Depth
   - 3.5 Structured Claims
   - 3.6 Multimodal Content
   - 3.7 Brand Mentions
   - 3.8 Content Freshness
4. [Competitor Analysis](#4-competitor-analysis)
5. [KPI Tracking](#5-kpi-tracking)
6. [Implementation Priority](#6-implementation-priority)
7. [Quick Wins](#7-quick-wins)

---

# 1. SEO — Search Engine Optimization

## 1.1 Technical SEO

### Site Speed on GHL

GHL pages are hosted on their CDN infrastructure, which generally delivers acceptable load times. However, VetActive must address GHL-specific speed pitfalls:

**Actions:**
- **Image optimization (P0):** Compress all images to WebP format before uploading to GHL. Target max 100 KB for hero images, 50 KB for thumbnails. GHL does not auto-compress images.
- **Lazy loading (P0):** GHL supports native lazy loading on images. Enable `loading="lazy"` on all below-the-fold images via custom code blocks.
- **Minimize custom code (P1):** GHL pages can accumulate bloat from custom HTML/CSS/JS blocks. Consolidate all custom CSS into a single `<style>` block in the page head, not repeated per section.
- **Font loading (P1):** Load DM Sans (or the practice's chosen font) via `<link rel="preconnect">` followed by the Google Fonts stylesheet. Use `font-display: swap` to avoid FOIT (Flash of Invisible Text).
- **Third-party script audit (P1):** Defer or async-load any non-critical scripts (Facebook Pixel, Google Analytics). Place tracking scripts in the footer, not the head.
- **GHL tracking code (P2):** GHL injects its own tracking scripts. These cannot be removed but have minimal impact. Do not duplicate with additional GHL-related scripts.

**Target Core Web Vitals:**

| Metric | Target | Common GHL Issue |
|--------|--------|-----------------|
| LCP (Largest Contentful Paint) | < 2.5s | Large uncompressed hero images |
| FID / INP (Interaction to Next Paint) | < 200ms | Heavy custom JS widgets |
| CLS (Cumulative Layout Shift) | < 0.1 | Images without explicit dimensions |

### Mobile-First Design

- GHL pages are responsive by default, but custom code blocks may break on mobile.
- **Test every page** on mobile viewport (375px width minimum) after build.
- Ensure tap targets (buttons, phone links) are at least 48x48px.
- Use `tel:` links for all phone numbers so mobile users can tap to call.
- The booking CTA must be sticky or always visible on mobile (GHL supports sticky sections).

### Crawlability

- **XML Sitemap (P0):** GHL auto-generates a sitemap at `/sitemap.xml`. After migration, verify it includes all 28+ pages. If GHL's auto-sitemap is incomplete, create a manual sitemap and host it via custom code or Cloudflare Workers.
- **robots.txt (P0):** Deploy the prepared `robots.txt` (already drafted — see `robots.txt` in the website folder). Key rules:
  - Allow all public pages
  - Block `/backend/`, `/widget/`, `/surveys/`, `/forms/`, `/search/`, `/thank-you/`, `/confirmation/`
  - Reference sitemap: `Sitemap: https://vetactive.pl/sitemap.xml`
- **Canonical URLs (P0):** Add `<link rel="canonical" href="...">` to every page to prevent duplicate content issues. GHL sometimes generates pages at both `/page` and `/page/` (with and without trailing slash). Canonicalize to the trailing-slash version to match the current WordPress structure.
- **Crawl budget:** With only ~30 pages, crawl budget is not a concern. Focus on ensuring zero 404s and zero redirect chains.
- **hreflang:** Not needed. The site is Polish-language only, serving a Polish audience.

### HTTPS

- vetactive.pl must use HTTPS with a valid SSL certificate. GHL provides SSL automatically for custom domains.
- Ensure all internal links use `https://` protocol.
- Check for mixed content (HTTP images/scripts on HTTPS pages) after migration.

---

## 1.2 On-Page SEO

### Title Tag Formulas

Each page type follows a consistent formula that includes the primary keyword, brand name, and location:

| Page Type | Formula | Example |
|-----------|---------|---------|
| Homepage | `{Brand} {City} -- {Primary Service} \| {Secondary Service}` | `Vet-Active Lodz -- Przychodnia Weterynaryjna Retkinia \| Rehabilitacja Zwierzat` |
| Service category | `{Service} -- {Brand} {City} \| {Differentiator}` | `Uslugi Weterynaryjne -- Vet-Active Lodz \| Diagnostyka, Chirurgia, Szczepienia` |
| Rehab overview | `Rehabilitacja Zwierzat {City} -- {Brand} \| {Count} Metod Terapeutycznych` | `Rehabilitacja Zwierzat Lodz -- Vet-Active \| 10 Metod Terapeutycznych` |
| Rehab service | `{Therapy Name} -- Rehabilitacja Zwierzat \| {Brand} {City}` | `Laser Wysokoenergetyczny -- Rehabilitacja Zwierzat \| Vet-Active Lodz` |
| Blood Bank | `Bank Krwi dla Zwierzat -- {Brand} {City} \| {Emotional Hook}` | `Bank Krwi dla Zwierzat -- Vet-Active Lodz \| Oddaj Krew, Ratuj Zycie` |
| Team | `Nasz Zespol -- {Brand} {City} \| Lekarze Weterynarii i Specjalisci` | As shown |
| Contact | `Kontakt -- {Brand} {City} \| {Street}, {District}` | `Kontakt -- Vet-Active Lodz \| ul. Batalionow Chlopskich 12, Retkinia` |
| Blog post | `{Post Title} \| Blog {Brand}` | `Co Powinienes Wiedziec Przed Wizyta u Weterynarza \| Blog Vet-Active` |
| Booking | `Umow Wizyte Online -- {Brand} {City} \| Rezerwacja Terminu` | As shown |

**Rules:**
- Title length: 50-60 characters (Google truncates at ~60).
- Always include "Lodz" for local intent.
- Always include "Vet-Active" for brand recognition.
- Primary keyword goes first (leftmost) for higher keyword weight.
- Use `--` (em dash) and `|` (pipe) as separators.

### Meta Descriptions

Meta descriptions are already drafted in `seo-meta-tags.html`. Refinement guidelines:

- Length: 150-160 characters.
- Include a call to action: "Umow wizyte: +48 607 250 290" or "Zarezerwuj online."
- Include the primary keyword naturally.
- Include the location (Lodz) at least once.
- For rehab service pages, mention the specific benefit (e.g., "Skuteczne leczenie bolu i stanow zapalnych").
- For Blood Bank, use emotional appeal: "Twoj pupil moze uratowac zycie."

### Heading Hierarchy (H1-H6 Strategy)

Every page must follow a strict single-H1 hierarchy:

```
H1: One per page — contains primary keyword + location
  H2: Major content sections (3-5 per page)
    H3: Sub-sections within H2 blocks
      H4: Detail items (FAQ questions, team member names, etc.)
```

**Page-specific H1 examples:**

| Page | H1 |
|------|-----|
| Homepage | `Przychodnia Weterynaryjna Vet-Active Lodz` |
| /uslugi/ | `Uslugi Weterynaryjne w Vet-Active Lodz` |
| /rehabilitacja/ | `Rehabilitacja Zwierzat w Lodzi -- 10 Metod Terapeutycznych` |
| /bank-krwi/ | `Bank Krwi dla Zwierzat -- Vet-Active Lodz` |
| /services/bieznia-wodna/ | `Bieznia Wodna -- Rehabilitacja Zwierzat w Lodzi` |
| /personel/ | `Nasz Zespol Weterynaryjny -- Vet-Active Lodz` |
| /kontakt/ | `Kontakt -- Przychodnia Weterynaryjna Vet-Active Lodz` |
| /blog/ | `Blog Weterynaryjny -- Porady i Aktualnosci Vet-Active` |
| /rezerwacja/ | `Umow Wizyte w Vet-Active Lodz` |

**Rules:**
- Never skip heading levels (do not jump from H2 to H4).
- H2s should be keyword-rich section headers (e.g., "Kiedy stosujemy bieznie wodna?", "Jak przebiega zabieg?").
- H3s for supporting detail (e.g., "Wskazania", "Przeciwwskazania", "Efekty terapii").
- GHL uses visual heading sizes independently of semantic heading tags. Ensure the HTML tag matches the visual hierarchy, not the other way around.

### Image Alt Text Strategy

Every image must have descriptive, keyword-relevant alt text:

| Image Type | Alt Text Pattern | Example |
|-----------|-----------------|---------|
| Team photo | `{Name} -- {Role} w Vet-Active Lodz` | `Ewelina Romanska -- Lekarz weterynarii w Vet-Active Lodz` |
| Equipment | `{Equipment Name} do rehabilitacji zwierzat -- Vet-Active` | `Bieznia wodna do rehabilitacji zwierzat -- Vet-Active` |
| Treatment in action | `{Treatment} u {animal} w przychodni Vet-Active Lodz` | `Laseroterapia u psa w przychodni Vet-Active Lodz` |
| Practice exterior | `Przychodnia weterynaryjna Vet-Active Lodz -- budynek` | As shown |
| Practice interior | `Gabinet {type} w przychodni Vet-Active Lodz` | `Gabinet rehabilitacyjny w przychodni Vet-Active Lodz` |
| Blog illustrations | Descriptive of the image content with keyword context | `Pies u weterynarza -- przygotowanie do wizyty` |

**Rules:**
- No keyword stuffing. Alt text must describe the image accurately.
- 5-15 words per alt text.
- Include brand name ("Vet-Active") and location ("Lodz") in ~50% of alt texts, not all.
- Decorative images (borders, patterns) get `alt=""` (empty alt).

### Internal Linking Plan

A deliberate internal linking structure reinforces topical authority:

```
Homepage
  |-- /uslugi/ (general vet services)
  |-- /rehabilitacja/ (rehab hub page -- CRITICAL for topical authority)
  |     |-- /services/laser-wysokoenergetyczny/
  |     |-- /services/laser-niskoenergetyczny/
  |     |-- /services/bieznia-sucha/
  |     |-- /services/bieznia-wodna/
  |     |-- /services/pole-magnetyczne/
  |     |-- /services/ultradzwieki/
  |     |-- /services/elektrostymulacja/
  |     |-- /services/neurorehabiltacja-funkcjonalna/
  |     |-- /services/masaze/
  |     |-- /services/terapia-blizny/
  |-- /bank-krwi/
  |-- /personel/
  |-- /kontakt/
  |-- /rezerwacja/
  |-- /blog/
  |     |-- (individual posts)
  |-- /informacje-dla-wlascicieli/
```

**Linking rules:**

1. **Every rehab service page** must link back to `/rehabilitacja/` (parent hub) and to 2-3 related rehab services (e.g., laser-wysokoenergetyczny links to laser-niskoenergetyczny and pole-magnetyczne).
2. **The /rehabilitacja/ hub page** must link to all 10 individual therapy pages.
3. **Homepage** links to all main sections (/uslugi/, /rehabilitacja/, /bank-krwi/, /kontakt/, /rezerwacja/).
4. **Every page** should include a booking CTA that links to `/rezerwacja/`.
5. **Blog posts** must link to relevant service pages (e.g., a post about post-surgical recovery links to rehab therapies).
6. **Team page** links to services each vet specializes in.
7. **Footer** on all pages includes links to: Homepage, Services, Rehabilitation, Blood Bank, Contact, Booking, Privacy Policy.
8. Use descriptive anchor text, not "kliknij tutaj" or "wiecej." Example: "Dowiedz sie wiecej o [biezni wodnej w rehabilitacji zwierzat](/services/bieznia-wodna/)".

### URL Slug Optimization

Current URL structure is well-optimized. Preserve all existing slugs exactly (including the `neurorehabiltacja` typo — changing it would break indexed URLs and inbound links).

**New pages** should follow Polish-language slug conventions:
- Lowercase, hyphen-separated
- Remove Polish diacritics in slugs (already the pattern: "bieznia" not "bieznia")
- Keep slugs concise (3-5 words max)
- Include primary keyword

---

## 1.3 Local SEO

### Google Business Profile (GBP) Optimization

GBP is the single most impactful local SEO asset. Full optimization checklist:

**P0 — Critical (do immediately):**

- [ ] **Verify ownership** of the GBP listing for "Vet-Active" at ul. Batalionow Chlopskich 12, Lodz.
- [ ] **Primary category:** "Weterynarz" (Veterinarian) or "Przychodnia weterynaryjna" (Veterinary Clinic).
- [ ] **Secondary categories:** "Rehabilitacja zwierzat" (Animal Rehabilitation), "Bank krwi" (if available as a category).
- [ ] **Business name:** Exactly "Vet-Active" (do not keyword-stuff the name).
- [ ] **Address:** ul. Batalionow Chlopskich 12, Lodz, Poland — must match website and all citations exactly.
- [ ] **Phone:** +48 607 250 290 (primary), +48 607 270 190 (Blood Bank emergency — add as secondary).
- [ ] **Website:** https://vetactive.pl/
- [ ] **Hours:** Mon-Fri 9:00-20:00, Sat 9:00-15:00, Sun Closed.
- [ ] **Business description:** 750 characters max. Include keywords: "przychodnia weterynaryjna Lodz", "rehabilitacja zwierzat", "bank krwi", "Retkinia". Describe all main services.

**P1 — Important (within 30 days):**

- [ ] **Photos:** Upload 20+ high-quality photos:
  - Practice exterior (3-5 angles, including signage)
  - Interior (reception, treatment rooms, rehab equipment)
  - Team at work (vets with animals)
  - Equipment close-ups (each of the 10 rehab therapies)
  - Update quarterly with fresh photos
- [ ] **Services list:** Add every service with description in GBP:
  - Konsultacja weterynaryjna
  - Szczepienia
  - Czipowanie
  - Chirurgia
  - Diagnostyka (USG, RTG)
  - Stomatologia
  - Endoskopia
  - Rehabilitacja zwierzat (10 methods — list each)
  - Bank Krwi
- [ ] **Products/Services with pricing** (if prices are available): Add price ranges for common services. Google shows these in the GBP panel.
- [ ] **Booking link:** Set the appointment URL to `https://vetactive.pl/rezerwacja/`
- [ ] **Attributes:** Pet-friendly, wheelchair accessible (if applicable), accepts walk-ins (if applicable).

**P2 — Ongoing:**

- [ ] **Google Posts:** Publish 1-2 posts per week (promotions, tips, team highlights, new equipment).
- [ ] **Q&A section:** Pre-populate with 10-15 common questions and answers (hours, emergency contact, parking, species treated, pricing guidance).
- [ ] **Photo updates:** Add 3-5 new photos monthly.

### NAP Consistency

NAP (Name, Address, Phone) must be identical across every online mention:

```
Name:    Vet-Active
Address: ul. Batalionow Chlopskich 12, Lodz
Phone:   +48 607 250 290
Website: https://vetactive.pl/
```

**Check and correct NAP on:**
- Google Business Profile
- Facebook page (https://facebook.com/przychodniavetactive/)
- Instagram (https://instagram.com/vetactive_lodz/)
- ZnanyLekarz (znany lekarz-weterynarii equivalent, if listed)
- Panorama Firm (panoramafirm.pl)
- Aleo.com
- PKT.pl
- Firmy.net
- Veterinary directories (weterynarze.pl, psy.pl, zwierzaki.pl)
- Any WordPress-era directory submissions

### Local Schema Markup (VeterinaryCare)

The existing schema draft in `seo-meta-tags.html` uses `VeterinaryCare` type — this is correct and should be deployed. Enhancements:

```json
{
  "@context": "https://schema.org",
  "@type": "VeterinaryCare",
  "name": "Vet-Active",
  "alternateName": "Przychodnia Weterynaryjna Vet-Active",
  "description": "Nowoczesna przychodnia weterynaryjna w Lodzi...",
  "url": "https://vetactive.pl/",
  "telephone": "+48607250290",
  "email": "vetactivelodz@gmail.com",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "ul. Batalionow Chlopskich 12",
    "addressLocality": "Lodz",
    "addressRegion": "lodzkie",
    "postalCode": "94-058",
    "addressCountry": "PL"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 51.7592,
    "longitude": 19.4105
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday","Tuesday","Wednesday","Thursday","Friday"],
      "opens": "09:00",
      "closes": "20:00"
    },
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": "Saturday",
      "opens": "09:00",
      "closes": "15:00"
    }
  ],
  "sameAs": [
    "https://facebook.com/przychodniavetactive/",
    "https://instagram.com/vetactive_lodz/"
  ],
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Uslugi Weterynaryjne",
    "itemListElement": [
      {
        "@type": "OfferCatalog",
        "name": "Rehabilitacja Zwierzat",
        "itemListElement": [
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Laser wysokoenergetyczny"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Laser niskoenergetyczny"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Bieznia wodna"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Bieznia sucha"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Pole magnetyczne"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Ultradzwieki"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Elektrostymulacja"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Neurorehabilitacja funkcjonalna"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Masaze"}},
          {"@type": "Offer", "itemOffered": {"@type": "Service", "name": "Terapia blizny"}}
        ]
      },
      {
        "@type": "Offer",
        "itemOffered": {"@type": "Service", "name": "Bank Krwi dla Zwierzat"}
      }
    ]
  },
  "image": "[PRACTICE_PHOTO_URL]",
  "priceRange": "$$",
  "paymentAccepted": "Cash, Credit Card, Bank Transfer",
  "areaServed": {
    "@type": "City",
    "name": "Lodz"
  },
  "memberOf": {
    "@type": "Organization",
    "name": "Izba Lekarsko-Weterynaryjna"
  }
}
```

> **NOTE:** Confirm the postal code (94-058 is approximate for Retkinia/Batalionow Chlopskich area). Verify against the actual postal code.

### Local Keyword Targeting

**Primary keywords (highest intent, highest priority):**

| Keyword | Est. Monthly Volume | Difficulty | Target Page |
|---------|-------------------|-----------|-------------|
| weterynarz lodz | High | Medium | Homepage |
| przychodnia weterynaryjna lodz | High | Medium | Homepage |
| weterynarz lodz retkinia | Low-Med | Low | Homepage, Contact |
| rehabilitacja zwierzat lodz | Medium | Low | /rehabilitacja/ |
| bank krwi dla zwierzat | Low | Very Low | /bank-krwi/ |
| bank krwi dla zwierzat lodz | Very Low | Very Low | /bank-krwi/ |
| weterynarz lodz czynny w sobote | Low | Low | Contact |

**Secondary keywords (service-specific):**

| Keyword | Target Page |
|---------|-------------|
| bieznia wodna dla psa lodz | /services/bieznia-wodna/ |
| laseroterapia zwierzat lodz | /services/laser-wysokoenergetyczny/ |
| fizjoterapia zwierzat lodz | /rehabilitacja/ |
| zoofizjoterapia lodz | /rehabilitacja/ |
| neurorehabilitacja zwierzat | /services/neurorehabiltacja-funkcjonalna/ |
| elektrostymulacja psa | /services/elektrostymulacja/ |
| masaz dla psa lodz | /services/masaze/ |
| usg psa lodz | /uslugi/ |
| stomatologia weterynaryjna lodz | /uslugi/ |
| czipowanie psa lodz | /uslugi/ |
| szczepienie psa lodz | /uslugi/ |
| chirurgia weterynaryjna lodz | /uslugi/ |

**Long-tail keywords (lower volume, higher conversion):**

| Keyword | Target Page |
|---------|-------------|
| ile kosztuje wizyta u weterynarza lodz | /uslugi/ or /informacje-dla-wlascicieli/ |
| rehabilitacja psa po operacji kolana lodz | /rehabilitacja/ |
| bieznia wodna dla psa po operacji | /services/bieznia-wodna/ |
| jak przygotowac psa do wizyty u weterynarza | Blog post (existing) |
| oddanie krwi przez psa | /bank-krwi/ |
| czy moj pies moze byc dawca krwi | /bank-krwi/ |
| weterynarz lodz opinie | Homepage (review signals) |
| dobry weterynarz lodz polecany | Homepage (review signals) |
| weterynarz lodz bez kolejki | /rezerwacja/ |

### Google Maps Integration

- Embed a Google Maps iframe on the `/kontakt/` page showing the exact practice location.
- Use the GBP CID (Customer ID) link format for the map embed if possible, so clicks go to the GBP listing.
- Add driving directions from major Lodz landmarks (Manufaktura, Lodz Fabryczna station) in the contact page text.
- Include a "Jak do nas dojechac" section with:
  - Public transport: nearest tram/bus stops
  - Car: parking information
  - Walking directions from the Retkinia neighbourhood center

### Local Citations

Create and maintain consistent listings on these platforms (ranked by priority):

**P0 — Essential:**
1. Google Business Profile (already discussed)
2. Facebook Business Page
3. Panorama Firm (panoramafirm.pl) — very high domain authority in Poland
4. ZnanyLekarz / equivalent vet directory
5. PKT.pl (Polskie Ksiazki Telefoniczne)

**P1 — Important:**
6. Firmy.net
7. Aleo.com
8. Targeo.pl
9. Yelp (limited in Poland but still crawled)
10. Cylex.pl
11. Weterynarze.pl (if a listing exists)
12. Psy.pl directory
13. Zumi.pl

**P2 — Nice to have:**
14. Oferteo.pl
15. Onet Biznes
16. Baza Firm WP
17. GoWork.pl (for employer brand, indirectly helps visibility)

### Review Strategy

Reviews are a top-3 local ranking factor. Strategy:

**Review generation:**
- Implement an automated post-visit email/SMS (GHL workflow) requesting a Google review 24-48 hours after the appointment.
- Include a direct review link: `https://search.google.com/local/writereview?placeid=[PLACE_ID]`
- Time the request after positive outcomes (e.g., "Mamy nadzieje, ze [PET_NAME] czuje sie lepiej!").
- Train reception staff to verbally ask for reviews after successful visits.
- Add a "Zostaw opinie" link in the website footer.

**Review response:**
- Respond to every review within 24-48 hours.
- Thank positive reviewers by name, mention the pet's name if shared.
- Address negative reviews professionally: acknowledge, apologize, offer to resolve offline.
- Use keyword-rich language naturally in responses (e.g., "Dziekujemy za wizyte w naszej przychodni weterynaryjnej na Retkini").

**Target:** 50+ Google reviews with 4.5+ average rating within 6 months.

---

## 1.4 Content SEO

### Blog Content Calendar (12 Months, 2 Posts/Month)

Each post should be 800-1500 words, optimized for a specific keyword cluster, and include internal links to relevant service pages.

**Month 1 (March 2026):**
1. "Jak przygotowac zwierzaka do rehabilitacji -- poradnik" --> links to /rehabilitacja/
2. "Wiosenne zagrozenia dla psow i kotow -- na co uwazac" --> links to /uslugi/

**Month 2 (April 2026):**
3. "Bieznia wodna w rehabilitacji psa -- kiedy i dlaczego?" --> links to /services/bieznia-wodna/
4. "Czipowanie psa i kota -- obowiazek czy wybor?" --> links to /uslugi/

**Month 3 (May 2026):**
5. "Bank krwi dla zwierzat -- jak Twoj pies moze uratowac zycie" --> links to /bank-krwi/
6. "Kleszcze i choroby odkleszczowe -- profilaktyka i leczenie" --> links to /uslugi/

**Month 4 (June 2026):**
7. "Rehabilitacja psa po operacji ACL (wiezadla krzyzowego)" --> links to /rehabilitacja/, /services/bieznia-wodna/, /services/elektrostymulacja/
8. "Udar cieplny u psa -- objawy i pierwsza pomoc" --> links to /kontakt/ (emergency)

**Month 5 (July 2026):**
9. "Laseroterapia w weterynarii -- co warto wiedziec" --> links to /services/laser-wysokoenergetyczny/, /services/laser-niskoenergetyczny/
10. "Jak dbac o zeby psa i kota -- stomatologia weterynaryjna" --> links to /uslugi/

**Month 6 (August 2026):**
11. "Neurorehabilitacja zwierzat -- kiedy jest potrzebna?" --> links to /services/neurorehabiltacja-funkcjonalna/
12. "Pierwsza wizyta szczeniaka u weterynarza -- krok po kroku" --> links to /uslugi/, /informacje-dla-wlascicieli/

**Month 7 (September 2026):**
13. "Pole magnetyczne w rehabilitacji zwierzat -- zastosowania" --> links to /services/pole-magnetyczne/
14. "Jesienne szczepienia -- harmonogram dla psa i kota" --> links to /uslugi/

**Month 8 (October 2026):**
15. "Masaz terapeutyczny dla psa -- korzysdci i wskazania" --> links to /services/masaze/
16. "Diagnostyka USG u zwierzat -- kiedy jest potrzebna?" --> links to /uslugi/

**Month 9 (November 2026):**
17. "Elektrostymulacja w rehabilitacji zwierzat" --> links to /services/elektrostymulacja/
18. "Jak przygotowac zwierzaka do operacji chirurgicznej" --> links to /uslugi/

**Month 10 (December 2026):**
19. "Swieta z pupilem -- niebezpieczne potrawy i dekoracje" --> links to /kontakt/ (emergency)
20. "Terapia blizny u zwierzat -- rekonwalescencja pooperacyjna" --> links to /services/terapia-blizny/

**Month 11 (January 2027):**
21. "Noworoczne postanowienia dla wlascicieli zwierzat -- zdrowie pupila" --> links to /uslugi/
22. "Bieznia sucha w rehabilitacji -- odbudowa sily miesniowej" --> links to /services/bieznia-sucha/

**Month 12 (February 2027):**
23. "Ultradzzwieki w weterynarii -- leczenie tkanek miekkich" --> links to /services/ultradzwieki/
24. "Jak wybrac dobrego weterynarza w Lodzi -- poradnik" --> links to /personel/, Homepage

### Keyword Clusters by Service

**Cluster 1: Rehabilitation (hub page + 10 service pages)**
- Core: rehabilitacja zwierzat, fizjoterapia zwierzat, zoofizjoterapia
- Modifiers: lodz, dla psa, dla kota, po operacji, cena
- Equipment: bieznia wodna, laser, pole magnetyczne, elektrostymulacja

**Cluster 2: General Veterinary Care**
- Core: weterynarz, przychodnia weterynaryjna, gabinet weterynaryjny
- Services: szczepienia, czipowanie, diagnostyka, chirurgia, stomatologia, endoskopia, USG, RTG
- Modifiers: lodz, retkinia, cena, dobry, polecany

**Cluster 3: Blood Bank**
- Core: bank krwi dla zwierzat, oddanie krwi pies, transfuzja zwierzat
- Questions: czy pies moze oddac krew, jak zostac dawca krwi zwierzat
- Emergency: nagly przypadek weterynarz, krew dla psa pilnie

**Cluster 4: Informational / Owner Education**
- Preparation: przygotowanie do wizyty, co zabrac do weterynarza
- Seasonal: kleszcze, udar cieplny, swieta zagrozenia, fajerwerki stres
- Care: dieta psa, zeby psa, profilaktyka

### Content Gaps vs Competitors

Based on typical veterinary clinic websites in Lodz, VetActive has these content gaps:

1. **Pricing information:** Most competitors avoid publishing prices. VetActive can gain competitive advantage by publishing at least price ranges (e.g., "Konsultacja: od 150 zl"). This captures high-intent "ile kosztuje" queries.
2. **Video content:** Zero videos currently. Even a 60-second practice tour video embedded on the homepage would increase time-on-page and rank for video carousels.
3. **Patient success stories / case studies:** Before-and-after rehabilitation cases (with owner permission) are extremely engaging and link-worthy.
4. **Detailed FAQ pages per service:** Current `/informacje-dla-wlascicieli/` is a single page. Expand with FAQ sections on every service page.
5. **"Pierwsza wizyta" (First Visit) guide:** Dedicated page explaining what to expect, what to bring, parking, paperwork — captures nervous new pet owners.
6. **Seasonal content hub:** A dedicated section for seasonal pet health advice, updated regularly.
7. **Emergency information page:** What constitutes an emergency, triage guidance, after-hours options.

### FAQ Content on Each Service Page

Every service page (general services, each rehab therapy, Blood Bank) should include a 5-8 question FAQ section at the bottom. This serves three purposes:
1. Captures long-tail search queries
2. Provides FAQ schema markup for rich results
3. Gives AI assistants structured answers to pull from

**Example FAQ for /services/bieznia-wodna/:**

```
Q: Czym jest bieznia wodna w rehabilitacji zwierzat?
A: Bieznia wodna (podwodna) to urzadzenie rehabilitacyjne, w ktorym zwierze
   chodzi na biezni zanurzonej w cieplej wodzie. Woda zmniejsza obciazenie
   stawow nawet o 60%, jednoczesnie zapewniajac opor, ktory wzmacnia miesnie.

Q: Dla jakich zwierzat jest przeznaczona bieznia wodna?
A: Bieznia wodna jest przeznaczona glownie dla psow, ale moze byc stosowana
   rowniez u kotow i innych zwierzat srednich rozmiarow.

Q: Kiedy weterynarz zaleca bieznia wodna?
A: Najczesciej po operacjach ortopedycznych (np. ACL, dysplazja biodra),
   w rehabilitacji neurologicznej, przy otylosci, oraz w celu utrzymania
   kondycji u starszych psow z problemami stawowymi.

Q: Ile trwa sesja na biezni wodnej?
A: Typowa sesja trwa 15-30 minut, w zaleznosci od stanu zdrowia zwierzecia
   i celu terapeutycznego. Cykl rehabilitacji obejmuje zwykle 8-12 sesji.

Q: Czy bieznia wodna jest bezpieczna dla mojego psa?
A: Tak, bieznia wodna w Vet-Active jest obsługiwana przez wykwalifikowanych
   zoofizjoterapeutow. Temperatura wody jest kontrolowana, a zwierze jest
   zawsze pod nadzorem specjalisty.
```

---

## 1.5 Schema Markup Strategy

### Full Schema Implementation Plan

Each page type requires specific schema markup. All schema should be implemented as JSON-LD in the `<head>` section.

**1. VeterinaryCare (Homepage) — P0**
Already drafted (see section 1.3). Deploy as-is with postal code confirmation.

**2. Service Schema (each service page) — P0**

```json
{
  "@context": "https://schema.org",
  "@type": "Service",
  "name": "Bieznia Wodna -- Rehabilitacja Zwierzat",
  "description": "Hydroterapia na biezni wodnej...",
  "provider": {
    "@type": "VeterinaryCare",
    "name": "Vet-Active",
    "url": "https://vetactive.pl/"
  },
  "serviceType": "Animal Rehabilitation",
  "areaServed": {
    "@type": "City",
    "name": "Lodz"
  },
  "url": "https://vetactive.pl/services/bieznia-wodna/",
  "category": "Rehabilitacja Zwierzat"
}
```

Deploy a similar Service schema on each of the 10 rehab pages and the general services page.

**3. FAQPage Schema (every page with FAQ section) — P0**

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Czym jest bieznia wodna w rehabilitacji zwierzat?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Bieznia wodna to urzadzenie rehabilitacyjne..."
      }
    }
  ]
}
```

Deploy on: every rehab service page, /uslugi/, /bank-krwi/, /informacje-dla-wlascicieli/.

**4. BreadcrumbList (all pages) — P1**

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {"@type": "ListItem", "position": 1, "name": "Strona glowna", "item": "https://vetactive.pl/"},
    {"@type": "ListItem", "position": 2, "name": "Rehabilitacja", "item": "https://vetactive.pl/rehabilitacja/"},
    {"@type": "ListItem", "position": 3, "name": "Bieznia Wodna"}
  ]
}
```

Deploy on all pages except homepage.

**5. Article Schema (blog posts) — P1**

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "Bieznia wodna w rehabilitacji psa -- kiedy i dlaczego?",
  "author": {
    "@type": "Person",
    "name": "Ewelina Romanska",
    "jobTitle": "Lekarz weterynarii",
    "worksFor": {"@type": "VeterinaryCare", "name": "Vet-Active"}
  },
  "publisher": {
    "@type": "Organization",
    "name": "Vet-Active",
    "url": "https://vetactive.pl/"
  },
  "datePublished": "2026-04-15",
  "dateModified": "2026-04-15",
  "image": "https://vetactive.pl/blog-images/bieznia-wodna-pies.jpg",
  "mainEntityOfPage": "https://vetactive.pl/blog/bieznia-wodna-rehabilitacja-psa/"
}
```

Attribute each blog post to a specific vet to build individual E-E-A-T.

**6. Review / AggregateRating (Homepage) — P1**

```json
{
  "@context": "https://schema.org",
  "@type": "VeterinaryCare",
  "name": "Vet-Active",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.8",
    "reviewCount": "52",
    "bestRating": "5",
    "worstRating": "1"
  }
}
```

**Important:** Only deploy AggregateRating if the reviews are collected on vetactive.pl itself (e.g., via a widget). Google penalizes AggregateRating markup for reviews hosted on third-party platforms (like Google reviews). If reviews are only on Google, do NOT use this schema — let Google pull the rating from GBP instead.

**7. MedicalOrganization (supplementary, homepage) — P2**

While VeterinaryCare is the primary type, adding MedicalOrganization as an additional type can help with broader medical/health queries:

```json
{
  "@context": "https://schema.org",
  "@type": ["VeterinaryCare", "MedicalOrganization"],
  "name": "Vet-Active",
  "medicalSpecialty": "Veterinary Medicine"
}
```

**8. Person Schema (team page) — P2**

For each vet on `/personel/`:

```json
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Ewelina Romanska",
  "jobTitle": "Lekarz weterynarii",
  "worksFor": {
    "@type": "VeterinaryCare",
    "name": "Vet-Active",
    "url": "https://vetactive.pl/"
  },
  "image": "[PHOTO_URL]",
  "description": "Lekarz weterynarii specjalizujacy sie w..."
}
```

### Schema Validation

After deployment, validate all schema using:
- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema.org Validator: https://validator.schema.org/
- Check Google Search Console "Enhancements" section for schema errors.

---

## 1.6 WordPress-to-GHL Migration SEO Checklist

This is the most critical short-term SEO task. A botched migration can lose years of ranking equity in days.

### Pre-Migration (P0 — do before any DNS change)

- [ ] **Crawl the current WordPress site** with Screaming Frog or Sitebulb. Export:
  - All indexed URLs
  - All title tags and meta descriptions
  - All H1 tags
  - All internal links
  - All 301 redirects already in place
  - All images and their alt text
  - All schema markup
  - Robots.txt content
  - XML sitemap content
- [ ] **Screenshot every page** (desktop and mobile) for visual reference.
- [ ] **Export Google Search Console data:**
  - Performance report (last 16 months) — queries, pages, clicks, impressions
  - Index Coverage report — all indexed URLs
  - Sitemaps report
  - Core Web Vitals report
  - Any manual actions or security issues
- [ ] **Export Google Analytics data** (all historical data).
- [ ] **Document all backlinks** using Ahrefs, SEMrush, or Google Search Console Links report.
- [ ] **Build all GHL pages** with matching URL slugs BEFORE switching DNS.
- [ ] **Implement all meta tags** from `seo-meta-tags.html` on GHL pages.
- [ ] **Deploy schema markup** on all GHL pages.
- [ ] **Set up all 301 redirects** in GHL (per `301-redirects.md`).
- [ ] **Set up robots.txt** on GHL (per prepared `robots.txt` file).
- [ ] **Verify GHL generates a correct sitemap.xml** containing all public pages.

### During Migration (day of DNS switch)

- [ ] **Point DNS to GHL** (update A record / CNAME as per GHL docs).
- [ ] **Verify HTTPS** is working on the new GHL site.
- [ ] **Test every URL** from the crawl export — confirm each returns 200 OK or redirects correctly.
- [ ] **Test all 301 redirects** — verify they go to the correct destination.
- [ ] **Test the XML sitemap** — ensure it is accessible and lists correct URLs.
- [ ] **Test robots.txt** — ensure it is accessible.
- [ ] **Submit the new sitemap** in Google Search Console.
- [ ] **Request indexing** of the homepage via Google Search Console URL Inspection tool.

### Post-Migration (P0 — first 7 days)

- [ ] **Monitor Google Search Console daily** for:
  - Crawl errors (404s, 5xx errors)
  - Drop in indexed pages
  - Coverage issues
- [ ] **Check Google cache** for 5-10 key pages (search `cache:vetactive.pl/rehabilitacja/`).
- [ ] **Monitor organic traffic** in GA4 — compare to pre-migration baseline.
- [ ] **Check ranking positions** for top 10 keywords.
- [ ] **Verify all images** are loading correctly.
- [ ] **Verify all forms** (contact, booking) are functional.
- [ ] **Test site speed** on PageSpeed Insights for all key pages.

### Post-Migration (P1 — 30 days)

- [ ] **Re-crawl the site** with Screaming Frog and compare to pre-migration crawl.
- [ ] **Resolve any 404s** that appear in Search Console.
- [ ] **Monitor keyword rankings** weekly for the first month.
- [ ] **Check backlinks** — ensure they are resolving to the correct pages.
- [ ] **Update any external profiles** (GBP, directories, social media) if URLs changed.
- [ ] **Remove Yoast SEO references** (any Yoast-specific schema or meta tags that may conflict).

### Post-Migration (P2 — 90 days)

- [ ] **Full SEO audit** of the new site.
- [ ] **Core Web Vitals check** — ensure all pages pass.
- [ ] **Content performance review** — which pages gained/lost traffic.
- [ ] **Adjust strategy** based on post-migration data.

---

# 2. AEO — Answer Engine Optimization

AEO focuses on making VetActive's content the answer that AI assistants (ChatGPT, Google AI Overviews, Perplexity, Copilot) and voice assistants (Google Assistant, Siri) cite when users ask veterinary questions about Lodz.

## 2.1 FAQ Strategy

### Implementation Approach

Every service page, the Blood Bank page, and the informational page must include a dedicated FAQ section with 5-10 questions structured as proper question-answer pairs.

**Format requirements:**
- Use H2 heading: "Najczesciej Zadawane Pytania" (or "FAQ")
- Each question in an H3 tag (or H4 if under a section H3)
- Answer directly below in `<p>` tags
- Answer begins with a direct, concise statement (1-2 sentences) followed by elaboration
- Implement FAQPage schema markup for every FAQ section

**FAQ content by page:**

### Homepage FAQ (5 questions)
1. Gdzie znajduje sie przychodnia Vet-Active w Lodzi?
2. Jakie sa godziny otwarcia Vet-Active?
3. Czy moge umowic wizyte online?
4. Jakie uslugi oferuje Vet-Active?
5. Czy Vet-Active przyjmuje w soboty?

### /uslugi/ FAQ (8 questions)
1. Jakie uslugi weterynaryjne oferuje Vet-Active?
2. Ile kosztuje wizyta u weterynarza w Vet-Active Lodz?
3. Czy potrzebna jest rejestracja przed pierwsza wizyta?
4. Jakie badania diagnostyczne wykonuje Vet-Active?
5. Czy Vet-Active wykonuje zabiegi chirurgiczne?
6. Czy mozna przyjsc bez umowienia wizyty?
7. Jakie gatunki zwierzat przyjmuje Vet-Active?
8. Jak przygotowac zwierze do badania USG?

### /rehabilitacja/ FAQ (8 questions)
1. Na czym polega rehabilitacja zwierzat w Vet-Active?
2. Ile metod rehabilitacji oferuje Vet-Active?
3. Kiedy weterynarz zaleca rehabilitacje?
4. Ile trwa typowy cykl rehabilitacji?
5. Czy rehabilitacja jest bolesna dla zwierzecia?
6. Ile kosztuje rehabilitacja zwierzat w Lodzi?
7. Czy potrzebne jest skierowanie na rehabilitacje?
8. Jakie kwalifikacje maja rehabilitanci w Vet-Active?

### /bank-krwi/ FAQ (8 questions)
1. Czym jest bank krwi dla zwierzat?
2. Czy moj pies moze byc dawca krwi?
3. Jakie warunki musi spelnic dawca krwi?
4. Czy oddanie krwi jest bezpieczne dla psa?
5. Jak czesto pies moze oddawac krew?
6. Co sie dzieje z oddana krwia?
7. W jakich sytuacjach zwierze potrzebuje transfuzji?
8. Jak skontaktowac sie z bankiem krwi w nagłym przypadku?

### Each rehab service page FAQ (5-6 questions)
Tailored to the specific therapy. See the bieznia wodna example in section 1.4.

## 2.2 Speakable Markup

Voice assistants (Google Assistant, Siri via structured data) can read aloud specific content blocks when Speakable schema is implemented.

**Implementation:**

Add Speakable markup to key content blocks on each page — specifically the introductory paragraph and the FAQ section:

```json
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Rehabilitacja Zwierzat Lodz -- Vet-Active",
  "speakable": {
    "@type": "SpeakableSpecification",
    "cssSelector": [".page-intro", ".faq-section"]
  }
}
```

**Content guidelines for speakable sections:**
- Write in natural, conversational Polish.
- Avoid abbreviations — write "ul." as "ulica" in speakable blocks, "tel." as "telefon".
- Include the practice name, address, and phone number in the first speakable block.
- Keep sentences short (15-20 words max) for natural speech flow.
- Avoid complex sentence structures or parenthetical asides.

**Priority pages for Speakable markup:**
1. Homepage (P0)
2. Contact page (P0)
3. Rehabilitation overview (P1)
4. Blood Bank (P1)
5. Booking page (P1)

## 2.3 Conversational Content

AI assistants process and cite content that matches natural language question patterns. Every page should include content that directly answers questions people would ask verbally.

**Natural language questions to target (and where to answer them):**

### Location & General
- "Gdzie jest dobry weterynarz w Lodzi?" --> Homepage intro + GBP
- "Jaka przychodnia weterynaryjna jest otwarta w sobote w Lodzi?" --> Contact page, Hours section
- "Jak umowic wizyte u weterynarza w Lodzi?" --> /rezerwacja/, also answered in Homepage CTA block
- "Czy Vet-Active przyjmuje bez umowienia?" --> FAQ on /uslugi/
- "Ile kosztuje wizyta u weterynarza w Lodzi?" --> /uslugi/ or /informacje-dla-wlascicieli/

### Rehabilitation
- "Gdzie jest rehabilitacja zwierzat w Lodzi?" --> /rehabilitacja/ intro paragraph
- "Ile kosztuje rehabilitacja psa w Lodzi?" --> /rehabilitacja/ FAQ
- "Czy pies potrzebuje rehabilitacji po operacji kolana?" --> Blog post + /rehabilitacja/
- "Co to jest bieznia wodna dla psow?" --> /services/bieznia-wodna/ intro
- "Jak dziala laseroterapia u weterynarza?" --> /services/laser-wysokoenergetyczny/

### Blood Bank
- "Czy pies moze oddac krew?" --> /bank-krwi/ intro
- "Gdzie moge oddac krew mojego psa w Lodzi?" --> /bank-krwi/
- "Kiedy pies potrzebuje transfuzji krwi?" --> /bank-krwi/ FAQ

**Writing style for conversational content:**
- Start important paragraphs with the answer, then elaborate.
- Use "Vet-Active w Lodzi" rather than just "nasza przychodnia" — AI needs the entity name and location to cite correctly.
- Mirror the question in the opening sentence: "Rehabilitacja zwierzat w Vet-Active Lodz obejmuje 10 metod terapeutycznych..."
- Use numbered lists and bullet points for multi-item answers.
- Include specific data points: "10 metod terapeutycznych", "7-osobowy zespol", "ponad X lat doswiadczenia".

## 2.4 Featured Snippet Optimization

Featured snippets (position zero) appear above traditional search results. Target these formats:

### Paragraph Snippets
For definitional queries ("Co to jest bieznia wodna?"), write a 40-60 word paragraph immediately following the H2/H3 question:

```html
<h3>Co to jest bieznia wodna w rehabilitacji zwierzat?</h3>
<p>Bieznia wodna (inaczej: bieznia podwodna) to specjalistyczne urzadzenie
rehabilitacyjne, w ktorym zwierze chodzi lub biega na ruchomej tasmie
zanurzonej w cieplej wodzie. Woda zmniejsza obciazenie stawow o 40-60%,
jednoczesnie zapewniajac opor wzmacniajacy miesnie. Jest to jedna
z najskuteczniejszych metod rehabilitacji pooperacyjnej u psow.</p>
```

### List Snippets
For "how to" or "steps" queries, use ordered lists:

```html
<h3>Jak przygotowac psa do rehabilitacji?</h3>
<ol>
  <li>Umow wizyte konsultacyjna z weterynarzem lub zoofizjoterapeuta</li>
  <li>Przyniesi wyniki badan i dokumentacje medyczna zwierzecia</li>
  <li>Nie karm psa 2 godziny przed wizyta (przy biezni wodnej)</li>
  <li>Przyniesi ulubiony smakoly psa jako nagrode</li>
  <li>Zaplanuj transport -- zwierze moze byc zmeczone po sesji</li>
</ol>
```

### Table Snippets
For comparison or pricing queries, use HTML tables:

```html
<h3>Metody rehabilitacji zwierzat w Vet-Active</h3>
<table>
  <tr><th>Metoda</th><th>Zastosowanie</th><th>Czas sesji</th></tr>
  <tr><td>Bieznia wodna</td><td>Pooperacyjna, neurologiczna</td><td>15-30 min</td></tr>
  <tr><td>Laser wysokoenergetyczny</td><td>Bol, stany zapalne</td><td>10-20 min</td></tr>
  <!-- etc. -->
</table>
```

### Target Queries for Position Zero

| Query | Snippet Type | Target Page |
|-------|-------------|-------------|
| rehabilitacja zwierzat lodz | Paragraph | /rehabilitacja/ |
| bieznia wodna dla psa | Paragraph | /services/bieznia-wodna/ |
| bank krwi dla zwierzat | Paragraph | /bank-krwi/ |
| jak przygotowac psa do weterynarza | List | Blog post (existing) |
| metody rehabilitacji zwierzat | Table | /rehabilitacja/ |
| kiedy pies potrzebuje rehabilitacji | List | /rehabilitacja/ FAQ |
| co to jest laseroterapia weterynaryjna | Paragraph | /services/laser-wysokoenergetyczny/ |
| ile kosztuje weterynarz lodz | Table | /uslugi/ or /informacje-dla-wlascicieli/ |

## 2.5 Entity-First Content

For AI to cite VetActive, it must recognize "Vet-Active" as a distinct, authoritative entity — not just a keyword.

**Entity establishment strategy:**

1. **Consistent naming:** Always use "Vet-Active" (with hyphen) everywhere. Never "VetActive", "Vet Active", or "vetactive". The only exception is the domain "vetactive.pl" (which cannot have a hyphen).

2. **Structured data reinforcement:** The VeterinaryCare schema on the homepage is the primary entity definition. Ensure it includes:
   - `name`: "Vet-Active"
   - `alternateName`: "Przychodnia Weterynaryjna Vet-Active"
   - `sameAs`: Links to all official profiles (Facebook, Instagram, directories)
   - `url`: "https://vetactive.pl/"

3. **Cross-platform consistency:** The practice must appear with identical information on:
   - Google Business Profile
   - Facebook
   - Instagram
   - Panorama Firm
   - PKT.pl
   - At least 5 additional directories (see Local Citations section)

4. **Wikipedia / Wikidata consideration:** For long-term entity recognition, consider creating a Wikidata entry for the practice (if notable enough — Blood Bank service is a differentiator that may warrant notability).

5. **Knowledge panel strategy:** Google Knowledge Panels are triggered by entity recognition. To earn one:
   - Claim and fully optimize GBP
   - Ensure NAP consistency across 10+ authoritative sources
   - Generate press coverage or notable mentions
   - Build backlinks from authoritative sources (.edu, .gov, industry organizations)

## 2.6 Direct Answer Blocks

Each page should include a clearly structured summary block near the top that AI can extract as a complete, citable answer.

**Format:**

```html
<div class="answer-block" itemscope itemtype="https://schema.org/Service">
  <p><strong>Vet-Active w Lodzi</strong> oferuje specjalistyczna
  <span itemprop="name">rehabilitacje zwierzat</span> z wykorzystaniem
  10 metod terapeutycznych, w tym biezni wodnej, laseroterapii,
  elektrostymulacji i neurorehabilitacji funkcjonalnej. Przychodnia
  znajduje sie przy <span itemprop="address">ul. Batalionow Chlopskich 12
  w Lodzi (dzielnica Retkinia)</span> i przyjmuje od poniedzialku do
  piatku w godzinach 9:00-20:00 oraz w soboty 9:00-15:00.</p>
</div>
```

**Rules for answer blocks:**
- Place within the first 300 pixels of visible page content (above the fold).
- Include: practice name, location, key service, hours, and/or contact info.
- Keep to 2-3 sentences (50-80 words).
- Use full entity names, not pronouns: "Vet-Active w Lodzi" not "nasza przychodnia".
- Include at least one factual claim (number, date, address).

**Deploy on:**
- Homepage (P0): Practice overview
- /rehabilitacja/ (P0): Rehabilitation summary
- /bank-krwi/ (P0): Blood Bank summary
- /uslugi/ (P1): Services summary
- Each rehab service page (P1): Therapy-specific summary
- /kontakt/ (P1): Contact details summary

## 2.7 "People Also Ask" (PAA) Targeting

Research and target PAA questions that appear for key veterinary queries in Polish Google.

### PAA Queries by Category

**"weterynarz lodz" PAA cluster:**
- Jaki jest najlepszy weterynarz w Lodzi?
- Ile kosztuje wizyta u weterynarza w Lodzi?
- Gdzie jest calodobowy weterynarz w Lodzi?
- Czy trzeba umawiac sie do weterynarza?
- Ile kosztuje badanie krwi u psa?

**"rehabilitacja zwierzat" PAA cluster:**
- Na czym polega rehabilitacja zwierzat?
- Ile kosztuje rehabilitacja psa?
- Czy rehabilitacja pomaga psom po operacji?
- Jakie sa metody rehabilitacji zwierzat?
- Kiedy pies potrzebuje rehabilitacji?
- Jak dlugo trwa rehabilitacja psa?

**"bank krwi zwierzat" PAA cluster:**
- Czy pies moze byc dawca krwi?
- Jakie sa wymagania dla psa dawcy krwi?
- Ile krwi oddaje pies?
- Czy oddanie krwi jest bezpieczne dla psa?
- Gdzie oddac krew psa?

**"bieznia wodna pies" PAA cluster:**
- Ile kosztuje bieznia wodna dla psa?
- Jak dlugo trwa sesja na biezni wodnej?
- Czy bieznia wodna pomaga po operacji ACL?
- Od jakiego wieku pies moze korzystac z biezni wodnej?

**Action:** Create content that directly answers each PAA question. The answer should appear on the most relevant page within an FAQ section or as a distinct content block with the question as an H3 heading.

---

# 3. GEO — Generative Engine Optimization

GEO focuses on making VetActive's content maximally citable by AI language models when generating answers. Unlike traditional SEO (ranking a link) or AEO (answering a specific query), GEO ensures that when an LLM synthesizes information about veterinary care in Lodz, it draws from and attributes to VetActive.

## 3.1 E-E-A-T Signals

Google's E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) framework is increasingly used by AI systems to determine source quality.

### Experience

Demonstrate real-world experience with specific, verifiable details:

- **Years of operation:** State the founding year prominently. "Vet-Active obsluguje pacjentow w Lodzi od [YEAR] roku."
- **Patient volume:** If possible, state approximate patient numbers: "Rocznie przyjmujemy ponad [X] pacjentow."
- **Rehabilitation cases:** "Przeprowadzilismy ponad [X] sesji rehabilitacyjnych na biezni wodnej."
- **Blood Bank impact:** "Nasz Bank Krwi pomogl uratowac [X] zwierzat od momentu uruchomienia."
- **Patient success stories:** Publish 3-5 case studies (with owner consent):
  - Patient name, breed, age
  - Condition / diagnosis
  - Treatment protocol (which therapies were used)
  - Outcome (recovery time, improvement metrics)
  - Owner testimonial quote
- **Photo/video evidence:** Real photos of actual patients during therapy (with consent). Not stock photos.

### Expertise

Highlight professional qualifications and specialized knowledge:

- **Team credentials on /personel/ page:**
  - Full name with title (lek. wet., zoofizjoterapeuta)
  - University / education
  - Years of experience
  - Areas of specialization
  - Continuing education / certifications
  - Professional memberships
- **Author attribution on blog posts:** Every blog post credited to a specific vet with their credentials.
- **Equipment specifications:** On rehab service pages, mention equipment brands/models and certifications: "Korzystamy z biezni wodnej [Brand/Model] z certyfikatem [X]."
- **Training and certifications:** List all team certifications in rehabilitation, surgery, diagnostics.

### Authoritativeness

Establish VetActive as an authority in animal rehabilitation:

- **Izba Lekarsko-Weterynaryjna:** Display membership/license numbers for each vet.
- **Professional affiliations:** List memberships in veterinary associations (Polish, European, international).
- **Conference participation:** If any team members have presented or attended conferences, mention it.
- **Published work:** If any vet has published papers or articles, link to them.
- **Collaborations:** Mention any collaborations with universities (Uniwersytet Lodzki, SGGW) or research institutions.
- **Blood Bank as unique authority:** Position the Blood Bank as a rare and specialized service — "Jeden z niewielu bankow krwi dla zwierzat w wojewodztwie lodzkim."

### Trustworthiness

Build trust signals throughout the site:

- **Reviews and ratings:** Display Google review rating prominently. Link to Google reviews.
- **Transparent pricing:** Publish price ranges for common services. Even approximate ranges build trust.
- **Clear contact information:** Phone, email, address, and map visible on every page (header/footer).
- **Privacy policy and legal pages:** Already planned (/polityka-prywatnosci/, /polityka-cookies/, /warunki-uzytkowania/).
- **RODO compliance:** Cookie consent, data processing notice, patient data handling transparency.
- **Booking transparency:** Show available appointment types and durations. No hidden fees messaging.
- **Response to negative reviews:** Professional, empathetic responses visible on Google.

## 3.2 Citation-Worthy Content

AI models cite content that contains specific, verifiable claims. Structure service pages to be maximally citable.

**Types of citation-worthy content to include:**

### Factual Claims with Numbers
- "Vet-Active oferuje 10 specjalistycznych metod rehabilitacji zwierzat."
- "Bieznia wodna zmniejsza obciazenie stawow zwierzecia o 40-60%."
- "Typowy cykl rehabilitacji na biezni wodnej obejmuje 8-12 sesji."
- "Nasz zespol liczy 7 specjalistow, w tym 4 lekarzy weterynarii i 2 zoofizjoterapeutow."

### Pricing Ranges
- "Konsultacja weterynaryjna w Vet-Active: od [X] zl."
- "Sesja rehabilitacyjna na biezni wodnej: [X]-[Y] zl."
- Pricing content is extremely citation-worthy because LLMs frequently encounter "ile kosztuje" queries.

### Equipment Specifications
- "Laser wysokoenergetyczny klasy IV o mocy [X]W."
- "Bieznia wodna z regulacja temperatury wody (28-32 C) i predkosci (0.5-7 km/h)."
- "Cyfrowy aparat RTG z moca [X] kV."

### Comparative Statements
- "Vet-Active to jedna z niewielu przychodni weterynaryjnych w Lodzi oferujacych pelny program rehabilitacji zwierzat z 10 metodami terapeutycznymi."
- "Bank Krwi dla Zwierzat w Vet-Active jest jednym z nielicznych tego typu programow w wojewodztwie lodzkim."

### Service Definitions
Every rehab therapy page should include a clear, factual, 2-3 sentence definition of the therapy at the very beginning. This is the content most likely to be cited by AI.

## 3.3 Source Authority

AI models preferentially cite content from sources that appear across multiple authoritative platforms.

**Strategy to maximize source authority:**

### Platform Presence (P0)
Ensure VetActive appears with consistent, detailed information on:

| Platform | Priority | Why it Matters for GEO |
|----------|---------|----------------------|
| Google Business Profile | P0 | Google AI Overviews pull directly from GBP |
| vetactive.pl (own website) | P0 | Direct source for all AI crawlers |
| Facebook Business Page | P0 | Meta AI and social-based AI systems crawl Facebook |
| Instagram | P1 | Visual content indexing, increasingly crawled |
| Panorama Firm | P1 | High DA Polish directory, crawled by many AI systems |
| ZnanyLekarz / equivalent | P1 | Health-specific authority platform |
| PKT.pl | P1 | Traditional Polish business directory |
| Yelp | P2 | International AI systems (ChatGPT, Perplexity) know Yelp well |
| Wikipedia / Wikidata | P2 | Strongest entity signal for AI systems |

### Backlink Quality
Pursue backlinks from authoritative domains:

1. **Izba Lekarsko-Weterynaryjna** — get listed in their member directory.
2. **Local Lodz government or tourism sites** — "businesses in Retkinia" listings.
3. **Veterinary schools** — if any vet on the team is an alumni, get listed.
4. **Pet adoption organizations** — partner with Lodz animal shelters (e.g., Schronisko dla Zwierzat w Lodzi). Offer discounted first-visit for adopted animals, earn a backlink.
5. **Local news / press** — pitch a story about the Blood Bank (unique angle).
6. **Pet blogger outreach** — invite local pet bloggers for a practice tour.

## 3.4 Content Depth

For GEO, each rehabilitation therapy page should become the definitive Polish-language resource for that therapy. AI models favor comprehensive, well-structured content over thin pages.

**Target page structure for each rehab service page (1500-2500 words):**

```
H1: [Therapy Name] -- Rehabilitacja Zwierzat | Vet-Active Lodz

[Direct Answer Block -- 2-3 sentences, see section 2.6]

H2: Czym jest [therapy]?
  - Clear definition (2-3 paragraphs)
  - How it works (mechanism of action)
  - Brief history / scientific basis

H2: Wskazania -- kiedy stosujemy [therapy]?
  - Bulleted list of conditions/indications
  - Post-surgical applications
  - Chronic conditions
  - Preventive/maintenance use

H2: Jak przebiega zabieg [therapy] w Vet-Active?
  - Step-by-step description of a typical session
  - Duration
  - Frequency
  - What to expect (animal's experience)

H2: Efekty i korzysci [therapy]
  - List of benefits with evidence
  - Timeline for results
  - Success metrics

H2: Przeciwwskazania
  - When this therapy should NOT be used
  - (This demonstrates medical responsibility and E-E-A-T)

H2: Sprzet i bezpieczenstwo
  - Equipment used (brand, specifications)
  - Safety protocols
  - Staff qualifications for this therapy

H2: [Therapy] w polaczeniu z innymi metodami
  - How this therapy combines with other rehabilitation methods
  - Cross-links to related therapy pages

H2: Najczesciej Zadawane Pytania
  - 5-8 FAQ pairs
  - FAQPage schema

H2: Umow wizyte
  - CTA block with booking link and phone number
```

This structure ensures:
- AI can extract a clear definition (first H2)
- AI can find specific indications and contraindications
- AI encounters factual claims it can cite
- The page is the most comprehensive Polish source on the topic

## 3.5 Structured Claims

Use a "claim - evidence - conclusion" format throughout content to make claims more credible to AI systems.

**Pattern:**

```
CLAIM: Bieznia wodna jest jedną z najskuteczniejszych metod rehabilitacji
pooperacyjnej u psow.

EVIDENCE: Badania wykazuja, ze hydroterapia zmniejsza obciazenie stawow
o 40-60% dzieki wypornodci wody, jednoczesnie zapewniajac opor budujacy
sile miesniowa. W Vet-Active obserwujemy, ze psy po operacji wiezadla
krzyzowego przedniego odzyskuja pelna sprawnosc srednio o 30% szybciej
przy zastosowaniu biezni wodnej w porownaniu z samą rehabilitacja
naziemna.

CONCLUSION: Dlatego bieznia wodna jest elementem wiekszosci programow
rehabilitacyjnych w Vet-Active, szczegolnie po zabiegach ortopedycznych
i u pacjentow z chorobami zwyrodnieniowymi stawow.
```

**Where to apply:**
- The "Efekty i korzysci" section of each rehab service page
- Blog posts (especially educational/informational ones)
- Blood Bank page (why blood donation matters)
- General services page (why choose Vet-Active)

**Important:** Use real data wherever possible. If clinical data is available from the practice's own records (anonymized), reference it. If citing external studies, link to the source.

## 3.6 Multimodal Content

AI systems increasingly process images, videos, and structured data alongside text. Optimize all content modalities.

### Image Optimization for AI

- **Descriptive alt text** (see section 1.2) — AI image models and text models both use alt text.
- **Image file names:** Use descriptive names: `bieznia-wodna-rehabilitacja-psa-vet-active-lodz.jpg` not `IMG_4523.jpg`.
- **Image captions:** Add visible captions beneath images: "Pies rasy labrador retriever podczas sesji na biezni wodnej w Vet-Active Lodz."
- **Image schema:** For key images, add ImageObject schema with `contentUrl`, `description`, and `caption` properties.

### Video Content (Recommended Addition)

Currently VetActive has zero video content. Priority video recommendations:

1. **Practice tour (60-90 sec)** — Walk through the practice, show equipment, team. Embed on homepage. (P1)
2. **Rehabilitation demonstration (2-3 min per therapy)** — Show each therapy in action. Embed on respective service pages. (P2)
3. **Blood Bank explainer (2 min)** — How donation works, why it matters. Embed on /bank-krwi/. (P2)
4. **Meet the team (60 sec per vet)** — Short intro from each vet. Embed on /personel/. (P2)

**For every video:**
- Host on YouTube (create a Vet-Active YouTube channel).
- Embed on the relevant page.
- Include a full Polish transcript on the page (below or beside the video).
- Add VideoObject schema markup.
- Optimize YouTube title, description, and tags for the same keywords as the page.

### Infographics

Create shareable infographics for key content:
- "10 Metod Rehabilitacji Zwierzat w Vet-Active" — visual overview of all therapies
- "Twoj Pies Moze Byc Dawca Krwi — Jak To Dziala" — Blood Bank process infographic
- "Kiedy Jechac do Weterynarza Natychmiast" — Emergency symptoms checklist

For each infographic:
- Include full text description on the page (for crawlers that cannot read images)
- Use descriptive alt text
- Make the infographic embeddable (others can share it, earning backlinks)

## 3.7 Brand Mentions

AI models build entity knowledge from mentions across the web, not just from the practice's own site. Strategy for earning brand mentions:

### Online Forums and Communities (P1)

- **Facebook groups:** Identify and participate (as the practice or as individual vets) in:
  - "Psy Lodz" / "Koty Lodz" — local pet owner groups
  - "Rehabilitacja Zwierzat Polska" — national rehab community
  - "Weterynarz Poleca" — vet recommendation groups
  - Breed-specific groups (labradory, owczarki, buldogi) — where rehab questions arise
- **Quora / Polish Q&A sites:** Answer questions about veterinary care in Lodz. Include natural mentions of Vet-Active when relevant.
- **Reddit (r/lodz, r/poland):** If pet-related questions appear, answer helpfully.

### Vet Communities and Professional Forums (P1)

- Participate in Polish veterinary forums/groups where professionals discuss rehabilitation techniques.
- Present case studies from the practice (with anonymized patient data).
- This establishes individual vet expertise, which AI systems can pick up.

### Local News and PR (P2)

- **Blood Bank angle:** Pitch to local Lodz media (Dziennik Lodzki, TVP Lodz, Radio Lodz):
  - "First/only animal Blood Bank in the Lodz voivodeship"
  - Human interest stories about saved animals
  - Call for donors
- **Rehabilitation success stories:** "Dog walks again after innovative rehabilitation at Lodz clinic"
- **Seasonal angles:** Heat stroke warnings in summer, firework anxiety before New Year's — expert quotes from Vet-Active vets.

### Partnership Mentions (P2)

- Partner with Schronisko dla Zwierzat w Lodzi (animal shelter) — "Vet-Active proudly supports adopted animals with discounted first visits."
- Partner with local pet shops, groomers, trainers — cross-promotion with brand mentions.
- Sponsor local dog walking events, pet adoption days.

### Industry Publications (P2)

- Write guest articles for Polish veterinary publications (Zycie Weterynaryjne, Magazyn Weterynaryjny).
- Topic: The role of rehabilitation in modern veterinary practice, with VetActive as the case study.

## 3.8 Content Freshness

AI systems increasingly weight recency. Stale content is less likely to be cited.

### "Last Updated" Timestamps

- Every page should display a visible "Ostatnia aktualizacja: [date]" line.
- Implement this in the page template, near the top or bottom of the content area.
- Use `dateModified` in schema markup (Article schema, WebPage schema).
- **Commit to updating** each service page at least quarterly (even small updates trigger a new `dateModified`).

### Content Update Schedule

| Page | Update Frequency | What to Update |
|------|-----------------|----------------|
| Homepage | Monthly | Seasonal messaging, latest reviews, new services |
| /uslugi/ | Quarterly | New services, pricing updates, new equipment |
| /rehabilitacja/ | Quarterly | New case studies, updated statistics |
| Rehab service pages (x10) | Every 6 months | New evidence, patient outcomes, equipment updates |
| /bank-krwi/ | Monthly | Donor call-to-action updates, impact numbers |
| /personel/ | When team changes | New team members, new qualifications |
| /blog/ | Twice monthly | New posts per content calendar |
| /kontakt/ | When info changes | Hours, phone, holiday schedule |
| /informacje-dla-wlascicieli/ | Quarterly | New FAQ items, seasonal advice |

### Seasonal Content Refresh

Mark specific times to update content with seasonal relevance:

- **March:** Update tick/flea prevention advice. Add spring allergy content.
- **June:** Heat stroke awareness. Swimming safety for dogs.
- **September:** Back-to-routine health checks. Autumn parasite season.
- **December:** Holiday pet safety. New Year firework anxiety.

### Blog Post Updates

Existing blog posts should be updated annually:
- Add new information
- Update any outdated advice
- Refresh the `dateModified` in schema
- Re-promote on social media

---

# 4. Competitor Analysis

## Recommended Competitors to Benchmark

Based on the Lodz veterinary market and VetActive's specialization in rehabilitation:

### 1. Klinika Weterynaryjna Anivet (Lodz)
- **Website:** anivet.pl (if exists — verify)
- **Why benchmark:** Large, established multi-vet practice in Lodz. Likely ranks for "weterynarz lodz."
- **What to compare:** Number of Google reviews, GBP optimization, service range, website content depth.

### 2. Przychodnia Weterynaryjna "Pod Jarzebina" (Lodz)
- **Why benchmark:** Well-known local practice. Strong local reputation.
- **What to compare:** Review count and rating, local citation presence, website SEO.

### 3. Przychodnia Weterynaryjna VetCare Lodz
- **Why benchmark:** Modern practice, likely has updated website.
- **What to compare:** Website design, content strategy, booking system, social media presence.

### 4. Wet-Net Lodz (or similar multi-location chain)
- **Why benchmark:** Chain practices often have professional SEO. Understand what a budget-heavy competitor does.
- **What to compare:** Content volume, schema implementation, backlink profile, local pack ranking.

### 5. Any practice offering animal rehabilitation in Lodz (or nearby)
- **Why benchmark:** Direct competitor for the flagship service.
- **What to compare:** Rehabilitation-specific content, equipment claims, pricing transparency.

### Competitive Analysis Checklist

For each competitor, evaluate:

| Factor | What to Check |
|--------|--------------|
| Domain Authority | Use Ahrefs/SEMrush to check DA |
| Indexed pages | `site:competitor.pl` in Google |
| Google reviews | Count + average rating |
| GBP completeness | Photos, posts, Q&A, services listed |
| Schema markup | Use Rich Results Test |
| Content depth | Word count on service pages |
| Blog activity | Number of posts, frequency, last update |
| Backlinks | Number and quality (Ahrefs) |
| Local pack ranking | Search "weterynarz lodz" — who appears in the 3-pack? |
| Featured snippets | Do they own any position-zero results? |
| Social presence | Facebook followers, post frequency, engagement |
| Mobile experience | PageSpeed Insights score |

---

# 5. KPI Tracking

## Metrics to Track

### Organic Search Performance (Monthly)
| Metric | Tool | Target (6 months) | Target (12 months) |
|--------|------|-------------------|-------------------|
| Organic sessions | GA4 | +50% vs pre-migration | +100% vs pre-migration |
| Organic clicks | Google Search Console | +40% | +80% |
| Impressions | Google Search Console | +60% | +120% |
| Average position (top 20 keywords) | GSC / Ahrefs | Top 5 for branded, Top 10 for local | Top 3 for branded, Top 5 for local |
| Click-through rate (CTR) | GSC | > 5% average | > 7% average |
| Indexed pages | GSC | 30+ (all pages indexed) | 50+ (with new blog content) |

### Local SEO (Monthly)
| Metric | Tool | Target (6 months) | Target (12 months) |
|--------|------|-------------------|-------------------|
| Google Maps views | GBP Insights | +100% vs current | +200% vs current |
| GBP clicks to website | GBP Insights | Track baseline + grow 50% | Double baseline |
| GBP phone calls | GBP Insights | Track baseline | +30% |
| Google reviews count | GBP | 50+ reviews | 100+ reviews |
| Google review rating | GBP | 4.5+ stars | 4.7+ stars |
| Local Pack ranking for "weterynarz lodz" | Manual check / Ahrefs | Top 3 | Top 3 consistently |

### Content Performance (Monthly)
| Metric | Tool | What to Track |
|--------|------|--------------|
| Blog traffic | GA4 | Sessions per post, top-performing posts |
| Average time on page | GA4 | Target > 2 minutes on service pages |
| Bounce rate | GA4 | Target < 60% on service pages |
| Pages per session | GA4 | Target > 2.0 |
| FAQ click-through | GSC | Which FAQ rich results get clicks |
| Featured snippet wins | GSC / Manual | Track position-zero appearances |

### AEO / GEO Performance (Monthly)
| Metric | Tool | What to Track |
|--------|------|--------------|
| AI Overview appearances | Google Search Console (if available) | Queries where VetActive appears in AI Overviews |
| Brand mentions | Google Alerts, Brand24, Mention | New mentions of "Vet-Active" across the web |
| Citation tracking | Manual / Perplexity / ChatGPT queries | Ask AI assistants about vets in Lodz — does VetActive appear? |
| Rich result impressions | GSC Enhancements | FAQ, Review, Service rich result performance |

### Conversion Tracking (Monthly)
| Metric | Tool | What to Track |
|--------|------|--------------|
| Online bookings | GHL | Bookings via /rezerwacja/ |
| Phone calls from website | Call tracking / GHL | Calls from tel: links |
| Contact form submissions | GHL | Form fills on /kontakt/ |
| Chat conversations | GHL | Chatbot interactions |

## Recommended Tools

### Essential (P0)
| Tool | Purpose | Cost |
|------|---------|------|
| Google Search Console | Organic search performance, indexing, errors | Free |
| Google Analytics 4 | Traffic, behavior, conversions | Free |
| Google Business Profile | Local SEO management and insights | Free |
| Google PageSpeed Insights | Core Web Vitals monitoring | Free |
| Google Alerts | Brand mention monitoring | Free |

### Recommended (P1)
| Tool | Purpose | Cost |
|------|---------|------|
| Ahrefs (Lite plan) | Keyword tracking, backlinks, competitor analysis | ~$99/mo |
| Screaming Frog (free up to 500 URLs) | Technical SEO audits | Free for small sites |
| Schema Markup Validator | Validate structured data | Free |
| Brand24 (Polish tool) | Social listening, brand mentions in Polish web | ~199 PLN/mo |

### Nice to Have (P2)
| Tool | Purpose | Cost |
|------|---------|------|
| Semrush | Comprehensive SEO suite (alternative to Ahrefs) | ~$129/mo |
| Surfer SEO | Content optimization, SERP analysis | ~$89/mo |
| Frase.io | AI content optimization, SERP analysis | ~$45/mo |

---

# 6. Implementation Priority

## P0 — Critical (Do First, Before/During Migration)

These items must be completed before or at the time of the WordPress-to-GHL migration. Failure here means permanent SEO damage.

| # | Action | Section | Effort |
|---|--------|---------|--------|
| 1 | Crawl current WordPress site and export all SEO data | 1.6 | 2-3 hours |
| 2 | Build all GHL pages with exact URL slugs | 1.6 | Included in site build |
| 3 | Implement all meta tags from seo-meta-tags.html | 1.2 | 1-2 hours |
| 4 | Deploy VeterinaryCare schema on homepage | 1.5 | 30 min |
| 5 | Set up all 301 redirects per 301-redirects.md | 1.6 | 1 hour |
| 6 | Deploy robots.txt | 1.1 | 15 min |
| 7 | Verify XML sitemap generation | 1.1 | 30 min |
| 8 | Submit sitemap to Google Search Console | 1.6 | 15 min |
| 9 | Verify and optimize Google Business Profile | 1.3 | 2-3 hours |
| 10 | Ensure NAP consistency on Facebook + Instagram | 1.3 | 30 min |
| 11 | Set canonical URLs on all pages | 1.1 | 1 hour |
| 12 | Image compression (WebP, proper dimensions) | 1.1 | 1-2 hours |
| 13 | Post-migration monitoring (7 days daily checks) | 1.6 | 30 min/day |

## P1 — Important (Within 30 Days Post-Migration)

| # | Action | Section | Effort |
|---|--------|---------|--------|
| 14 | Deploy Service schema on all service pages | 1.5 | 2 hours |
| 15 | Deploy FAQPage schema on all pages with FAQ | 1.5 | 2 hours |
| 16 | Deploy BreadcrumbList schema on all pages | 1.5 | 1 hour |
| 17 | Write FAQ sections for /uslugi/, /rehabilitacja/, /bank-krwi/ | 2.1 | 4-6 hours |
| 18 | Create Direct Answer Blocks on top 6 pages | 2.6 | 2-3 hours |
| 19 | Optimize all image alt text | 1.2 | 1-2 hours |
| 20 | Upload 20+ photos to Google Business Profile | 1.3 | 1 hour |
| 21 | Set up GBP Q&A with pre-populated answers | 1.3 | 1 hour |
| 22 | Set up automated review request workflow in GHL | 1.3 | 1-2 hours |
| 23 | Create/claim listings on Panorama Firm, PKT.pl, Firmy.net | 1.3 | 2-3 hours |
| 24 | Implement internal linking plan | 1.2 | 2 hours |
| 25 | Implement Speakable markup on homepage and contact page | 2.2 | 1 hour |
| 26 | Write first 2 blog posts | 1.4 | 4-6 hours |
| 27 | Deploy Article schema on blog posts | 1.5 | 30 min |
| 28 | Set up Google Analytics 4 on GHL site | 5 | 1 hour |
| 29 | Add Person schema for each vet on /personel/ | 1.5 | 1 hour |
| 30 | Add "Ostatnia aktualizacja" timestamps to all pages | 3.8 | 1 hour |

## P2 — Nice to Have (Within 90 Days)

| # | Action | Section | Effort |
|---|--------|---------|--------|
| 31 | Expand rehab service pages to 1500-2500 words each | 3.4 | 3-4 hours/page |
| 32 | Write FAQ sections for all 10 rehab service pages | 2.1 | 5-8 hours |
| 33 | Create pricing ranges page or pricing sections on service pages | 3.2 | 2-3 hours |
| 34 | Produce practice tour video | 3.6 | Half day + editing |
| 35 | Create 2-3 patient success stories / case studies | 3.1 | 2-3 hours each |
| 36 | Create "10 Metod Rehabilitacji" infographic | 3.6 | 4-6 hours |
| 37 | Competitor analysis (benchmark 5 competitors) | 4 | 4-6 hours |
| 38 | Pursue backlink from Izba Lekarsko-Weterynaryjna | 3.3 | 1-2 hours |
| 39 | Pursue partnership with Schronisko dla Zwierzat Lodz | 3.7 | Ongoing |
| 40 | Set up Brand24 or Google Alerts for brand monitoring | 5 | 30 min |
| 41 | Pitch Blood Bank story to local Lodz media | 3.7 | 2-3 hours |
| 42 | Create/claim listings on remaining directories (P2 list) | 1.3 | 2-3 hours |
| 43 | MedicalOrganization supplementary schema | 1.5 | 30 min |
| 44 | Create YouTube channel + upload first video | 3.6 | 2-3 hours |
| 45 | Begin participating in Facebook pet groups | 3.7 | 30 min/week |
| 46 | Monthly GBP posts (ongoing) | 1.3 | 30 min/week |
| 47 | Bi-monthly blog posts (ongoing, per content calendar) | 1.4 | 3-4 hours/month |

---

# 7. Quick Wins

These 10 actions can be done immediately (or during migration) for the fastest SEO impact. They require minimal effort but deliver outsized results.

### 1. Claim and Verify Google Business Profile (if not already done)
**Impact:** Immediately appear in Google Maps and local pack for "weterynarz lodz."
**Effort:** 1 hour + verification wait (postcard or phone).
**Why it's fast:** GBP is the #1 local ranking factor. Without it, nothing else matters.

### 2. Deploy VeterinaryCare Schema on Homepage
**Impact:** Enable rich results (hours, rating, contact info in SERP). Help AI systems identify the entity.
**Effort:** 30 minutes (JSON-LD already drafted in seo-meta-tags.html).
**Why it's fast:** Copy-paste the prepared schema into GHL page head.

### 3. Add FAQ Sections to the 3 Highest-Value Pages
**Impact:** Trigger FAQ rich results in Google search. Provide content for AI assistants to cite.
**Effort:** 2-3 hours to write FAQs for /rehabilitacja/, /bank-krwi/, /uslugi/.
**Pages:** /rehabilitacja/ (8 Qs), /bank-krwi/ (8 Qs), /uslugi/ (8 Qs) + FAQPage schema.

### 4. Upload 20+ Real Photos to Google Business Profile
**Impact:** GBP listings with photos get 42% more direction requests and 35% more website clicks (Google data).
**Effort:** 1 hour to select and upload photos.
**Note:** Prioritize exterior, interior, team at work, equipment. Even smartphone photos are better than no photos.

### 5. Fix All Title Tags and Meta Descriptions Before Migration
**Impact:** Improved CTR from search results. Preserve ranking signals during migration.
**Effort:** Already done (seo-meta-tags.html is prepared). Just implement in GHL.

### 6. Set Up Google Search Console and Submit Sitemap
**Impact:** Google discovers and indexes the new GHL pages faster. Alerts you to crawl errors immediately.
**Effort:** 30 minutes.

### 7. Add tel: Links to All Phone Numbers
**Impact:** Mobile users can tap to call. Increases conversions. Google may show "Call" button in results.
**Effort:** 15 minutes.
**Implementation:** `<a href="tel:+48607250290">+48 607 250 290</a>` everywhere the phone number appears.

### 8. Pre-Populate GBP Q&A Section
**Impact:** Control the narrative. Prevent random users from posting misleading Q&A. Content appears in Google SERP.
**Effort:** 30-45 minutes.
**Content:** 10-15 questions covering hours, location, services, booking, emergency contact, parking, species treated.

### 9. Add Booking CTA to Every Page
**Impact:** Increases conversion rate from organic traffic. Every visitor is one click from booking.
**Effort:** 30 minutes (add a consistent CTA block to every GHL page footer/section).
**CTA:** "Umow wizyte online" button linking to /rezerwacja/ + phone number for those who prefer calling.

### 10. Request Reviews from 10 Recent Happy Clients
**Impact:** Reviews are a top-3 local ranking factor. Even 10 new 5-star reviews significantly improve local visibility.
**Effort:** 30 minutes to send personalized messages/emails to 10 recent clients.
**How:** Send a direct Google review link with a personal note: "Pani/Panie [Name], dziekujemy za wizyte z [Pet Name]. Bedzie nam bardzo milo, jesli podzieli sie Pan/Pani opinia: [link]."

---

# Appendix A: Full Keyword Research Matrix

This matrix should be expanded using Google Search Console data (once available) and Ahrefs/Semrush keyword research. Below is the starter matrix based on logical targeting.

| Keyword | Volume Est. | Difficulty | Intent | Target Page | Priority |
|---------|-----------|-----------|--------|-------------|----------|
| weterynarz lodz | High | Medium | Local/Transactional | Homepage | P0 |
| przychodnia weterynaryjna lodz | High | Medium | Local/Transactional | Homepage | P0 |
| rehabilitacja zwierzat lodz | Medium | Low | Local/Informational | /rehabilitacja/ | P0 |
| bank krwi dla zwierzat | Low | Very Low | Informational | /bank-krwi/ | P0 |
| weterynarz lodz retkinia | Low-Med | Low | Local/Transactional | Homepage, /kontakt/ | P0 |
| fizjoterapia zwierzat lodz | Low-Med | Low | Local/Informational | /rehabilitacja/ | P1 |
| zoofizjoterapia lodz | Low | Low | Local/Informational | /rehabilitacja/ | P1 |
| bieznia wodna dla psa | Low | Low | Informational | /services/bieznia-wodna/ | P1 |
| laseroterapia zwierzat | Low | Low | Informational | /services/laser-wysokoenergetyczny/ | P1 |
| weterynarz lodz sobota | Low | Low | Local/Transactional | /kontakt/ | P1 |
| ile kosztuje weterynarz lodz | Low | Low | Transactional | /uslugi/ | P1 |
| szczepienie psa lodz | Low-Med | Medium | Local/Transactional | /uslugi/ | P1 |
| czipowanie psa lodz | Low | Low | Local/Transactional | /uslugi/ | P1 |
| neurorehabilitacja zwierzat | Very Low | Very Low | Informational | /services/neurorehabiltacja-funkcjonalna/ | P2 |
| elektrostymulacja psa | Very Low | Very Low | Informational | /services/elektrostymulacja/ | P2 |
| masaz dla psa | Very Low | Very Low | Informational | /services/masaze/ | P2 |
| dobry weterynarz lodz | Low-Med | Medium | Local/Transactional | Homepage | P1 |
| weterynarz lodz opinie | Low | Medium | Local/Research | Homepage (reviews) | P1 |
| oddac krew psa lodz | Very Low | Very Low | Transactional | /bank-krwi/ | P1 |

---

# Appendix B: Schema Markup Deployment Checklist

| Page | Schema Types | Priority | Status |
|------|-------------|----------|--------|
| Homepage (/) | VeterinaryCare, WebSite, Speakable | P0 | To deploy |
| /uslugi/ | Service, FAQPage, BreadcrumbList | P1 | To deploy |
| /rehabilitacja/ | Service, FAQPage, BreadcrumbList, Speakable | P0 | To deploy |
| /bank-krwi/ | Service, FAQPage, BreadcrumbList, Speakable | P0 | To deploy |
| /personel/ | Person (x7), BreadcrumbList | P2 | To deploy |
| /kontakt/ | ContactPage, BreadcrumbList, Speakable | P1 | To deploy |
| /rezerwacja/ | WebPage, BreadcrumbList, Speakable | P1 | To deploy |
| /informacje-dla-wlascicieli/ | FAQPage, BreadcrumbList | P1 | To deploy |
| /services/* (x10) | Service, FAQPage, BreadcrumbList | P1 | To deploy |
| /blog/ | WebPage, BreadcrumbList | P1 | To deploy |
| Blog posts (each) | Article, BreadcrumbList | P1 | To deploy |
| All pages (global) | Organization (footer/sitewide) | P0 | To deploy |

---

# Appendix C: Monthly SEO Activity Calendar

| Week | Activity | Time Est. |
|------|----------|-----------|
| Week 1 | Write and publish 1 blog post | 2-3 hours |
| Week 1 | Publish 2 GBP posts (tip + promotion) | 30 min |
| Week 2 | Update 1 service page (content freshness) | 1-2 hours |
| Week 2 | Review and respond to all new Google reviews | 30 min |
| Week 3 | Write and publish 1 blog post | 2-3 hours |
| Week 3 | Upload 3-5 new photos to GBP | 15 min |
| Week 3 | Publish 2 GBP posts | 30 min |
| Week 4 | Monthly SEO reporting (GSC, GA4, GBP, rankings) | 1-2 hours |
| Week 4 | Review competitor activity | 30 min |
| Week 4 | Plan next month's content | 30 min |

**Total monthly time commitment: ~10-14 hours**

---

*This strategy document should be reviewed and updated quarterly to reflect changing search algorithms, new AI assistant capabilities, and shifts in the local competitive landscape.*

*Prepared for VetActive (Vet-Active Lodz) by the Avantwerk team.*
