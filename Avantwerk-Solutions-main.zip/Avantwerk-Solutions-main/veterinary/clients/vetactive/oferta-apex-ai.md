# Oferta Apex AI — Vet-Active Lodz
**Przygotowano przez:** Avantwerk
**Data:** 12 lutego 2026
**Pakiet:** Apex AI (kompleksowa transformacja cyfrowa)

---

## Podsumowanie

Proponujemy kompleksowa transformacje cyfrowa przychodni Vet-Active opartej na platformie GoHighLevel (GHL) — od nowej strony internetowej, przez automatyzacje marketingu, az po chatbota AI. Calosc zastepuje obecna strone WordPress i wtyczke Latepoint jednym, zintegrowanym systemem.

**Cena pakietu: 17 999 zl (jednorazowo)**
**Z subskrypcja roczna: 14 999 zl (oszczednosc 3 000 zl)**

---

## Co dzisiaj macie — analiza obecnej strony

| Element | Stan obecny | Ocena |
|---------|-------------|-------|
| Platforma | WordPress + Elementor + Yoast | Przestarzala, wolna, wymaga aktualizacji |
| Design | Szablon Elementor, niespojna stylistyka | 6/10 — funkcjonalna, ale nieatrakcyjna |
| Szybkosc ladowania | Ciezki JS, inline CSS, niezoptymalizowane grafiki | 4/10 — wolna, wplywa na SEO i konwersje |
| Strony uslug rehabilitacji (10) | **Tekst Lorem Ipsum** — brak tresci medycznych | 2/10 — puste strony, zmarnowany potencjal SEO |
| System rezerwacji | Latepoint — ukryty, niepromowany | 5/10 — brak integracji z CRM |
| Automatyzacja | Brak | 0/10 — zadnych automatycznych przypomnien, follow-upow |
| Email/SMS marketing | Brak | 0/10 — brak komunikacji po wizycie |
| Chatbot AI | Brak | 0/10 — brak automatycznej obslugi zapytan |
| CRM | Brak (lub zeszyt/Excel) | 0/10 — brak bazy pacjentow |
| Strony prawne (RODO) | Tylko polityka prywatnosci (podstawowa) | 3/10 — niezgodna z pelnym RODO |
| SEO zaawansowane | Yoast podstawowy, brak schema, AEO, GEO | 5/10 — podstawy sa, potencjal niewykorzystany |
| Certyfikaty zaufania | Brak opinii, certyfikatow, sygnalu E-E-A-T | 3/10 — brak social proof |

**Ogolna ocena obecnej strony: 6.4/10** — funkcjonalna, ale nie wykorzystuje potencjalu biznesowego.

---

## Co dostarczamy w pakiecie Apex AI

### 1. Nowa strona internetowa — 21+ stron

| Strona | Opis | Wartosc rynkowa* |
|--------|------|-----------------|
| Strona glowna | Kinematyczny design, animacje GSAP, sekcja hero z realnym zdjecie | 3 000 zl |
| Uslugi | Przeglad wszystkich uslug z nawigacja, 7 kategorii | 2 000 zl |
| Rehabilitacja (flagowa) | Dedykowana strona specjalizacji z 10 terapiami | 2 500 zl |
| 10x strony rehabilitacji | Indywidualne strony kazdej terapii z PRAWDZIWA trescia medyczna (zamiast Lorem Ipsum) | 10 000 zl |
| Bank Krwi | Dedykowana strona z linia alarmowa 24/7 | 1 500 zl |
| Zespol | Profile 7 czlonkow zespolu z kotwicami URL (301 redirect) | 2 000 zl |
| Kontakt | Mapa, godziny, formularz, media spolecznosciowe | 1 500 zl |
| Informacje dla wlascicieli | Kompletny poradnik — przygotowanie do wizyty, FAQ, pobranie materialow | 2 000 zl |
| Rezerwacja online | Zintegrowany kalendarz GHL (zastepuje Latepoint) | 1 500 zl |
| Blog + 2 artykuly | Listing + 2 zmigrowane artykuly z pelna trescia | 2 000 zl |
| 4 strony prawne (RODO) | Polityka prywatnosci, Warunki, Cookies, Podmiot odpowiedzialny | 4 000 zl |
| **Razem strona www** | | **32 000 zl** |

### 2. Automatyzacja marketingu — 10+ procesow

| Workflow | Opis | Wartosc* |
|----------|------|----------|
| Przypomnienie o wizycie | Potwierdzenie → 24h email → 2h SMS → podziekowanie po wizycie | 1 500 zl |
| Prosby o opinie | 48h po wizycie → email z prosba o Google review → follow-up | 1 000 zl |
| Przypomnienie o szczepieniu | 2 tyg. przed → email → 3 dni → SMS → 2 tyg. po terminie → final | 1 500 zl |
| Powitanie nowego klienta | Rejestracja → email powitalny + przewodnik pierwszej wizyty | 1 000 zl |
| Nurturing nowego klienta | Zapytanie bez rezerwacji → sekwencja 4 wiadomosci w 7 dni | 1 500 zl |
| Follow-up po operacji | Po zabiegu → 24h SMS → 3 dni email → 10 dni "jak sie czuje [imie]?" | 1 500 zl |
| Odzyskiwanie anulacji | Anulowana wizyta → 2h SMS → 24h email z linkiem do rezerwacji | 1 000 zl |
| Urodziny pupila | Automatyczne zyczenia + oferta badania profilaktycznego | 800 zl |
| Przypomnienia sezonowe | Kleszcze/pchly, sylwester, upal — kampanie sezonowe | 1 200 zl |
| Program polecen | Klient polecil kogos → podziekowanie + bonus lojalnosciowy | 1 000 zl |
| **Razem automatyzacja** | | **12 000 zl** |

### 3. Szablony email/SMS — 18+ sztuk

| Typ | Ilosc | Wartosc* |
|-----|-------|----------|
| Emaile transakcyjne (potwierdzenia, przypomnienia) | 6 | 2 400 zl |
| Emaile marketingowe (nurturing, follow-up, sezonowe) | 8 | 3 200 zl |
| SMS-y (przypomnienia, odzyskiwanie, urgentne) | 4+ | 1 200 zl |
| **Razem szablony** | **18+** | **6 800 zl** |

### 4. Chatbot AI (zaawansowany)

| Funkcja | Opis |
|---------|------|
| FAQ | Godziny, lokalizacja, parking, gatunki, ubezpieczenia |
| Rezerwacja | Kierowanie do kalendarza online z dopasowaniem specjalizacji |
| Triaz pilnosci | "Czy to nagly przypadek?" → przekierowanie na linie alarmowa |
| Informacje o uslugach | "Ile kosztuje kastracja?", "Czy leczycie kroliki?" |
| Obsluga wielu zwierzat | "Chce umowic Maxa i Belle" |
| Obsluga pooperacyjna | Ankiety sprawdzajace po wizycie |
| Przekierowanie do specjalisty | Automatyczne kierowanie do lekarza wg gatunku/schorzenia |

**Wartosc rynkowa chatbota AI: 8 000 — 15 000 zl**

### 5. System CRM (GoHighLevel)

| Funkcja | Zastepuje |
|---------|-----------|
| Baza pacjentow/wlascicieli | Zeszyt / Excel / brak |
| Historia wizyt i komunikacji | Brak |
| Segmentacja (gatunek, usluga, wartosc) | Brak |
| Pipeline sprzedazowy | Brak |
| Kalendarz online z automatycznym potwierdzeniem | Latepoint (ograniczony) |
| Chat widget na stronie | Brak |
| Raportowanie i analityka | Brak |

**Wartosc rynkowa wdrozenia CRM: 5 000 — 8 000 zl**

### 6. SEO / AEO / GEO — strategia i wdrozenie

| Element | Obecny stan | Po wdrozeniu |
|---------|-------------|--------------|
| Meta tagi | Podstawowe (Yoast) | Zoptymalizowane per strona + Open Graph |
| Schema markup | Brak | VeterinaryCare JSON-LD, FAQ schema, LocalBusiness |
| Migracja URL | n/d | 28 URL zachowanych, 301 redirecty, zero utraty pozycji |
| Tresc medyczna | Lorem Ipsum na 10 stronach | Pelna, unikalna tresc na kazdej stronie |
| AEO (Answer Engine) | Brak | Sekcje FAQ, speakable markup, entity-first content |
| GEO (Generative Engine) | Brak | E-E-A-T sygnaly, tresc cytowalna przez AI |
| robots.txt | WordPress default | Zoptymalizowany dla GHL |
| Sitemap | Yoast auto | Nowa, czysta mapa witryny |

**Wartosc rynkowa strategii SEO/AEO/GEO: 6 000 — 12 000 zl**

### 7. Dodatkowe elementy Apex AI

| Element | Opis | Wartosc* |
|---------|------|----------|
| Brand kit | Kompletna identyfikacja wizualna (kolory, typografia, komponenty) | 3 000 zl |
| Migracja SEO | Plan 301 redirectow, monitoring 30 dni | 3 000 zl |
| Szkolenie zespolu | 1h sesja wideo (obsluga GHL, kalendarz, CRM) | 1 500 zl |
| Hypercare 30 dni | Priorytetowe wsparcie, poprawki, monitoring | 3 000 zl |
| Dashboard raportowy | Konfiguracja raportow w GHL | 2 000 zl |
| **Razem dodatkowe** | | **12 500 zl** |

---

## Podsumowanie wartosci

| Komponent | Wartosc rynkowa* |
|-----------|-----------------|
| Strona internetowa (21+ stron) | 32 000 zl |
| Automatyzacja marketingu (10+ workflows) | 12 000 zl |
| Szablony email/SMS (18+) | 6 800 zl |
| Chatbot AI (zaawansowany) | 12 000 zl |
| Wdrozenie CRM (GoHighLevel) | 6 500 zl |
| Strategia SEO/AEO/GEO | 9 000 zl |
| Dodatkowe (brand kit, migracja, szkolenie, hypercare) | 12 500 zl |
| **Laczna wartosc rynkowa** | **~90 800 zl** |

### Cena pakietu Apex AI: 17 999 zl (lub 14 999 zl z subskrypcja roczna)

**Oszczednosc: ponad 72 000 zl (~80% ponizej wartosci rynkowej)**

> *Wartosci rynkowe oszacowane na podstawie srednich cen agencji digitalowych w Polsce (2025-2026) za porownywalne uslugi zamawiane indywidualnie.

---

## Kluczowe ulepszenia vs obecna strona

| Aspekt | Teraz | Po wdrozeniu Apex AI |
|--------|-------|---------------------|
| **Design** | Szablon Elementor (6/10) | Kinematyczny, premium design z animacjami (9/10) |
| **Szybkosc** | Wolna — ciezki WordPress (4/10) | Szybka — lekki HTML na GHL CDN (9/10) |
| **Tresc rehab** | Lorem Ipsum (!) | Pelna tresc medyczna kazdej z 10 terapii |
| **Rezerwacja** | Latepoint (ukryty) | GHL kalendarz + automatyczne potwierdzenia |
| **Po wizycie** | Cisza | Automatyczne przypomnienia, follow-upy, prosby o opinie |
| **Nowi klienci** | Formularz kontaktowy | AI chatbot + nurturing emailowy + welcome sequence |
| **Odzyskiwanie** | Brak | Auto-SMS i email po anulacji |
| **RODO** | 1 podstawowa strona | 4 kompletne strony prawne + Podmiot Odpowiedzialny |
| **SEO** | Podstawowy Yoast | Schema, AEO, GEO, 301 migracja, meta per strona |
| **Zaufanie** | Brak opinii na stronie | Sekcja testimoniali, sygnaly E-E-A-T |
| **Mobile** | OK (Elementor responsive) | Zoptymalizowany od podstaw (320px+) |
| **Analityka** | Google Analytics | GA + GHL dashboard + raportowanie CRM |

---

## Subskrypcja GHL (miesieczna, oddzielnie)

Platforma GoHighLevel wymaga miesiecznej subskrypcji. Rekomendacja:

| Plan | Cena miesieczna | Cena roczna (2 mies. gratis) | Uwagi |
|------|----------------|------------------------------|-------|
| **Core (5 uzytkownikow)** | do uzgodnienia | do uzgodnienia | Wystarczajacy dla Vet-Active |

*Szczegoly subskrypcji do omowienia — zalezne od liczby uzytkownikow i wolumenu SMS/email.*

---

## Harmonogram wdrozenia

| Tydzien | Etap |
|---------|------|
| 1-2 | Konfiguracja GHL, migracja domeny, wdrozenie strony www |
| 2-3 | Konfiguracja kalendarza, formularzy, CRM |
| 3-4 | Wdrozenie workflowow i szablonow email/SMS |
| 4-5 | Konfiguracja chatbota AI, testy |
| 5-6 | Migracja DNS, uruchomienie produkcyjne, testy 301 |
| 6-8 | Hypercare — monitoring SEO, poprawki, szkolenie |

**Termin realizacji: 45-60 dni od akceptacji oferty**

---

## Co potrzebujemy od Panstwa

- [ ] NIP i REGON (do stron prawnych)
- [ ] Numer wpisu do Izby Lekarsko-Weterynaryjnej
- [ ] Dane ubezpieczenia OC (ubezpieczyciel, numer polisy, okres)
- [ ] Potwierdzenie ról zespolu i ewentualne korekty
- [ ] Aktualne zdjecia zespolu (opcjonalnie — mozemy uzywac obecnych)
- [ ] Zdjecia sprzetu rehabilitacyjnego (opcjonalnie)
- [ ] Dostep do Google Search Console (do monitorowania migracji)
- [ ] Dostep do obecnego hostingu/domeny (do przekierowania DNS)

---

## Nastepne kroki

1. **Akceptacja oferty** — podpisanie umowy
2. **Przekazanie danych** — checklist powyzej
3. **Kick-off** — 1h rozmowa video (cel, priorytety, preferencje)
4. **Wdrozenie** — 45-60 dni
5. **Go-live** — uruchomienie + 30 dni hypercare

---

*Avantwerk — avantwerk.com*
*Kontakt: b.kubas@bennovate.com*
