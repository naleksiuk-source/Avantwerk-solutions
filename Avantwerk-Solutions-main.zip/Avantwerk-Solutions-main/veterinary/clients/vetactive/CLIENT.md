# VetActive — Client Configuration

## Business Details
- **Practice Name:** Vet-Active
- **Legal Name:** [TO CONFIRM — check KRS/CEIDG]
- **Type:** Przychodnia weterynaryjna (Veterinary Clinic)
- **Specialization:** Rehabilitacja zwierząt (Animal Rehabilitation) + Bank Krwi (Blood Bank)
- **NIP:** [TO CONFIRM]
- **REGON:** [TO CONFIRM]

## Contact
- **Address:** ul. Batalionów Chłopskich 12, Łódź
- **District:** Retkinia
- **Phone:** +48 607 250 290
- **Email:** vetactivelodz@gmail.com
- **Website (current):** https://vetactive.pl/

## Opening Hours
| Day | Hours |
|-----|-------|
| Poniedziałek | 9:00 – 20:00 |
| Wtorek | 9:00 – 20:00 |
| Środa | 9:00 – 20:00 |
| Czwartek | 9:00 – 20:00 |
| Piątek | 9:00 – 20:00 |
| Sobota | 9:00 – 15:00 |
| Niedziela | Zamknięte |

## Team
| Name | Role | Slug (old URL) |
|------|------|----------------|
| Ewelina Romańska | Lekarz weterynarii | ewelina-romanska |
| Katarzyna Kubiak | Lekarz weterynarii | katarzyna-kubiak |
| Ewa Andrzejczak | Lekarz weterynarii | ewa-andrzejczak |
| Kinga Michalak | Lekarz weterynarii | kinga-michalak |
| Edyta Młynarczyk | Pomoc lekarza (Asystent) | edyta-mlynarczyk |
| Beata Markowska | Zoofizjoterapeutka | beata-markowska |
| Agata Lamus | Zoofizjoterapeutka | agata-lamus |

## Social Media
- **Facebook:** https://facebook.com/przychodniavetactive/
- **Instagram:** https://instagram.com/vetactive_lodz/

## Services

### General Veterinary
- Profilaktyka i leczenie psów i kotów
- Szczepienia
- Czipowanie (identyfikacja elektroniczna)
- Paszporty dla zwierząt
- Zabiegi pielęgnacyjne
- Chirurgia tkanek miękkich
- Diagnostyka (morfologia, biochemia, USG, RTG)
- Stomatologia weterynaryjna (skaler do usuwania kamienia)
- Endoskopia

### Rehabilitation (Flagship — 10 therapies)
| Service | Polish Name | URL slug |
|---------|-------------|----------|
| High-energy laser | Laser wysokoenergetyczny | laser-wysokoenergetyczny |
| Low-energy laser | Laser niskoenergetyczny | laser-niskoenergetyczny |
| Dry treadmill | Bieżnia sucha | bieznia-sucha |
| Water treadmill | Bieżnia wodna | bieznia-wodna |
| Magnetic field therapy | Pole magnetyczne | pole-magnetyczne |
| Ultrasound therapy | Ultradźwięki | ultradzwieki |
| Electrostimulation | Elektrostymulacja | elektrostymulacja |
| Functional neurorehab | Neurorehabilitacja funkcjonalna | neurorehabiltacja-funkcjonalna |
| Massage therapy | Masaże | masaze |
| Scar therapy | Terapia blizny | terapia-blizny |

### Blood Bank
- Bank Krwi (Blood Bank) — dedicated service

## Specialists Available (referral network)
- Radiolog
- Neurolog
- Dermatolog
- Gastroenterolog
- Hematolog

## Brand Override
```css
--va-primary: #059669;           /* Warm green — caring, natural */
--va-primary-hover: #047857;
--va-secondary: #f59e0b;         /* Amber accent */
--va-secondary-hover: #d97706;
--va-bg-page: #fffbeb;           /* Warm white */
--va-bg-section: #ffffff;        /* Clean white */
--va-bg-section-alt: #f0fdf4;   /* Very light green */
--va-bg-card: #fef3c7;          /* Warm card */
--va-text-heading: #0f172a;      /* Navy */
--va-text-body: #475569;         /* Medium gray */
--va-text-muted: #94a3b8;        /* Light gray */
--va-accent-star: #f59e0b;       /* Rating/review stars */
--va-radius-sm: 8px;
--va-radius-md: 12px;
--va-radius-lg: 16px;
--va-radius-xl: 24px;
--va-radius-2xl: 32px;
```

## Package Tier
- **Apex AI** (17,999 zł)
- 10+ pages, 10+ workflows, 18+ templates
- Full website rebuild with SEO preservation
- Individual rehabilitation service pages
- Advanced booking integration (GHL calendar replacing Latepoint)
- Blog migration + expansion

## SEO Migration Notes
- **Domain stays:** vetactive.pl
- **All existing URLs must be preserved** — see `301-redirects.md`
- **Current CMS:** WordPress + Elementor + Yoast SEO
- **Target CMS:** GHL (GoHighLevel)
- **Google Search Console:** Must update sitemap after migration
- **Key ranking terms:** [TO RESEARCH — check GSC data if available]

## GHL Sub-Account
- **Name:** [TO CREATE] — "VetActive — Łódź"
- **Snapshot:** Veterinary PL template
- **Calendar widget:** Replace Latepoint booking with GHL calendar
- **Chat widget:** Enable AI chatbot (Apex tier)

## Photos Needed
- [ ] Practice exterior
- [ ] Reception/waiting area
- [ ] Treatment rooms
- [ ] Rehabilitation equipment (each of the 10 therapies)
- [ ] Team photos (individual headshots + group)
- [ ] Happy patients (with owner permission)
- Until provided: use Pexels stock photos with animal/vet themes
