# Veterinary — Deliverables by Package Tier

## Ignite AI — £1,999 / 8,999 zł
**Delivery: 14 days | Hypercare: 7 days**

### Website (3 pages)
- Homepage (hero, services overview, emergency banner, booking CTA, testimonials)
- Services page (consultations, vaccinations, surgery, dental, diagnostics)
- Booking page (embedded GHL calendar widget)

### Workflows (2)
- **Appointment reminder**: booking confirmed → 24h SMS (with pet name) → 2h SMS → post-visit thank you
- **Review request**: 48h after appointment → email asking for Google review → 5-day follow-up

### Emails/SMS (3)
- Appointment confirmation with pet name (email)
- 24h reminder (SMS)
- Review request (email)

### AI Chatbot
- FAQ bot: opening hours, location, parking, emergency/OOH contact, species treated
- Booking redirect: guides to online booking page
- Emergency triage: "is this an emergency?" → redirect to emergency line

---

## Elevate AI — £2,499 / 11,499 zł
**Delivery: 21 days | Hypercare: 14 days**

### Website (5 pages)
- Everything in Ignite AI, plus:
- About page (practice story, team/vet bios with specialties, values)
- Contact page (form, map, phone, emergency number, WhatsApp)

### Workflows (4)
- Everything in Ignite AI, plus:
- **Vaccination recall**: booster due date - 2 weeks → email → due date - 3 days → SMS → overdue + 2 weeks → final email
- **New client welcome**: registration → welcome email with first-visit guide + pet registration form link

### Emails/SMS (7)
- Everything in Ignite AI, plus:
- Vaccination recall sequence (2 emails + 1 SMS)
- New client welcome (email)

### AI Chatbot
- Everything in Ignite AI, plus:
- Service info: "how much to neuter a cat?", "do you treat rabbits?"
- New client guidance: what to bring, pet registration process
- Basic triage: symptom questions to determine urgency level

---

## Momentum AI ★ — £2,999 / 13,999 zł (Most Popular)
**Delivery: 30 days | Hypercare: 21 days**

### Website (7+ pages)
- Everything in Elevate AI, plus:
- Pet Health Plans page (subscription plans with comparison table)
- Emergency / Out-of-Hours page (when to call, what to expect)
- Client testimonials / pet stories page
- Blog/advice section (3 seed articles: puppy vaccinations, dental care, seasonal hazards)

### Workflows (7)
- Everything in Elevate AI, plus:
- **New client nurture**: enquiry → 1h email → 24h SMS → 3-day email with new-client offer → 7-day final
- **Post-surgery follow-up**: surgery completed → 24h check-in SMS → 3-day email with care instructions → 10-day "how is [PET_NAME]?"
- **Cancellation recovery**: cancelled → 2h SMS with rebooking link → 24h email

### Emails/SMS (12)
- Everything in Elevate AI, plus:
- New client nurture sequence (3 emails + 1 SMS)
- Post-surgery follow-up (1 email + 2 SMS)
- Cancellation recovery (1 email + 1 SMS)

### AI Chatbot
- Everything in Elevate AI, plus:
- Full client journey: booking, rescheduling, cancellation for multiple pets
- Pet Health Plan enquiries: explain plans, compare tiers, redirect to sign-up
- Enhanced triage: multi-step symptom assessment with urgency scoring
- Species-specific responses (cats, dogs, rabbits, etc.)

---

## Apex AI — £3,999 / 17,999 zł
**Delivery: 45-60 days | Hypercare: 30 days**

### Website (10+ pages)
- Everything in Momentum AI, plus:
- Individual service category pages (surgery, dental, diagnostics, preventive care)
- Team individual profile pages with specialties
- FAQ page (structured for SEO)
- Pet advice hub / resource centre
- Multi-location support (if applicable)

### Workflows (10+)
- Everything in Momentum AI, plus:
- **Pet birthday**: automated birthday message for registered pets → optional wellness check offer
- **Seasonal reminders**: flea/tick season, fireworks anxiety, heatstroke warnings (scheduled campaigns)
- **Referral program**: client referred someone → thank you email + loyalty credit
- **Pet Health Plan renewal**: annual renewal approaching → email → renewal confirmation

### Emails/SMS (18+)
- Everything in Momentum AI, plus:
- Pet birthday (email)
- Seasonal campaign templates (4 emails)
- Referral thank you (email)
- Health plan renewal (email + SMS)

### AI Chatbot
- Everything in Momentum AI, plus:
- Multi-pet management: "I need to book for both Max and Bella"
- Integration with PMS for appointment availability
- Post-visit survey collection via chat
- Handoff to specific vets based on species/condition

### Additional
- Custom reporting dashboard setup in GHL
- Priority 30-day hypercare with dedicated support
- Staff training session (1h video call)

---

## Standard Legal Pages (ALL tiers)

The following 4 legal/footer pages are included with EVERY package tier at no additional page count. They are required for GDPR/RODO compliance and proper business disclosure.

### Pages
1. **Polityka Prywatności** (`/polityka-prywatnosci/`) — Privacy Policy, GDPR/RODO compliant, covers animal owner data + animal medical records
2. **Warunki Użytkowania** (`/warunki-uzytkowania/`) — Terms of Use, covers website use, online booking rules, cancellation policy, intellectual property
3. **Polityka Cookies** (`/polityka-cookies/`) — Cookie Policy, detailed cookie inventory (essential, analytics, functional, marketing), consent mechanism
4. **Podmiot Odpowiedzialny** (`/podmiot-odpowiedzialny/`) — Legal Entity / Impressum, business registration, Izba Lekarsko-Weterynaryjna, insurance, hosting info (GHL), copyright (Avantwerk)

### Notes
- These pages are NOT counted toward the package page quota (e.g., Ignite "3 pages" means 3 functional pages + 4 legal pages)
- All pages cross-link to each other
- Set to `noindex, follow` in meta robots (except podmiot-odpowiedzialny which can be indexed)
- Podmiot Odpowiedzialny must include: Avantwerk credit (copyright section) + GHL hosting disclosure (GDPR requirement for US-based data processor)
- Placeholder fields: [NIP], [REGON], [NUMER WPISU], [UBEZPIECZYCIEL], [NUMER POLISY], [DATA OD], [DATA DO]
- Veterinary regulatory bodies (PL): Okręgowa Izba Lekarsko-Weterynaryjna, Powiatowy Lekarz Weterynarii, Wojewódzki Inspektorat Weterynarii
- Veterinary regulatory bodies (UK): RCVS, VMD, ICO
