# Veterinary Industry Brief

## Overview
Veterinary practices handle high emotional stakes (pet owners), complex scheduling (multiple vets, species, procedures), and growing demand for 24/7 accessibility. Pet ownership surged post-COVID, creating capacity pressure. AI automation reduces admin burden and improves client communication during stressful pet health situations.

## Target Niches
- General / companion animal practice (cats, dogs)
- Emergency / out-of-hours veterinary
- Specialist referral clinics (ortho, cardio, oncology)
- Farm / large animal (equine, livestock)
- Exotic pets
- Mobile / house-call vets

## Common Pain Points
| Pain Point | Impact | Avantwerk Solution |
|-----------|--------|-------------------|
| Phone overwhelm | Peak hours = missed calls, frustrated pet owners | AI chatbot for triage, booking, FAQ |
| No-shows | £100-250 lost per empty slot | Automated reminders with pet name personalization |
| Vaccination recall | Pets missing annual boosters = lost revenue + risk | Automated recall sequences by pet/vaccine due date |
| Emergency triage | Reception can't assess urgency by phone | AI chatbot with triage questions, urgent flagging |
| Post-op follow-up | Manual calls to check on patients | Automated check-in sequences post-procedure |
| New client registration | Long forms at reception, delays | Online pre-registration form + automated welcome |
| Review collection | Pet owners share experiences but aren't prompted | Post-visit review request (timed after positive outcomes) |

## Key Services (for website/chatbot)

### UK
- Consultation: £40-70
- Vaccination (primary course): £60-80
- Annual Booster: £40-55
- Neutering (cat): £80-150 / (dog): £150-350
- Dental Scale & Polish: £200-400
- X-Ray: £150-300
- Blood Test: £80-150
- Emergency Consultation: £150-300 (OOH surcharge)
- Microchipping: £15-25
- Pet Health Plan (monthly): £10-25

### Poland (PL)
- Konsultacja: 100-200 zł
- Szczepienie (kurs podstawowy): 80-150 zł
- Szczepienie przypominające: 60-120 zł
- Kastracja (kot): 200-400 zł / (pies): 400-1,000 zł
- Scaling zębów: 400-800 zł
- RTG: 100-250 zł
- Badanie krwi: 100-300 zł
- Wizyta nagła: 200-500 zł
- Mikrochip: 50-100 zł
- Plan zdrowotny (miesięcznie): 50-120 zł

## Industry Terminology

### UK English
| Term | Usage |
|------|-------|
| Practice / Surgery | The vet clinic |
| Consult / Consultation | Standard vet appointment |
| OOH | Out of hours (emergency) |
| Booster | Annual vaccination reminder |
| Neuter / Spay | Sterilisation procedures |
| PTS | Put to sleep (euthanasia) |
| Referral | Sent to specialist clinic |
| Pet Health Plan / Wellness Plan | Monthly subscription for preventive care |
| RCVS | Royal College of Veterinary Surgeons (regulator) |

### Polish
| Term | Usage |
|------|-------|
| Klinika weterynaryjna / Gabinet | Vet clinic |
| Wizyta / Konsultacja | Standard appointment |
| Dyżur nocny | Out of hours / night duty |
| Szczepienie przypominające | Booster vaccination |
| Kastracja / Sterylizacja | Neutering |
| Eutanazja | Euthanasia |
| Skierowanie do specjalisty | Referral |
| Pakiet profilaktyczny | Wellness plan |
| Izba Lekarsko-Weterynaryjna | Veterinary Chamber (regulator) |

## Compliance Notes
- **UK**: RCVS Practice Standards Scheme, Veterinary Medicines Regulations, no advertising prescription-only medicines
- **PL**: Izba Lekarsko-Weterynaryjna regulations, EU veterinary medicine directives
- Pet health data less regulated than human health data but still under GDPR (pet owner = data subject)
- Cannot give veterinary medical advice through chatbot — must triage and refer to vet

## Competitive Landscape
- Main PMS: Vet-AI, RoboVet, Merlin (UK); Vet-Manager, Klinika XP (PL)
- Pet health plans growing rapidly (Healthy Pets Club model)
- Very few practices have AI chatbots — massive gap especially for emergency triage
- Post-COVID pet boom means practices are overloaded — automation is welcome
