# Dental Industry Brief

## Overview
Dental practices are high-volume appointment businesses with strong recurring revenue (check-ups every 6 months). They suffer from high no-show rates, poor recall compliance, and manual admin that consumes reception staff time. AI automation has immediate, measurable ROI.

## Target Niches
- General dentistry (family practices)
- Orthodontics (braces, aligners)
- Cosmetic dentistry (veneers, whitening)
- Pediatric dentistry
- Emergency / walk-in dental
- Dental implant clinics

## Common Pain Points
| Pain Point | Impact | Avantwerk Solution |
|-----------|--------|-------------------|
| No-shows | £150-300 lost per empty slot | Automated SMS/email reminders (24h + 2h before) |
| Recall lapses | 30-40% of patients miss 6-month check-up | AI-powered recall sequences with escalating urgency |
| Low Google reviews | Under 4.5 stars = losing to competitors | Automated review request after positive visits |
| Phone overload | Reception can't answer during treatments | AI chatbot handles booking, FAQ, directions |
| Manual booking | Staff spending 2-3h/day on phone scheduling | Online booking widget + confirmation automation |
| New patient dropout | 50% enquiry-to-booking conversion | Nurture sequence: enquiry → follow-up → booking |
| Cancellation gaps | Empty slots not refilled | Cancellation recovery workflow with waitlist |

## Key Services (for website/chatbot)

### UK
- Check-up & Clean: £50-80
- Dental Hygiene: £55-75
- Teeth Whitening: £300-600
- Composite Bonding: £200-400 per tooth
- Dental Implants: £2,000-3,000 per tooth
- Invisalign / Clear Aligners: £2,500-5,500
- Root Canal Treatment: £250-600
- Crown: £400-700
- Emergency Appointment: £80-150

### Poland (PL)
- Przegląd i czyszczenie: 150-250 zł
- Higienizacja: 200-350 zł
- Wybielanie zębów: 800-1,500 zł
- Bonding kompozytowy: 300-800 zł / ząb
- Implant: 3,000-6,000 zł / ząb
- Nakładki prostujące: 6,000-15,000 zł
- Leczenie kanałowe: 400-1,000 zł
- Korona: 800-1,500 zł
- Wizyta nagła: 150-300 zł

## Industry Terminology

### UK English
| Term | Usage |
|------|-------|
| Surgery / Practice | The dental clinic |
| Reception | Front desk |
| Recall | 6-month check-up reminder system |
| Hygienist | Dental hygienist appointment |
| Chair time | Billable treatment time |
| FTA / DNA | Failed to attend / Did not attend (no-show) |
| NHS / Private | National Health vs private patients |
| Treatment plan | Proposed treatment with costs |

### Polish
| Term | Usage |
|------|-------|
| Gabinet stomatologiczny | Dental clinic |
| Rejestracja | Reception / front desk |
| Wizyta kontrolna | Check-up / recall |
| Higienistka | Dental hygienist |
| NFZ / Prywatnie | Public health vs private patients |
| Plan leczenia | Treatment plan |
| Znieczulenie | Anaesthesia |
| Protetyka | Prosthetics (crowns, bridges) |

## Compliance Notes
- **UK**: CQC registered, GDC (General Dental Council) standards, NHS contract rules if applicable
- **PL**: NFZ contracts (public), Izba Lekarska (Medical Chamber), patient data under EU GDPR
- Dental practices handle sensitive health data — extra GDPR care required
- Marketing claims about treatments must be factual and not misleading (ASA/CAP Code UK, UOKiK PL)

## Competitive Landscape
- Many practices still use paper recall systems or basic practice management software
- Main PMS competitors: Dentally, SOE, Carestream (UK); Mediporta, KS-Medis (PL)
- Few have AI chatbots or automated patient journeys — strong differentiator
