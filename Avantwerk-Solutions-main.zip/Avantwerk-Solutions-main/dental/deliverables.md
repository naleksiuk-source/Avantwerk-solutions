# Dental — Deliverables by Package Tier

## Ignite AI — £1,999 / 8,999 zł
**Delivery: 14 days | Hypercare: 7 days**

### Website (3 pages)
- Homepage (hero, services overview, booking CTA, testimonials, map)
- Services page (treatment list with descriptions and price ranges)
- Booking page (embedded GHL calendar widget)

### Workflows (2)
- **Appointment reminder**: booking confirmed → 24h SMS → 2h SMS → post-visit thank you
- **Review request**: 24h after appointment → email asking for Google review → 3-day follow-up if not clicked

### Emails/SMS (3)
- Appointment confirmation (email)
- 24h reminder (SMS)
- Review request (email)

### AI Chatbot
- FAQ bot: opening hours, location, parking, accepted insurance/NHS, emergency contact
- Booking redirect: guides to online booking page

---

## Elevate AI — £2,499 / 11,499 zł
**Delivery: 21 days | Hypercare: 14 days**

### Website (5 pages)
- Everything in Ignite AI, plus:
- About page (practice story, team bios, values)
- Contact page (form, map, phone, WhatsApp)

### Workflows (4)
- Everything in Ignite AI, plus:
- **Recall reminder**: 5.5 months after last check-up → email → 2 weeks later SMS → 1 month later final email
- **New patient welcome**: registration → welcome email with what-to-expect guide → 48h follow-up

### Emails/SMS (6)
- Everything in Ignite AI, plus:
- Recall reminder sequence (2 emails + 1 SMS)

### AI Chatbot
- Everything in Ignite AI, plus:
- Treatment info: can answer "how much is whitening?", "do you do implants?"
- New patient guidance: what to bring, first visit process

---

## Momentum AI ★ — £2,999 / 13,999 zł (Most Popular)
**Delivery: 30 days | Hypercare: 21 days**

### Website (7+ pages)
- Everything in Elevate AI, plus:
- Individual treatment pages (whitening, implants, Invisalign — top 3 by revenue)
- Patient reviews/testimonials page
- Blog/news section (3 seed articles)

### Workflows (6)
- Everything in Elevate AI, plus:
- **New patient nurture**: enquiry (no booking) → 1h email → 24h SMS → 3-day email with offer → 7-day final
- **Cancellation recovery**: cancelled appointment → 1h SMS with rebooking link → 24h email → waitlist fill

### Emails/SMS (10)
- Everything in Elevate AI, plus:
- New patient nurture sequence (3 emails + 1 SMS)
- Cancellation recovery (1 email + 1 SMS)

### AI Chatbot
- Everything in Elevate AI, plus:
- Full patient journey: can handle booking, rescheduling, cancellation
- Treatment recommendations: "I have a toothache" → triage to emergency or routine
- Insurance/NHS questions

---

## Apex AI — £3,999 / 17,999 zł
**Delivery: 45-60 days | Hypercare: 30 days**

### Website (10+ pages)
- Everything in Momentum AI, plus:
- All treatment category pages (full service catalogue)
- Team individual profile pages
- FAQ page (structured for SEO)
- Multi-location support (if applicable)

### Workflows (8+)
- Everything in Momentum AI, plus:
- **Birthday/loyalty**: automated birthday greeting → special offer
- **Treatment plan follow-up**: after treatment plan presented → 48h check-in → 7-day reminder → 30-day re-engage
- **Referral program**: patient referred someone → thank you + reward tracking

### Emails/SMS (15+)
- Everything in Momentum AI, plus:
- Birthday greeting (email)
- Treatment plan follow-up sequence (3 emails)
- Referral thank you (email)

### AI Chatbot
- Everything in Momentum AI, plus:
- Multi-language support (if multi-market practice)
- Handoff to specific team members based on enquiry type
- Post-treatment check-in via chat
- Integration with practice management system (custom setup)

### Additional
- Custom reporting dashboard setup in GHL
- Priority 30-day hypercare with dedicated support
- Staff training session (1h video call)

---

## Standard Legal Pages (ALL tiers)

The following 4 legal/footer pages are included with EVERY package tier at no additional page count. They are required for GDPR/RODO compliance and proper business disclosure.

### Pages
1. **Polityka Prywatności** (`/polityka-prywatnosci/`) — Privacy Policy, GDPR/RODO compliant, covers patient data + medical records
2. **Warunki Użytkowania** (`/warunki-uzytkowania/`) — Terms of Use, covers website use, online booking rules, cancellation policy, intellectual property
3. **Polityka Cookies** (`/polityka-cookies/`) — Cookie Policy, detailed cookie inventory (essential, analytics, functional, marketing), consent mechanism
4. **Podmiot Odpowiedzialny** (`/podmiot-odpowiedzialny/`) — Legal Entity / Impressum, business registration, Izba Lekarska, insurance, hosting info (GHL), copyright (Avantwerk)

### Notes
- These pages are NOT counted toward the package page quota (e.g., Ignite "3 pages" means 3 functional pages + 4 legal pages)
- All pages cross-link to each other
- Set to `noindex, follow` in meta robots (except podmiot-odpowiedzialny which can be indexed)
- Podmiot Odpowiedzialny must include: Avantwerk credit (copyright section) + GHL hosting disclosure (GDPR requirement for US-based data processor)
- Placeholder fields: [NIP], [REGON], [NUMER WPISU], [UBEZPIECZYCIEL], [NUMER POLISY], [DATA OD], [DATA DO]
- Dental regulatory bodies (PL): Okręgowa Izba Lekarska, Wojewódzki Inspektor Sanitarny, Rzecznik Praw Pacjenta
- Dental regulatory bodies (UK): GDC, CQC, ICO
