# Cancellation Recovery

**Package tier**: Momentum AI
**Trigger**: Appointment cancelled by patient (GHL appointment status changed to "cancelled")
**Goal**: Recover 25%+ of cancelled appointments through rebooking and fill 50%+ of vacated slots via waitlist

## Pipeline & Tags

- Pipeline: Cancellation Recovery
- Entry tag: `appointment-cancelled`
- Completion tag: `cancellation-recovered` or `cancellation-recovery-complete`
- Additional tags: `recovery-sms-sent`, `recovery-email-sent`, `waitlist-notified`, `cancellation-rebooked`
- Custom fields used:
  - `{{contact.first_name}}` — patient first name
  - `{{contact.email}}` — patient email address
  - `{{contact.phone}}` — patient mobile number
  - `{{appointment.start_time}}` — original appointment date/time
  - `{{appointment.calendar_name}}` — appointment type
  - `{{custom_field.cancellation_reason}}` — reason for cancellation (if captured)
  - `{{location.name}}` — practice name
  - `{{location.phone}}` — practice phone number
  - `{{location.booking_link}}` — online booking URL

## Flow

1. **Trigger**: Appointment status changed to "Cancelled"
   - Fires when: patient cancels via phone, online portal, SMS reply, or receptionist marks as cancelled
   - Add tag: `appointment-cancelled`
   - Move to pipeline stage: **Cancelled**

2. **Condition**: Check cancellation timing
   - **If appointment was within the next 2 hours** (very short notice): Skip patient outreach, go directly to Step 9 (waitlist fill) -- too late for nurturing, focus on filling the slot
   - **If appointment is more than 2 hours away**: Continue to Step 3

3. **Condition**: Check if patient has already rebooked (sometimes patients cancel and immediately rebook a different time)
   - **If new appointment already exists**: Add tag `cancellation-rebooked`, exit workflow
   - **If no new appointment**: Continue

4. **Wait**: 1 hour after cancellation
   - Brief pause to avoid feeling aggressive. Also allows reception to handle if they want to call first.
   - If 1h falls outside business hours (before 8:00 or after 20:00), send at next 09:00

5. **Action**: Send rebooking SMS (immediate, direct channel)
   - Template: `emails/uk/cancellation-recovery-sms.txt`
   - Message: "Hi {{contact.first_name}}, we're sorry you had to cancel your appointment at {{location.name}}. We'd love to get you rebooked -- choose a new time: {{location.booking_link}} or call {{location.phone}}."
   - Respect business hours: 08:00-20:00 UK time
   - Add tag: `recovery-sms-sent`
   - Type: **Transactional** (related to an existing service relationship; no opt-out required for rebooking invitation)

6. **Wait**: 23 hours (total approximately 24h from cancellation)

7. **Condition**: Check if patient has rebooked
   - **If rebooked** (new appointment detected or tag `appointment-booked` added):
     - Add tag: `cancellation-rebooked`
     - Add tag: `cancellation-recovered`
     - Move to pipeline stage: **Rebooked**
     - Exit workflow
   - **If not rebooked**: Continue

8. **Action**: Send rebooking email (follow-up with more context)
   - Template: `emails/uk/cancellation-recovery-email.html`
   - Subject: "Let's get you rescheduled, {{contact.first_name}}"
   - Body includes:
     - Understanding tone: "We understand things come up"
     - Importance of keeping on track with dental health (without being preachy)
     - Easy rebooking: one-click CTA to online booking
     - Mention alternative times: "We have availability this week including evenings"
     - "Need to discuss? Call us on {{location.phone}}"
   - Add tag: `recovery-email-sent`
   - Type: **Transactional** (rebooking facilitation for an existing appointment relationship)

9. **Action**: Trigger waitlist fill (runs in parallel with patient recovery)
   - This step attempts to fill the now-vacant appointment slot
   - **Condition**: Check if the cancelled slot is within the next 7 days
     - **If within 7 days**: Continue with waitlist notification
     - **If more than 7 days away**: Skip waitlist (slot may fill naturally via regular bookings)

10. **Action**: Identify waitlist candidates
    - Search contacts with tag `waitlist` or custom field `waitlist_preference` matching the cancelled appointment type and day
    - Filter: only contacts who opted into waitlist notifications
    - Limit: notify up to 5 waitlist contacts (first come, first served)

11. **Action**: Send waitlist notification SMS to eligible contacts
    - Template: `emails/uk/waitlist-notification-sms.txt`
    - Message: "Hi {{contact.first_name}}, a {{appointment.calendar_name}} slot has just opened up at {{location.name}} on {{appointment.start_time}}. Want it? Book now: {{location.booking_link}} or call {{location.phone}}. First come, first served!"
    - Respect business hours: 08:00-20:00 UK time
    - Add tag: `waitlist-notified` to each contact messaged
    - Type: **Transactional** (requested notification based on waitlist opt-in)

12. **Wait**: 7 days after cancellation (final check on original patient)

13. **Condition**: Final check if the cancelling patient has rebooked
    - **If rebooked**:
      - Add tag: `cancellation-rebooked`
      - Add tag: `cancellation-recovered`
      - Move to pipeline stage: **Rebooked**
      - Exit workflow
    - **If not rebooked**: Continue

14. **Action**: Mark recovery sequence as complete
    - Add tag: `cancellation-recovery-complete`
    - Move to pipeline stage: **Not Recovered**
    - If cancellation reason was captured and indicates a pattern (e.g., "too expensive", "found another dentist"), add appropriate tag for reporting
    - No further automated outreach to this patient about this specific cancellation

15. **End workflow**

### Exit Conditions
- Patient rebooks at any point during the sequence --> exit with `cancellation-recovered`
- Patient already rebooked before the workflow begins (cancel + immediate rebook) --> exit immediately
- Cancellation was within 2 hours of appointment --> skip patient outreach, only do waitlist fill
- Contact marked as "Do Not Contact" --> exit immediately
- Contact is already in a nurture or recall sequence --> recovery takes priority (these are more time-sensitive)
- Practice manually marks the cancellation as "resolved" --> exit workflow

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/cancellation-recovery-sms.txt` | 5 | SMS | Transactional |
| `emails/uk/cancellation-recovery-email.html` | 8 | Email | Transactional |
| `emails/uk/waitlist-notification-sms.txt` | 11 | SMS | Transactional |

## Success Metrics

- **Target**: 25%+ of cancelling patients rebook within 7 days
- **Measure**: Percentage of contacts with `appointment-cancelled` who gain `cancellation-rebooked` tag
- **Waitlist fill rate**: 50%+ of vacated slots (within 7 days) are filled by waitlist patients
- **SMS response**: Rebooking click-through > 12% on recovery SMS
- **Email response**: Open rate > 50%, click-through > 15% on recovery email
- **Revenue recovery**: Track estimated revenue recovered per month (average appointment value x recovered appointments)

## Notes

- **Transactional classification**: The rebooking SMS and email are classified as transactional because they relate to an existing service relationship (the patient had a booked appointment). They are facilitating the continuation of agreed care, not marketing a new service. However, if the practice wants to add promotional content (e.g., "Book a whitening session too"), that portion becomes marketing and requires consent.
- **Cancellation reason capture**: If GHL is configured to capture a cancellation reason (dropdown or free text), store it in `cancellation_reason`. This data is valuable for reporting (e.g., "20% cancel due to cost" --> adjust pricing or payment plan messaging).
- **Short-notice cancellations**: For cancellations within 2 hours, the focus shifts entirely to filling the slot. There is no point sending the patient a rebooking sequence -- they likely have an immediate conflict. The waitlist fill becomes the priority action.
- **Waitlist management**: The waitlist feature requires patients to opt in (via a form, chatbot, or reception). Store preferences in custom fields: `waitlist = yes`, `waitlist_preference = [day of week, time of day, appointment type]`. Only notify patients whose preferences match the vacant slot.
- **Concurrent workflows**: Cancellation recovery takes priority over recall-reminder and new-patient-nurture. If a patient cancels and is also due for recall, the recovery workflow runs first. After recovery completes (whether rebooked or not), the recall sequence can resume.
- **Repeat cancellations**: If a patient cancels 3+ times within 6 months, consider adding a tag `frequent-canceller` and creating an internal alert for the practice manager. The automated recovery still runs, but the practice may want to address the pattern directly.
- **Business hours**: SMS sends constrained to 08:00-20:00 UK time. The 1-hour delay at Step 4 means a cancellation at 19:30 would trigger the SMS at 09:00 the next day.
- **No-show vs cancellation**: This workflow is for cancellations only. No-shows (FTA/DNA) are a different scenario and may warrant a separate workflow with different messaging (the patient didn't proactively cancel, which changes the tone).
