# Appointment Reminder

**Package tier**: Ignite AI
**Trigger**: Appointment booked (GHL calendar event created)
**Goal**: Reduce no-show rate by 40% through timely, multi-channel reminders and post-visit follow-up

## Pipeline & Tags

- Pipeline: Patient Appointments
- Entry tag: `appointment-booked`
- Completion tag: `appointment-completed`
- Additional tags: `appointment-confirmed`, `appointment-no-show`
- Custom fields used:
  - `{{appointment.start_time}}` — date and time of appointment
  - `{{appointment.calendar_name}}` — type of appointment (e.g., Check-up, Hygiene)
  - `{{contact.first_name}}` — patient first name
  - `{{contact.phone}}` — patient mobile number
  - `{{contact.email}}` — patient email address
  - `{{location.name}}` — practice name
  - `{{location.address}}` — practice address
  - `{{location.phone}}` — practice phone number

## Flow

1. **Trigger**: Appointment booked in GHL calendar
   - Fires when a new appointment is created (online booking, manual entry, or chatbot booking)
   - Add tag: `appointment-booked`
   - Move to pipeline stage: **Booked**

2. **Action**: Send appointment confirmation email (immediate)
   - Template: `emails/uk/appointment-confirmation.html`
   - Subject: "Your appointment at {{location.name}} is confirmed"
   - Includes: date, time, location with map link, what to bring, cancellation/reschedule link
   - Type: **Transactional** (no opt-out required)

3. **Condition**: Check if appointment is more than 24 hours away
   - **If appointment is less than 24h away**: Skip to Step 5 (2h reminder)
   - **If appointment is 24h+ away**: Continue to Step 4

4. **Wait**: Until 24 hours before appointment start time
   - Use GHL "Wait until" with appointment date minus 24h
   - Respect business hours: if 24h-before falls outside 8:00-20:00, send at next 9:00 AM

5. **Condition**: Check if appointment is still active (not cancelled or rescheduled)
   - **If cancelled/rescheduled**: Exit workflow, remove tag `appointment-booked`
   - **If still active**: Continue

6. **Action**: Send 24-hour reminder SMS
   - Template: `emails/uk/appointment-reminder-24h-sms.txt`
   - Message: "Hi {{contact.first_name}}, this is a reminder of your appointment at {{location.name}} tomorrow at {{appointment.start_time}}. Reply YES to confirm or call us on {{location.phone}} to reschedule."
   - Type: **Transactional** (no opt-out required)

7. **Condition**: Check for reply within 4 hours
   - **If reply = YES/CONFIRMED**: Add tag `appointment-confirmed`, move to pipeline stage **Confirmed**
   - **If reply = CANCEL/NO**: Trigger cancellation-recovery workflow, exit this workflow
   - **If no reply**: Continue (proceed to 2h reminder)

8. **Wait**: Until 2 hours before appointment start time
   - Use GHL "Wait until" with appointment date minus 2h
   - Respect business hours: if 2h-before falls outside 8:00-20:00, send at previous day 19:00

9. **Condition**: Check if appointment is still active
   - **If cancelled/rescheduled**: Exit workflow
   - **If still active**: Continue

10. **Action**: Send 2-hour reminder SMS
    - Template: `emails/uk/appointment-reminder-2h-sms.txt`
    - Message: "Hi {{contact.first_name}}, just a quick reminder -- your appointment is in 2 hours at {{appointment.start_time}}. See you soon at {{location.name}}, {{location.address}}."
    - Type: **Transactional** (no opt-out required)

11. **Wait**: Until appointment time + 1 hour (buffer for appointment completion)

12. **Condition**: Check appointment outcome
    - **If marked as "No Show" / tag `appointment-no-show`**: Exit workflow (no thank-you sent; consider separate no-show recovery)
    - **If attended / completed**: Continue

13. **Wait**: 2 hours after appointment end time
    - Ensures patient has left the practice before receiving follow-up

14. **Action**: Send post-visit thank you email
    - Template: `emails/uk/post-visit-thankyou.html`
    - Subject: "Thank you for visiting {{location.name}}, {{contact.first_name}}"
    - Includes: thank you message, aftercare tips if applicable, link to leave a review (soft ask), next appointment reminder if recall due
    - Type: **Transactional** (no opt-out required)
    - Add tag: `appointment-completed`
    - Move to pipeline stage: **Completed**

15. **End workflow**

### Exit Conditions
- Appointment cancelled or rescheduled at any point --> exit workflow
- Contact unsubscribes from SMS --> skip SMS steps, continue email only
- Contact marked as "Do Not Contact" --> exit workflow immediately

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/appointment-confirmation.html` | 2 | Email | Transactional |
| `emails/uk/appointment-reminder-24h-sms.txt` | 6 | SMS | Transactional |
| `emails/uk/appointment-reminder-2h-sms.txt` | 10 | SMS | Transactional |
| `emails/uk/post-visit-thankyou.html` | 14 | Email | Transactional |

## Success Metrics

- **Target**: Reduce no-show (FTA/DNA) rate from industry average of 15-20% to below 8%
- **Measure**: Compare FTA rate for 90 days pre-automation vs 90 days post-automation
- **Secondary**: Appointment confirmation rate > 60% (reply YES to 24h SMS)
- **Tracking**: GHL reporting on appointment outcomes by tag

## Notes

- **Business hours**: All SMS messages constrained to 08:00-20:00 UK time. If a scheduled send falls outside this window, defer to the next valid window (9:00 AM next day for overnight, or 19:00 same day for late evening).
- **Same-day appointments**: If the appointment is booked less than 2 hours in advance, only the confirmation email is sent. The reminder SMS steps are skipped.
- **Appointment changes**: If the patient reschedules, the old workflow instance should be terminated and a new one triggered by the new appointment event.
- **SMS delivery**: Ensure the practice's GHL account has SMS enabled with a registered UK sender number. Two-way SMS is required for the confirmation reply feature at Step 7.
- **GDPR**: All messages in this workflow are transactional (directly related to the booked service) and do not require marketing consent. However, the post-visit thank-you email should not contain promotional offers unless the patient has opted into marketing.
- **No-show handling**: Patients marked as no-show do NOT receive the thank-you email. Consider implementing a separate no-show follow-up if needed (not part of this workflow).
- **Multi-appointment**: If a patient has multiple upcoming appointments, each appointment triggers its own independent workflow instance.
