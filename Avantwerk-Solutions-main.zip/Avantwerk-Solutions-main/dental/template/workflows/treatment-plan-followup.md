# Treatment Plan Follow-Up

**Package tier**: Apex AI
**Trigger**: Treatment plan presented to patient (tag `treatment-plan-presented` added after consultation)
**Goal**: Convert 40%+ of presented treatment plans into booked procedures within 30 days

## Pipeline & Tags

- Pipeline: Treatment Plan Conversion
- Entry tag: `treatment-plan-presented`
- Completion tag: `treatment-plan-accepted` or `treatment-plan-followup-complete`
- Additional tags: `tp-checkin-sent`, `tp-reminder-sent`, `tp-reengage-sent`, `treatment-plan-declined`
- Custom fields used:
  - `{{contact.first_name}}` — patient first name
  - `{{contact.email}}` — patient email address
  - `{{contact.phone}}` — patient mobile number
  - `{{custom_field.treatment_plan_type}}` — type of treatment proposed (e.g., "Implant", "Invisalign", "Crown", "Whitening")
  - `{{custom_field.treatment_plan_value}}` — estimated cost of the treatment plan
  - `{{custom_field.treatment_plan_date}}` — date the plan was presented
  - `{{custom_field.treating_dentist}}` — name of the dentist who presented the plan
  - `{{location.name}}` — practice name
  - `{{location.phone}}` — practice phone number
  - `{{location.booking_link}}` — online booking URL
  - `{{custom_field.payment_plan_available}}` — whether the practice offers payment plans (yes/no)

## Flow

1. **Trigger**: Tag `treatment-plan-presented` added to contact
   - Fires when: the dentist or treatment coordinator marks that a treatment plan has been discussed with the patient
   - This is typically added manually by the clinical team after a consultation or via a GHL form
   - Move to pipeline stage: **Plan Presented**

2. **Condition**: Check if patient has already accepted and booked the treatment
   - **If tag `treatment-plan-accepted` already exists**: Exit workflow (they've already committed)
   - **If no acceptance tag**: Continue

3. **Condition**: Check if contact has a valid email address
   - **If no email**: Create internal task "Call {{contact.first_name}} {{contact.last_name}} re: treatment plan follow-up -- no email on file", exit workflow
   - **If email exists**: Continue

4. **Wait**: 48 hours after treatment plan was presented
   - Gives the patient time to review, discuss with family, consider finances
   - If 48h falls on a Sunday, defer to Monday 10:00

5. **Condition**: Check if patient has booked the treatment since the plan was presented
   - **If booked**: Add tag `treatment-plan-accepted`, move to pipeline stage **Accepted**, exit workflow
   - **If not booked**: Continue

6. **Action**: Send 48-hour check-in email (caring, no-pressure)
   - Template: `emails/uk/treatment-plan-checkin.html`
   - Subject: "Following up on your treatment plan, {{contact.first_name}}"
   - Body includes:
     - Personal reference: "After your consultation with {{custom_field.treating_dentist}} on {{custom_field.treatment_plan_date}}"
     - Acknowledge the decision: "We understand that [treatment type] is an important decision"
     - Invitation to ask questions: "If you have any questions about the procedure, recovery, or costs, we're here to help"
     - Offer a free follow-up call: "Would you like to speak with {{custom_field.treating_dentist}} again? Just reply to this email and we'll arrange it"
     - If payment plans available: "We offer flexible payment plans to make treatment more manageable"
     - Soft CTA: "Ready to go ahead? Book your next appointment: {{location.booking_link}}"
   - Add tag: `tp-checkin-sent`
   - Type: **Transactional** (follow-up on a clinical consultation)

7. **Wait**: 5 days (total approximately 7 days from plan presentation)

8. **Condition**: Check if patient has booked the treatment
   - **If booked**: Add tag `treatment-plan-accepted`, move to pipeline stage **Accepted**, exit workflow
   - **If not booked**: Continue

9. **Condition**: Verify contact has not unsubscribed
   - **If unsubscribed**: Exit workflow, add tag `treatment-plan-followup-complete`
   - **If still active**: Continue

10. **Action**: Send 7-day reminder email (informative, addresses concerns)
    - Template: `emails/uk/treatment-plan-reminder.html`
    - Subject: "Your {{custom_field.treatment_plan_type}} treatment -- what you need to know"
    - Body includes:
      - Brief recap of the proposed treatment and its benefits
      - Address common concerns for this treatment type:
        - For implants: "Modern implants have a 95%+ success rate and can last a lifetime"
        - For Invisalign: "Most patients see results within 6-12 months"
        - For whitening: "Our professional whitening is safe and dramatically more effective than shop-bought kits"
      - Patient testimonial or before/after reference (if available, treatment-specific)
      - Payment plan details if applicable: "From as little as £X/month"
      - Urgency (if appropriate): "Starting sooner means enjoying your results sooner"
      - CTA: "Book Your Treatment" linking to {{location.booking_link}}
      - Alternative: "Call {{location.phone}} to discuss further"
    - Add tag: `tp-reminder-sent`
    - Type: **Marketing** (include unsubscribe link -- this goes beyond transactional follow-up)

11. **Wait**: 23 days (total approximately 30 days from plan presentation)

12. **Condition**: Check if patient has booked the treatment
    - **If booked**: Add tag `treatment-plan-accepted`, move to pipeline stage **Accepted**, exit workflow
    - **If not booked**: Continue

13. **Condition**: Verify contact has not unsubscribed
    - **If unsubscribed**: Exit workflow, add tag `treatment-plan-followup-complete`
    - **If still active**: Continue

14. **Action**: Send 30-day re-engagement email (final touchpoint)
    - Template: `emails/uk/treatment-plan-reengage.html`
    - Subject: "We're here when you're ready, {{contact.first_name}}"
    - Body includes:
      - Warm, no-pressure tone: "It's been a month since we discussed your treatment plan, and we wanted to check in one more time"
      - Acknowledge their pace: "We completely understand if now isn't the right time"
      - Remind what's at stake (clinically, not sales-y):
        - "Delaying [treatment] can sometimes lead to [specific consequence]" (e.g., bone loss for implants, further misalignment for ortho)
        - Keep this factual and caring, not fear-based
      - Offer to revise the plan: "If cost or timing is a concern, we'd be happy to explore alternative options or adjust the plan"
      - Open door: "Whenever you're ready, your treatment plan is here waiting for you. Just call us on {{location.phone}} or book online"
      - Final CTA: "Book When You're Ready" linking to {{location.booking_link}}
    - Add tag: `tp-reengage-sent`
    - Type: **Marketing** (include unsubscribe link)

15. **Wait**: 14 days (total approximately 44 days from plan presentation)

16. **Condition**: Final check if patient has booked
    - **If booked**: Add tag `treatment-plan-accepted`, move to pipeline stage **Accepted**, exit workflow
    - **If not booked**: Continue

17. **Action**: Mark follow-up sequence as complete
    - Add tag: `treatment-plan-followup-complete`
    - Move to pipeline stage: **Pending - Manual Review**
    - Create internal task: "Treatment plan follow-up complete for {{contact.first_name}} {{contact.last_name}}. Plan: {{custom_field.treatment_plan_type}} (£{{custom_field.treatment_plan_value}}). No automated booking after 44 days. Consider: manual call, revised treatment plan, or mark as declined."
    - The dentist/treatment coordinator should review and decide on next steps

18. **End workflow**

### Exit Conditions
- Patient books the treatment at any step --> exit with `treatment-plan-accepted`
- Patient explicitly declines (replies with decline, or reception marks as declined) --> add tag `treatment-plan-declined`, exit workflow, create internal note
- Contact unsubscribes --> exit and mark complete
- Contact marked "Do Not Contact" --> exit immediately
- A new, different treatment plan is presented (supersedes the current one) --> exit current workflow, new instance triggers for the new plan
- Patient contacts the practice to discuss (detected via reply or inbound call) --> continue workflow but create internal note to alert the team

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/treatment-plan-checkin.html` | 6 | Email | Transactional |
| `emails/uk/treatment-plan-reminder.html` | 10 | Email | Marketing |
| `emails/uk/treatment-plan-reengage.html` | 14 | Email | Marketing |

## Success Metrics

- **Target**: 40%+ of presented treatment plans result in booked procedures within 44 days
- **Measure**: Conversion rate = contacts with `treatment-plan-accepted` / contacts with `treatment-plan-presented`
- **Revenue**: Total treatment plan value converted per month (track using `treatment_plan_value` field)
- **Email metrics**: Check-in email open rate > 60%, reminder open rate > 45%, re-engage open rate > 35%
- **Time to acceptance**: Median days from plan presentation to booking (target < 10 days)
- **Secondary**: Reduction in "treatment plan sitting in drawer" syndrome (plans that never convert)

## Notes

- **Clinical sensitivity**: Treatment plans involve medical decisions. The tone must be caring, informative, and never sales-pushy. Phrases like "limited time offer" or "don't miss out" are inappropriate for clinical treatment follow-ups. Focus on health outcomes and patient wellbeing.
- **First email is transactional**: The 48-hour check-in (Step 6) is a direct follow-up to a clinical consultation and is classified as transactional. It does not promote a new service -- it facilitates the continuation of a care discussion. Steps 10 and 14 escalate to marketing territory as they become more promotional.
- **Treatment-specific content**: The email templates should use conditional content blocks based on `treatment_plan_type` to show relevant information. An implant follow-up email should discuss implant-specific benefits and concerns, not generic dental content. If GHL's conditional content is too limited, create separate template variants per treatment category.
- **High-value plans**: For treatment plans over a certain threshold (e.g., over 2,000 GBP -- implants, full orthodontics), the 48-hour check-in should also trigger an internal notification to the treatment coordinator for a personal phone call. High-value plans benefit from human touch in addition to automated follow-up.
- **Payment plans**: If the practice offers finance/payment plans (0% interest, monthly payments), this is a major conversion lever. Include payment plan information prominently in Steps 10 and 14. Store `payment_plan_available = yes` and reference it in templates.
- **No SMS in this sequence**: Treatment plan decisions are significant and personal. SMS feels too casual for this context. All touchpoints are email, which allows for more detailed, considered communication. The internal task at Step 17 prompts the team to call if needed.
- **Multiple treatment plans**: If a patient has multiple treatment plans presented (e.g., a crown AND whitening), each triggers its own workflow instance. However, to avoid email overload, add a GHL condition: "Contact is NOT already in treatment-plan-followup workflow" and batch or merge communications where possible.
- **Superseded plans**: If the dentist revises the treatment plan (different treatment, updated pricing), the old workflow should be terminated and a new one triggered with updated custom fields.
- **GDPR and health data**: Treatment plan details are sensitive health data under UK GDPR. Email content should be appropriately vague in subject lines (don't put "Your implant quote" in the subject -- intercepted emails reveal health information). Use "Your treatment plan" in subjects and save specifics for the email body.
- **Integration with PMS**: Ideally, `treatment-plan-presented` tag and the associated custom fields are populated automatically from the practice management system (Dentally, SOE, etc.) via GHL integration or Zapier. If manual entry is required, provide the reception team with a simple GHL form to log treatment plan presentations.
