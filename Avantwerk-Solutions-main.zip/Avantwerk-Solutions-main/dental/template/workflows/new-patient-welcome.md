# New Patient Welcome

**Package tier**: Elevate AI
**Trigger**: New patient registration (contact created with tag `new-patient` or form submission)
**Goal**: Improve new patient experience and reduce first-appointment anxiety, achieving 90%+ first-appointment attendance rate

## Pipeline & Tags

- Pipeline: New Patient Journey
- Entry tag: `new-patient`
- Completion tag: `new-patient-welcomed`
- Additional tags: `welcome-email-sent`, `welcome-followup-sent`
- Custom fields used:
  - `{{contact.first_name}}` — patient first name
  - `{{contact.email}}` — patient email address
  - `{{contact.phone}}` — patient mobile number
  - `{{appointment.start_time}}` — first appointment date/time (if already booked)
  - `{{location.name}}` — practice name
  - `{{location.address}}` — practice full address
  - `{{location.phone}}` — practice phone number
  - `{{location.parking_info}}` — parking instructions (custom field)
  - `{{location.booking_link}}` — online booking URL

## Flow

1. **Trigger**: New contact created with tag `new-patient`
   - Fires when: online registration form submitted, receptionist manually adds patient, or chatbot captures new patient details
   - Move to pipeline stage: **New Registration**

2. **Condition**: Check if contact has a valid email address
   - **If no email**: Skip email steps, send SMS welcome at Step 3b instead, then exit
   - **If email exists**: Continue to Step 3

3. **Action**: Send welcome email (immediate, within 5 minutes of registration)
   - Template: `emails/uk/new-patient-welcome.html`
   - Subject: "Welcome to {{location.name}}, {{contact.first_name}}!"
   - Body includes:
     - Warm welcome message from the practice
     - What to expect at your first visit (arrival time, duration, what happens)
     - What to bring: ID, medical history, list of medications, insurance/NHS details
     - Practice location with embedded map link and parking info
     - Online booking link if first appointment not yet booked
     - Contact information and how to reach the team
     - Link to pre-registration/medical history form (if practice uses one)
   - Add tag: `welcome-email-sent`
   - Type: **Transactional** (directly related to service registration; no opt-out required)

3b. **Alternative — SMS welcome** (only if no email address):
   - Template: `emails/uk/new-patient-welcome-sms.txt`
   - Message: "Welcome to {{location.name}}, {{contact.first_name}}! We're looking forward to seeing you. If you have any questions before your first visit, call us on {{location.phone}} or book online: {{location.booking_link}}"
   - Type: **Transactional**
   - Add tag: `welcome-email-sent`
   - Skip to Step 7 (no follow-up email without email address)

4. **Wait**: 48 hours

5. **Condition**: Check if first appointment is booked
   - **If appointment already booked**: Continue to Step 6a (follow-up with appointment context)
   - **If no appointment booked**: Continue to Step 6b (follow-up with booking nudge)

6a. **Action**: Send follow-up email (appointment booked path)
   - Template: `emails/uk/new-patient-followup-booked.html`
   - Subject: "Your first appointment at {{location.name}} -- a quick reminder"
   - Body includes:
     - Reminder of appointment date and time
     - Reiterate what to bring
     - "Any questions? Just reply to this email or call us"
     - Reassurance: "Our team is friendly and here to make you comfortable"
   - Add tag: `welcome-followup-sent`
   - Type: **Transactional**
   - Skip to Step 7

6b. **Action**: Send follow-up email (no appointment yet)
   - Template: `emails/uk/new-patient-followup-unbooked.html`
   - Subject: "Ready to book your first visit, {{contact.first_name}}?"
   - Body includes:
     - Gentle nudge to book first appointment
     - Highlight ease of online booking (takes 60 seconds)
     - Mention available appointment types (check-up, specific concern)
     - Booking CTA button
     - "Need help choosing? Call us on {{location.phone}}"
   - Add tag: `welcome-followup-sent`
   - Type: **Marketing** (include unsubscribe link, as this is promotional)

7. **Action**: Mark welcome sequence as complete
   - Add tag: `new-patient-welcomed`
   - Move to pipeline stage: **Welcomed**
   - If no appointment booked and patient came via enquiry, consider enrolling in new-patient-nurture workflow (check if not already in it)

8. **End workflow**

### Exit Conditions
- Contact marked as "Do Not Contact" at any point --> exit immediately
- Contact unsubscribes --> exit and mark complete
- Duplicate contact detected (already exists as a patient) --> exit, do not send welcome
- Contact is already in the new-patient-nurture workflow --> check for overlap; welcome takes priority, nurture should pause for 48h

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/new-patient-welcome.html` | 3 | Email | Transactional |
| `emails/uk/new-patient-welcome-sms.txt` | 3b | SMS | Transactional |
| `emails/uk/new-patient-followup-booked.html` | 6a | Email | Transactional |
| `emails/uk/new-patient-followup-unbooked.html` | 6b | Email | Marketing |

## Success Metrics

- **Target**: 90%+ first-appointment attendance rate for new patients
- **Measure**: Percentage of contacts tagged `new-patient` who attend their first appointment within 30 days
- **Email metrics**: Welcome email open rate > 70% (high due to recency of registration)
- **Secondary**: Reduction in "what do I need to bring?" phone calls to reception (target 50% reduction)
- **Secondary**: Increase in pre-registration form completion rate to 60%+ (if applicable)

## Notes

- **Immediate send**: The welcome email must send within 5 minutes of registration. Speed matters -- the patient just took action and expects confirmation. Use GHL's immediate action, not a scheduled send.
- **Transactional classification**: The initial welcome email and the appointment-booked follow-up are transactional (service-related). The unbooked follow-up at Step 6b is marketing (encouraging a new booking) and requires opt-in + unsubscribe link.
- **Medical history form**: If the practice uses a digital pre-registration or medical history form, include the link in the welcome email. This saves chair time and improves the first-visit experience. Store the form URL in a location custom field.
- **Parking and directions**: Dental anxiety is common. Practical details like parking, public transport options, and "what floor are we on" significantly reduce first-visit stress. Include these in the welcome email.
- **48-hour follow-up timing**: The 48h wait ensures the follow-up doesn't feel rushed but arrives while the patient is still in "new registration" mode. If the 48h mark falls on a Sunday, GHL should send at Monday 09:00 instead.
- **Overlap with nurture**: If a patient submitted an enquiry (entering nurture) and then registered (entering welcome), the welcome workflow takes priority. The nurture workflow should pause or exit when `new-patient` tag is added. The welcome flow is more relevant at that point.
- **NHS vs Private**: Welcome content may need slight variation based on patient type. NHS patients may need different "what to bring" information (exemption certificates, HC2 forms). Consider a condition on `patient_type` custom field for Step 3 template selection.
- **Data capture**: If the registration form didn't capture all needed fields (e.g., date of birth for recall tracking, medical conditions for chatbot), the follow-up email can prompt the patient to complete their profile.
