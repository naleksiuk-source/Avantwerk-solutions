# Recall Reminder

**Package tier**: Elevate AI
**Trigger**: 5.5 months (approximately 167 days) after last check-up appointment completed
**Goal**: Increase 6-month recall compliance from the industry average of 60% to 85%+

## Pipeline & Tags

- Pipeline: Recall Management
- Entry tag: `recall-due`
- Completion tag: `recall-booked` or `recall-sequence-complete`
- Additional tags: `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-overdue`
- Custom fields used:
  - `{{contact.first_name}}` — patient first name
  - `{{contact.email}}` — patient email address
  - `{{contact.phone}}` — patient mobile number
  - `{{custom_field.last_checkup_date}}` — date of last check-up/recall appointment
  - `{{location.name}}` — practice name
  - `{{location.phone}}` — practice phone number
  - `{{location.booking_link}}` — online booking URL

## Flow

1. **Trigger**: Date-based trigger — 167 days (5 months, 2 weeks) after `custom_field.last_checkup_date`
   - GHL date-based workflow trigger using custom field
   - Add tag: `recall-due`
   - Move to pipeline stage: **Recall Due**

2. **Condition**: Check if patient already has a future appointment booked
   - **If future appointment exists**: Add tag `recall-booked`, exit workflow (no reminder needed)
   - **If no future appointment**: Continue

3. **Condition**: Check if contact has marketing email consent
   - **If no marketing consent**: Skip to Step 6 (SMS path if transactional angle is applicable)
   - **If consent given**: Continue

4. **Action**: Send recall reminder email (first touchpoint)
   - Template: `emails/uk/recall-reminder-1.html`
   - Subject: "Time for your check-up, {{contact.first_name}}"
   - Body: Friendly reminder that 6 months is approaching, importance of regular check-ups, one-click booking button, mention of hygiene appointment option too
   - CTA: "Book Your Check-up" linking to {{location.booking_link}}
   - Add tag: `recall-email-1-sent`
   - Type: **Marketing** (include unsubscribe link)

5. **Wait**: 14 days (2 weeks)

6. **Condition**: Check if patient has booked since the first email
   - **If booked** (tag `appointment-booked` added, or future appointment detected):
     - Add tag: `recall-booked`
     - Remove tag: `recall-due`
     - Move to pipeline stage: **Recall Booked**
     - Exit workflow
   - **If not booked**: Continue

7. **Action**: Send recall reminder SMS (escalation to direct channel)
   - Template: `emails/uk/recall-reminder-sms.txt`
   - Message: "Hi {{contact.first_name}}, it's been nearly 6 months since your last check-up at {{location.name}}. Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out."
   - Respect business hours: send between 09:00-19:00 UK time only
   - Add tag: `recall-sms-sent`
   - Type: **Marketing** (include STOP opt-out)

8. **Wait**: 14 days (2 weeks) — now approximately 6.5 months since last check-up

9. **Condition**: Check if patient has booked since the SMS
   - **If booked**: Add tag `recall-booked`, remove `recall-due`, exit workflow
   - **If not booked**: Continue

10. **Condition**: Verify contact still has marketing consent
    - **If unsubscribed**: Mark as `recall-sequence-complete`, exit workflow
    - **If still subscribed**: Continue

11. **Action**: Send final recall email (urgency messaging)
    - Template: `emails/uk/recall-reminder-final.html`
    - Subject: "Don't miss your check-up, {{contact.first_name}} -- it's overdue"
    - Body: Emphasize that check-up is now overdue, highlight consequences of skipping (early detection of issues, gum disease prevention), strong booking CTA, mention that the practice team is ready to help
    - CTA: "Book Now" linking to {{location.booking_link}}
    - Add tag: `recall-email-2-sent`
    - Type: **Marketing** (include unsubscribe link)

12. **Wait**: 7 days

13. **Condition**: Final check if patient has booked
    - **If booked**: Add tag `recall-booked`, remove `recall-due`, exit workflow
    - **If not booked**: Continue

14. **Action**: Mark sequence as complete and flag for manual follow-up
    - Add tag: `recall-sequence-complete`
    - Add tag: `recall-overdue`
    - Move to pipeline stage: **Overdue - Manual Follow-up**
    - Create internal task: "Manual recall follow-up needed for {{contact.first_name}} {{contact.last_name}} -- no response to automated sequence"
    - **Do NOT send further automated messages**

15. **End workflow**

### Exit Conditions
- Patient books an appointment at any point during the sequence --> exit with `recall-booked` tag
- Patient already has a future appointment when the workflow triggers --> exit immediately
- Patient unsubscribes from marketing --> exit and mark complete
- Patient marked as "Do Not Contact" or "Inactive" --> exit immediately
- Patient is currently in a new-patient-nurture or cancellation-recovery workflow --> defer recall start by 14 days to avoid overlap

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/recall-reminder-1.html` | 4 | Email | Marketing |
| `emails/uk/recall-reminder-sms.txt` | 7 | SMS | Marketing |
| `emails/uk/recall-reminder-final.html` | 11 | Email | Marketing |

## Success Metrics

- **Target**: 85%+ recall compliance rate (patients returning within 7 months of last check-up)
- **Measure**: Percentage of patients with `recall-due` tag who receive `recall-booked` tag within the sequence window
- **Email metrics**: Open rate > 40% on first email, > 35% on final email
- **SMS response**: Booking rate > 10% from SMS touchpoint
- **Secondary**: Reduction in manual recall phone calls by reception staff (target 60% reduction)

## Notes

- **Timing logic**: The 5.5-month trigger (167 days) gives the patient 2 weeks' notice before the ideal 6-month mark. The full sequence spans approximately 5 weeks, ending around 7 months after the last visit.
- **Custom field dependency**: This workflow requires `last_checkup_date` to be updated after every check-up appointment. Ensure the appointment-reminder workflow or a separate automation writes this field when a check-up is completed.
- **Business hours for SMS**: SMS at Step 7 must be sent between 09:00-19:00 UK time. If the trigger time falls outside this window, GHL should queue it for the next valid slot.
- **Marketing consent**: All messages in this sequence are marketing (encouraging a repeat visit). Require explicit marketing opt-in. Include unsubscribe/opt-out in every message.
- **Overlap prevention**: If the patient is already in an active nurture, cancellation-recovery, or treatment-plan-followup workflow, delay the recall sequence start by 14 days to avoid message fatigue. Use GHL workflow condition "Contact is NOT in workflow [X]" to check.
- **NHS vs Private**: For NHS patients, recall intervals may differ (some NHS guidelines suggest 12-24 months based on risk assessment). Consider adding a condition on a custom field `patient_type` to adjust the trigger timing accordingly. The default 6-month cycle applies to private patients.
- **Manual follow-up**: Patients who complete the full sequence without booking are flagged for the reception team. This is intentional -- some patients prefer phone calls, and a personal touch after automated messages can be very effective.
- **Re-entry**: After the patient completes their next check-up, the `last_checkup_date` field is updated, and the cycle begins again automatically in another 5.5 months.
