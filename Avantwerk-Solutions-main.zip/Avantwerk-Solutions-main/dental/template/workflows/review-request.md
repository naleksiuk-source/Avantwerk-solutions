# Review Request

**Package tier**: Ignite AI
**Trigger**: 24 hours after appointment completed (tag `appointment-completed` added)
**Goal**: Increase Google review volume by 50% and maintain a 4.5+ star average rating

## Pipeline & Tags

- Pipeline: Patient Engagement
- Entry tag: `appointment-completed`
- Completion tag: `review-requested-complete`
- Additional tags: `review-requested`, `review-clicked`, `review-left`
- Custom fields used:
  - `{{contact.first_name}}` — patient first name
  - `{{contact.email}}` — patient email address
  - `{{location.name}}` — practice name
  - `{{location.google_review_link}}` — direct Google review URL
  - `{{appointment.calendar_name}}` — treatment type (for personalization)

## Flow

1. **Trigger**: Tag `appointment-completed` added to contact
   - This tag is applied by the appointment-reminder workflow after a successful visit

2. **Condition**: Check if contact already has tag `review-left` or `review-requested` (within last 90 days)
   - **If tagged `review-left`**: Exit workflow (don't ask for another review too soon)
   - **If tagged `review-requested` within last 90 days**: Exit workflow (avoid pestering)
   - **If neither**: Continue

3. **Condition**: Check if contact has marketing email consent
   - **If no marketing consent**: Exit workflow (review requests are marketing, not transactional)
   - **If consent given**: Continue

4. **Wait**: 24 hours after trigger
   - Gives the patient time to reflect on their experience
   - If 24h falls outside business hours, defer to next 10:00 AM (mid-morning optimal for email open rates)

5. **Action**: Send review request email
   - Template: `emails/uk/review-request.html`
   - Subject: "How was your visit, {{contact.first_name}}?"
   - Body: Personal thank-you, 1-click Google review button, brief explanation of why reviews matter
   - CTA: "Leave a Review" button linking to {{location.google_review_link}}
   - Add tag: `review-requested`
   - Type: **Marketing** (include unsubscribe link)

6. **Wait**: 3 days (72 hours)

7. **Condition**: Check if contact clicked the review link in the email
   - **If clicked** (tag `review-clicked` or GHL link tracking shows click):
     - Add tag: `review-clicked`
     - Move to pipeline stage: **Review Clicked**
     - Exit workflow (assume review was left or will be left)
   - **If email not opened**: Continue to Step 8
   - **If email opened but link not clicked**: Continue to Step 8

8. **Condition**: Verify contact still has marketing consent and has not unsubscribed
   - **If unsubscribed**: Exit workflow
   - **If still subscribed**: Continue

9. **Action**: Send follow-up review request email
   - Template: `emails/uk/review-request-followup.html`
   - Subject: "We'd love to hear from you, {{contact.first_name}}"
   - Body: Shorter, more direct ask. Mention it takes less than 60 seconds. Include the same Google review link.
   - CTA: "Share Your Experience" button linking to {{location.google_review_link}}
   - Type: **Marketing** (include unsubscribe link)

10. **Wait**: 48 hours

11. **Condition**: Check if contact clicked review link in follow-up email
    - **If clicked**: Add tag `review-clicked`, exit workflow
    - **If not clicked**: Continue

12. **Action**: Mark sequence as complete
    - Add tag: `review-requested-complete`
    - Move to pipeline stage: **Review Sequence Complete**
    - No further follow-up (respect the patient's choice not to leave a review)

13. **End workflow**

### Exit Conditions
- Contact already left a review in the last 90 days --> exit immediately
- Contact already received a review request in the last 90 days --> exit immediately
- Contact unsubscribes at any point --> exit immediately and remove from sequence
- Contact clicks the review link --> exit (goal achieved)
- Contact has no marketing consent --> exit immediately
- Contact replies with negative feedback --> exit and notify practice manager (internal notification)

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/review-request.html` | 5 | Email | Marketing |
| `emails/uk/review-request-followup.html` | 9 | Email | Marketing |

## Success Metrics

- **Target**: Generate 8-12 new Google reviews per month per practice (from baseline of 2-4)
- **Measure**: Google review count tracked monthly; GHL click-through rate on review link
- **Email metrics**: Open rate > 45%, click-through rate > 15% on initial email
- **Secondary**: Maintain average rating of 4.5+ stars on Google

## Notes

- **Marketing consent required**: Unlike appointment reminders, review requests are considered marketing communications under UK GDPR / PECR. Only send to contacts who have explicitly opted in to marketing emails. Every email must include an unsubscribe link.
- **Timing**: The 24-hour delay after the appointment allows the patient to settle in before being asked for feedback. Mid-morning (10:00 AM) sends tend to perform best for email engagement.
- **Frequency cap**: Never send more than one review request sequence per patient per 90 days, even if they attend multiple appointments. This prevents review fatigue and maintains a positive patient relationship.
- **Negative feedback handling**: If the patient replies to the email with negative feedback or a complaint, GHL should trigger an internal notification to the practice manager rather than directing them to Google. This protects the practice's online reputation while still addressing concerns.
- **Google review link**: The practice must provide their direct Google review link. This is typically: `https://search.google.com/local/writereview?placeid=PLACE_ID`. Store this in the GHL location custom field `google_review_link`.
- **SMS not used**: Review requests are kept to email only for this tier. SMS review requests can feel intrusive. Higher tiers could add an SMS nudge as an optional enhancement.
- **Do not combine with other sequences**: If the patient enters a recall-reminder or nurture sequence within 48 hours, pause the review request to avoid email overload.
