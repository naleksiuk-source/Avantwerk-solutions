# Birthday & Loyalty

**Package tier**: Apex AI
**Trigger**: Contact's date of birth matches today's date (annual recurring trigger)
**Goal**: Strengthen patient loyalty and generate incremental revenue through birthday offers, achieving 15%+ redemption rate

## Pipeline & Tags

- Pipeline: Patient Engagement
- Entry tag: `birthday-triggered`
- Completion tag: `birthday-complete`
- Additional tags: `birthday-email-sent`, `birthday-offer-redeemed`
- Custom fields used:
  - `{{contact.first_name}}` — patient first name
  - `{{contact.email}}` — patient email address
  - `{{contact.date_of_birth}}` — patient date of birth (used for trigger matching)
  - `{{custom_field.birthday_offer_code}}` — unique discount code for tracking redemption
  - `{{custom_field.birthday_offer_description}}` — current birthday offer text (e.g., "10% off teeth whitening")
  - `{{custom_field.birthday_offer_expiry}}` — offer expiry date (typically 30 days from birthday)
  - `{{location.name}}` — practice name
  - `{{location.phone}}` — practice phone number
  - `{{location.booking_link}}` — online booking URL

## Flow

1. **Trigger**: Date-based trigger — `contact.date_of_birth` matches today's date (day and month)
   - GHL date-based workflow: "Date of birth" is "today"
   - Runs annually for every patient with a recorded date of birth
   - Add tag: `birthday-triggered`

2. **Condition**: Check if contact is an active patient
   - **If contact has tag `inactive-patient` or `do-not-contact`**: Exit workflow
   - **If contact has no appointments in the last 18 months**: Exit workflow (lapsed patient, don't send)
   - **If active patient**: Continue

3. **Condition**: Check if contact has marketing email consent
   - **If no marketing consent**: Exit workflow (birthday offers are marketing)
   - **If consent given**: Continue

4. **Action**: Generate birthday offer code
   - Create unique code: e.g., `BDAY-{{contact.first_name}}-2025` or use GHL's coupon/offer feature
   - Set `birthday_offer_code` custom field
   - Set `birthday_offer_expiry` to today + 30 days
   - Current default offer: "10% off teeth whitening" (configurable per practice)

5. **Action**: Send birthday greeting email
   - **Schedule**: Send at 09:00 on the patient's birthday (morning delivery for best experience)
   - Template: `emails/uk/birthday-greeting.html`
   - Subject: "Happy Birthday, {{contact.first_name}}! A gift from {{location.name}}"
   - Body includes:
     - Warm, personal birthday greeting from the practice team
     - Special birthday offer: {{custom_field.birthday_offer_description}}
     - Unique offer code: {{custom_field.birthday_offer_code}}
     - Offer validity: "Valid for 30 days until {{custom_field.birthday_offer_expiry}}"
     - How to redeem: "Book online and mention your birthday code, or call us on {{location.phone}}"
     - CTA: "Treat Yourself" button linking to {{location.booking_link}}
     - Practice team signature (warm, personal sign-off)
   - Add tag: `birthday-email-sent`
   - Type: **Marketing** (include unsubscribe link)

6. **Wait**: 30 days (offer expiry window)

7. **Condition**: Check if offer was redeemed
   - **If redeemed** (tag `birthday-offer-redeemed` added by reception/booking system when code is used):
     - Move to pipeline stage: **Offer Redeemed**
     - Add tag: `birthday-complete`
     - Exit workflow
   - **If not redeemed**: Continue

8. **Action**: Mark birthday sequence as complete
   - Add tag: `birthday-complete`
   - Remove tag: `birthday-triggered` (clean up for next year)
   - No follow-up: the offer simply expires. Chasing a birthday gift feels inappropriate.

9. **End workflow**

### Exit Conditions
- Patient is inactive (no appointments in 18 months) --> exit, don't send
- Patient has no marketing consent --> exit
- Patient marked "Do Not Contact" --> exit immediately
- Patient unsubscribes after receiving the email --> exit, mark complete
- Offer redeemed --> exit with success tag

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/birthday-greeting.html` | 5 | Email | Marketing |

## Success Metrics

- **Target**: 15%+ offer redemption rate (patients who book using the birthday code)
- **Measure**: Percentage of `birthday-email-sent` contacts who gain `birthday-offer-redeemed` tag within 30 days
- **Email metrics**: Open rate > 55% (birthday emails typically have high engagement), click-through > 20%
- **Revenue**: Track incremental revenue from birthday offer bookings per quarter
- **Secondary**: Patient sentiment and loyalty (qualitative, via reception feedback)

## Notes

- **Morning delivery**: Birthday emails should arrive at 09:00 UK time on the patient's birthday. This feels personal and timely. GHL's scheduling feature should queue the email for 09:00 regardless of when the trigger fires overnight.
- **Marketing classification**: Birthday offers are marketing communications. They require explicit marketing consent and must include an unsubscribe link. Even though the email feels personal, it contains a commercial offer.
- **Offer configuration**: The default birthday offer is "10% off teeth whitening" -- a high-margin cosmetic treatment that appeals broadly. Practices can customise this via the `birthday_offer_description` location custom field. Alternative offers:
  - Free hygiene session upgrade (add polish/fluoride)
  - 15% off cosmetic consultation
  - Complimentary teeth whitening consultation
  - Free dental goodie bag at next visit
- **Offer tracking**: The practice reception team must be briefed to record when a birthday code is redeemed. This can be done by: (a) adding the `birthday-offer-redeemed` tag manually, (b) using a GHL form/action when booking with the code, or (c) noting it in appointment notes. Without tracking, redemption metrics cannot be measured.
- **No follow-up chase**: Unlike other sequences, the birthday workflow deliberately does NOT include a reminder or follow-up. Chasing someone to use their "gift" undermines the goodwill gesture. The email is sent once; if they use it, great; if not, it still created a positive touchpoint.
- **Date of birth requirement**: This workflow only works for patients who have their date of birth recorded. Ensure the new-patient registration form and practice management system capture DOB. Consider a data enrichment campaign to collect missing DOBs from existing patients.
- **Age sensitivity**: Do NOT include the patient's age or year of birth in the email. "Happy Birthday" is warm; "Happy 47th Birthday" can be unwelcome.
- **Annual reset**: The `birthday-triggered` tag is removed at Step 8 so the workflow can re-trigger the following year. Ensure GHL's date-based trigger is configured to run annually, not as a one-time event.
- **Children**: For pediatric patients (under 16), the birthday email should be addressed to the parent/guardian. Consider a separate template or condition based on `patient_type = child` custom field.
- **Overlap**: Birthday emails can coexist with other sequences (recall, nurture). However, if a patient receives both a recall email and a birthday email on the same day, the birthday email should take priority (more personal). Use GHL send time spacing to ensure at least 4 hours between emails.
