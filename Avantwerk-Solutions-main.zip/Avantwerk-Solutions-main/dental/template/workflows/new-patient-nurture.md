# New Patient Nurture

**Package tier**: Momentum AI
**Trigger**: Enquiry received without a booking (form submission, chatbot enquiry, or missed call without appointment)
**Goal**: Convert 30%+ of enquiries into booked first appointments within 7 days

## Pipeline & Tags

- Pipeline: Lead Nurture
- Entry tag: `enquiry-no-booking`
- Completion tag: `nurture-converted` or `nurture-sequence-complete`
- Additional tags: `nurture-email-1-sent`, `nurture-sms-sent`, `nurture-email-2-sent`, `nurture-email-3-sent`, `nurture-cold`
- Custom fields used:
  - `{{contact.first_name}}` — enquiry name
  - `{{contact.email}}` — enquiry email
  - `{{contact.phone}}` — enquiry phone number
  - `{{custom_field.enquiry_source}}` — where the enquiry came from (website form, chatbot, phone, social media)
  - `{{custom_field.enquiry_interest}}` — what treatment/service they enquired about (if captured)
  - `{{location.name}}` — practice name
  - `{{location.phone}}` — practice phone number
  - `{{location.booking_link}}` — online booking URL
  - `{{custom_field.new_patient_offer}}` — current new patient offer (e.g., "Free check-up" or "20% off first visit")

## Flow

1. **Trigger**: Contact created or updated with tag `enquiry-no-booking`
   - Fires when: website enquiry form submitted, chatbot conversation ended without booking, missed call logged without callback resulting in booking
   - Move to pipeline stage: **New Enquiry**

2. **Condition**: Check if contact already has tag `new-patient` or `appointment-booked`
   - **If already a patient or has booking**: Exit workflow (they've already converted)
   - **If neither**: Continue

3. **Condition**: Check if contact has a valid email address
   - **If no email**: Skip to Step 5 (SMS path)
   - **If email exists**: Continue

4. **Wait**: 1 hour after enquiry
   - Short delay allows for: manual follow-up by reception if they're available, patient booking on their own, and avoids appearing "too automated"
   - If 1h falls outside business hours (before 8:00 or after 20:00), send at next 09:00

5. **Action**: Send initial nurture email
   - Template: `emails/uk/nurture-email-1.html`
   - Subject: "Thanks for your enquiry, {{contact.first_name}} -- here's how we can help"
   - Body includes:
     - Acknowledge their enquiry (reference {{custom_field.enquiry_interest}} if available)
     - Brief practice introduction (friendly, professional, established)
     - Key differentiators (modern equipment, gentle approach, flexible hours)
     - Clear booking CTA with online booking link
     - Alternative: "Prefer to call? Ring us on {{location.phone}}"
     - Practice photo or team photo for trust-building
   - Add tag: `nurture-email-1-sent`
   - Type: **Marketing** (include unsubscribe link)

6. **Wait**: 23 hours (total 24h from enquiry)
   - If send time falls outside 09:00-19:00, defer to next valid window

7. **Condition**: Check if contact has booked an appointment
   - **If booked**: Add tag `nurture-converted`, move to pipeline stage **Converted**, exit workflow
   - **If not booked**: Continue

8. **Action**: Send SMS nudge
   - Template: `emails/uk/nurture-sms.txt`
   - Message: "Hi {{contact.first_name}}, we noticed you were looking into dental care at {{location.name}}. We'd love to help! Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out."
   - Respect business hours: 09:00-19:00 UK time only
   - Add tag: `nurture-sms-sent`
   - Type: **Marketing** (include STOP opt-out)

9. **Wait**: 2 days (total approximately 3 days from enquiry)

10. **Condition**: Check if contact has booked an appointment
    - **If booked**: Add tag `nurture-converted`, move to pipeline stage **Converted**, exit workflow
    - **If not booked**: Continue

11. **Condition**: Verify contact still has marketing consent (not unsubscribed)
    - **If unsubscribed**: Exit workflow, add tag `nurture-sequence-complete`
    - **If still subscribed**: Continue

12. **Action**: Send offer email (value + incentive)
    - Template: `emails/uk/nurture-email-2-offer.html`
    - Subject: "A special welcome offer for you, {{contact.first_name}}"
    - Body includes:
      - Reference that it's been a few days since their enquiry
      - New patient offer: {{custom_field.new_patient_offer}} (e.g., "Free consultation", "20% off first check-up", or "Complimentary hygiene assessment")
      - Patient testimonials or review snippets for social proof
      - "Spaces are filling up" -- gentle urgency (only if true/appropriate)
      - Prominent booking CTA
    - Add tag: `nurture-email-2-sent`
    - Type: **Marketing** (include unsubscribe link)

13. **Wait**: 4 days (total approximately 7 days from enquiry)

14. **Condition**: Check if contact has booked an appointment
    - **If booked**: Add tag `nurture-converted`, move to pipeline stage **Converted**, exit workflow
    - **If not booked**: Continue

15. **Condition**: Verify contact still has marketing consent
    - **If unsubscribed**: Exit workflow, add tag `nurture-sequence-complete`
    - **If still subscribed**: Continue

16. **Action**: Send final push email (last chance)
    - Template: `emails/uk/nurture-email-3-final.html`
    - Subject: "Still thinking about it, {{contact.first_name}}?"
    - Body includes:
      - Acknowledge they might be busy or undecided
      - Address common concerns: cost transparency, nervous patients welcome, flexible scheduling
      - Reiterate the offer if still valid
      - "We're here whenever you're ready" -- warm, no-pressure close
      - Final booking CTA
      - "If you have questions, reply to this email and our team will get back to you"
    - Add tag: `nurture-email-3-sent`
    - Type: **Marketing** (include unsubscribe link)

17. **Wait**: 7 days (total approximately 14 days from enquiry)

18. **Condition**: Final check if contact has booked
    - **If booked**: Add tag `nurture-converted`, move to pipeline stage **Converted**, exit workflow
    - **If not booked**: Continue

19. **Action**: Mark lead as cold
    - Add tag: `nurture-sequence-complete`
    - Add tag: `nurture-cold`
    - Move to pipeline stage: **Cold Lead**
    - No further automated outreach
    - Internal task created: "Cold lead: {{contact.first_name}} {{contact.last_name}} -- enquired about {{custom_field.enquiry_interest}} on [date]. Consider manual outreach in 30 days."

20. **End workflow**

### Exit Conditions
- Contact books an appointment at any step --> exit with `nurture-converted`
- Contact registers as new patient (tag `new-patient` added) --> exit, new-patient-welcome workflow takes over
- Contact unsubscribes from marketing --> exit immediately
- Contact marked as "Do Not Contact" --> exit immediately
- Contact replies with "not interested" or similar --> exit, add tag `nurture-cold`
- Contact enters the new-patient-welcome workflow --> exit nurture (welcome takes priority)

## Templates Referenced

| Template | Step | Channel | Type |
|----------|------|---------|------|
| `emails/uk/nurture-email-1.html` | 5 | Email | Marketing |
| `emails/uk/nurture-sms.txt` | 8 | SMS | Marketing |
| `emails/uk/nurture-email-2-offer.html` | 12 | Email | Marketing |
| `emails/uk/nurture-email-3-final.html` | 16 | Email | Marketing |

## Success Metrics

- **Target**: 30%+ of enquiries convert to booked first appointments within 14 days
- **Measure**: Conversion rate = contacts with `nurture-converted` / contacts with `enquiry-no-booking`
- **Email metrics**: Open rate > 40% on email 1, > 30% on emails 2-3; click-through > 10%
- **SMS metrics**: Click-through > 8% on booking link
- **Speed to booking**: Median time from enquiry to booking (target < 3 days)
- **Secondary**: Reduce reception time spent on manual follow-up calls by 70%

## Notes

- **Speed matters**: Research shows that responding to enquiries within 1 hour increases conversion by 7x compared to waiting 24 hours. The 1-hour initial email is critical.
- **All messages are marketing**: Every message in this sequence is marketing (encouraging a new booking from a prospect). All require marketing consent and unsubscribe options. If the enquiry form doesn't capture marketing consent, the practice must add a consent checkbox.
- **Enquiry source personalization**: If `enquiry_interest` is captured (e.g., "whitening", "implants", "check-up"), use it to personalize email content. GHL conditional content blocks or separate template variants can handle this.
- **Offer management**: The `new_patient_offer` custom field should be maintained by the practice. If no current offer, the email template should gracefully hide the offer section and focus on value proposition instead.
- **Business hours**: All sends constrained to 09:00-19:00 UK time. Weekend sends are acceptable (Saturday morning is actually a good time for dental enquiry follow-ups) but avoid Sundays before 10:00.
- **Do not overlap**: If the contact is already in a recall-reminder or cancellation-recovery workflow, they should NOT enter the nurture sequence. Use GHL "Contact is NOT in workflow" conditions.
- **Manual follow-up complement**: The reception team should still attempt to call new enquiries within 30 minutes during business hours. The automated sequence is a safety net, not a replacement for personal contact. If reception confirms they've already spoken to the patient, the workflow should still run (it reinforces the conversation).
- **Re-entry prevention**: Once a contact has completed the nurture sequence (either converted or marked cold), they should not re-enter for 90 days. Use the `nurture-sequence-complete` tag with a date-based condition to enforce this.
- **Cold lead re-engagement**: Contacts tagged `nurture-cold` can be re-engaged with a separate reactivation campaign in 60-90 days, but this is outside the scope of this workflow.
