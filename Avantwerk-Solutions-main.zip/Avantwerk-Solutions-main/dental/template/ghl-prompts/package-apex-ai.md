# Apex AI -- Dental Practice (UK)

**Package price**: GBP 3,999 (GBP 3,399 with annual subscription)
**Delivery timeline**: 45-60 days
**Hypercare**: 30 days post-handoff
**Total estimated build time**: 55-70 hours

This is the complete GHL execution playbook for the Apex AI dental implementation package (UK market). It is self-contained: one person should be able to deliver the entire package by working through this document sequentially, from pre-setup through to client handoff.

**Cross-references**: This playbook references detailed build instructions in three companion documents. Where a deliverable is fully specified in a companion file, a cross-reference is given. Where it is not (Apex-exclusive items), the full specification is provided here.

| Companion Document | Contents |
|--------------------|----------|
| `website-pages.md` | GHL AI builder prompts and manual build notes for all 17+ website pages |
| `workflows.md` | Step-by-step GHL workflow builder instructions for all 8+ automations |
| `chatbot-setup.md` | Full chatbot system prompt, knowledge base, widget config, and testing |

---

## Pre-Setup Checklist

Complete all items below before starting any GHL build work. Estimated time: 2-4 hours (includes client kick-off call and information gathering).

### Client Information Required

Gather the following from the client before starting. Use the Client Information Template in Appendix A to collect systematically.

| Category | Information Needed | Status |
|----------|--------------------|--------|
| Business basics | Practice trading name, legal entity name, company number | [ ] |
| Contact | Main phone, emergency phone, email, website domain (if existing) | [ ] |
| Location | Full address, postcode, Google Maps link, parking info, accessibility info | [ ] |
| Opening hours | Monday-Sunday hours, bank holiday hours, out-of-hours emergency info | [ ] |
| NHS status | NHS accepting? Private only? Mixed? NHS band prices if applicable | [ ] |
| Services & pricing | Full treatment list with current prices (private and NHS if applicable) | [ ] |
| Team | Names, roles, qualifications, GDC numbers, brief bios, headshot photos | [ ] |
| Brand | Logo files (PNG/SVG), brand colours (if any -- otherwise use dental defaults), tagline | [ ] |
| Existing presence | Google Business Profile URL, Google review link, existing website URL, social media links | [ ] |
| Reviews | 3-5 real patient reviews (with permission) for use on the website | [ ] |
| Finance | Payment plans offered? Finance provider? Monthly membership plan details and price | [ ] |
| Insurance | Dental insurance accepted? Which providers? | [ ] |
| Multi-location | Additional locations? (Apex includes multi-location support) | [ ] |
| Booking preferences | Appointment types, durations, buffer times, available calendars | [ ] |
| Chatbot | Bot name preference, languages spoken by staff, sedation options offered, cancellation policy, missed appointment fee | [ ] |
| PMS | Practice management software in use (Dentally, SOE, Carestream, etc.) | [ ] |
| Birthday offer | Birthday offer details (e.g., "10% off teeth whitening"), offer code format | [ ] |
| Referral programme | Referral reward details (e.g., "GBP 25 credit for referrer and referee") | [ ] |
| Training | Preferred date and time for staff training session (1 hour video call) | [ ] |
| Blog topics | 3 seed article topics (suggest based on their top services) | [ ] |
| Photos | Practice interior, exterior, treatment room, waiting area, team photos | [ ] |
| Compliance | CQC registration number, GDC practice number, data protection registration | [ ] |

### Accounts and Access Required

| Account / Access | Purpose | Status |
|------------------|---------|--------|
| GHL agency sub-account created | All build work | [ ] |
| Email sending domain verified in GHL | Transactional and marketing emails | [ ] |
| SMS enabled with UK sender number | Two-way SMS for reminders | [ ] |
| Google Business Profile access | Review link, business info verification | [ ] |
| Domain DNS access (or client's IT contact) | Custom domain connection | [ ] |
| Practice management system credentials (if PMS integration) | Chatbot PMS integration | [ ] |
| Client's social media links | Footer and contact page | [ ] |

### Kick-Off Call Agenda (30-45 minutes)

1. Introduce the Apex AI package scope and 45-60 day timeline
2. Walk through the Client Information Template (Appendix A)
3. Agree on brand direction (client colours or dental industry defaults)
4. Confirm multi-location requirements
5. Discuss PMS integration scope and feasibility
6. Agree on blog article topics
7. Schedule the staff training session date
8. Set expectations: weekly progress updates, mid-point review at day 25, QA at day 40
9. Share Hypercare overview and what happens post-handoff

---

## Phase 1: GHL Sub-Account Setup (45-60 min)

### Step 1.1 -- Create Sub-Account

1. Log into the GHL agency dashboard
2. Click **Sub-Accounts** -> **Create Sub-Account**
3. Complete the setup:
   - Business name: `[BUSINESS_NAME]`
   - Business email: `[EMAIL]`
   - Phone: `[PHONE]`
   - Address: `[ADDRESS]`, `[CITY]`, `[POSTCODE]`
   - Country: United Kingdom
   - Timezone: Europe/London
   - Currency: GBP
4. Click **Save**

### Step 1.2 -- Configure Location Settings

1. Go to **Settings -> Business Profile**
2. Upload the practice logo
3. Set business name, address, phone, email
4. Set opening hours (Monday-Sunday)
5. Add the Google review link to Location custom fields (create `google_review_link` if it does not exist)
6. Add the online booking link to Location custom fields (create `booking_link` if it does not exist)
7. Add parking info to Location custom fields (create `parking_info` if it does not exist)

### Step 1.3 -- Verify Email Domain

1. Go to **Settings -> Email Services**
2. Add the client's email domain
3. Configure SPF, DKIM, and DMARC records with the client's DNS provider
4. Verify the domain in GHL (may take up to 48 hours for DNS propagation)
5. Set the default "From" name to `[BUSINESS_NAME]`
6. Set the default "Reply-To" to `[EMAIL]`

### Step 1.4 -- Enable SMS

1. Go to **Settings -> Phone Numbers**
2. Purchase or port a UK phone number
3. Register the number for two-way SMS
4. Configure the SMS sending window: 08:00-20:00 (respect UK marketing regulations)
5. Test SMS send and receive

### Step 1.5 -- Connect Domain

1. Go to **Sites -> Domains**
2. Add the client's domain (or a subdomain, e.g., `book.[DOMAIN].co.uk`)
3. Configure DNS CNAME records as instructed by GHL
4. Verify SSL certificate is active

### Step 1.6 -- Set Up Calendars

Create the following calendars in **Calendars**:

| Calendar | Type | Duration | Buffer | Confirmation |
|----------|------|----------|--------|-------------|
| General Check-up | Round Robin / Unassigned | 30 min | 15 min | Auto-confirm |
| Dental Hygiene | Assigned (hygienist) | 45 min | 15 min | Auto-confirm |
| Emergency | Round Robin / Priority | 20 min | 10 min | Auto-confirm |
| Cosmetic Consultation | Assigned (cosmetic dentist) | 45 min | 15 min | Auto-confirm |
| Invisalign Consultation | Assigned (orthodontist/trained dentist) | 60 min | 15 min | Auto-confirm |
| Implant Consultation | Assigned (implant dentist) | 60 min | 15 min | Auto-confirm |
| New Patient Examination | Round Robin | 60 min | 15 min | Auto-confirm |
| Treatment Appointment | Assigned | 60 min | 15 min | Manual confirm |

For each calendar:
- Set available hours to match practice opening times
- Configure team member assignments
- Enable online booking
- Set the confirmation email trigger (this will be handled by Workflow 1)

---

## Phase 2: Custom Fields & Tags (30-45 min)

### Step 2.1 -- Create Contact Custom Fields

Go to **Settings -> Custom Fields -> Contact** and create the following:

| Field Name | Field Type | Used By | Notes |
|------------|-----------|---------|-------|
| `last_checkup_date` | Date | Recall Reminder | Updated after every check-up |
| `enquiry_source` | Dropdown | New Patient Nurture | Options: Website Form, Chatbot, Phone, Social Media |
| `enquiry_interest` | Single Line Text | New Patient Nurture | Treatment they enquired about |
| `new_patient_offer` | Single Line Text | New Patient Nurture | Current new patient offer text |
| `cancellation_reason` | Dropdown | Cancellation Recovery | Options: Schedule Conflict, Cost, Found Another Dentist, Feeling Better, Other |
| `treatment_plan_type` | Dropdown | Treatment Plan Follow-up | Options: Implant, Invisalign, Crown, Whitening, Veneer, Bonding, Bridge, Root Canal, Other |
| `treatment_plan_value` | Number (Currency) | Treatment Plan Follow-up | Estimated cost of the plan |
| `treatment_plan_date` | Date | Treatment Plan Follow-up | Date the plan was presented |
| `treating_dentist` | Single Line Text | Treatment Plan Follow-up | Dentist who presented the plan |
| `payment_plan_available` | Dropdown | Treatment Plan Follow-up | Options: Yes, No |
| `patient_type` | Dropdown | Recall Reminder, New Patient Welcome | Options: NHS, Private |
| `birthday_offer_code` | Single Line Text | Birthday/Loyalty | Unique offer code |
| `birthday_offer_description` | Single Line Text | Birthday/Loyalty | Offer description text |
| `birthday_offer_expiry` | Date | Birthday/Loyalty | Offer expiry date |
| `waitlist` | Dropdown | Cancellation Recovery | Options: Yes, No |
| `waitlist_preference` | Multi Line Text | Cancellation Recovery | Preferred days/times |
| `referral_source_patient` | Single Line Text | Referral Programme | Name of the referring patient |
| `referral_reward_status` | Dropdown | Referral Programme | Options: Pending, Credited, Expired |
| `referral_date` | Date | Referral Programme | Date of referral |

### Step 2.2 -- Create Location Custom Fields

Go to **Settings -> Custom Fields -> Location** and create (if not already present):

| Field Name | Field Type | Notes |
|------------|-----------|-------|
| `google_review_link` | URL | Direct Google review link |
| `booking_link` | URL | Online booking page URL |
| `parking_info` | Multi Line Text | Parking instructions |
| `referral_reward_description` | Single Line Text | e.g., "GBP 25 credit for you and your friend" |

### Step 2.3 -- Create Tags

Go to **Settings -> Tags** and create all tags. Organise them by category using tag folders if your GHL version supports it.

**Appointment Reminder**:
`appointment-booked`, `appointment-confirmed`, `appointment-no-show`, `appointment-completed`

**Review Request**:
`review-requested`, `review-clicked`, `review-left`, `review-requested-complete`

**Recall Reminder**:
`recall-due`, `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-booked`, `recall-sequence-complete`, `recall-overdue`

**New Patient Welcome**:
`new-patient`, `welcome-email-sent`, `welcome-followup-sent`, `new-patient-welcomed`

**New Patient Nurture**:
`enquiry-no-booking`, `nurture-email-1-sent`, `nurture-sms-sent`, `nurture-email-2-sent`, `nurture-email-3-sent`, `nurture-converted`, `nurture-sequence-complete`, `nurture-cold`

**Cancellation Recovery**:
`appointment-cancelled`, `recovery-sms-sent`, `recovery-email-sent`, `waitlist-notified`, `cancellation-rebooked`, `cancellation-recovered`, `cancellation-recovery-complete`

**Birthday/Loyalty**:
`birthday-triggered`, `birthday-email-sent`, `birthday-offer-redeemed`, `birthday-complete`

**Treatment Plan Follow-up**:
`treatment-plan-presented`, `tp-checkin-sent`, `tp-reminder-sent`, `tp-reengage-sent`, `treatment-plan-accepted`, `treatment-plan-declined`, `treatment-plan-followup-complete`

**Referral Programme**:
`referral-made`, `referral-thank-you-sent`, `referral-new-patient-booked`, `referral-reward-credited`, `referral-programme-complete`

**General**:
`inactive-patient`, `do-not-contact`, `frequent-canceller`

---

## Phase 3: Pipeline Setup (20-30 min)

Go to **CRM -> Pipelines** and create the following pipelines:

| # | Pipeline | Stages |
|---|----------|--------|
| 1 | Patient Appointments | Booked -> Confirmed -> Completed -> No Show |
| 2 | Patient Engagement | Review Requested -> Review Clicked -> Review Sequence Complete |
| 3 | Recall Management | Recall Due -> Recall Booked -> Overdue - Manual Follow-up |
| 4 | New Patient Journey | New Registration -> Welcomed |
| 5 | Lead Nurture | New Enquiry -> Converted -> Cold Lead |
| 6 | Cancellation Recovery | Cancelled -> Rebooked -> Not Recovered |
| 7 | Treatment Plan Conversion | Plan Presented -> Accepted -> Pending - Manual Review |
| 8 | Referral Programme | Referral Made -> New Patient Booked -> Reward Credited |

For each pipeline:
1. Set the pipeline name
2. Add stages in the order listed
3. Set the default stage (first stage)
4. Configure pipeline visibility for relevant team members

---

## Phase 4: Website -- 17+ Pages (18-24 hours)

### Design System

All pages use the dental industry default palette and DM Sans typography. Full specification in `website-pages.md`.

| Property | Value |
|----------|-------|
| Primary Blue | #2563eb |
| Primary Hover | #1d4ed8 |
| Secondary Cyan | #06b6d4 |
| Accent Green | #10b981 |
| Page Background | #f8fafc |
| Section Background | #ffffff |
| Card Background | #f1f5f9 |
| Card Hover | #e2e8f0 |
| Heading Text | #0f172a |
| Body Text | #475569 |
| Muted Text | #94a3b8 |
| Font | DM Sans (Google Fonts) |
| Border Radius (cards) | 16px |
| Border Radius (buttons) | 12px |
| Tone | Professional, warm, trustworthy, British English |

### CSS Variables (include at top of every Custom Code section)

```css
:root {
  --brand-primary: #2563eb;
  --brand-primary-hover: #1d4ed8;
  --brand-primary-light: rgba(37,99,235,0.08);
  --brand-secondary: #06b6d4;
  --brand-accent: #10b981;
  --bg-page: #f8fafc;
  --bg-section: #ffffff;
  --bg-card: #f1f5f9;
  --bg-card-hover: #e2e8f0;
  --text-heading: #0f172a;
  --text-body: #475569;
  --text-muted: #94a3b8;
  --text-on-primary: #ffffff;
  --border-color: rgba(0,0,0,0.08);
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
  --shadow-md: 0 4px 16px rgba(0,0,0,0.08);
  --shadow-lg: 0 12px 40px rgba(0,0,0,0.10);
  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 16px;
  --radius-full: 100px;
}
```

### Header & Footer (Enhanced with Mega-Menu)

**Estimated time**: 90 minutes

Build natively in GHL's page builder. The Apex header includes a mega-menu for the Services dropdown.

**Header:**
- Logo (left-aligned)
- Navigation links: Home, Services (mega-menu dropdown), About, Reviews, Blog, FAQ, Contact
- CTA button (right-aligned): "Book Online" linking to `/booking`
- Emergency phone number displayed: "Emergency? Call [EMERGENCY_PHONE]"
- Mobile: hamburger menu with full navigation

**Services Mega-Menu** (desktop only -- falls back to standard dropdown on mobile):

| Column 1: General | Column 2: Cosmetic | Column 3: Specialist | Column 4: Other |
|-------------------|--------------------|-----------------------|-----------------|
| Check-up & Exam | Teeth Whitening | Dental Implants | Emergency Care |
| Dental Hygiene | Composite Bonding | Invisalign | Children's Dentistry |
| Fillings | Porcelain Veneers | Fixed Braces | |
| Root Canal | Smile Makeover | | |
| Crowns & Bridges | | | |
| Extractions | | | |

Each mega-menu item links to its respective page or the Services page anchor.

**Footer:**
- 4-column layout:
  - Column 1: Logo, brief practice description (2 sentences), social media icons
  - Column 2: Quick Links (Home, Services, About, Reviews, Blog, Contact)
  - Column 3: Treatments (Check-up, Whitening, Implants, Invisalign, Cosmetic, Emergency)
  - Column 4: Contact Info (address, phone, emergency phone, email, opening hours summary)
- Bottom bar: Copyright line, Privacy Policy link, Terms & Conditions link, Cookie Policy link, Complaints Procedure link
- "Powered by Avantwerk" small text (optional -- discuss with client)

### Page 1: Homepage (2.5 hours)

**See**: `website-pages.md` -> Page 1: Homepage

**URL slug**: `/` (root)
**Sections**: 8
- Hero with badge, headline, subheadline, dual CTA, trust line
- Trust bar (Google rating, patient count, years established, GDC registered)
- Services overview (8 service cards in grid)
- Why Choose Us (4 feature cards)
- Meet the Team preview (4 team members)
- Patient Reviews (3 review cards)
- Booking CTA banner (full-width gradient)
- Location and opening hours (2-column with map)

**Native GHL elements**: Header, footer, Google Maps embed, chat widget.

### Page 2: Services (Comprehensive) (2 hours)

**See**: `website-pages.md` -> Page 2: Services

**URL slug**: `/services`
**Sections**: 5
- Compact hero with breadcrumb
- Service categories (6 categories: General, Cosmetic, Orthodontics, Implants, Emergency, Children's) with treatment cards showing descriptions and prices
- Treatment process (4-step timeline: Consultation -> Plan -> Treatment -> Aftercare)
- Payment options (3 cards: Pay As You Go, 0% Finance, Dental Plan)
- CTA banner

### Page 3: About Us (2 hours)

**See**: `website-pages.md` -> Page 3: About Us

**URL slug**: `/about`
**Sections**: 7
- Compact hero
- Practice story (2-column: image + text)
- Values (4 cards: Clinical Excellence, Patient-First Care, Honest Communication, Continuous Innovation)
- Full team (6 team member cards with photos, roles, qualifications, bios)
- Facilities (3-column with images: treatment rooms, waiting area, technology)
- Accreditations & memberships
- CTA banner

### Page 4: Contact (1.5 hours)

**See**: `website-pages.md` -> Page 4: Contact

**URL slug**: `/contact`
**Sections**: 4
- Compact hero
- Contact details + Google Maps embed (2-column)
- **Native GHL contact form** (name, email, phone, message, enquiry type dropdown)
- Opening hours + emergency info

**Native GHL elements**: Contact form (wired to pipeline: Lead Nurture / New Enquiry stage), Google Maps embed.

**GHL form fields**:
- First Name (required)
- Last Name (required)
- Email (required)
- Phone (required)
- Enquiry Type (dropdown: General Enquiry, New Patient Registration, Treatment Enquiry, Appointment Change, Complaint, Other)
- Message (textarea)
- Marketing consent checkbox: "I consent to receiving communications from [BUSINESS_NAME]"

**Form submission actions**:
- Add tag: `enquiry-no-booking`
- Add to pipeline: Lead Nurture -> New Enquiry
- Send internal notification to Reception

### Page 5: Booking (1 hour)

**See**: `website-pages.md` -> Page 5: Booking

**URL slug**: `/booking`
**Sections**: 3
- Compact hero: "Book Your Appointment"
- **Native GHL calendar widget** (embedded, showing all available appointment types)
- Info section: what to expect, what to bring, cancellation policy

**Native GHL elements**: Calendar booking widget (this is the primary page element -- must be native for automation wiring).

### Page 6: Teeth Whitening (1.5 hours)

**See**: `website-pages.md` -> Page 6: Teeth Whitening

**URL slug**: `/teeth-whitening`
**Sections**: 7
- Compact hero with breadcrumb
- Treatment overview (what is teeth whitening, in-surgery vs home kits)
- Benefits (6 benefit points with icons)
- Treatment process (step-by-step: consultation, shade assessment, treatment, aftercare)
- Pricing table (In-surgery from GBP 300-600, Home kit from GBP 200-350)
- FAQ accordion (5-6 common whitening questions)
- CTA banner: "Ready for a Brighter Smile?"

### Page 7: Dental Implants (1.5 hours)

**See**: `website-pages.md` -> Page 7: Dental Implants

**URL slug**: `/dental-implants`
**Sections**: 8
- Compact hero with breadcrumb
- What are dental implants (overview with image)
- Types of implants (3 cards: single tooth, implant bridge, All-on-4)
- Benefits vs alternatives comparison table (implants vs dentures vs bridges)
- Treatment timeline (5 steps: consultation, planning, placement, healing, crown fitting)
- Pricing table (single from GBP 2,000, bridge from GBP 4,000, All-on-4 from GBP 8,000)
- FAQ accordion (6-8 implant questions)
- CTA banner: "Discover If Implants Are Right for You"

### Page 8: Invisalign (1.5 hours)

**See**: `website-pages.md` -> Page 8: Invisalign

**URL slug**: `/invisalign`
**Sections**: 7
- Compact hero with breadcrumb
- What is Invisalign (overview with before/after image area)
- How it works (4-step process: scan, plan, wear, retain)
- Invisalign vs braces comparison table
- Pricing (from GBP 2,500-5,500 depending on complexity)
- FAQ accordion (6-8 Invisalign questions)
- CTA banner: "Start Your Invisalign Journey"

### Page 9: Cosmetic Dentistry (Overview) (1.5 hours)

**See**: `website-pages.md` -> Page 9: Cosmetic Dentistry

**URL slug**: `/cosmetic-dentistry`
**Sections**: 6
- Compact hero with breadcrumb
- Overview: "Transform Your Smile"
- Treatment cards (4 cards: whitening, bonding, veneers, smile makeover -- each with description, starting price, link to dedicated page where applicable)
- Digital Smile Design section (explain the consultation process)
- Before/after gallery placeholder (image grid with caption placeholders)
- CTA banner: "Book Your Smile Consultation"

### Page 10: Emergency Dental Care (1.5 hours)

**See**: `website-pages.md` -> Page 10: Emergency Dental Care

**URL slug**: `/emergency`
**Sections**: 6
- Compact hero (urgent tone): "Dental Emergency? We're Here to Help"
- Emergency contact bar (prominent display of `[EMERGENCY_PHONE]` and call button)
- Common emergencies grid (6 cards: toothache, knocked-out tooth, broken/chipped tooth, abscess/swelling, lost filling/crown, bleeding that will not stop -- each with immediate first-aid advice)
- What to expect: same-day emergency process
- Out-of-hours guidance (NHS 111, A&E, when to call 999)
- Pricing: Emergency consultation from GBP 80-150

### Page 11: Reviews / Testimonials (1.5 hours)

**See**: `website-pages.md` -> Page 11: Reviews / Testimonials

**URL slug**: `/reviews`
**Sections**: 4
- Compact hero: "What Our Patients Say"
- Stats bar: Google rating, total review count, percentage 5-star
- Review grid (9-12 review cards, 3 columns desktop, each with star rating, quote, name initial, treatment type)
- CTA: "Leave us a review" button linking to `[GOOGLE_REVIEW_URL]` + "Book your appointment" button

### Page 12: FAQ (With Schema Markup) (2 hours)

**URL slug**: `/faq`
**Sections**: 4

**GHL AI Builder Prompt**:

> Build a Frequently Asked Questions page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Light blue-tinted background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > FAQ"
> - Headline (H1): "Frequently Asked Questions"
> - Subheadline: "Find answers to the most common questions about our practice, treatments, and what to expect when you visit."
>
> SECTION 2 -- FAQ CATEGORIES
> Organise FAQs into accordion sections grouped by category. Each question expands on click to show the answer. Use smooth CSS animations for the expand/collapse.
>
> Category 1: "About Our Practice"
> Q: Where is [BUSINESS_NAME] located?
> A: We are located at [ADDRESS]. There is [PARKING_INFO]. For directions, view our location on Google Maps: [GOOGLE_MAPS_URL]
>
> Q: What are your opening hours?
> A: Monday to Friday: [MON_FRI_HOURS]. Saturday: [SAT_HOURS]. Sunday: Closed. For dental emergencies outside these hours, call [EMERGENCY_PHONE].
>
> Q: Do you accept NHS patients?
> A: [NHS_STATUS_ANSWER]
>
> Q: Is the practice wheelchair accessible?
> A: [ACCESSIBILITY_INFO]
>
> Q: Do you see children?
> A: Yes, we welcome patients of all ages. We recommend bringing children for their first visit from around 6-12 months of age. Our team is experienced in making dental visits fun and positive for young patients.
>
> Category 2: "New Patients"
> Q: How do I register as a new patient?
> A: You can register by booking your first appointment online at [BOOKING_URL] or by calling us on [PHONE]. We will send you a medical history form to complete before your visit. There is no registration fee.
>
> Q: What should I bring to my first appointment?
> A: Please bring photo ID, a list of any medications you are currently taking, dental insurance details (if applicable), and any previous dental records or X-rays. Allow approximately 45-60 minutes for your first visit.
>
> Q: I have not been to the dentist in years. Will you judge me?
> A: Absolutely not. Many of our patients come to us after a long gap, and we understand this can feel daunting. Our team is friendly, non-judgemental, and will take things at your pace. You are in safe hands.
>
> Q: Do you treat nervous patients?
> A: Yes, we specialise in helping anxious patients feel comfortable. We offer a calm, welcoming environment, longer appointment slots so you never feel rushed, and [SEDATION_OPTIONS]. Your dentist will explain every step before doing anything.
>
> Category 3: "Treatments"
> Q: How often should I have a check-up?
> A: We generally recommend every 6 months, but your dentist may suggest a different interval depending on your oral health. Regular check-ups help catch problems early when they are easier and cheaper to treat.
>
> Q: How long does teeth whitening last?
> A: Professional whitening results typically last 12-18 months, depending on your diet and oral hygiene habits. We provide aftercare advice and offer top-up options to maintain your results.
>
> Q: Are dental implants painful?
> A: The implant procedure is performed under local anaesthetic, so you should not feel pain during treatment. Most patients report mild discomfort for a few days afterwards, manageable with over-the-counter pain relief. We provide full aftercare instructions.
>
> Q: How long does Invisalign treatment take?
> A: Treatment time varies depending on the complexity of your case. Mild cases may take as little as 3-6 months, while more complex cases can take 12-18 months. Your dentist will give you an accurate estimate at your consultation.
>
> Q: What is the difference between NHS and private treatment?
> A: NHS treatment covers clinically necessary care at set government prices across three bands. Private treatment offers a wider choice of materials, longer appointment times, access to cosmetic procedures not available on the NHS, and appointments at times that suit you.
>
> Category 4: "Appointments & Cancellations"
> Q: How do I book an appointment?
> A: Book online anytime at [BOOKING_URL] or call us on [PHONE] during opening hours. Our chatbot on this website can also help you book.
>
> Q: How do I cancel or reschedule?
> A: Please call us on [PHONE] with at least 24 hours' notice. [CANCELLATION_POLICY]
>
> Q: What happens if I miss my appointment?
> A: We understand that things come up. However, missed appointments without notice prevent other patients from being seen. [MISSED_APPT_FEE]. Please give us at least 24 hours' notice if you need to cancel or reschedule.
>
> Q: Do you offer evening or weekend appointments?
> A: [EXTENDED_HOURS_ANSWER]
>
> Category 5: "Costs & Payment"
> Q: How much does a check-up cost?
> A: A private dental check-up starts from GBP [CHECKUP_PRICE]. NHS check-ups are GBP [NHS_BAND1] (Band 1). Your dentist will explain all costs before any treatment begins.
>
> Q: Do you offer payment plans?
> A: [FINANCE_ANSWER]. We believe cost should never be a barrier to good dental health.
>
> Q: Do you accept dental insurance?
> A: [INSURANCE_ANSWER]
>
> Category 6: "Emergencies"
> Q: What counts as a dental emergency?
> A: Severe toothache, a knocked-out or broken tooth, uncontrolled bleeding, facial swelling, difficulty breathing or swallowing, and jaw injuries all require urgent attention. Call us on [EMERGENCY_PHONE] immediately.
>
> Q: What should I do if I knock out a tooth?
> A: Pick up the tooth by the crown (the white part), not the root. Rinse it briefly under cold water. Try to place it back in the socket. If you cannot, store it in milk. Call us immediately on [EMERGENCY_PHONE] -- time is critical and we need to see you within 30-60 minutes.
>
> Q: What if I have a dental emergency outside your opening hours?
> A: Call [EMERGENCY_PHONE] for guidance. If you are experiencing difficulty breathing, difficulty swallowing, or severe swelling spreading to your neck or eye, call 999 or go to A&E immediately. You can also call NHS 111 for non-life-threatening emergencies.
>
> SECTION 3 -- SCHEMA MARKUP
> Add FAQPage schema markup (JSON-LD) to the page for SEO. Include every question and answer pair in the schema.
>
> SECTION 4 -- CTA
> Full-width blue gradient banner:
> - Headline: "Still Have Questions?"
> - Subtext: "Our team is happy to help. Get in touch and we will get back to you promptly."
> - Buttons: "Contact Us" (links to /contact) and "Chat with Us" (opens chat widget)

**Manual Build Notes**:

1. Add a new Website Page with slug `/faq`
2. Section 1 (Hero): Custom Code block with breadcrumb and heading
3. Section 2 (FAQ Accordions): Custom Code block. Build accordion components with JavaScript for expand/collapse. Group by category with category headings (H3). Each accordion item shows the question as the clickable header and the answer as the expandable body.
4. Section 3 (Schema): Add JSON-LD FAQPage schema in a Custom Code block at the bottom of the page (or in the page's header code injection). Include every Q&A pair.
5. Section 4 (CTA): Custom Code block with gradient banner.

**Schema Markup Template** (add to page head or bottom Custom Code block):

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "Where is [BUSINESS_NAME] located?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We are located at [ADDRESS]. [PARKING_INFO]."
      }
    },
    {
      "@type": "Question",
      "name": "What are your opening hours?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Monday to Friday: [MON_FRI_HOURS]. Saturday: [SAT_HOURS]. Sunday: Closed."
      }
    }
  ]
}
</script>
```

Repeat for every Q&A pair. This structured data helps the FAQ appear in Google search results as rich snippets.

### Page 13: Blog Index (1.5 hours)

**URL slug**: `/blog`
**Sections**: 3

**GHL AI Builder Prompt**:

> Build a blog index page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Blog"
> - Headline (H1): "Dental Health Blog"
> - Subheadline: "Expert advice, treatment guides, and the latest news from [BUSINESS_NAME]."
>
> SECTION 2 -- ARTICLE GRID
> A grid of blog article cards (2 columns desktop, 1 mobile). Each card has:
> - Featured image placeholder (16:9 aspect ratio)
> - Category badge (e.g., "Oral Health Tips", "Cosmetic Dentistry", "Practice News")
> - Article title (H3, linked to the article page)
> - Publication date in British format (e.g., "15 January 2026")
> - 2-sentence excerpt
> - "Read More" link
>
> Show 6 article card placeholders. The first 3 will be populated with real articles (see Pages 14-16). The remaining 3 are placeholder cards labelled "Coming Soon".
>
> SECTION 3 -- CTA
> Blue gradient banner:
> - Headline: "Have a Question About Your Dental Health?"
> - Subtext: "Our team is always happy to help. Get in touch or book a consultation."
> - Button: "Book a Consultation" linking to [BOOKING_URL]

**Manual Build Notes**:

1. Add a new Website Page with slug `/blog`
2. GHL does not have a native blog system with auto-indexing. Options:
   - Option A: Build the index page as a static Custom Code block and manually add new article cards as blog posts are published
   - Option B: If the client's GHL version supports the Blog feature, use native blog functionality
3. For Apex delivery, build 3 real articles and 3 placeholder cards

### Pages 14-16: Blog Articles (3 Seed Articles) (3 hours total)

Build 3 seed articles as individual GHL website pages. Each article should be 800-1,200 words, optimised for SEO, and written in a professional but accessible British English tone.

#### Article 1: "How Often Should You Visit the Dentist?"

**URL slug**: `/blog/how-often-should-you-visit-the-dentist`
**Category**: Oral Health Tips
**Target keyword**: "how often should you visit the dentist uk"

**Content outline**:
- Introduction: why regular dental visits matter
- The 6-month rule and when your dentist may recommend differently
- What happens during a routine check-up
- Consequences of skipping check-ups (cost comparison: prevention vs treatment)
- Special cases: children, pregnant women, smokers, diabetics
- CTA: Book your check-up at [BUSINESS_NAME]

**Schema**: Add Article schema markup (JSON-LD) with headline, author (practice name), datePublished, and description.

#### Article 2: "Everything You Need to Know About Teeth Whitening"

**URL slug**: `/blog/teeth-whitening-guide`
**Category**: Cosmetic Dentistry
**Target keyword**: "teeth whitening uk guide"

**Content outline**:
- Introduction: why teeth whitening is the UK's most popular cosmetic dental treatment
- Professional vs shop-bought whitening (safety and results comparison)
- In-surgery whitening explained (process, duration, results)
- Home whitening kits from your dentist
- How long results last and how to maintain them
- Who is eligible and who should avoid whitening
- CTA: Book a whitening consultation at [BUSINESS_NAME]

#### Article 3: "Nervous About the Dentist? Here's How We Can Help"

**URL slug**: `/blog/nervous-patient-guide`
**Category**: Patient Information
**Target keyword**: "nervous patient dentist uk"

**Content outline**:
- Introduction: dental anxiety is incredibly common (statistics)
- You are not alone: normalising dental fear
- What [BUSINESS_NAME] does differently for nervous patients
- Sedation options explained
- Tips for managing dental anxiety before your visit
- What to tell your dentist (communication is key)
- CTA: Book a no-pressure first visit

**For each article page**:
- Compact hero with breadcrumb, title, date, category badge, estimated read time
- Article body (Custom Code block with well-formatted HTML)
- Author box: "[BUSINESS_NAME] Team" with practice logo
- Related articles section (2 cards linking to the other articles)
- CTA banner at bottom
- Article schema markup (JSON-LD)

### Page 17+: Team Individual Profiles (Template) (2 hours for template + 30 min per profile)

**URL slug pattern**: `/team/[NAME_SLUG]` (e.g., `/team/dr-smith`)

Build a reusable template page for individual team member profiles. For the Apex package, create one fully-built profile and provide the template for the client to replicate for additional team members.

**GHL AI Builder Prompt**:

> Build an individual team member profile page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Light blue background (#eff6ff):
> - Breadcrumb: "Home > About > [TEAM_MEMBER_NAME]"
> - No headline (the team member name is in the profile section below)
>
> SECTION 2 -- PROFILE
> Two-column layout. Left column (40%): Large portrait image placeholder (square with 16px rounded corners). Right column (60%):
> - Name (H1): "[TEAM_MEMBER_NAME]"
> - Role badge: "[ROLE]" (styled as a pill badge with primary blue background and white text)
> - Qualifications: "[QUALIFICATIONS]" (e.g., "BDS, MJDF RCS (Eng)")
> - GDC Number: "[GDC_NUMBER]"
> - Bio: 2-3 paragraphs about the team member's background, specialisms, approach to patient care, and personal interests. Written in a warm, professional tone.
>
> SECTION 3 -- SPECIALISMS
> Heading (H2): "Areas of Expertise"
> A grid of 4-6 specialism cards (3 columns desktop). Each card has an icon area, specialism name, and a one-sentence description. Example specialisms:
> - Dental Implants
> - Cosmetic Dentistry
> - Invisalign / Orthodontics
> - Nervous Patient Care
> - Root Canal Treatment
> - Smile Makeovers
>
> SECTION 4 -- QUALIFICATIONS & TRAINING
> Heading (H2): "Qualifications & Professional Development"
> A timeline or list showing:
> - Degree and university
> - Postgraduate qualifications
> - Continued professional development courses
> - Professional memberships (British Dental Association, etc.)
>
> SECTION 5 -- PATIENT REVIEWS
> Heading (H2): "What Patients Say About [TEAM_MEMBER_NAME]"
> 2-3 review cards specific to this team member (or practice reviews mentioning them by name).
>
> SECTION 6 -- CTA
> Blue gradient banner:
> - Headline: "Book an Appointment with [TEAM_MEMBER_NAME]"
> - Button: "Book Now" linking to [BOOKING_URL]
> - Text link: "Or call [PHONE]"

**Multi-Location Pages (if applicable)**:

If the client has multiple locations, create a `/locations` index page listing all locations with address, phone, and map for each. Each location should link to a dedicated sub-page or have its own booking calendar.

---

## Phase 5: Workflows -- 9+ Automations (12-16 hours)

Build workflows in the order specified below to handle tag dependencies correctly. Full step-by-step instructions for Workflows 1-8 are in `workflows.md`. Workflow 9 (Referral Programme) is Apex-exclusive and fully specified here.

### Recommended Build Order

| Order | Workflow | Package Tier | Build Time | Reference |
|-------|----------|--------------|------------|-----------|
| 1 | Appointment Reminder | Ignite AI | 45-60 min | `workflows.md` -> Workflow 1 |
| 2 | Review Request | Ignite AI | 30-40 min | `workflows.md` -> Workflow 2 |
| 3 | New Patient Welcome | Elevate AI | 35-45 min | `workflows.md` -> Workflow 4 |
| 4 | New Patient Nurture | Momentum AI | 55-70 min | `workflows.md` -> Workflow 5 |
| 5 | Cancellation Recovery | Momentum AI | 50-60 min | `workflows.md` -> Workflow 6 |
| 6 | Recall Reminder | Elevate AI | 50-60 min | `workflows.md` -> Workflow 3 |
| 7 | Birthday/Loyalty | Apex AI | 25-35 min | `workflows.md` -> Workflow 7 |
| 8 | Treatment Plan Follow-up | Apex AI | 50-65 min | `workflows.md` -> Workflow 8 |
| 9 | Referral Programme | Apex AI | 40-55 min | This document (below) |

### Workflow Interaction Rules

To prevent message fatigue, configure these overlap rules using "Contact is NOT in Workflow" conditions:

| If Patient Is In... | And Enters... | Action |
|---------------------|---------------|--------|
| New Patient Nurture | New Patient Welcome | Exit Nurture, Welcome takes priority |
| Recall Reminder | Cancellation Recovery | Pause Recall for 14 days |
| Recall Reminder | New Patient Nurture | Defer Recall start by 14 days |
| Any workflow | Birthday/Loyalty | Both can run; space emails 4h apart |
| Treatment Plan Follow-up | Cancellation Recovery | Recovery takes priority (time-sensitive) |
| Review Request | Any other workflow | Pause Review Request if another email due within 48h |
| Any workflow | Referral Programme | Both can run; Referral emails are low-frequency |

### Workflow 9: Referral Programme (Apex AI Exclusive)

**Package tier**: Apex AI
**Estimated build time**: 40-55 minutes

#### Pre-requisites

- Pipeline: Referral Programme (stages: Referral Made, New Patient Booked, Reward Credited)
- Tags: `referral-made`, `referral-thank-you-sent`, `referral-new-patient-booked`, `referral-reward-credited`, `referral-programme-complete`
- Custom fields: `referral_source_patient`, `referral_reward_status`, `referral_date`
- Location custom field: `referral_reward_description` (e.g., "GBP 25 credit for you and your friend")
- Location custom field: `booking_link`
- Email templates built (see below)
- Marketing consent tracking enabled

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation -> Workflows -> Create New Workflow -> Start from Scratch**
2. Name the workflow: **Referral Programme**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `referral-made`
7. Note: This tag is applied when a new patient registration form includes a "Who referred you?" field, or when reception manually tags the referrer's contact record after a verbal referral

**Step 1 -- Move Pipeline:**

8. Add action: **Move Pipeline** -> Pipeline: Referral Programme -> Stage: Referral Made

**Step 2 -- Condition: Active Patient with Marketing Consent?**

9. Add action: **If/Else Condition**
10. Condition: Contact DND (Marketing Email) = OFF AND does NOT have tag `do-not-contact` AND does NOT have tag `inactive-patient`
11. **If no consent or inactive**: Create internal task "Referral received from {{contact.first_name}} {{contact.last_name}} but cannot send marketing email (no consent or inactive). Process referral reward manually." -> End workflow
12. **If active with consent**: Continue

**Step 3 -- Set Referral Custom Fields:**

13. Add action: **Update Contact Field**
14. Set `referral_date` to **today**
15. Set `referral_reward_status` to **Pending**
16. Note: `referral_source_patient` should already be populated from the new patient form or by reception

**Step 4 -- Send Referral Thank You Email (Immediate):**

17. Add action: **Send Email**
18. Name: "Referral Thank You Email"
19. Use content from the **Referral Thank You Email** section below
20. Add action: **Add Tag** -> `referral-thank-you-sent`

**Step 5 -- Wait 14 Days:**

21. Add action: **Wait**
22. Wait time: **14 days**

**Step 6 -- Condition: Has Referred Patient Booked?**

23. Add action: **If/Else Condition**
24. Condition: The referred new patient (identified by `referral_source_patient` matching this contact's name in the new patient's record) **has tag** `appointment-booked` or `appointment-completed`
25. Note: In GHL, this cross-contact check may require a workaround. Options:
    - Option A: Use a Webhook to check if a contact with `referral_source_patient` matching this contact exists and has the `appointment-booked` tag
    - Option B: Reception manually adds the tag `referral-new-patient-booked` to the referrer when the new patient books
    - Option C: Build a separate mini-workflow on the new patient that, when they book and have a `referral_source_patient` value, adds `referral-new-patient-booked` to the referrer
26. **If new patient has booked**: Continue to Step 7
27. **If not booked**: Continue to Step 8

**Step 7 -- Credit Referral Reward:**

28. Add action: **Add Tag** -> `referral-new-patient-booked`
29. Add action: **Update Contact Field** -> `referral_reward_status` = "Credited"
30. Add action: **Send Email**
31. Name: "Referral Reward Confirmation Email"
32. Use content from the **Referral Reward Confirmation** section below
33. Add action: **Add Tag** -> `referral-reward-credited`
34. Add action: **Move Pipeline** -> Stage: Reward Credited
35. Add action: **Create Task** (Internal)
    - Task name: "Apply referral reward for {{contact.first_name}} {{contact.last_name}}"
    - Description: "Referral reward ({{location.referral_reward_description}}) is due for {{contact.first_name}} {{contact.last_name}}. The referred patient has booked/attended. Apply the credit to their account."
    - Assign to: Reception / Practice Manager
36. Go to Step 9

**Step 8 -- New Patient Has Not Booked:**

37. Add action: **Create Task** (Internal)
    - Task name: "Referral follow-up: referred patient has not booked"
    - Description: "{{contact.first_name}} {{contact.last_name}} referred a new patient on {{custom_field.referral_date}}, but the referred patient has not booked after 14 days. Consider reaching out to the referrer or the referred patient."
    - Assign to: Reception
38. Continue to Step 9

**Step 9 -- Wait 60 Days (From Trigger):**

39. Add action: **Wait**
40. Wait time: **46 days** (total ~60 days from trigger)

**Step 10 -- Final Check and Cleanup:**

41. Add action: **If/Else Condition**
42. Condition: Contact **does NOT have tag** `referral-reward-credited`
43. **If not credited**: Update `referral_reward_status` to "Expired"
44. **If credited**: No action needed

**Step 11 -- Mark Sequence Complete:**

45. Add action: **Add Tag** -> `referral-programme-complete`
46. Add action: **Remove Tag** -> `referral-made` (clean up so the contact can refer again in the future)
47. End workflow

#### Email/SMS Content

##### Referral Thank You Email

- **Subject**: Thank you for recommending us, {{contact.first_name}}!
- **Body**:

```
Hi {{contact.first_name}},

We are thrilled that you have recommended {{location.name}} to a friend or family member. Thank you -- there is no greater compliment than a personal recommendation, and it means a great deal to our team.

As a thank you, we would like to offer you our referral reward:

{{location.referral_reward_description}}

Here is how it works:
1. Your referral registers and books their first appointment at {{location.name}}
2. Once they have attended, your reward will be applied automatically
3. We will send you a confirmation email when your reward is ready

If you know anyone else who could benefit from exceptional dental care, we are always grateful for referrals!

Thank you again for your trust and support.

Warm regards,
The team at {{location.name}}
```

- **Footer**: Include unsubscribe link (marketing email)

##### Referral Reward Confirmation Email

- **Subject**: Your referral reward is ready, {{contact.first_name}}!
- **Body**:

```
Hi {{contact.first_name}},

Great news! The friend you referred to {{location.name}} has booked their appointment, which means your referral reward is now ready.

Your reward: {{location.referral_reward_description}}

To redeem, simply mention your referral reward at your next appointment or call us on {{location.phone}} to have it applied to your account.

Thank you for being a wonderful advocate for {{location.name}}. Our practice grows through recommendations from patients like you, and we truly appreciate it.

Know someone else who deserves great dental care? Referrals are always welcome!

Warm regards,
The team at {{location.name}}
```

- **CTA Button**: "Book Your Next Appointment" -> link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

#### Tags & Custom Fields Required

| Name | Type | Purpose |
|------|------|---------|
| `referral-made` | Tag | Trigger tag |
| `referral-thank-you-sent` | Tag | Tracks thank-you email |
| `referral-new-patient-booked` | Tag | Referred patient has booked |
| `referral-reward-credited` | Tag | Reward applied |
| `referral-programme-complete` | Tag | Sequence finished |
| `referral_source_patient` | Custom Field (Text) | Name of the referrer (on the new patient's record) |
| `referral_reward_status` | Custom Field (Dropdown) | Pending / Credited / Expired |
| `referral_date` | Custom Field (Date) | Date the referral was made |
| `referral_reward_description` | Location Custom Field (Text) | Reward description text |

#### Cross-Contact Referral Tracking (Implementation Note)

GHL does not natively support cross-contact condition checks (i.e., "check if a different contact has a certain tag"). To implement the referral tracking:

**Recommended approach -- Parallel Workflow on New Patient:**

1. On the new patient registration form, include a field: "Were you referred by an existing patient? If so, please tell us their name."
2. When the form is submitted, store the referrer name in `referral_source_patient` on the new patient's contact record
3. Build a mini-workflow triggered by the new patient's `appointment-booked` tag:
   - Condition: `referral_source_patient` is not empty
   - If not empty: Search for a contact matching that name and add tag `referral-new-patient-booked` to the referrer
   - Note: In GHL, this "search and tag another contact" action may require a Webhook to a custom script, or reception can manually add the tag
4. If automated cross-contact tagging is not feasible in the client's GHL version, instruct reception to manually add `referral-new-patient-booked` to the referrer when the referred patient attends

#### Testing Checklist

- [ ] Trigger fires when `referral-made` tag is added to referrer's contact
- [ ] Workflow exits if referrer has no marketing consent or is inactive
- [ ] Thank-you email sends immediately with correct merge fields
- [ ] Referral reward description renders correctly from location custom field
- [ ] 14-day wait functions correctly
- [ ] `referral-new-patient-booked` tag detection works on the referrer's contact
- [ ] Reward confirmation email sends when the referred patient books
- [ ] Internal task is created for reception to apply the reward credit
- [ ] Internal task is created if the referred patient has not booked after 14 days
- [ ] `referral_reward_status` updates correctly (Pending -> Credited or Expired)
- [ ] `referral-made` tag is removed at the end (allows the patient to refer again)
- [ ] Cross-contact referral tracking works (either automated or manual process is documented)
- [ ] Pipeline stages update correctly
- [ ] Unsubscribe link works in both emails

---

## Phase 6: Email/SMS Templates -- 15+ Templates (6-8 hours)

Build all email and SMS templates in GHL's **Marketing -> Emails** section. Each template must be:
- Self-contained HTML with inline CSS
- Responsive for mobile email clients
- Using the client's brand colours (or dental defaults)
- British English throughout
- Including GHL merge fields for personalisation
- Including unsubscribe links on all marketing emails

### Template List

Templates 1-10 are fully specified in `workflows.md` under each workflow's "Email/SMS Content" section. Templates 11-15 are Apex-exclusive and specified in this document.

| # | Template Name | Used By | Type | Reference |
|---|---------------|---------|------|-----------|
| 1 | Appointment Confirmation Email | Workflow 1 | Transactional | `workflows.md` -> Workflow 1 |
| 2 | 24h Reminder SMS | Workflow 1 | Transactional | `workflows.md` -> Workflow 1 |
| 3 | 2h Reminder SMS | Workflow 1 | Transactional | `workflows.md` -> Workflow 1 |
| 4 | Post-Visit Thank You Email | Workflow 1 | Transactional | `workflows.md` -> Workflow 1 |
| 5 | Review Request Email | Workflow 2 | Marketing | `workflows.md` -> Workflow 2 |
| 6 | Review Request Follow-Up Email | Workflow 2 | Marketing | `workflows.md` -> Workflow 2 |
| 7 | Recall Reminder Email 1 | Workflow 3 | Marketing | `workflows.md` -> Workflow 3 |
| 8 | Recall Reminder SMS | Workflow 3 | Marketing | `workflows.md` -> Workflow 3 |
| 9 | Recall Reminder Final Email | Workflow 3 | Marketing | `workflows.md` -> Workflow 3 |
| 10 | New Patient Welcome Email | Workflow 4 | Transactional | `workflows.md` -> Workflow 4 |
| 11 | New Patient Welcome SMS | Workflow 4 | Transactional | `workflows.md` -> Workflow 4 |
| 12 | Welcome Follow-Up (Booked) | Workflow 4 | Transactional | `workflows.md` -> Workflow 4 |
| 13 | Welcome Follow-Up (Not Booked) | Workflow 4 | Marketing | `workflows.md` -> Workflow 4 |
| 14 | Nurture Email 1 | Workflow 5 | Marketing | `workflows.md` -> Workflow 5 |
| 15 | Nurture SMS | Workflow 5 | Marketing | `workflows.md` -> Workflow 5 |
| 16 | Nurture Email 2 (Offer) | Workflow 5 | Marketing | `workflows.md` -> Workflow 5 |
| 17 | Nurture Email 3 (Final) | Workflow 5 | Marketing | `workflows.md` -> Workflow 5 |
| 18 | Cancellation Recovery SMS | Workflow 6 | Transactional | `workflows.md` -> Workflow 6 |
| 19 | Cancellation Recovery Email | Workflow 6 | Transactional | `workflows.md` -> Workflow 6 |
| 20 | Waitlist Notification SMS | Workflow 6 | Transactional | `workflows.md` -> Workflow 6 |
| 21 | Birthday Greeting Email | Workflow 7 | Marketing | `workflows.md` -> Workflow 7 |
| 22 | Treatment Plan Check-in (48h) | Workflow 8 | Transactional | `workflows.md` -> Workflow 8 |
| 23 | Treatment Plan Reminder (7d) | Workflow 8 | Marketing | `workflows.md` -> Workflow 8 |
| 24 | Treatment Plan Re-engage (30d) | Workflow 8 | Marketing | `workflows.md` -> Workflow 8 |
| 25 | Referral Thank You Email | Workflow 9 | Marketing | This document -> Phase 5 |
| 26 | Referral Reward Confirmation Email | Workflow 9 | Marketing | This document -> Phase 5 |

### Email Template Design Specifications

All email templates must follow this design system:

```
Width: 600px (desktop), fluid (mobile)
Background: #f8fafc (outer), #ffffff (inner content area)
Header: Practice logo centred, optional blue accent bar below
Body padding: 32px left/right, 24px top/bottom
Headings: DM Sans 700, #0f172a (fallback: Arial, Helvetica, sans-serif)
Body text: DM Sans 400, #475569, 16px line-height 1.6 (fallback: Arial)
CTA buttons: background #2563eb, colour #ffffff, padding 14px 28px, border-radius 8px, font-weight 600
Links: #2563eb, underline on hover
Footer: #94a3b8 text, 12px, includes practice name, address, phone, unsubscribe link
Dividers: 1px solid #e2e8f0
```

### SMS Template Guidelines

- Maximum 160 characters per segment (aim for 1 segment where possible)
- Include practice name for identification
- Include STOP opt-out instruction on marketing SMS
- Sending window: 08:00-20:00 only
- Use {{merge_fields}} for personalisation
- No URLs longer than 30 characters (use URL shortener or GHL's built-in link tracking)

---

## Phase 7: AI Chatbot -- Premium (4-6 hours)

The Apex AI chatbot is the full-featured version with multi-language support, team-specific handoff, post-treatment check-in, and PMS integration notes.

**Full build instructions**: See `chatbot-setup.md` for the complete setup guide including:
- Step 1: Bot creation and channel configuration
- Step 2: Full system prompt (copy-paste ready with all placeholders)
- Step 3: Knowledge base documents to upload
- Step 4: Conversation flows and intents (8 intents)
- Step 5: Escalation rules and team routing
- Step 6: Widget configuration
- Step 7: Testing (43 test scenarios)

### Apex-Exclusive Chatbot Enhancements

The following features are added on top of the Momentum AI chatbot for the Apex package:

#### Enhancement 1: Multi-Language Support

Add the following to the system prompt's CONVERSATION RULES section:

```
MULTI-LANGUAGE SUPPORT:
If the patient writes in a language other than English, respond in that language if possible.

Languages supported by the practice team: [ADDITIONAL_LANGUAGES] (e.g., "Polish, Hindi, Urdu")

When responding in another language:
- Mirror the patient's language from the second message onwards
- Keep medical/dental terms in English with a translation in brackets
- Provide the booking link and phone number in every response (these are universal)
- If you are unsure of a translation, respond in English and note: "I can see you may prefer to communicate in [language]. Our team includes [TEAM_MEMBER] who speaks [language] fluently. Would you like me to arrange a callback?"
- For languages not spoken by the team, respond in English and suggest: "I apologise, but our team does not currently have a [language] speaker. I will do my best to assist in English. You are also welcome to bring a friend or family member to translate at your appointment."
```

#### Enhancement 2: Team-Specific Handoff Routing

Replace the basic escalation section with enhanced routing:

```
TEAM-SPECIFIC HANDOFF ROUTING:
When escalating, route to the most appropriate team member based on the enquiry type:

| Enquiry Type | Route To | Method |
|-------------|----------|--------|
| General booking questions | [RECEPTION_NAME] (Reception) | In-app notification |
| Emergency | [EMERGENCY_CONTACT] | SMS + email notification |
| Implant enquiry | [IMPLANT_DENTIST_NAME] (Treatment Coordinator) | In-app notification |
| Invisalign/orthodontics | [ORTHO_DENTIST_NAME] | In-app notification |
| Cosmetic consultation | [COSMETIC_DENTIST_NAME] | In-app notification |
| Nervous patient support | [NERVOUS_PATIENT_LEAD] | In-app notification |
| Finance/payment plans | [FINANCE_CONTACT] | In-app notification |
| Complaints | [PRACTICE_MANAGER_NAME] (Practice Manager) | Email notification |
| Children's dentistry | [PAEDIATRIC_LEAD] | In-app notification |
| Safeguarding concern | [SAFEGUARDING_LEAD] | Urgent email (internal only) |

When routing, tell the patient:
"I am going to connect you with [Name], our [Role], who is the best person to help with this. Could I take your name and phone number so they can call you back within [CALLBACK_TIME]?"
```

#### Enhancement 3: Post-Treatment Check-In via Chat

Add to the system prompt:

```
POST-TREATMENT CHECK-IN:
If a patient messages within 7 days of a treatment appointment (detected by recent appointment tags or context), proactively check in:

"Welcome back, {{contact.first_name}}! I can see you had a recent treatment with us. How are you feeling? Is everything healing well?"

Post-treatment guidance rules:
- If the patient reports expected symptoms (mild discomfort, sensitivity): Provide reassurance and standard aftercare advice
- If the patient reports concerning symptoms (increasing pain after 48h, fever, excessive swelling, pus, bleeding that will not stop): Recommend calling [PHONE] urgently or, if severe, provide the EMERGENCY RESPONSE
- Always remind: "If your symptoms change or worsen, please do not hesitate to call us on [PHONE]."
- Never dismiss post-treatment concerns -- always validate and guide to the appropriate action
```

#### Enhancement 4: PMS Integration Notes

Add to the system prompt (informational -- actual integration depends on PMS capabilities):

```
PRACTICE MANAGEMENT SYSTEM INTEGRATION:
This practice uses [PMS_NAME] as their practice management system.

IMPORTANT: You do NOT have direct access to [PMS_NAME]. You cannot look up appointment details, patient records, or treatment history. If a patient asks about their specific appointment, treatment plan, or account balance, acknowledge you cannot access this information and direct them to call [PHONE].

However, you CAN reference general booking availability (via GHL calendar integration) and general pricing information from your knowledge base.

Future integration note: If [PMS_NAME] API integration becomes available through GHL, the following capabilities could be added:
- Real-time appointment slot availability
- Patient record lookup (with authentication)
- Treatment plan status checking
- Account balance enquiries
These would be configured in GHL's Integrations section when available.
```

### Apex Chatbot Widget Page-Specific Prompts

Extend the widget trigger rules for the additional Apex pages:

| Page | Trigger | Prompt Message |
|------|---------|----------------|
| `/faq` | 8 seconds | "Cannot find your answer? Ask me anything!" |
| `/blog` | 15 seconds | "Have a question about something you have read?" |
| `/blog/*` (articles) | 20 seconds | "Want to know more about this topic?" |
| `/team/*` (profiles) | 10 seconds | "Want to book with this dentist?" |
| `/reviews` | 10 seconds | "Ready to experience our care? Book now!" |

---

## Phase 8: Reporting Dashboard (3-4 hours)

Set up a custom GHL reporting dashboard so the practice can track key performance metrics at a glance.

### Step 8.1 -- Navigate to Dashboard Builder

1. Go to **Reporting -> Dashboards** (or **Dashboard -> Custom Dashboards** depending on GHL version)
2. Click **Create New Dashboard**
3. Name it: "[BUSINESS_NAME] -- Performance Dashboard"

### Step 8.2 -- Dashboard Widgets

Add the following widgets/cards to the dashboard:

#### Row 1: Key Metrics (4 summary cards)

| Widget | Metric | Source | Notes |
|--------|--------|--------|-------|
| New Appointments (This Month) | Count of appointments booked | GHL Calendar | Filter: current month |
| New Patient Registrations | Count of contacts with `new-patient` tag added | Tags | Filter: current month |
| Revenue Pipeline | Sum of `treatment_plan_value` for plans accepted | Custom field | Filter: current month, tag `treatment-plan-accepted` |
| Google Review Rating | Current average rating | Manual input or Google integration | Update monthly |

#### Row 2: Appointment Analytics (2 charts)

| Widget | Type | Data |
|--------|------|------|
| Appointments by Type | Pie/Doughnut chart | Breakdown by calendar type (Check-up, Hygiene, Emergency, Cosmetic, etc.) |
| Appointments by Week | Line chart | Weekly appointment count, 12-week trend |

#### Row 3: Workflow Performance (3 cards)

| Widget | Metric | Calculation |
|--------|--------|-------------|
| No-Show Rate | Percentage | `appointment-no-show` count / total appointments x 100 |
| Recall Compliance | Percentage | `recall-booked` count / `recall-due` count x 100 |
| Enquiry Conversion | Percentage | `nurture-converted` count / `enquiry-no-booking` count x 100 |

#### Row 4: Pipeline Summary (2 widgets)

| Widget | Type | Data |
|--------|------|------|
| Lead Nurture Pipeline | Funnel chart | Contacts at each stage: New Enquiry -> Converted -> Cold Lead |
| Treatment Plan Pipeline | Funnel chart | Contacts at each stage: Plan Presented -> Accepted -> Pending |

#### Row 5: Communication Stats (3 cards)

| Widget | Metric | Source |
|--------|--------|--------|
| Emails Sent (This Month) | Count | GHL email analytics |
| SMS Sent (This Month) | Count | GHL SMS analytics |
| Chatbot Conversations | Count | GHL Conversation AI analytics |

#### Row 6: Review & Referral Tracking (2 cards)

| Widget | Metric | Source |
|--------|--------|--------|
| Review Requests vs Reviews Left | Comparison | `review-requested` count vs `review-left` count |
| Active Referrals | Count | `referral-made` count minus `referral-programme-complete` count |

### Step 8.3 -- Dashboard Access

1. Share the dashboard with the Practice Manager and relevant team members
2. Set the dashboard as the default view for the sub-account (if possible)
3. Configure an automated weekly email summary if GHL supports it:
   - Recipients: Practice Manager, Practice Owner
   - Schedule: Every Monday at 08:00
   - Content: Key metrics summary for the previous week

### Step 8.4 -- Google Review Monitoring (Optional Integration)

If the client's GHL version supports Google Business Profile integration:
1. Go to **Settings -> Integrations -> Google**
2. Connect the practice's Google Business Profile
3. Enable review monitoring
4. Configure notifications for new reviews (positive and negative)
5. Add a review feed widget to the dashboard

---

## Phase 9: Google Review Automation (1-2 hours)

This builds on Workflow 2 (Review Request) with additional Apex-tier enhancements.

### Step 9.1 -- Review Request Landing Page (Optional)

Build a simple intermediate page that asks patients to rate their experience before directing them to Google:

**URL slug**: `/review`

**Content**:
- Headline: "How Was Your Visit?"
- Subtext: "We would love to hear about your experience at [BUSINESS_NAME]."
- 5-star rating selector (clickable stars)
- If 4-5 stars selected: Redirect to `[GOOGLE_REVIEW_URL]` with a message: "Thank you! Please share your experience on Google."
- If 1-3 stars selected: Show a feedback form (name, email, message) with text: "We are sorry to hear that. Please share your feedback and our Practice Manager will be in touch." Submit goes to an internal notification (not public).

This approach:
- Routes happy patients to Google (boosting public reviews)
- Intercepts unhappy patients for private resolution (protecting online reputation)

### Step 9.2 -- Review Monitoring Workflow

Build a mini-workflow to alert the team when new reviews appear:

1. If GHL has Google review integration: Set up notifications for new reviews
2. For negative reviews (1-3 stars): Send an immediate alert to the Practice Manager
3. Practice Manager responds within 24 hours (provide response templates below)

### Step 9.3 -- Review Response Templates

Provide the client with templated responses for common review scenarios:

**5-Star Positive Review Response:**
```
Thank you so much for your kind words, [REVIEWER_NAME]! We are delighted to hear you had such a positive experience with us. Your feedback means the world to our team. We look forward to seeing you at your next visit!
```

**4-Star Positive Review Response:**
```
Thank you for your lovely review, [REVIEWER_NAME]. We are pleased you had a good experience. If there is anything we could do to make your next visit even better, please do not hesitate to let us know. We look forward to welcoming you back!
```

**Constructive/Negative Review Response:**
```
Thank you for taking the time to share your feedback, [REVIEWER_NAME]. We are sorry to hear that your experience did not meet expectations, and we take your comments seriously. We would very much like the opportunity to discuss this further and make things right. Please contact our Practice Manager at [EMAIL] or [PHONE] at your earliest convenience. We value your feedback and are committed to improving.
```

---

## Phase 10: Testing & QA (Comprehensive) (4-6 hours)

The Apex QA process is the most thorough, covering every deliverable across all phases.

### Step 10.1 -- Website Testing (2 hours)

For **every page** (17+ pages):

| # | Test | Pass/Fail |
|---|------|-----------|
| 1 | Page loads correctly on desktop (Chrome, Firefox, Edge) | |
| 2 | Page is fully responsive on mobile (iPhone 14 size, Android equivalent) | |
| 3 | Page is fully responsive on tablet (iPad size) | |
| 4 | All images load or have appropriate placeholder styling | |
| 5 | All links work (internal navigation, booking, phone, email) | |
| 6 | All CTA buttons link to correct destinations | |
| 7 | Phone links use `tel:` protocol | |
| 8 | Email links use `mailto:` protocol | |
| 9 | Google Maps embed loads correctly | |
| 10 | No `[PLACEHOLDER]` text visible anywhere on the page | |
| 11 | All merge fields render correctly (no blank `{{fields}}`) | |
| 12 | Page title and meta description are set for SEO | |
| 13 | FAQ page schema markup validates (use Google Rich Results Test) | |
| 14 | Blog article schema markup validates | |
| 15 | Font (DM Sans) loads correctly | |
| 16 | Colours match the design system (spot-check headings, buttons, cards) | |
| 17 | Mega-menu works on desktop and falls back to standard menu on mobile | |
| 18 | Footer displays correctly with all links working | |
| 19 | Chat widget appears on appropriate pages and not on excluded pages | |
| 20 | Page load time is under 3 seconds (use Google PageSpeed Insights) | |

### Step 10.2 -- Workflow Testing (1.5 hours)

For **every workflow** (9 workflows):

| # | Test | Pass/Fail |
|---|------|-----------|
| 1 | Trigger fires correctly when the trigger condition is met | |
| 2 | Each wait step calculates the correct time | |
| 3 | Business hour restrictions work (emails/SMS not sent outside 08:00-20:00) | |
| 4 | Booking/conversion checks correctly detect when a patient books | |
| 5 | Marketing consent checks work (DND contacts do not receive marketing) | |
| 6 | Pipeline stages update at each key transition | |
| 7 | Tags are applied correctly at each step | |
| 8 | Internal tasks/notifications are created where specified | |
| 9 | Workflow exits cleanly when conditions change mid-sequence | |
| 10 | Overlap rules work (workflow defers or exits when another takes priority) | |

Test workflows using test contacts with realistic data. Create at least 3 test contacts:
- Test Contact A: Full data, marketing consent ON, no existing tags
- Test Contact B: Full data, marketing consent OFF (DND)
- Test Contact C: Minimal data (no email, phone only)

### Step 10.3 -- Email/SMS Testing (1 hour)

For **every template** (26 templates):

| # | Test | Pass/Fail |
|---|------|-----------|
| 1 | Email renders correctly on desktop (Gmail, Outlook, Apple Mail) | |
| 2 | Email renders correctly on mobile (Gmail app, Apple Mail app) | |
| 3 | All merge fields populate correctly | |
| 4 | CTA buttons are clickable and link to the correct URL | |
| 5 | Unsubscribe link works on marketing emails | |
| 6 | Marketing emails include the required unsubscribe footer | |
| 7 | SMS messages are within character limits | |
| 8 | SMS STOP keyword triggers DND correctly | |
| 9 | No `[PLACEHOLDER]` text in any template | |
| 10 | Reply-to address is correct | |
| 11 | From name matches the practice name | |

### Step 10.4 -- Chatbot Testing (1 hour)

Run through all 43 test scenarios in `chatbot-setup.md` -> Step 7. Additionally, test Apex-exclusive features:

| # | Test | Pass/Fail |
|---|------|-----------|
| 1 | Bot responds in the patient's language (test with Polish, Hindi, or another language the practice supports) | |
| 2 | Bot correctly routes to specific team members based on enquiry type | |
| 3 | Bot provides post-treatment check-in response when a recent patient messages | |
| 4 | Bot correctly states it cannot access PMS records and directs to phone | |
| 5 | Escalation notifications reach the correct team member (not just generic reception) | |
| 6 | Widget prompt messages are correct on Apex-specific pages (FAQ, blog, team profiles) | |

### Step 10.5 -- Reporting Dashboard Testing (30 min)

| # | Test | Pass/Fail |
|---|------|-----------|
| 1 | Dashboard loads without errors | |
| 2 | All widgets display data (even if zero -- confirm no error states) | |
| 3 | Date filters work correctly | |
| 4 | Pipeline funnels show correct stage counts | |
| 5 | Dashboard is accessible to the Practice Manager | |
| 6 | Weekly email summary is configured and test-sent | |

### Step 10.6 -- Cross-System Integration Testing (30 min)

| # | Test | Pass/Fail |
|---|------|-----------|
| 1 | Website form submission -> adds tag -> triggers workflow -> sends email | |
| 2 | Online booking -> triggers Appointment Reminder workflow -> sends confirmation | |
| 3 | Appointment completed -> triggers Review Request workflow | |
| 4 | Contact with `date_of_birth` -> Birthday workflow triggers on correct date | |
| 5 | Contact with `last_checkup_date` -> Recall workflow triggers at 167 days | |
| 6 | New patient with referral -> triggers both Welcome and Referral workflows | |
| 7 | Chatbot escalation -> correct team member is notified | |

---

## Phase 11: Staff Training Session Plan (1 hour session + 1 hour preparation)

The Apex package includes a 1-hour staff training video call. Prepare the following materials and agenda.

### Pre-Training Preparation (1 hour)

1. Create a training document (PDF or shared screen) covering:
   - GHL login and navigation overview
   - How to check and manage appointments in GHL
   - How to view and respond to chatbot conversations
   - How to manage pipelines and contact records
   - How to apply tags manually (critical for referral and treatment plan workflows)
   - How to check the reporting dashboard
2. Record a 10-minute Loom video walkthrough as a reference for staff who cannot attend live

### Training Session Agenda (60 minutes)

| Time | Topic | Details |
|------|-------|---------|
| 0-5 min | Welcome & overview | Introduce what has been built, key capabilities |
| 5-15 min | GHL navigation | Login, dashboard, contacts, conversations, calendars |
| 15-25 min | Appointment management | How bookings appear, how to mark no-shows, how to see workflow activity |
| 25-35 min | Chatbot management | How to monitor conversations, how to take over from the bot, how escalations work |
| 35-45 min | Manual actions | How to add tags (new-patient, treatment-plan-presented, referral-made, appointment-no-show, birthday-offer-redeemed), how to update custom fields (last_checkup_date, treatment_plan_type/value/date) |
| 45-50 min | Dashboard & reporting | How to read the performance dashboard, key metrics to watch |
| 50-55 min | Q&A | Address team questions |
| 55-60 min | Wrap-up | Share reference materials, confirm Hypercare support contact, schedule first check-in |

### Key Staff Actions to Train

These are the manual actions that staff must perform for workflows to function correctly:

| Action | Who | When | How |
|--------|-----|------|-----|
| Mark no-shows | Reception | After missed appointment | Add tag `appointment-no-show` |
| Mark appointment completed | Reception / Dentist | After patient attends | Add tag `appointment-completed` (or configure auto from calendar) |
| Update last check-up date | Reception | After every check-up | Update `last_checkup_date` custom field |
| Tag new patients | Reception | After first registration | Add tag `new-patient` (or configure auto from form) |
| Present treatment plan | Dentist / Treatment Coordinator | After consultation | Add tag `treatment-plan-presented`, fill in `treatment_plan_type`, `treatment_plan_value`, `treatment_plan_date`, `treating_dentist` |
| Process referral | Reception | When new patient mentions referral | Add tag `referral-made` to referrer, add `referral-new-patient-booked` when referred patient books |
| Mark birthday offer redeemed | Reception | When code is used | Add tag `birthday-offer-redeemed` |
| Mark review left | Reception | When review is confirmed on Google | Add tag `review-left` |
| Take over chatbot | Reception | When escalated | Open Conversations tab, respond in the thread |

---

## Phase 12: Client Handoff (2-3 hours)

### Step 12.1 -- Final Review (1 hour)

Walk through the entire sub-account with the client (video call):

1. Show every website page (quick scroll-through)
2. Demonstrate a test booking flow end-to-end
3. Show the chatbot in action (run 3-4 common scenarios)
4. Walk through each workflow (show the workflow builder, explain triggers and steps)
5. Show the reporting dashboard
6. Confirm all placeholder data has been replaced with real client data
7. Get client sign-off on content, design, and functionality

### Step 12.2 -- Go-Live Checklist

| # | Item | Status |
|---|------|--------|
| 1 | All website pages are published | [ ] |
| 2 | Custom domain is connected and SSL is active | [ ] |
| 3 | All workflows are set to **Published** (not Draft) | [ ] |
| 4 | Chatbot is set to **Auto-Reply** mode | [ ] |
| 5 | Email domain is verified and tested | [ ] |
| 6 | SMS number is active and tested | [ ] |
| 7 | All placeholder values have been replaced | [ ] |
| 8 | Google review link is correct | [ ] |
| 9 | Booking calendar availability matches practice hours | [ ] |
| 10 | All internal notifications are routed to correct team members | [ ] |
| 11 | Staff training session has been completed | [ ] |
| 12 | Practice manager has GHL login credentials | [ ] |
| 13 | Emergency phone number is correct on all pages, emails, and chatbot | [ ] |
| 14 | Unsubscribe links work on all marketing emails | [ ] |
| 15 | Chat widget appears on correct pages and hides on excluded pages | [ ] |
| 16 | Reporting dashboard is accessible and showing data | [ ] |
| 17 | DNS records are fully propagated (check with dnschecker.org) | [ ] |

### Step 12.3 -- Handoff Documentation

Provide the client with the Handoff Documentation (see Appendix C), which includes:
- GHL login credentials and access instructions
- Summary of what has been built (pages, workflows, templates, chatbot)
- List of manual actions required by staff (from Phase 11)
- Contact details for Hypercare support
- Schedule for Hypercare check-ins (weekly for 30 days)
- Instructions for common changes (updating prices, hours, team info)

---

## Appendix A: Client Information Template

Send this to the client before the kick-off call. They should complete as much as possible in advance.

```
===================================================================
APEX AI IMPLEMENTATION -- CLIENT INFORMATION FORM
===================================================================

SECTION 1: BUSINESS DETAILS
-------------------------------------------------------------------
Practice trading name:
Legal entity name:
Company registration number:
CQC registration number:
GDC practice number:
Year established:

SECTION 2: CONTACT INFORMATION
-------------------------------------------------------------------
Main telephone:
Emergency telephone:
Email address:
Website (existing, if any):
Preferred contact person:
Preferred contact method:

SECTION 3: LOCATION
-------------------------------------------------------------------
Address line 1:
Address line 2:
City:
Postcode:
Google Maps link:
Parking information:
Wheelchair / accessibility info:
Public transport directions:

SECTION 4: OPENING HOURS
-------------------------------------------------------------------
Monday:
Tuesday:
Wednesday:
Thursday:
Friday:
Saturday:
Sunday:
Bank holidays:
Emergency out-of-hours info:

SECTION 5: SERVICES & PRICING
-------------------------------------------------------------------
NHS status (accepting / private only / mixed):
If NHS, current band prices:
  Band 1:
  Band 2:
  Band 3:
  Urgent:

Private treatment pricing:
  Check-up & examination:
  Dental hygiene (scale & polish):
  Fillings (composite):
  Root canal treatment:
  Simple extraction:
  Wisdom tooth removal:
  Teeth whitening (in-surgery):
  Teeth whitening (home kit):
  Composite bonding (per tooth):
  Porcelain veneers (per tooth):
  Smile makeover (starting from):
  Invisalign / clear aligners:
  Fixed braces:
  Retainers:
  Dental crowns:
  Dental bridges:
  Dental implants (single):
  Implant-supported bridge:
  All-on-4:
  Dentures (full):
  Dentures (partial):
  Emergency appointment:
  Children's check-up:
  Fluoride varnish:
  Fissure sealants:
  Other (please list):

SECTION 6: TEAM
-------------------------------------------------------------------
For each team member, provide:
  Name:
  Role:
  Qualifications:
  GDC number:
  Short bio (2-3 sentences):
  Specialisms / interests:
  Photo (attach separately):

SECTION 7: BRAND
-------------------------------------------------------------------
Do you have brand guidelines? (Y/N):
If yes, please attach.
Primary brand colour (hex code):
Secondary brand colour (hex code):
Logo files (attach PNG/SVG):
Tagline or strapline (if any):

SECTION 8: ONLINE PRESENCE
-------------------------------------------------------------------
Google Business Profile URL:
Google review direct link:
Current Google rating:
Current Google review count:
Facebook page URL:
Instagram URL:
Twitter / X URL:
Other social media:

SECTION 9: PATIENT REVIEWS
-------------------------------------------------------------------
Please provide 3-5 real patient reviews (with permission to use):

Review 1:
  Text:
  Patient first name and initial:
  Treatment type:
  Star rating:

Review 2:
  Text:
  Patient first name and initial:
  Treatment type:
  Star rating:

Review 3:
  Text:
  Patient first name and initial:
  Treatment type:
  Star rating:

(Add more as desired)

SECTION 10: FINANCE & PAYMENT
-------------------------------------------------------------------
Payment methods accepted:
Do you offer 0% finance? (Y/N):
Finance provider name:
Minimum treatment value for finance:
Finance term options (months):
Do you have a practice membership/dental plan? (Y/N):
Plan name:
Plan monthly price:
Plan inclusions:
Dental insurance providers accepted:

SECTION 11: CHATBOT PREFERENCES
-------------------------------------------------------------------
Preferred chatbot name (e.g., "Ava"):
Preferred greeting message:
Languages spoken by staff (other than English):
Sedation options offered (e.g., IV sedation, inhalation sedation, oral sedation):
Cancellation policy:
Missed appointment fee:
What should the chatbot NOT discuss?

SECTION 12: PRACTICE MANAGEMENT SYSTEM
-------------------------------------------------------------------
PMS software name:
PMS provider contact (for integration enquiries):
Is API access available? (Y/N / Unsure):

SECTION 13: MULTI-LOCATION (if applicable)
-------------------------------------------------------------------
Number of locations:
For each additional location, provide:
  Location name:
  Address:
  Phone:
  Opening hours:
  Team members at this location:

SECTION 14: REFERRAL PROGRAMME
-------------------------------------------------------------------
Referral reward for referrer:
Referral reward for referred (new patient):
Any terms or limitations:

SECTION 15: BIRTHDAY OFFER
-------------------------------------------------------------------
Birthday offer description (e.g., "10% off professional teeth whitening"):
Offer code format (e.g., BDAY-[NAME]-2026):
Offer validity period (e.g., 30 days):

SECTION 16: BLOG TOPICS
-------------------------------------------------------------------
Preferred topic 1:
Preferred topic 2:
Preferred topic 3:
(If unsure, we will suggest topics based on your most popular treatments)

SECTION 17: PHOTOS
-------------------------------------------------------------------
Please provide (attach separately):
[ ] Practice exterior
[ ] Reception / waiting area
[ ] Treatment room(s)
[ ] Team group photo
[ ] Individual team member portraits
[ ] Equipment / technology photos
[ ] Any before/after treatment photos (with patient consent)

SECTION 18: TRAINING
-------------------------------------------------------------------
Preferred training date:
Preferred training time:
Number of attendees:
Staff names and roles who will attend:
===================================================================
```

---

## Appendix B: 30-Day Hypercare Checklist

The Apex package includes 30 days of priority hypercare support after go-live. Use this checklist to structure the support period.

### Week 1 (Days 1-7): Active Monitoring

| Day | Task | Status |
|-----|------|--------|
| 1 | Monitor all workflows for trigger errors | [ ] |
| 1 | Check chatbot conversation logs for unexpected responses | [ ] |
| 1 | Verify all emails render correctly in real sends | [ ] |
| 2 | Review first 24h of chatbot conversations -- refine any weak responses | [ ] |
| 2 | Check SMS delivery reports | [ ] |
| 3 | Review workflow pipeline movements -- confirm contacts move through stages correctly | [ ] |
| 3 | Check for any bounce-back emails (domain issues) | [ ] |
| 5 | First check-in call with Practice Manager (15 min) | [ ] |
| 5 | Review chatbot escalation rate -- aim for less than 20% | [ ] |
| 7 | Week 1 summary report to client (email) | [ ] |

### Week 2 (Days 8-14): Refinement

| Day | Task | Status |
|-----|------|--------|
| 8 | Review chatbot FAQ gaps -- add missing answers to knowledge base | [ ] |
| 9 | Check Google review automation -- are review requests being sent? | [ ] |
| 10 | Verify recall reminders are queueing correctly for upcoming dates | [ ] |
| 11 | Check dashboard data accuracy | [ ] |
| 12 | Second check-in call with Practice Manager (15 min) | [ ] |
| 14 | Week 2 summary report to client | [ ] |

### Week 3 (Days 15-21): Optimisation

| Day | Task | Status |
|-----|------|--------|
| 15 | Review nurture sequence performance -- open rates, click rates | [ ] |
| 16 | Analyse no-show rate -- is the reminder workflow reducing no-shows? | [ ] |
| 17 | Review treatment plan follow-up -- any accepted plans from the workflow? | [ ] |
| 18 | Check referral programme -- any referrals processed? | [ ] |
| 19 | Third check-in call with Practice Manager (15 min) | [ ] |
| 21 | Week 3 summary report with preliminary KPIs | [ ] |

### Week 4 (Days 22-30): Stabilisation & Handoff

| Day | Task | Status |
|-----|------|--------|
| 22 | Final chatbot refinement based on 3 weeks of data | [ ] |
| 23 | Review all pipeline data -- clean up any stuck contacts | [ ] |
| 25 | Compile 30-day performance report | [ ] |
| 26 | Final check-in call with Practice Manager (30 min) -- present 30-day results | [ ] |
| 28 | Transfer to standard support (confirm client has support contact details) | [ ] |
| 29 | Remove any test contacts and clean up test data | [ ] |
| 30 | Send Hypercare completion email with: 30-day report, ongoing support details, next steps | [ ] |

### Key Metrics to Track During Hypercare

| Metric | Target | Week 1 | Week 2 | Week 3 | Week 4 |
|--------|--------|--------|--------|--------|--------|
| No-show rate | < 8% | | | | |
| Recall compliance rate | > 85% | | | | |
| Enquiry-to-booking conversion | > 30% | | | | |
| Google reviews requested per week | 5-10 | | | | |
| Chatbot escalation rate | < 20% | | | | |
| Email open rate (marketing) | > 40% | | | | |
| SMS delivery rate | > 95% | | | | |
| Treatment plan acceptance rate | > 40% | | | | |
| Website page load time | < 3 seconds | | | | |

---

## Appendix C: Handoff Documentation Template

Provide this document to the client at go-live.

```
===================================================================
[BUSINESS_NAME] -- AVANTWERK APEX AI IMPLEMENTATION
HANDOFF DOCUMENTATION
===================================================================
Date: [HANDOFF_DATE]
Delivered by: [IMPLEMENTER_NAME], Avantwerk
Package: Apex AI (GBP 3,999)

-------------------------------------------------------------------
1. ACCESS
-------------------------------------------------------------------
GHL Login URL: https://app.gohighlevel.com
Email: [CLIENT_GHL_EMAIL]
Password: [SET_BY_CLIENT]
Sub-Account Name: [BUSINESS_NAME]

-------------------------------------------------------------------
2. WHAT HAS BEEN BUILT
-------------------------------------------------------------------

WEBSITE (17+ pages):
- Homepage (/)
- Services (/services)
- About Us (/about)
- Contact (/contact)
- Booking (/booking)
- Teeth Whitening (/teeth-whitening)
- Dental Implants (/dental-implants)
- Invisalign (/invisalign)
- Cosmetic Dentistry (/cosmetic-dentistry)
- Emergency (/emergency)
- Reviews (/reviews)
- FAQ (/faq)
- Blog Index (/blog)
- Blog: How Often Should You Visit the Dentist
- Blog: Teeth Whitening Guide
- Blog: Nervous Patient Guide
- Team Profile Template (/team/[name])
- [Multi-location pages if applicable]

WORKFLOWS (9 automations):
1. Appointment Reminder (trigger: appointment booked)
2. Review Request (trigger: appointment completed)
3. Recall Reminder (trigger: 167 days after last check-up)
4. New Patient Welcome (trigger: new-patient tag)
5. New Patient Nurture (trigger: enquiry-no-booking tag)
6. Cancellation Recovery (trigger: appointment cancelled)
7. Birthday/Loyalty (trigger: date of birth = today)
8. Treatment Plan Follow-up (trigger: treatment-plan-presented tag)
9. Referral Programme (trigger: referral-made tag)

EMAIL/SMS TEMPLATES (26):
[List all 26 templates with their workflow associations]

AI CHATBOT:
- Full-feature dental chatbot with FAQ, triage, booking, multi-language, team routing
- Channels: Website widget [+ Facebook/Instagram/WhatsApp if configured]

REPORTING DASHBOARD:
- [BUSINESS_NAME] Performance Dashboard
- Key metrics: appointments, registrations, pipeline, reviews, workflows

GOOGLE REVIEW AUTOMATION:
- Automated review requests after appointments
- Review routing page (/review)
- Response templates provided

-------------------------------------------------------------------
3. MANUAL ACTIONS YOUR TEAM MUST PERFORM
-------------------------------------------------------------------

[Include the full table from Phase 11 -- Key Staff Actions to Train]

-------------------------------------------------------------------
4. HOW TO MAKE COMMON CHANGES
-------------------------------------------------------------------

Update opening hours:
- Website: Edit the Location/Hours section on the Homepage and Contact page
- Chatbot: Settings -> Conversation AI -> Bot Instructions -> OPENING HOURS section
- Emails: Automated emails reference {{location}} fields -- update in Settings -> Business Profile

Update prices:
- Website: Edit the Services page and individual treatment pages
- Chatbot: Settings -> Conversation AI -> Bot Instructions -> SERVICES AND PRICING section
- Also update the Knowledge Base document (Conversation AI -> Knowledge Base)

Add/remove a team member:
- Website: Edit the About page team section and create/remove individual profile pages
- Chatbot: Update TEAM section in the system prompt
- Workflows: Update `treating_dentist` dropdown if relevant

Update Google review link:
- Settings -> Custom Fields -> Location -> google_review_link

Add a new blog article:
- Sites -> Pages -> Create new page based on the blog article template
- Add a card to the Blog Index page manually

-------------------------------------------------------------------
5. HYPERCARE SUPPORT
-------------------------------------------------------------------

Period: [HANDOFF_DATE] to [HYPERCARE_END_DATE] (30 days)
Priority: Apex AI (priority response)
Contact: [SUPPORT_EMAIL]
Response time: Within 4 business hours
Check-in calls: Weekly (schedule confirmed during training)

After Hypercare, standard support is available via:
- Email: [SUPPORT_EMAIL]
- Response time: Within 24 business hours

-------------------------------------------------------------------
6. KEY CONTACTS
-------------------------------------------------------------------

Avantwerk Implementation: [IMPLEMENTER_NAME] -- [IMPLEMENTER_EMAIL]
Avantwerk Support: [SUPPORT_EMAIL]
Practice Manager: [PM_NAME] -- [PM_EMAIL]
Technical Issues: [TECH_CONTACT]

===================================================================
```

---

## Build Summary and Time Estimates

| Phase | Description | Estimated Time |
|-------|-------------|----------------|
| Pre-Setup | Client info gathering, kick-off call | 2-4 hours |
| Phase 1 | GHL sub-account setup | 45-60 min |
| Phase 2 | Custom fields & tags | 30-45 min |
| Phase 3 | Pipeline setup | 20-30 min |
| Phase 4 | Website (17+ pages) | 18-24 hours |
| Phase 5 | Workflows (9 automations) | 12-16 hours |
| Phase 6 | Email/SMS templates (26) | 6-8 hours |
| Phase 7 | AI chatbot (premium) | 4-6 hours |
| Phase 8 | Reporting dashboard | 3-4 hours |
| Phase 9 | Google review automation | 1-2 hours |
| Phase 10 | Testing & QA | 4-6 hours |
| Phase 11 | Staff training preparation + session | 2 hours |
| Phase 12 | Client handoff | 2-3 hours |
| **Total** | | **55-76 hours** |

### Recommended Delivery Schedule (45-60 Days)

| Week | Days | Focus | Milestones |
|------|------|-------|------------|
| 1 | 1-5 | Pre-setup + Phases 1-3 | Sub-account live, infrastructure ready |
| 2 | 6-10 | Phase 4 (website pages 1-8) | Core pages built |
| 3 | 11-15 | Phase 4 (website pages 9-17+) | All pages built |
| 4 | 16-20 | Phase 5 (workflows 1-6) | Core workflows live |
| 5 | 21-25 | Phase 5 (workflows 7-9) + Phase 6 | All workflows and templates built |
| | 25 | Mid-point review with client | Client reviews progress |
| 6 | 26-30 | Phase 7 (chatbot) + Phase 8 (dashboard) | Chatbot and reporting live |
| 7 | 31-35 | Phase 9 (reviews) + Phase 10 (QA) | Full QA pass |
| 8 | 36-40 | QA fixes + Phase 11 (training prep) | Training materials ready |
| | 40 | Final QA sign-off | All tests passing |
| 9 | 41-45 | Phase 11 (training) + Phase 12 (handoff) | Client trained and live |
| 10-13 | 46-75 | Hypercare (30 days) | Weekly check-ins, refinement |

---

*Document version: 1.0*
*Last updated: 2026-02-11*
*Package: Apex AI -- Dental Practice (UK Market)*
*Prepared by: Avantwerk Implementation Team*
