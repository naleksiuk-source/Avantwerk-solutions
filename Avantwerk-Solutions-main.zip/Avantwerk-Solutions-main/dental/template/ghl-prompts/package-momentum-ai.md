# Momentum AI ★ — Dental Practice (UK)

**Package**: Momentum AI ★ (Most Popular)
**Package price**: £2,999 (£2,499 with annual subscription)
**Industry**: Dental Practice
**Market**: UK (GBP, British English)
**Delivery timeline**: 30 days
**Hypercare**: 21 days
**Total estimated build time**: 38–44 hours

This is a complete, self-contained execution playbook for building and deploying the Momentum AI package for a UK dental practice inside GoHighLevel (GHL). Every deliverable is documented with full content, step-by-step GHL instructions, and realistic time estimates.

---

## How to Use This Playbook

1. Work through each phase in order — later phases depend on infrastructure created in earlier ones.
2. Replace every `[PLACEHOLDER]` with the client's actual information before going live. A complete placeholder reference is provided in the Appendix.
3. Time estimates are per-deliverable. Track actual hours against estimates to improve future scoping.
4. Mark each checklist item as you complete it.

---

## Placeholder Reference (Quick)

| Placeholder | Example Value |
|-------------|---------------|
| `[BUSINESS_NAME]` | Bright Smile Dental |
| `[PHONE]` | 020 1234 5678 |
| `[EMERGENCY_PHONE]` | 07700 900123 |
| `[EMAIL]` | hello@brightsmile.co.uk |
| `[ADDRESS]` | 42 High Street, London, SW1A 1AA |
| `[CITY]` | London |
| `[POSTCODE]` | SW1A 1AA |
| `[WEBSITE_URL]` | https://www.brightsmile.co.uk |
| `[BOOKING_URL]` | /booking |
| `[GOOGLE_MAPS_URL]` | https://maps.google.com/... |
| `[GOOGLE_REVIEW_URL]` | https://g.page/brightsmile/review |
| `[PARKING_INFO]` | Free patient car park at the rear of the building |
| `[ACCESSIBILITY_INFO]` | Full step-free access throughout the practice |
| `[NHS_STATUS]` | Mixed NHS and private practice |
| `[RATING]` | 4.9 |
| `[REVIEW_COUNT]` | 280 |
| `[YEAR_ESTABLISHED]` | 2012 |
| `[BOT_NAME]` | Ava |
| `[BOT_GREETING]` | Hello! I'm Ava, the virtual assistant for [BUSINESS_NAME]. How can I help you today? |
| `[DENTIST_1_NAME]` | Dr James Patel |
| `[DENTIST_2_NAME]` | Dr Sarah Thompson |
| `[HYGIENIST_NAME]` | Lisa Chen |
| `[MANAGER_NAME]` | Rachel Adams |
| `[MON_HOURS]` – `[SUN_HOURS]` | 08:00 – 18:00 (varies by day) |
| `[PLAN_PRICE]` | 19.95 |
| `[CANCELLATION_POLICY]` | We kindly ask for at least 24 hours' notice. Late cancellations may incur a charge of £25. |
| `[MISSED_APPT_FEE]` | £25 |

See the full placeholder checklist in the Appendix for the complete list.

---

## Design System (Dental UK)

| Property | Value |
|----------|-------|
| Primary Blue | #2563eb |
| Primary Hover | #1d4ed8 |
| Secondary Cyan | #06b6d4 |
| Accent Green | #10b981 |
| Page Background | #f8fafc |
| Section Background | #ffffff |
| Card Background | #f1f5f9 |
| Card Hover | #e2e8f0 |
| Heading Text | #0f172a |
| Body Text | #475569 |
| Muted Text | #94a3b8 |
| Text on Primary | #ffffff |
| Border Colour | rgba(0,0,0,0.08) |
| Font | DM Sans (Google Fonts) |
| H1 | 2.5rem / 700 |
| H2 | 2rem / 700 |
| H3 | 1.5rem / 600 |
| Body | 1rem / 400 |
| Button Padding | 14px 28px |
| Button Radius | 12px |
| Card Radius | 16px |
| Tone | Professional, warm, trustworthy, British English |

---

## Pre-Setup Checklist

Complete these items before starting any GHL build work. These require client input or account-level configuration.

- [ ] Client onboarding form completed (business name, address, phone, email, opening hours, team info, services, pricing, NHS status)
- [ ] GHL Agency account has available sub-account slot
- [ ] Client's custom domain ready (or domain to be purchased and pointed to GHL)
- [ ] SMS sender registration submitted (UK two-way SMS requires registration — allow 3–5 working days)
- [ ] Email sending domain verified in GHL (DKIM, SPF, DMARC records added)
- [ ] Client's Google Business Profile URL obtained (for review link)
- [ ] Google Maps embed URL or API key obtained
- [ ] Client logo (PNG, SVG) and brand colours collected (or confirm use of industry defaults)
- [ ] Team member photos collected (or confirm use of placeholders)
- [ ] Treatment pricing confirmed and signed off by client
- [ ] Client's cancellation policy and missed appointment fee confirmed
- [ ] NHS band pricing confirmed (current as of deployment date)
- [ ] Payment plan / finance provider details confirmed
- [ ] Dental insurance accepted list confirmed
- [ ] Out-of-hours emergency instructions confirmed

---

## Phase 1: GHL Sub-Account Setup (45 min)

### Step-by-Step

1. Log in to the GHL Agency dashboard.
2. Go to **Settings → Sub-Accounts → Create Sub-Account**.
3. Name the sub-account: `[BUSINESS_NAME] — Dental UK`.
4. Set the timezone to **Europe/London (GMT/BST)**.
5. Enter the business details:
   - Business name: `[BUSINESS_NAME]`
   - Address: `[ADDRESS]`
   - Phone: `[PHONE]`
   - Email: `[EMAIL]`
   - Website: `[WEBSITE_URL]`
6. Upload the client's logo.
7. Configure the custom domain:
   - Go to **Settings → Domains** → Add domain.
   - Add `[WEBSITE_URL]` and follow the DNS CNAME instructions.
   - Verify the domain once DNS has propagated.
8. Configure email sending:
   - Go to **Settings → Email Services**.
   - Add the sending domain and verify DKIM/SPF/DMARC records.
   - Set the default "From" name to `[BUSINESS_NAME]`.
   - Set the default "Reply-to" to `[EMAIL]`.
9. Configure SMS:
   - Go to **Settings → Phone Numbers**.
   - Purchase or port a UK number with SMS capability.
   - Register the sender for two-way SMS (if not already done at agency level).
10. Set business hours in **Settings → Business Profile**:
    - Monday: `[MON_HOURS]`
    - Tuesday: `[TUE_HOURS]`
    - Wednesday: `[WED_HOURS]`
    - Thursday: `[THU_HOURS]`
    - Friday: `[FRI_HOURS]`
    - Saturday: `[SAT_HOURS]`
    - Sunday: `[SUN_HOURS]`
11. Configure the Google Maps integration (if using GHL's native map).
12. Set the locale to **English (United Kingdom)** and currency to **GBP**.

### Verification Checklist
- [ ] Sub-account created and accessible
- [ ] Custom domain verified and SSL active
- [ ] Email sending domain verified (test email received)
- [ ] SMS number active and two-way SMS working (test SMS sent and received)
- [ ] Business hours configured
- [ ] Logo uploaded
- [ ] Timezone set to Europe/London

---

## Phase 2: Custom Fields & Tags (30 min)

### Custom Fields — Contact Level

Create these in **Settings → Custom Fields → Contact**:

| Field Name | Field Type | Used By |
|------------|-----------|---------|
| `last_checkup_date` | Date | Recall Reminder workflow |
| `enquiry_source` | Dropdown: Website Form, Chatbot, Phone, Social Media | New Patient Nurture workflow |
| `enquiry_interest` | Single Line Text | New Patient Nurture workflow |
| `new_patient_offer` | Single Line Text | New Patient Nurture workflow |
| `cancellation_reason` | Dropdown: Schedule Conflict, Cost, Found Another Dentist, Feeling Better, Other | Cancellation Recovery workflow |
| `patient_type` | Dropdown: NHS, Private | Recall, Welcome workflows |
| `waitlist` | Dropdown: Yes, No | Cancellation Recovery workflow |
| `waitlist_preference` | Multi Line Text | Cancellation Recovery workflow |

### Custom Fields — Location Level

Create these in **Settings → Custom Fields → Location** (if not already present):

| Field Name | Field Type | Value |
|------------|-----------|-------|
| `google_review_link` | URL | `[GOOGLE_REVIEW_URL]` |
| `booking_link` | URL | `[BOOKING_URL]` |
| `parking_info` | Multi Line Text | `[PARKING_INFO]` |

### Tags

Create all of the following tags in **Settings → Tags**:

**Appointment Reminder**: `appointment-booked`, `appointment-confirmed`, `appointment-no-show`, `appointment-completed`

**Review Request**: `review-requested`, `review-clicked`, `review-left`, `review-requested-complete`

**Recall Reminder**: `recall-due`, `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-booked`, `recall-sequence-complete`, `recall-overdue`

**New Patient Welcome**: `new-patient`, `welcome-email-sent`, `welcome-followup-sent`, `new-patient-welcomed`

**New Patient Nurture**: `enquiry-no-booking`, `nurture-email-1-sent`, `nurture-sms-sent`, `nurture-email-2-sent`, `nurture-email-3-sent`, `nurture-converted`, `nurture-sequence-complete`, `nurture-cold`

**Cancellation Recovery**: `appointment-cancelled`, `recovery-sms-sent`, `recovery-email-sent`, `waitlist-notified`, `cancellation-rebooked`, `cancellation-recovered`, `cancellation-recovery-complete`

**General**: `inactive-patient`, `do-not-contact`, `frequent-canceller`

### Verification Checklist
- [ ] All 8 contact custom fields created with correct types
- [ ] All 3 location custom fields created and populated with values
- [ ] All tags created (verify against the list above — 35 total)

---

## Phase 3: Pipeline Setup (20 min)

Create these pipelines in **CRM → Pipelines**:

| Pipeline | Stages |
|----------|--------|
| Patient Appointments | Booked → Confirmed → Completed → No Show |
| Patient Engagement | Review Requested → Review Clicked → Review Sequence Complete |
| Recall Management | Recall Due → Recall Booked → Overdue - Manual Follow-up |
| New Patient Journey | New Registration → Welcomed |
| Lead Nurture | New Enquiry → Converted → Cold Lead |
| Cancellation Recovery | Cancelled → Rebooked → Not Recovered |

### Calendar Setup

Create these appointment types in **Calendars**:

| Appointment Type | Duration | Colour |
|-----------------|----------|--------|
| New Patient Check-up | 45 min | Blue |
| Returning Patient Check-up | 30 min | Blue |
| Hygiene Appointment | 30 min | Cyan |
| Emergency | 20 min | Red |
| General Consultation | 30 min | Blue |
| Teeth Whitening Consultation | 20 min | Green |
| Invisalign Consultation | 30 min | Green |
| Implant Consultation | 30 min | Green |

Set availability based on `[MON_HOURS]` through `[SAT_HOURS]`. Block at least one emergency slot per day.

### Verification Checklist
- [ ] All 6 pipelines created with correct stages
- [ ] All 8 appointment types created with correct durations
- [ ] Calendar availability matches client's opening hours
- [ ] At least 1 emergency slot blocked per day

---

## Phase 4: Website — 13 Pages (14–17 hours)

The Momentum AI package includes 7+ pages. We deliver 13 pages total: Homepage, Services, About, Contact, Booking, 3 treatment pages (Teeth Whitening, Dental Implants, Invisalign), Reviews/Testimonials, Blog Index, and 3 blog articles.

### Global Website Setup (1 hour)

Before building individual pages:

1. **Header Navigation**: Build natively in GHL page builder.
   - Logo (left)
   - Menu links: Home, Services, About, Reviews, Blog, Contact
   - CTA button (right): "Book Now" linking to /booking
   - Mobile: hamburger menu
   - Sticky on scroll

2. **Footer**: Build natively in GHL page builder.
   - Four columns:
     1. Practice name, address, phone, email
     2. Quick links: Home, Services, About, Reviews, Blog, Contact, Book Online
     3. Treatments: Check-up, Whitening, Implants, Invisalign
     4. Opening Hours
   - Bottom bar: Copyright, Privacy Policy, Terms, Cookie Policy links
   - Social icons: Facebook, Instagram, Google

3. **Chat Widget**: Configure GHL Conversation AI (see Phase 7 for full chatbot setup).

4. **SEO Defaults**: Meta title format: "[Page Title] | [BUSINESS_NAME] — Dental Practice in [CITY]"

---

### Page 1: Homepage (2 hours)

**URL Slug**: / (root)
**Sections**: 8

**GHL AI Builder Prompt** — Copy this entire block into GHL's AI website builder:

> Build a homepage for a dental practice called [BUSINESS_NAME]. Use a clean, clinical, trustworthy design with a light theme. The primary colour is blue #2563eb, secondary is cyan #06b6d4, accent is green #10b981. Page background is #f8fafc, cards are #f1f5f9, headings are #0f172a, body text is #475569. Use the font DM Sans from Google Fonts. British English throughout. No emojis. All content below must appear on the page exactly as written.
>
> SECTION 1 — HERO
> Full-width hero with a subtle gradient overlay on a dental surgery background image placeholder. Left-aligned text:
> - Small badge above headline: "Trusted by [REVIEW_COUNT]+ Patients"
> - Headline (H1): "Your Smile Deserves the Best Care"
> - Subheadline: "Welcome to [BUSINESS_NAME] — your trusted local dental practice offering NHS and private treatments for the whole family. Gentle, professional care in a modern, relaxed setting."
> - Two buttons side by side: "Book Appointment" (primary blue #2563eb, links to [BOOKING_URL]) and "Call Us: [PHONE]" (outlined style, links to tel:[PHONE])
> - Below buttons, a small trust line: "No registration fee. New patients welcome. Evening appointments available."
>
> SECTION 2 — TRUST BAR
> A horizontal bar with a light blue tinted background (#eff6ff). Display four trust indicators in a row:
> - "[RATING] Stars" with label "Google Rating"
> - "[REVIEW_COUNT]+" with label "Happy Patients"
> - "Est. [YEAR_ESTABLISHED]" with label "Years of Experience"
> - "GDC Registered" with label "Fully Accredited"
>
> SECTION 3 — SERVICES OVERVIEW
> Section heading (H2): "Our Treatments"
> Subtext: "Comprehensive dental care for every member of your family, from routine check-ups to advanced cosmetic treatments."
> A grid of 8 service cards (4 columns on desktop, 2 on mobile). Each card has an icon area, service name, short description, and a "from" price:
> 1. General Check-up — "Thorough examination, digital X-rays, and personalised treatment plan." From £50
> 2. Dental Hygiene — "Professional scale and polish to keep your gums healthy and your smile fresh." From £55
> 3. Teeth Whitening — "Professional whitening for a brighter, more confident smile. In-surgery and take-home options." From £300
> 4. Dental Implants — "Permanent tooth replacement that looks, feels, and functions like natural teeth." From £2,000
> 5. Invisalign — "Nearly invisible clear aligners to straighten your teeth without metal braces." From £2,500
> 6. Cosmetic Dentistry — "Veneers, bonding, and smile makeovers to transform your appearance." From £200
> 7. Emergency Dental — "Same-day emergency appointments for pain, swelling, or dental trauma." From £80
> 8. Children's Dentistry — "Gentle, fun dental care to give your child a lifetime of healthy smiles." From £40
> Cards have a white background (#ffffff), subtle border, 16px border radius, and hover shadow effect.
>
> SECTION 4 — WHY CHOOSE US
> Section heading (H2): "Why Patients Choose [BUSINESS_NAME]"
> Four feature cards:
> 1. "Experienced Team" — "Our dentists have over 50 combined years of experience and hold advanced qualifications in implantology, orthodontics, and cosmetic dentistry."
> 2. "Modern Technology" — "Digital X-rays, intraoral scanners, and laser dentistry mean faster, more comfortable treatments with better results."
> 3. "Nervous Patients Welcome" — "We specialise in gentle dentistry. Sedation options, a calm environment, and a patient-first approach to help you feel at ease."
> 4. "Flexible Payments" — "0% finance available on treatments over £500. Spread the cost with affordable monthly payments that suit your budget."
>
> SECTION 5 — MEET THE TEAM (PREVIEW)
> Section heading (H2): "Meet Your Dental Team"
> Subtext: "Skilled, caring professionals dedicated to your oral health."
> 4 team member cards with circular image placeholders:
> 1. "[DENTIST_1_NAME]" — "Principal Dentist" — "BDS, MJDF RCS — Special interest in implants and cosmetic dentistry."
> 2. "[DENTIST_2_NAME]" — "Associate Dentist" — "BDS — Passionate about preventive care and nervous patient management."
> 3. "[HYGIENIST_NAME]" — "Dental Hygienist" — "Dip DH — Expert in gum health, deep cleaning, and stain removal."
> 4. "[MANAGER_NAME]" — "Practice Manager" — "Keeping everything running smoothly so your visit is always comfortable."
> A "Meet the Full Team" link pointing to /about.
>
> SECTION 6 — PATIENT REVIEWS
> Section heading (H2): "What Our Patients Say"
> Subtext: "Rated [RATING] out of 5 from [REVIEW_COUNT]+ Google reviews."
> Three 5-star review cards:
> 1. "I was terrified of the dentist but the team at [BUSINESS_NAME] made me feel completely at ease. The check-up was painless and they explained everything clearly. I actually look forward to my appointments now." — Sarah T., General Check-up
> 2. "Had my teeth whitened here and the results are incredible. Four shades brighter in just one session. The staff were professional and friendly throughout. Could not recommend more highly." — James R., Teeth Whitening
> 3. "After years of hiding my smile, I finally got Invisalign at [BUSINESS_NAME]. The whole process was seamless from consultation to final result. My confidence has completely changed." — Emma L., Invisalign
> "Read All Reviews" link to /reviews. "Leave a Review" link to [GOOGLE_REVIEW_URL].
>
> SECTION 7 — BOOKING CTA BANNER
> Full-width banner with blue gradient (#2563eb to #1d4ed8). White text:
> - Headline (H2): "Ready to Book Your Appointment?"
> - Subtext: "New patients welcome. No registration fee. Book online in under 60 seconds or call us directly."
> - Two white buttons: "Book Online" (links to [BOOKING_URL]) and "Call [PHONE]" (links to tel:[PHONE])
>
> SECTION 8 — LOCATION AND OPENING HOURS
> Two-column layout. Left: address, phone, email, map placeholder. Right: opening hours table and emergency number.
>
> Mobile responsive. 60-80px section spacing. All buttons: 14px 28px padding, 12px radius, font-weight 600, hover lift.

**Manual Build Notes**: Build header/footer natively. Each section as a Custom Code block except Section 8 (native map element + text).

**Native GHL Elements**: Header nav, footer, Google Maps embed, chat widget.

---

### Page 2: Services (1.5 hours)

**URL Slug**: /services
**Sections**: 5

**GHL AI Builder Prompt**:

> Build a services page for [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page bg #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO: Breadcrumb "Home > Services". H1: "Our Dental Treatments". Subheadline: "From routine check-ups to advanced restorative and cosmetic procedures, we offer a full range of dental treatments under one roof."
>
> SECTION 2 — SERVICE CATEGORIES: Grouped by category with card grids. Each card: treatment name, description, starting price.
>
> Category 1 — "General Dentistry": Dental Check-up (from £50), Dental Hygiene (from £55), Fillings (from £80), Root Canal Treatment (from £250), Extractions (from £100), Crowns (from £400).
>
> Category 2 — "Cosmetic Dentistry": Teeth Whitening (from £300, link: /teeth-whitening), Composite Bonding (from £200), Porcelain Veneers (from £500), Smile Makeover (from £2,000).
>
> Category 3 — "Orthodontics": Invisalign (from £2,500, link: /invisalign), Fixed Braces (from £2,000).
>
> Category 4 — "Dental Implants": Single Tooth Implant (from £2,000, link: /dental-implants), Implant-Supported Bridge (from £4,000), All-on-4 (from £8,000).
>
> Category 5 — "Emergency Dental Care": Emergency Consultation (from £80), Emergency Treatment (from £100).
>
> Category 6 — "Children's Dentistry": Children's Check-up (from £40), Fissure Sealants (from £30), Fluoride Treatments (from £25).
>
> SECTION 3 — TREATMENT PROCESS: 4-step horizontal timeline: Consultation → Treatment Plan → Treatment → Aftercare. Each with description.
>
> SECTION 4 — PAYMENT OPTIONS: Three cards: Pay As You Go, 0% Finance (over £500), Dental Plan (from £[PLAN_PRICE]/month).
>
> SECTION 5 — CTA: Blue gradient banner. "Not Sure Which Treatment You Need?" "Book a consultation." Button to [BOOKING_URL].
>
> Mobile responsive.

---

### Page 3: About Us (1.5 hours)

**URL Slug**: /about
**Sections**: 6

**GHL AI Builder Prompt**:

> Build an About Us page for [BUSINESS_NAME]. Primary blue #2563eb. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO: H1: "About [BUSINESS_NAME]". Subheadline: "A modern dental practice built on trust, expertise, and genuine patient care."
>
> SECTION 2 — PRACTICE STORY: Two-column. Left: image placeholder (practice interior). Right: "Our Story" — Founded in [YEAR_ESTABLISHED], invested in technology, built reputation for clinical excellence. Three paragraphs covering origin, growth, patient-first philosophy.
>
> SECTION 3 — OUR VALUES: Four value cards: Clinical Excellence, Patient-First Care, Honest Communication, Continuous Innovation. Each with 2-sentence description.
>
> SECTION 4 — FULL TEAM: 4 team member cards (3 columns desktop, 2 mobile). Each with portrait image placeholder, name, role, qualifications, 2-sentence bio:
> 1. [DENTIST_1_NAME] — Principal Dentist, BDS, MJDF RCS
> 2. [DENTIST_2_NAME] — Associate Dentist, BDS
> 3. [HYGIENIST_NAME] — Dental Hygienist, Dip DH
> 4. [MANAGER_NAME] — Practice Manager
>
> SECTION 5 — ACCREDITATIONS: Horizontal row: GDC, CQC, BDA, Invisalign Provider, Denplan.
>
> SECTION 6 — CTA: "Join the [BUSINESS_NAME] Family". Buttons: "Book Your First Visit" and "Contact Us".
>
> Mobile responsive.

---

### Page 4: Contact (1 hour)

**URL Slug**: /contact
**Sections**: 4

**GHL AI Builder Prompt**:

> Build a Contact page for [BUSINESS_NAME]. Primary blue #2563eb. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO: H1: "Get in Touch". Subheadline: "We would love to hear from you."
>
> SECTION 2 — CONTACT METHODS AND FORM: Two-column. Left: phone ([PHONE]), email ([EMAIL]), WhatsApp, emergency ([EMERGENCY_PHONE]), address. Right: [GHL NATIVE FORM — Fields: First Name, Last Name, Email, Phone, Subject dropdown (General Enquiry, New Patient Registration, Appointment Query, Treatment Question, Complaint, Other), Message textarea. Submit: "Send Message"].
>
> SECTION 3 — MAP AND DIRECTIONS: Google Maps embed placeholder. Three info cards: By Car, By Public Transport, Accessibility.
>
> SECTION 4 — OPENING HOURS: Table of hours, emergency note, "Book an Appointment" button.
>
> Mobile responsive.

**Native GHL Elements**: Contact form (wire to tag `enquiry-no-booking` or pipeline), Google Maps embed.

---

### Page 5: Book Online (45 min)

**URL Slug**: /booking
**Sections**: 3

**GHL AI Builder Prompt**:

> Build a Booking page for [BUSINESS_NAME]. Primary blue #2563eb. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO: H1: "Book Your Appointment". Subheadline: "Choose a time that suits you and book online in under 60 seconds. New patients welcome — no registration fee."
>
> SECTION 2 — BOOKING CALENDAR: [GHL NATIVE CALENDAR — Appointment types: New Patient Check-up (45 min), Returning Patient Check-up (30 min), Hygiene Appointment (30 min), Emergency (20 min), General Consultation (30 min), Teeth Whitening Consultation (20 min), Invisalign Consultation (30 min), Implant Consultation (30 min).]
> Below calendar, three info cards: New Patients (what to bring, arrive 10 min early), Appointment Types (guidance), Cancellation Policy (24h notice, £25 fee).
>
> SECTION 3 — PREFER TO CALL: "Call [PHONE]" and "Send us a Message" buttons.
>
> Mobile responsive.

**Native GHL Elements**: Calendar widget (primary element — wire to pipelines and confirmation workflow).

---

### Page 6: Teeth Whitening (1.5 hours)

**URL Slug**: /teeth-whitening
**Sections**: 8

**GHL AI Builder Prompt**:

> Build a Teeth Whitening treatment page for [BUSINESS_NAME]. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO: Breadcrumb "Home > Services > Teeth Whitening". H1: "Professional Teeth Whitening". Subheadline about safe, effective whitening. Buttons: "Book a Whitening Consultation" and "Call [PHONE]".
>
> SECTION 2 — WHAT IS WHITENING: Two-column. Image placeholder. Three paragraphs explaining professional whitening, in-surgery vs take-home, consultation process.
>
> SECTION 3 — BENEFITS: Four cards: Clinically Proven Results (up to 8 shades), Safe and Supervised, Fast and Convenient (60 min in-surgery), Long-Lasting (12–18 months).
>
> SECTION 4 — PROCESS TIMELINE: 4 steps: Consultation → Custom Trays → Whitening → Aftercare.
>
> SECTION 5 — PRICING: Three cards:
> 1. "In-Surgery Power Whitening" — £400 — 60 min session, immediate results
> 2. "Take-Home Whitening Kit" — £300 — custom trays, 2–3 weeks
> 3. "Combined Package" — £500 — Badge: "Best Value"
> "0% finance available. Free initial consultation."
>
> SECTION 6 — FAQS: 5 accordions: Is whitening safe? How long do results last? Will it make teeth sensitive? Crowns/veneers? Why professional vs shop-bought?
>
> SECTION 7 — BEFORE AND AFTER: Three before/after image placeholder pairs.
>
> SECTION 8 — TESTIMONIAL AND CTA: 5-star review. "Ready for a Brighter Smile?" Button: "Book Consultation".
>
> Mobile responsive.

---

### Page 7: Dental Implants (1.5 hours)

**URL Slug**: /dental-implants
**Sections**: 8

**GHL AI Builder Prompt**:

> Build a Dental Implants page for [BUSINESS_NAME]. Primary blue #2563eb. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO: Breadcrumb. H1: "Dental Implants". Subheadline about permanent, natural-looking replacement. Buttons: "Book a Free Implant Consultation" and "Call [PHONE]".
>
> SECTION 2 — WHAT ARE IMPLANTS: Two-column. Image placeholder (implant diagram). Three paragraphs: titanium post + osseointegration, benefits vs dentures/bridges, 3D guided surgery.
>
> SECTION 3 — BENEFITS: Five cards: Look Natural, Feel Natural, Preserve Bone, Long-Lasting, Protect Healthy Teeth.
>
> SECTION 4 — PROCESS TIMELINE: 6 steps: Free Consultation → Treatment Planning → Implant Placement → Healing (3–6 months) → Abutment & Impression → Final Crown.
>
> SECTION 5 — PRICING: Three cards:
> 1. Single Tooth Implant — From £2,000
> 2. Implant-Supported Bridge — From £4,000
> 3. All-on-4 Full Arch — From £8,000
> "Free consultation. 0% finance available."
>
> SECTION 6 — FAQS: 5 accordions: Am I suitable? Is it painful? How long do they last? Can I have implants if I wear dentures? Success rate?
>
> SECTION 7 — BEFORE AND AFTER: Three placeholder pairs.
>
> SECTION 8 — TESTIMONIAL AND CTA: 5-star review. "Ready to Restore Your Smile?" Button: "Book Free Consultation".
>
> Mobile responsive.

---

### Page 8: Invisalign (1.5 hours)

**URL Slug**: /invisalign
**Sections**: 8

**GHL AI Builder Prompt**:

> Build an Invisalign page for [BUSINESS_NAME]. Primary blue #2563eb. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO: H1: "Invisalign Clear Aligners". Subheadline about discreet straightening. Buttons: "Book a Free Invisalign Consultation" and "Call [PHONE]".
>
> SECTION 2 — WHAT IS INVISALIGN: Two-column. Three paragraphs: leading aligner system, removable custom trays, certified provider with digital scan and 3D simulation.
>
> SECTION 3 — BENEFITS: Five cards: Nearly Invisible, Removable, Comfortable, Predictable Results, Fewer Appointments.
>
> SECTION 4 — PROCESS: 5 steps: Free Consultation → Digital Scan → Custom Aligners → Wear & Progress → Retainers.
>
> SECTION 5 — PRICING: Three cards:
> 1. Invisalign Lite — From £2,500 — 3–6 months
> 2. Invisalign Comprehensive — From £3,500 — Badge: "Most Popular" — 12–18 months
> 3. Monthly Payment Plan — From £80/month — 0% finance
> "Free consultation. No obligation."
>
> SECTION 6 — FAQS: 5 accordions: How long? Does it hurt? Can I eat normally? How often wear? Am I suitable?
>
> SECTION 7 — BEFORE AND AFTER: Three placeholder pairs.
>
> SECTION 8 — TESTIMONIAL AND CTA: 5-star review. "Start Your Invisalign Journey". Button: "Book Free Consultation".
>
> Mobile responsive.

---

### Page 9: Reviews / Testimonials (1 hour)

**URL Slug**: /reviews
**Sections**: 4

**GHL AI Builder Prompt**:

> Build a Reviews page for [BUSINESS_NAME]. Primary blue #2563eb, accent green #10b981. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO WITH RATING: H1: "Patient Reviews". Large rating: "[RATING] out of 5" with star icons. Subheadline: "Based on [REVIEW_COUNT]+ verified Google reviews." "Leave a Review" button to [GOOGLE_REVIEW_URL].
>
> SECTION 2 — RATING BREAKDOWN: Visual bar chart: 5 stars [5_STAR_PERCENT]%, 4 stars, 3 stars, 2 stars, 1 star.
>
> SECTION 3 — REVIEW CARDS: Grid of 9 review cards (3 columns desktop). All 5 stars:
> 1. David M. — General Check-up — "Consistently excellent. Thorough check-ups, brilliant hygienist, friendly reception."
> 2. Priya K. — Teeth Whitening — "Over the moon with results. Noticeably brighter, comfortable process."
> 3. Robert H. — Dental Implants — "Life-changing. Outstanding care from consultation to crown fitting."
> 4. Claire S. — Nervous Patient — "Avoided the dentist for 8 years. Incredibly patient, felt completely safe."
> 5. Michael T. — Children's Dentistry — "Both children love coming here. Staff wonderful with kids."
> 6. Sophie W. — Emergency — "Saturday morning toothache. Seen within the hour. Calm, reassuring, sorted quickly."
> 7. Angela P. — Hygiene — "Best hygienist I've ever visited. Thorough but gentle. Practical advice."
> 8. Tom R. — Cosmetic Dentistry — "Composite bonding transformation is amazing. Completely natural."
> 9. Hannah J. — Invisalign — "Could not be happier. Well-organised from scan to retainer."
>
> SECTION 4 — CTA: "Ready to Experience the Difference?" Buttons: "Book Appointment" and "Leave a Review".
>
> Mobile responsive.

---

### Page 10: Blog Index (45 min)

**URL Slug**: /blog
**Sections**: 4

**GHL AI Builder Prompt**:

> Build a Blog Index page for [BUSINESS_NAME]. Primary blue #2563eb. Page bg #f8fafc. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO: H1: "Dental Health Blog". Subheadline: "Expert advice, treatment guides, and oral health tips."
>
> SECTION 2 — FEATURED ARTICLE: Full-width card. Badge: "Featured". Category: "Prevention". H2: "5 Daily Habits for Healthier Teeth". Excerpt. 5 min read. Link: /blog/daily-habits.
>
> SECTION 3 — ARTICLE GRID: Three cards:
> 1. "Everything You Need to Know About Teeth Whitening" — Cosmetic — 7 min — /blog/whitening-guide
> 2. "Your Child's First Dental Visit: What to Expect" — Family — 6 min — /blog/childs-first-visit
> 3. "Coming Soon" — placeholder
>
> SECTION 4 — NEWSLETTER SIGNUP: Light blue bg. H2: "Stay Informed". [GHL NATIVE FORM — Fields: First Name, Email. Submit: "Subscribe". Tag: "Newsletter Subscriber".]
>
> Mobile responsive.

**Native GHL Elements**: Newsletter form (tag subscriber, wire to email welcome).

---

### Page 11: Blog — "5 Daily Habits for Healthier Teeth" (1 hour)

**URL Slug**: /blog/daily-habits
**Sections**: 4

**Full Article Content** (paste into GHL Custom Code block, max-width 720px):

> **Category**: Prevention | **Read time**: 5 min | **Author**: [AUTHOR_NAME]
>
> **H1**: 5 Daily Habits for Healthier Teeth
>
> Your oral health is not just about what happens in the dental chair. The habits you practise every day at home have the biggest impact on the long-term health of your teeth and gums. Here are five simple, evidence-based habits that our dentists at [BUSINESS_NAME] recommend to every patient.
>
> **H2: 1. Brush Twice a Day with Fluoride Toothpaste**
> Use a soft-bristled toothbrush (electric is even better) and fluoride toothpaste. Brush for a full two minutes, covering all surfaces — front, back, and biting surfaces of every tooth. Hold the brush at a 45-degree angle to your gum line and use gentle, circular motions. Replace your toothbrush every three months. Brush first thing in the morning and last thing at night.
>
> **H2: 2. Floss or Use Interdental Brushes Every Day**
> Your toothbrush only cleans about 60% of the tooth surface. Flossing or using interdental brushes once a day removes plaque and bacteria from between teeth. If traditional floss is difficult, try TePe brushes, a water flosser, or floss picks. Ask your hygienist for a personalised recommendation.
>
> **H2: 3. Limit Sugary and Acidic Food and Drinks**
> Every time you consume sugar, bacteria in your mouth produce acid that attacks your enamel for about 30 minutes. Have sugary treats with meals rather than as separate snacks. Choose water over fizzy drinks. Wait 30 minutes after acidic foods before brushing.
>
> **H2: 4. Drink Plenty of Water**
> Water washes away food particles and bacteria, dilutes acids, and keeps your mouth hydrated. A dry mouth creates an environment where bacteria thrive. Sip water throughout the day, especially after meals.
>
> **H2: 5. Do Not Skip Your Dental Check-ups**
> Even with excellent home care, you need regular professional check-ups. Many dental problems develop painlessly in their early stages. We recommend a check-up every six months. Prevention is always simpler, more comfortable, and cheaper than treatment.
>
> Small, consistent habits make the biggest difference. Start with these five and you will be giving your teeth and gums the best possible care between visits to [BUSINESS_NAME].

**Related articles**: Whitening Guide, Child's First Visit.
**CTA**: "Time for a Check-up?" Button to [BOOKING_URL].
**SEO**: Title: "5 Daily Habits for Healthier Teeth | [BUSINESS_NAME] Blog"

---

### Page 12: Blog — "Everything About Teeth Whitening" (1 hour)

**URL Slug**: /blog/whitening-guide
**Sections**: 4

**Full Article Content**:

> **Category**: Cosmetic | **Read time**: 7 min | **Author**: [AUTHOR_NAME]
>
> **H1**: Everything You Need to Know About Teeth Whitening
>
> A brighter smile can make a remarkable difference to your confidence. Teeth whitening is one of the most popular cosmetic dental treatments in the UK. This guide covers everything you need to make an informed decision.
>
> **H2: Why Do Teeth Become Discoloured?**
> Extrinsic stains from tea, coffee, red wine, tobacco, and pigmented foods sit on the enamel surface. Intrinsic discolouration occurs within the tooth from ageing, medications, fluoride exposure, or trauma — these require whitening treatment.
>
> **H2: Professional vs Shop-Bought Whitening**
> Professional whitening uses higher-concentration gels (up to 6% hydrogen peroxide, EU-regulated) applied by a dentist with custom trays. Shop-bought products use much lower concentrations with generic trays — results are uneven and disappointing. Whitening by non-dental professionals is illegal in the UK.
>
> **H2: Types of Professional Whitening**
> In-surgery power whitening (from £400): 60-minute session, 4–8 shades lighter immediately. Take-home whitening (from £300): custom trays worn 30–60 min daily for 2–3 weeks. Combined package (from £500): best long-term value.
>
> **H2: What to Expect During Treatment**
> Examination first to check suitability. Whitening does not change crowns, veneers, or fillings. Protective barrier applied to gums. Some temporary sensitivity is normal (resolves in 24–48 hours).
>
> **H2: How Long Do Results Last?**
> 12–18 months with good oral hygiene. Maintain with whitening toothpaste, regular hygiene appointments, and periodic top-ups using take-home trays.
>
> **H2: Is Whitening Safe?**
> Yes, when performed by a qualified dental professional. Products are regulated and clinically tested. Main side effect is temporary sensitivity.
>
> **H2: How Much Does Whitening Cost?**
> In-surgery: from £400. Take-home: from £300. Combined: from £500. 0% finance available over £500.
>
> Book your free whitening consultation at [BUSINESS_NAME]: [BOOKING_URL] or call [PHONE].

**Related articles**: Daily Habits, Child's First Visit.
**CTA**: "Interested in Teeth Whitening?" Button to [BOOKING_URL].

---

### Page 13: Blog — "Your Child's First Dental Visit" (1 hour)

**URL Slug**: /blog/childs-first-visit
**Sections**: 4

**Full Article Content**:

> **Category**: Family | **Read time**: 6 min | **Author**: [AUTHOR_NAME]
>
> **H1**: Your Child's First Dental Visit: What to Expect
>
> Taking your child to the dentist for the first time is an important milestone. A positive first experience helps build good habits and confidence. Here is everything you need to know.
>
> **H2: When Should My Child First Visit the Dentist?**
> By their first birthday, or within six months of their first tooth appearing. Early visits check development, identify issues early, and help your child become comfortable in the dental environment.
>
> **H2: How to Prepare Your Child**
> Keep it casual and positive. Avoid words like "hurt", "needle", "drill". Say the dentist will "count your teeth". Read a children's book about the dentist. Play pretend with a teddy bear. Avoid transferring your own anxiety. Book when your child is well-rested and fed.
>
> **H2: What Happens at the First Visit**
> Warm welcome. Chat with the dentist about health, diet, brushing. Gentle examination on your lap (small mirror, gloved finger — no instruments for very young children). Advice on brushing, fluoride, diet, thumb-sucking. A sticker.
>
> **H2: Tips for a Positive Experience**
> Arrive early. Let the dental team lead. Stay positive afterwards — "well done, you did brilliantly". Make it routine (every 6 months).
>
> **H2: Common Concerns from Parents**
> "My child will not open their mouth" — completely normal, we never force anything. "My child is very anxious" — tell-show-do approach, we go at their pace. "Are X-rays safe?" — digital X-rays are very low dose, only taken when clinically necessary.
>
> **H2: Is Children's Dental Treatment Free?**
> Yes. All NHS dental treatment is free for children under 18 (under 19 in full-time education).
>
> Book your child's first visit at [BUSINESS_NAME]: [BOOKING_URL] or call [PHONE].

**Related articles**: Daily Habits, Whitening Guide.
**CTA**: "Book Your Child's First Visit". Button to [BOOKING_URL].

---

### Website Phase Verification Checklist

- [ ] All 13 pages built and accessible
- [ ] All placeholder values replaced with client data
- [ ] All internal links working (test every navigation link)
- [ ] All external links working (Google Maps, Google Review, tel: links)
- [ ] Header and footer consistent across all pages
- [ ] Mobile responsive on all pages (test on iPhone and Android)
- [ ] Chat widget visible on all pages except legal pages
- [ ] Calendar widget functional on /booking (test a booking)
- [ ] Contact form submits and tags contact correctly
- [ ] Newsletter form submits and tags subscriber
- [ ] SEO meta titles and descriptions set on all pages
- [ ] Images/logos uploaded and rendering correctly
- [ ] Page load speed acceptable (< 3 seconds)
- [ ] SSL certificate active (https)
- [ ] Favicon set

---

## Phase 5: Workflows — 6 Automations (8–10 hours)

Build the workflows in this order to handle tag dependencies correctly:

1. Appointment Reminder (creates `appointment-completed` tag used by Review Request)
2. Review Request (depends on `appointment-completed`)
3. New Patient Welcome (standalone, but interacts with Nurture)
4. 6-Month Recall Reminder (depends on `last_checkup_date`)
5. New Patient Nurture (should check for `new-patient` tag from Welcome)
6. Cancellation Recovery (referenced by Appointment Reminder's reply handling)

---

### Workflow 1: Appointment Reminder (60 min)

**Trigger**: Appointment Status = Booked

**Sequence**:
1. Add tag `appointment-booked` → Move pipeline to Booked
2. Send **Appointment Confirmation Email** (immediate)
3. If appointment > 24h away → Wait until 24h before
4. Check: appointment still active? (no `appointment-cancelled` tag)
5. Send **24h Reminder SMS** (business hours 08:00–20:00)
6. Wait 4h for reply (YES = confirm, CANCEL = trigger Cancellation Recovery)
7. Wait until 2h before appointment
8. Check: still active?
9. Send **2h Reminder SMS**
10. Wait until 2h after appointment end
11. Check: did patient attend? (no `appointment-no-show` tag)
12. Send **Post-Visit Thank You Email** → Add tag `appointment-completed` → Move pipeline to Completed

**Email/SMS Content**:

**Appointment Confirmation Email**
- Subject: Your appointment at {{location.name}} is confirmed
- Body:
```
Hi {{contact.first_name}},

Your appointment has been confirmed. Here are the details:

Appointment: {{appointment.calendar_name}}
Date & Time: {{appointment.start_time}}
Location: {{location.name}}, {{location.address}}

What to bring:
- Photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)

Need to reschedule or cancel? Please give us at least 24 hours' notice by calling {{location.phone}}.

We look forward to seeing you.

Warm regards,
The team at {{location.name}}
```
- CTA: "View on Map" → Google Maps URL

**24h Reminder SMS**
```
Hi {{contact.first_name}}, this is a reminder of your appointment at {{location.name}} tomorrow at {{appointment.start_time}}. Reply YES to confirm or call us on {{location.phone}} to reschedule.
```

**2h Reminder SMS**
```
Hi {{contact.first_name}}, just a quick reminder -- your appointment is in 2 hours at {{appointment.start_time}}. See you soon at {{location.name}}, {{location.address}}.
```

**Post-Visit Thank You Email**
- Subject: Thank you for visiting {{location.name}}, {{contact.first_name}}
- Body:
```
Hi {{contact.first_name}},

Thank you for visiting us today at {{location.name}}. We hope everything went well.

If you have any questions about your treatment or aftercare, please do not hesitate to contact us on {{location.phone}} or reply to this email.

A few helpful reminders:
- If you experienced any numbness from anaesthetic, avoid hot drinks and food until full feeling has returned.
- Brush gently around any treated areas for the first 24 hours.
- Take any recommended pain relief as directed.

We recommend scheduling your next check-up in 6 months to keep your oral health on track.

Thank you for choosing {{location.name}}.

Warm regards,
The team at {{location.name}}
```
- CTA: "Book Your Next Appointment" → {{location.booking_link}}

**Testing Checklist**:
- [ ] Trigger fires on new appointment (online and manual)
- [ ] Confirmation email sends immediately with correct merge fields
- [ ] 24h SMS sends within business hours
- [ ] Reply YES adds `appointment-confirmed` tag
- [ ] Reply CANCEL triggers Cancellation Recovery workflow
- [ ] 2h SMS sends with address
- [ ] Post-visit email does NOT send to no-shows
- [ ] Pipeline stages update correctly
- [ ] Same-day appointments skip 24h reminder

---

### Workflow 2: Review Request (40 min)

**Trigger**: Tag Added = `appointment-completed`

**Sequence**:
1. Check: already has `review-left` tag or `review-requested` in last 90 days? → Exit
2. Check: marketing consent (DND off)? → Exit if no
3. Wait 24h (defer to 10:00 AM if outside business hours)
4. Send **Review Request Email** → Add tag `review-requested` → Enable link tracking
5. Wait 3 days (72h)
6. Check: review link clicked? → If yes, tag `review-clicked`, end
7. Check: still has marketing consent? → Exit if no
8. Send **Review Follow-Up Email**
9. Wait 48h
10. Check: link clicked? → If yes, end
11. Add tag `review-requested-complete` → Move pipeline

**Email Content**:

**Review Request Email**
- Subject: How was your visit, {{contact.first_name}}?
- Body:
```
Hi {{contact.first_name}},

Thank you for visiting {{location.name}} yesterday. We hope you had a positive experience with us.

We would really appreciate it if you could take 60 seconds to share your experience on Google. Your feedback helps other patients find a dental practice they can trust, and it means a lot to our team.

[BUTTON: Leave a Review → {{location.google_review_link}}]

It is quick and easy -- just click the button above and leave a star rating with a few words about your visit.

Thank you for your support.

Warm regards,
The team at {{location.name}}
```
- Footer: Must include unsubscribe link

**Review Follow-Up Email**
- Subject: We'd love to hear from you, {{contact.first_name}}
- Body:
```
Hi {{contact.first_name}},

We sent you a message a few days ago asking about your recent visit to {{location.name}}. If you have a moment, we would truly value your feedback.

Leaving a Google review takes less than 60 seconds and helps us continue providing excellent care to our community.

[BUTTON: Share Your Experience → {{location.google_review_link}}]

No worries if you would rather not -- we are just grateful to have you as a patient.

Warm regards,
The team at {{location.name}}
```
- Footer: Must include unsubscribe link

**Testing Checklist**:
- [ ] Exits if contact has `review-left` tag
- [ ] Exits if no marketing consent
- [ ] First email sends 24h after trigger
- [ ] Google review link is correct and clickable
- [ ] Link tracking detects clicks
- [ ] Follow-up does NOT send if first link was clicked
- [ ] Unsubscribe works in both emails

---

### Workflow 3: 6-Month Recall Reminder (60 min)

**Trigger**: Date Based — `last_checkup_date` + 167 days — at 09:00 AM

**Sequence**:
1. Add tag `recall-due` → Move pipeline to Recall Due
2. Check: future appointment already booked? → If yes, tag `recall-booked`, end
3. Check: marketing consent? → If no, skip to SMS path
4. Send **Recall Email 1** → Tag `recall-email-1-sent`
5. Wait 14 days
6. Check: booked? → If yes, end
7. Check: not in another active workflow (Nurture/Cancellation Recovery)
8. Send **Recall SMS** → Tag `recall-sms-sent` (09:00–19:00 window)
9. Wait 14 days
10. Check: booked? → If yes, end
11. Check: marketing consent?
12. Send **Recall Final Email** → Tag `recall-email-2-sent`
13. Wait 7 days
14. Check: booked? → If yes, end
15. Tag `recall-sequence-complete` + `recall-overdue` → Create internal task for manual follow-up

**Email/SMS Content**:

**Recall Email 1**
- Subject: Time for your check-up, {{contact.first_name}}
- Body:
```
Hi {{contact.first_name}},

It has been almost 6 months since your last check-up at {{location.name}}, and it is time to book your next one.

Regular check-ups are the best way to keep your teeth and gums healthy. They allow us to spot potential issues early -- when they are quicker, simpler, and less costly to treat.

We also recommend combining your check-up with a hygiene appointment to keep your smile looking and feeling its best.

[BUTTON: Book Your Check-up → {{location.booking_link}}]

You can book online at any time, or call us on {{location.phone}} during opening hours.

We look forward to seeing you.

Warm regards,
The team at {{location.name}}
```

**Recall SMS**
```
Hi {{contact.first_name}}, it's been nearly 6 months since your last check-up at {{location.name}}. Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out.
```

**Recall Final Email**
- Subject: Don't miss your check-up, {{contact.first_name}} -- it's overdue
- Body:
```
Hi {{contact.first_name}},

Your 6-month check-up at {{location.name}} is now overdue, and we wanted to reach out one more time.

Regular dental check-ups are essential for:
- Early detection of decay, gum disease, and oral cancer
- Preventing small issues from becoming complex (and costly) treatments
- Keeping your teeth and gums in the best possible condition

We have availability this week and would love to get you booked in. It only takes a few minutes.

[BUTTON: Book Now → {{location.booking_link}}]

If you have any concerns or questions, please do not hesitate to call us on {{location.phone}}.

Warm regards,
The team at {{location.name}}
```

**Testing Checklist**:
- [ ] Trigger fires 167 days after `last_checkup_date`
- [ ] Exits if patient already has future appointment
- [ ] First email sends with working booking link
- [ ] SMS sends within 09:00–19:00 window with STOP opt-out
- [ ] Booking detected at each checkpoint
- [ ] Manual follow-up task created for non-responders
- [ ] Overlap prevention works with other workflows

---

### Workflow 4: New Patient Welcome (40 min)

**Trigger**: Tag Added = `new-patient`

**Sequence**:
1. Move pipeline to New Registration
2. Check: has valid email? → If no, send Welcome SMS, skip to complete
3. Send **Welcome Email** (immediate) → Tag `welcome-email-sent`
4. Wait 48h (defer Sunday to Monday 09:00)
5. Check: first appointment booked?
   - If booked → Send **Welcome Follow-Up (Booked)**
   - If not → Send **Welcome Follow-Up (Not Booked)**
6. Tag `welcome-followup-sent` → Tag `new-patient-welcomed` → Move pipeline to Welcomed

**Email/SMS Content**:

**Welcome Email**
- Subject: Welcome to {{location.name}}, {{contact.first_name}}!
- Body:
```
Hi {{contact.first_name}},

Welcome to {{location.name}}! We are delighted to have you join our practice.

Here is everything you need to know before your first visit:

WHAT TO EXPECT
Your first appointment will take approximately 45 minutes to an hour. We will carry out a thorough examination, take any necessary X-rays, and discuss your dental health and any concerns. There is no pressure for any treatment on your first visit.

WHAT TO BRING
- A form of photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)
- Any previous dental records or X-rays (if you have them)

FINDING US
{{location.name}} is located at {{location.address}}.
Parking: {{location.parking_info}}

[BUTTON: Get Directions → Google Maps URL]

BOOK YOUR FIRST APPOINTMENT
If you have not already booked, you can do so online -- it only takes a minute.

[BUTTON: Book Now → {{location.booking_link}}]

Or call us on {{location.phone}}.

Warm regards,
The team at {{location.name}}
```

**Welcome SMS (no email path)**
```
Welcome to {{location.name}}, {{contact.first_name}}! We're looking forward to seeing you. Questions? Call {{location.phone}} or book online: {{location.booking_link}}
```

**Welcome Follow-Up — Booked**
- Subject: Your first appointment at {{location.name}} -- a quick reminder
- Body:
```
Hi {{contact.first_name}},

Just a quick note to confirm we are looking forward to seeing you at your upcoming appointment.

As a reminder, please bring:
- Photo ID
- A list of any medications
- Insurance details (if applicable)

If you have any questions, reply to this email or call us on {{location.phone}}.

See you soon!

Warm regards,
The team at {{location.name}}
```

**Welcome Follow-Up — Not Booked**
- Subject: Ready to book your first visit, {{contact.first_name}}?
- Body:
```
Hi {{contact.first_name}},

We noticed you have not yet booked your first appointment at {{location.name}}.

Booking is quick and easy -- it takes less than a minute online:

[BUTTON: Book Your First Visit → {{location.booking_link}}]

We offer:
- Comprehensive new patient examinations
- Flexible appointment times, including early mornings and evenings
- A relaxed, no-pressure environment

Call us on {{location.phone}} if you need guidance.

Warm regards,
The team at {{location.name}}
```
- Footer: Include unsubscribe link

**Testing Checklist**:
- [ ] Welcome email sends within 5 minutes of tag being added
- [ ] SMS sends when contact has no email
- [ ] 48h follow-up branches correctly (booked vs not booked)
- [ ] Booking link and map link both work
- [ ] Pipeline updates correctly

---

### Workflow 5: New Patient Nurture — Enquiry to Booking (70 min)

**Trigger**: Tag Added = `enquiry-no-booking`

**Sequence**:
1. Check: already a patient or has booking? → Exit
2. Move pipeline to New Enquiry
3. Check: has valid email? → If no, skip to SMS
4. Wait 1h (defer to 09:00 if outside 08:00–20:00)
5. Send **Nurture Email 1 — Enquiry Acknowledgement** → Tag `nurture-email-1-sent`
6. Wait 23h (total ~24h from enquiry)
7. Check: booked? → If yes, tag `nurture-converted`, end
8. Send **Nurture SMS** → Tag `nurture-sms-sent` (09:00–19:00 window)
9. Wait 2 days (total ~3 days)
10. Check: booked? → If yes, end
11. Check: marketing consent?
12. Send **Nurture Email 2 — Special Offer** → Tag `nurture-email-2-sent`
13. Wait 4 days (total ~7 days)
14. Check: booked? → If yes, end
15. Check: marketing consent?
16. Send **Nurture Email 3 — Final Push** → Tag `nurture-email-3-sent`
17. Wait 7 days (total ~14 days)
18. Check: booked? → If yes, end
19. Tag `nurture-sequence-complete` + `nurture-cold` → Move pipeline to Cold Lead → Create internal task

**Email/SMS Content**:

**Nurture Email 1 — Enquiry Acknowledgement**
- Subject: Thanks for your enquiry, {{contact.first_name}} -- here's how we can help
- Body:
```
Hi {{contact.first_name}},

Thank you for getting in touch with {{location.name}}. We are glad you are considering us for your dental care.

We are a modern dental practice committed to providing exceptional care in a comfortable, welcoming environment. Here is what sets us apart:

- State-of-the-art equipment and techniques
- A friendly, experienced team
- Flexible appointment times including early mornings and evenings
- A gentle, patient-first approach

We would love to welcome you for your first visit.

[BUTTON: Book Your Appointment → {{location.booking_link}}]

Prefer to chat first? Call us on {{location.phone}}.

Warm regards,
The team at {{location.name}}
```

**Nurture SMS**
```
Hi {{contact.first_name}}, we noticed you were looking into dental care at {{location.name}}. We'd love to help! Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out.
```

**Nurture Email 2 — Special Offer**
- Subject: A special welcome offer for you, {{contact.first_name}}
- Body:
```
Hi {{contact.first_name}},

We hope you are doing well. We wanted to let you know about a special offer for new patients at {{location.name}}:

{{custom_field.new_patient_offer}}

Our patients love us -- here is what they are saying:

"Fantastic practice! The team made me feel so at ease from the moment I walked in. Could not recommend them more highly." -- Recent Google Review

We have availability this week.

[BUTTON: Book Now & Claim Your Offer → {{location.booking_link}}]

This offer is available for a limited time.

Warm regards,
The team at {{location.name}}
```

**Nurture Email 3 — Final Push**
- Subject: Still thinking about it, {{contact.first_name}}?
- Body:
```
Hi {{contact.first_name}},

We understand that choosing a new dental practice is an important decision, and we do not want to rush you.

At {{location.name}}:

- We offer transparent pricing with no surprises
- Nervous patients are always welcome -- we will go at your pace
- We offer flexible scheduling to fit around your commitments
- Payment plans are available for larger treatments

Whenever you are ready, we are here for you.

[BUTTON: Book When You're Ready → {{location.booking_link}}]

Or reply to this email and our team will get back to you promptly.

Warm regards,
The team at {{location.name}}
```

All nurture emails include unsubscribe link.

**Testing Checklist**:
- [ ] Exits if contact already has `new-patient` or `appointment-booked` tag
- [ ] First email sends 1h after enquiry (or next 09:00)
- [ ] SMS sends at 24h mark within business hours
- [ ] Offer email references `new_patient_offer` correctly
- [ ] Cold lead task created after 14 days for non-converters
- [ ] Contact who books at any stage exits and gets `nurture-converted`
- [ ] Unsubscribe and STOP work correctly

---

### Workflow 6: Cancellation Recovery (60 min)

**Trigger**: Appointment Status = Cancelled

**Sequence**:
1. Add tag `appointment-cancelled` → Move pipeline to Cancelled
2. Check: short-notice cancellation (< 2h)? → If yes, skip to waitlist only
3. Check: already rebooked (has future appointment)? → If yes, tag `cancellation-rebooked`, end
4. Wait 1h (08:00–20:00 window)
5. Send **Cancellation Recovery SMS** → Tag `recovery-sms-sent`
6. Wait 23h (total ~24h)
7. Check: rebooked? → If yes, tag `cancellation-rebooked` + `cancellation-recovered`, end
8. Send **Cancellation Recovery Email** → Tag `recovery-email-sent`
9. **Waitlist Fill** (parallel): if slot within 7 days, send **Waitlist SMS** to contacts with `waitlist = Yes`
10. Wait until 7 days after cancellation
11. Final rebooking check → If rebooked, end
12. Tag `cancellation-recovery-complete` → Move pipeline to Not Recovered

**Email/SMS Content**:

**Cancellation Recovery SMS**
```
Hi {{contact.first_name}}, we're sorry you had to cancel your appointment at {{location.name}}. We'd love to get you rebooked -- choose a new time: {{location.booking_link}} or call {{location.phone}}.
```

**Cancellation Recovery Email**
- Subject: Let's get you rescheduled, {{contact.first_name}}
- Body:
```
Hi {{contact.first_name}},

We understand that things come up, and we are sorry you had to cancel your appointment at {{location.name}}.

Your dental health is important, and we would love to get you rescheduled as soon as possible. Rebooking is quick and easy:

[BUTTON: Rebook Your Appointment → {{location.booking_link}}]

We have availability this week, including evenings, so there is sure to be a time that works for you.

If you need to discuss anything or would prefer to rebook by phone, call us on {{location.phone}}.

We look forward to seeing you soon.

Warm regards,
The team at {{location.name}}
```

**Waitlist Notification SMS**
```
Hi {{contact.first_name}}, a dental appointment slot has just opened up at {{location.name}}. Want it? Book now: {{location.booking_link}} or call {{location.phone}}. First come, first served!
```

**Testing Checklist**:
- [ ] Trigger fires on appointment cancellation
- [ ] Short-notice cancellations skip patient outreach, go to waitlist
- [ ] Exits if patient immediately rebooks
- [ ] Recovery SMS sends 1h after cancellation (business hours)
- [ ] Recovery email sends at ~24h
- [ ] Waitlist SMS goes to contacts with `waitlist = Yes`
- [ ] Pipeline updates correctly

---

### Workflow Interaction Rules

| If Patient Is In... | And Enters... | Action |
|---------------------|---------------|--------|
| New Patient Nurture | New Patient Welcome | Exit Nurture, Welcome takes priority |
| Recall Reminder | Cancellation Recovery | Pause Recall for 14 days |
| Recall Reminder | New Patient Nurture | Defer Recall start by 14 days |
| Review Request | Any other workflow | Pause Review Request if another email due within 48h |

Configure using GHL's "Contact is NOT in Workflow" conditions at workflow entry points.

---

## Phase 6: Email/SMS Templates — 10 Templates (3–4 hours)

All 10 templates are documented within the workflow sections above. Here is the master list for building as standalone templates in GHL's **Marketing → Templates**:

| # | Template Name | Type | Used By |
|---|--------------|------|---------|
| 1 | Appointment Confirmation | Email | Workflow 1: Appointment Reminder |
| 2 | 24h Reminder | SMS | Workflow 1: Appointment Reminder |
| 3 | 2h Reminder | SMS | Workflow 1: Appointment Reminder |
| 4 | Post-Visit Thank You | Email | Workflow 1: Appointment Reminder |
| 5 | Review Request | Email | Workflow 2: Review Request |
| 6 | Review Follow-Up | Email | Workflow 2: Review Request |
| 7 | Recall Reminder 1 | Email | Workflow 3: Recall Reminder |
| 8 | Recall SMS | SMS | Workflow 3: Recall Reminder |
| 9 | Recall Final | Email | Workflow 3: Recall Reminder |
| 10 | Welcome New Patient | Email | Workflow 4: New Patient Welcome |

**Additional templates included as part of workflows** (bundled, not counted separately):

| Template | Type | Workflow |
|----------|------|---------|
| Welcome Follow-Up (Booked) | Email | Workflow 4 |
| Welcome Follow-Up (Not Booked) | Email | Workflow 4 |
| Welcome SMS | SMS | Workflow 4 |
| Nurture Email 1 | Email | Workflow 5 |
| Nurture SMS | SMS | Workflow 5 |
| Nurture Email 2 (Offer) | Email | Workflow 5 |
| Nurture Email 3 (Final) | Email | Workflow 5 |
| Cancellation Recovery SMS | SMS | Workflow 6 |
| Cancellation Recovery Email | Email | Workflow 6 |
| Waitlist Notification SMS | SMS | Workflow 6 |

### Email Template Build Specifications

All email templates must:
- Use inline CSS (email client compatibility)
- Be mobile responsive
- Use the client's brand colours (default: Blue #2563eb for CTA buttons)
- Use DM Sans font family with web-safe fallback (Arial, Helvetica, sans-serif)
- Include the client's logo at the top
- Include the practice name, address, and phone in the footer
- Use GHL merge fields: `{{contact.first_name}}`, `{{location.name}}`, `{{location.phone}}`, `{{location.address}}`, `{{appointment.start_time}}`, `{{appointment.calendar_name}}`
- Marketing emails must include an unsubscribe link
- Transactional emails (confirmation, reminders) do not require unsubscribe
- SMS messages must include STOP opt-out where required by UK regulations

### Verification Checklist
- [ ] All 10+ templates built in GHL Templates
- [ ] All merge fields render correctly (test with sample contact)
- [ ] CTA buttons link to correct URLs
- [ ] Unsubscribe links work on marketing emails
- [ ] SMS messages within 160-character limit where possible
- [ ] Logo and brand colours correct in all emails
- [ ] Mobile rendering tested

---

## Phase 7: AI Chatbot — Full Patient Journey (4–5 hours)

### Bot Configuration in GHL

1. Go to **Settings → Conversation AI → Create New Bot**
2. Bot Name: `[BOT_NAME]` (e.g., "Ava")
3. Bot Type: Support Bot
4. Enable channels: Website Chat Widget (ON), Facebook Messenger (optional), WhatsApp (optional)
5. Response Mode: Auto-Reply
6. Operating Hours: Always On

### Complete System Prompt

Paste the following into GHL's System Prompt field. Replace ALL `[PLACEHOLDERS]` with client data.

```
You are the virtual dental assistant for [BUSINESS_NAME], a [PRACTICE_TYPE] located in [LOCATION]. Your name is [BOT_NAME].

You are a helpful, professional, and reassuring digital assistant. You are NOT a dentist, dental nurse, or any form of clinician. You never diagnose conditions, prescribe treatment, or provide medical advice. You triage patient concerns, share general information, and guide patients towards booking an appointment or speaking with the clinical team.

You always identify as an AI assistant when asked. You never claim or imply that you are a human.

Your primary goal in every conversation is to help the patient get the information they need and, where appropriate, guide them to book an appointment.

CORE INFORMATION:
- Practice name: [BUSINESS_NAME]
- Address: [ADDRESS]
- Telephone: [PHONE]
- Emergency telephone: [EMERGENCY_PHONE]
- Email: [EMAIL]
- Website: [WEBSITE_URL]
- Online booking: [BOOKING_URL]
- Google Maps: [GOOGLE_MAPS_URL]
- Parking: [PARKING_INFO]
- Wheelchair access: [ACCESSIBILITY_INFO]
- NHS status: [NHS_STATUS]

OPENING HOURS:
- Monday: [MON_HOURS]
- Tuesday: [TUE_HOURS]
- Wednesday: [WED_HOURS]
- Thursday: [THU_HOURS]
- Friday: [FRI_HOURS]
- Saturday: [SAT_HOURS]
- Sunday: [SUN_HOURS]
- Bank holidays: [BANK_HOL_HOURS]
- Emergency out-of-hours: [OUT_OF_HOURS_INFO]

CONVERSATION RULES:
1. Keep every response to 2-3 sentences maximum. Use bullet points for lists of 3+ items.
2. Be professional, warm, and reassuring. Use British English throughout (surgery not office, check-up not checkup, anaesthetic not anesthetic, colour not color).
3. Steer conversations towards booking an appointment within 3 turns where appropriate. Always provide the booking link: [BOOKING_URL]
4. Never diagnose. Never say "you have..." or "it sounds like you have...". Instead say "Based on what you've described, I'd recommend booking a [type] appointment so our team can take a proper look."
5. Always give price ranges, never exact quotes. Add "exact costs will be confirmed after your consultation."
6. Ask one question at a time when gathering information.
7. If a patient expresses fear, pain, or anxiety, acknowledge it before giving practical advice.
8. Never ask for full date of birth, NHS number, or medical details in chat. Direct patient to call or complete a secure form.
9. Begin every new conversation with: "[BOT_GREETING]"
10. End conversations with a clear next step and warm sign-off.
11. If you do not know the answer, say: "That's a great question -- let me connect you with our team for the most accurate answer." Then trigger escalation.
12. Never rush emergency patients. Provide the emergency phone number immediately.

SERVICES AND PRICING (price ranges only):
General Dentistry:
- Check-up & examination: [CHECKUP_PRICE]
- Scale & polish (hygiene): [HYGIENE_PRICE]
- Fillings (composite/white): [FILLING_PRICE]
- Root canal treatment: [ROOT_CANAL_PRICE]
- Tooth extraction: [EXTRACTION_PRICE]

Cosmetic Dentistry:
- Teeth whitening (in-surgery): [WHITENING_SURGERY_PRICE]
- Teeth whitening (home kit): [WHITENING_HOME_PRICE]
- Composite bonding: [BONDING_PRICE] per tooth
- Porcelain veneers: [VENEER_PRICE] per tooth

Orthodontics:
- Invisalign / clear aligners: [INVISALIGN_PRICE]
- Fixed braces: [BRACES_PRICE]

Restorative:
- Dental crowns: [CROWN_PRICE]
- Dental implants: [IMPLANT_PRICE] per tooth

Emergency:
- Emergency appointment: [EMERGENCY_PRICE]

Children:
- Child check-up (under 18): [CHILD_CHECKUP_PRICE]

NHS Bands (if applicable):
- Band 1: [NHS_BAND1]
- Band 2: [NHS_BAND2]
- Band 3: [NHS_BAND3]
- Urgent: [NHS_URGENT]

TEAM:
[TEAM_MEMBER_1_NAME] -- [ROLE] -- [NOTES]
[TEAM_MEMBER_2_NAME] -- [ROLE] -- [NOTES]
[TEAM_MEMBER_3_NAME] -- [ROLE] -- [NOTES]
[TEAM_MEMBER_4_NAME] -- [ROLE] -- [NOTES]

EMERGENCY DETECTION:
If the patient's message contains: "severe pain", "can't stop the bleeding", "heavy bleeding", "swollen face", "neck swelling", "knocked out tooth", "tooth fell out", "abscess", "difficulty breathing", "trouble swallowing", "pus", "hit in the face", "accident", "jaw feels locked", "can't open my mouth", "fever" combined with dental symptom -- immediately provide the emergency response.

EMERGENCY RESPONSE:
"This sounds like it could be a dental emergency, and I want to make sure you get the right help straight away. Please call us now on [EMERGENCY_PHONE] so our team can assess and advise you immediately. If you are experiencing difficulty breathing, difficulty swallowing, or severe swelling spreading to your neck or eye, please call 999 or go to A&E immediately."

SYMPTOM TRIAGE (Momentum AI feature):
When a patient describes symptoms, ask ONE question at a time to assess urgency:

Toothache pathway:
1. "Is it a sharp, stabbing pain or a dull, constant ache?"
2. "How long have you been experiencing this?"
3. "Is there any swelling around your face, jaw, or gums? Do you have a fever?"
- Mild ache, no swelling, < 48h -> Recommend routine check-up. Suggest OTC pain relief.
- Moderate-severe pain, some swelling, > 48h -> Recommend calling [PHONE] for urgent appointment.
- Severe pain + facial swelling + fever -> EMERGENCY RESPONSE.

Broken/chipped tooth pathway:
1. "Can you describe the damage -- small chip or large piece? Can you see pink/red inside?"
2. "Is it causing pain or sensitivity?"
- Small chip, no pain -> Routine appointment. Avoid biting on that side.
- Moderate break, sensitivity -> Call [PHONE] for urgent appointment.
- Large break, visible nerve, severe pain -> EMERGENCY RESPONSE.

Bleeding gums pathway:
1. "Are your gums bleeding when you brush, or on their own?"
2. "How long? Small amount or heavy?"
- Bleeding when brushing, mild -> Recommend hygiene appointment.
- Spontaneous/heavy bleeding with swelling -> Call [PHONE] for prompt appointment.
- Uncontrolled bleeding after trauma -> EMERGENCY RESPONSE.

Knocked-out tooth: ALWAYS emergency. Provide first aid: "Pick up tooth by crown only. Rinse briefly with cold water. Try to replant. If you can't, place in milk. Call [PHONE] immediately -- within 30-60 minutes."

BOOKING MANAGEMENT (Momentum AI feature):
- Guide patients to book online: [BOOKING_URL]
- Help patients select the right appointment type
- Assist with rescheduling requests (collect details, pass to reception)
- Handle cancellation requests (collect details, mention [CANCELLATION_POLICY])

INSURANCE/NHS QUESTIONS (Momentum AI feature):
- Explain NHS band pricing when asked
- Explain difference between NHS and private treatment
- Provide accepted insurance information: [INSURANCE_ANSWER]
- Direct complex finance queries to the practice manager

ESCALATION -- hand off to a human when:
- Complex treatment planning -> [TREATMENT_COORDINATOR]
- Insurance/payment queries beyond basic -> [FINANCE_CONTACT]
- Complaints or negative feedback -> [COMPLAINTS_CONTACT]
- Clinical advice requests -> Direct to [PHONE]
- Patient asks to speak to a person -> Reception via [PHONE]
- Question you cannot answer -> Reception via [PHONE]

When escalating: acknowledge, collect name and phone number, confirm next step and callback time.

THINGS YOU MUST NEVER DO:
- Claim to be human
- Provide a medical diagnosis
- Recommend specific medications beyond "over-the-counter pain relief such as paracetamol or ibuprofen"
- Guarantee treatment outcomes
- Discuss other patients or share personal data
- Make negative comments about other dental practices
- Pressure patients into booking
```

### Knowledge Base Documents to Upload

Upload these to **Conversation AI → Knowledge Base**:

1. **Services & Pricing List** — Full treatment list with price ranges (PDF or text)
2. **Opening Hours & Location** — Hours, address, parking, directions
3. **FAQ Document** — Common questions and answers (see FAQ content in website Phase 4)
4. **Team Information** — Names, roles, specialisms
5. **New Patient Guide** — What to expect, what to bring
6. **Payment & Finance Info** — Methods, insurance, finance options

### Widget Configuration

| Setting | Value |
|---------|-------|
| Position | Bottom-right |
| Primary colour | #2563eb |
| Header text colour | #ffffff |
| Bot name | [BOT_NAME] |
| Welcome message | [BOT_GREETING] |
| Prompt bubble | "Need help? Chat with us!" |
| Prompt bubble delay | 5 seconds |
| Show on mobile | Yes |

### Chatbot Testing Checklist

- [ ] Bot responds to "What are your opening hours?" with correct hours
- [ ] Bot responds to "Where are you located?" with address, parking, map link
- [ ] Bot responds to pricing questions with ranges and "confirmed after consultation"
- [ ] Bot guides to booking page within 3 turns
- [ ] Bot handles rescheduling/cancellation requests (collects details, passes to reception)
- [ ] Emergency keywords trigger immediate emergency response with phone number
- [ ] Symptom triage follows pathways correctly (toothache, broken tooth, bleeding gums)
- [ ] Bot identifies as AI when asked "Are you a real person?"
- [ ] Bot handles complaints with empathy and escalates to manager
- [ ] Bot handles nervous patient queries with reassurance
- [ ] NHS band pricing explained correctly
- [ ] Insurance questions answered or escalated
- [ ] Escalation collects name and phone number
- [ ] Widget appears correctly on desktop and mobile
- [ ] Widget does not appear on privacy/terms pages

---

## Phase 8: Google Review Automation Setup (20 min)

This is configured as part of Workflow 2 (Review Request), but requires additional GHL setup:

1. **Store the Google Review Link**:
   - Go to **Settings → Custom Fields → Location**
   - Set `google_review_link` to the client's direct Google review URL
   - To find this URL: search for the practice on Google → click "Write a review" → copy the URL

2. **Review Link Format**:
   - Direct link format: `https://search.google.com/local/writereview?placeid=[PLACE_ID]`
   - Or use: `https://g.page/[BUSINESS_SHORT_NAME]/review`

3. **Enable Link Click Tracking**:
   - In the Review Request email template, ensure the CTA button link has tracking enabled
   - This allows the workflow to detect when the review link is clicked

4. **Manual Review Confirmation**:
   - Train reception staff to add the `review-left` tag manually when a new Google review appears
   - This prevents the patient from receiving future review requests unnecessarily

5. **Google Business Profile Connection** (optional):
   - If GHL supports Google Business Messages, enable it in the chatbot channels
   - This allows patients to message directly from the Google listing

### Verification Checklist
- [ ] Google review direct URL is correct and opens the review form
- [ ] Link click tracking enabled in email templates
- [ ] Reception team trained to add `review-left` tag
- [ ] Review request workflow triggers correctly from `appointment-completed` tag

---

## Phase 9: Testing & QA (3–4 hours)

### End-to-End Test Scenarios

Complete each test scenario and mark as PASS or FAIL.

#### Website Tests

| # | Test | Expected | Pass/Fail |
|---|------|----------|-----------|
| 1 | Visit all 13 pages on desktop | All pages load correctly, no broken layouts | |
| 2 | Visit all 13 pages on mobile | All pages responsive, no horizontal scroll | |
| 3 | Click every internal link | All links go to correct pages | |
| 4 | Click tel: links on mobile | Phone dialler opens with correct number | |
| 5 | Test contact form submission | Form submits, contact created in GHL, correct tag applied | |
| 6 | Test booking calendar | Calendar loads, shows availability, booking completes | |
| 7 | Test newsletter signup | Form submits, "Newsletter Subscriber" tag applied | |
| 8 | Verify Google Maps embed | Map shows correct location | |
| 9 | Check all images/logos | No broken images, correct sizing | |
| 10 | SSL/HTTPS active | Padlock icon visible, no mixed content warnings | |

#### Workflow Tests

| # | Test | Expected | Pass/Fail |
|---|------|----------|-----------|
| 11 | Book appointment via calendar | Confirmation email sends immediately, tag applied | |
| 12 | 24h reminder timing | SMS sends at correct time before appointment | |
| 13 | Reply YES to 24h SMS | `appointment-confirmed` tag added | |
| 14 | Reply CANCEL to 24h SMS | Cancellation Recovery workflow triggered | |
| 15 | Mark appointment completed | Review Request email sends 24h later | |
| 16 | Click review link in email | `review-clicked` tag added, follow-up suppressed | |
| 17 | Add `new-patient` tag | Welcome email sends immediately | |
| 18 | Add `enquiry-no-booking` tag | Nurture email 1 sends after 1h | |
| 19 | Cancel appointment in GHL | Recovery SMS sends after 1h | |
| 20 | Set `last_checkup_date` to 167 days ago | Recall email triggers at 09:00 next day | |
| 21 | Book during nurture sequence | Workflow exits, `nurture-converted` tag applied | |
| 22 | All merge fields render | No blank `{{fields}}` in any email/SMS | |
| 23 | Unsubscribe link in marketing emails | Contact DND updated, future marketing suppressed | |
| 24 | SMS STOP keyword | Contact opted out of SMS | |

#### Chatbot Tests

| # | Test | Expected | Pass/Fail |
|---|------|----------|-----------|
| 25 | "What are your opening hours?" | Correct hours provided | |
| 26 | "I'd like to book a check-up" | Guided to booking page | |
| 27 | "How much is whitening?" | Price range + consultation offer | |
| 28 | "I have a toothache" | Triage pathway initiated | |
| 29 | "My tooth got knocked out" | Immediate emergency response + phone number | |
| 30 | "I want to cancel my appointment" | Collects details, passes to reception | |
| 31 | "Do you accept NHS patients?" | Correct NHS status answer | |
| 32 | "I'm scared of the dentist" | Empathetic response, anxiety support options | |
| 33 | "Are you a real person?" | Identifies as AI assistant | |
| 34 | "I want to speak to someone" | Collects name/phone, escalates | |
| 35 | Widget appears on homepage | Bottom-right, correct branding | |
| 36 | Widget on mobile | Functional, tappable, readable | |

#### Pipeline Tests

| # | Test | Expected | Pass/Fail |
|---|------|----------|-----------|
| 37 | New booking | Contact moves to Patient Appointments → Booked | |
| 38 | Appointment completed | Contact moves to Completed stage | |
| 39 | Review requested | Contact in Patient Engagement → Review Requested | |
| 40 | Recall triggered | Contact in Recall Management → Recall Due | |
| 41 | New patient registered | Contact in New Patient Journey → New Registration | |
| 42 | Enquiry no booking | Contact in Lead Nurture → New Enquiry | |
| 43 | Cancellation | Contact in Cancellation Recovery → Cancelled | |

### QA Sign-Off

- [ ] All website pages verified
- [ ] All 6 workflows tested end-to-end
- [ ] All email/SMS templates verified with merge fields
- [ ] Chatbot tested across all scenarios
- [ ] All pipelines and tags working correctly
- [ ] Mobile responsiveness verified
- [ ] Page load speed acceptable
- [ ] No placeholder text remaining (all `[PLACEHOLDERS]` replaced)

---

## Phase 10: Client Handoff (2 hours)

### Pre-Handoff Preparation

1. **Set all workflows to Published** (change from Draft to Active)
2. **Set chatbot to Auto-Reply mode**
3. **Prepare handoff documentation**:
   - Login credentials for the GHL sub-account
   - Summary of what was built (reference this playbook)
   - Quick-reference guide for common tasks (adding contacts, checking pipelines, etc.)

### Client Training Session (1 hour)

Walk the client through:

1. **Dashboard Overview**: Where to find conversations, contacts, pipelines, appointments
2. **Appointment Management**: How bookings appear, how to mark no-shows, how to manually add appointments
3. **Pipeline Review**: What each pipeline means, what each stage represents
4. **Tag Management**: When to manually add tags (e.g., `review-left`, `new-patient`, `enquiry-no-booking`)
5. **Chatbot Monitoring**: How to view chatbot conversations, how to take over from the bot
6. **Email/SMS Monitoring**: Where to see sent messages, how to check for delivery issues
7. **Reporting**: How to view basic reports (appointments, reviews, workflow performance)
8. **Updating Content**: How to update opening hours, pricing, team info
9. **Support Channels**: How to reach Avantwerk support during hypercare

### Handoff Checklist

- [ ] GHL login credentials provided securely
- [ ] Client can log in and navigate the dashboard
- [ ] Client understands how to view and manage appointments
- [ ] Client knows how to add `new-patient` tag for new registrations
- [ ] Client knows how to add `review-left` tag when a review appears on Google
- [ ] Client knows how to mark no-shows (`appointment-no-show` tag)
- [ ] Client knows how to check chatbot conversations
- [ ] Client knows how to take over a chatbot conversation
- [ ] Client knows how to update opening hours and pricing
- [ ] Client has been introduced to hypercare support process
- [ ] Hypercare period start date confirmed: [HYPERCARE_START_DATE]
- [ ] Hypercare period end date confirmed: [HYPERCARE_END_DATE] (21 days later)

### Hypercare Period (21 Days)

During the 21-day hypercare period:

- **Week 1**: Daily monitoring of all workflows, chatbot conversations, and website performance. Fix any issues immediately.
- **Week 2**: Twice-daily checks. Review chatbot conversation logs for missed questions or poor responses. Adjust system prompt if needed.
- **Week 3**: Daily check. Review overall performance metrics. Final adjustments before handoff to standard support.

**Hypercare deliverables**:
- [ ] Week 1 review completed — any issues fixed
- [ ] Week 2 chatbot review completed — prompt refined if needed
- [ ] Week 3 final review completed
- [ ] Performance summary provided to client (appointments booked, reviews requested, nurture conversions, recall compliance)
- [ ] Transition to standard support confirmed

---

## Appendix: Client Information Template

Provide this form to the client during onboarding. All fields are required unless marked optional.

```
PRACTICE INFORMATION
--------------------
Business name:
Address line 1:
Address line 2 (optional):
City:
Postcode:
Main phone number:
Emergency phone number:
Email address:
Website URL:
Year established:

OPENING HOURS
-------------
Monday:
Tuesday:
Wednesday:
Thursday:
Friday:
Saturday:
Sunday:
Bank holidays:
Out-of-hours emergency instructions:

ONLINE PRESENCE
---------------
Google Maps URL:
Google Business Profile URL:
Google review direct URL:
Facebook page URL (optional):
Instagram handle (optional):

TEAM MEMBERS (provide for each)
-------------------------------
Name:
Role:
Qualifications:
Specialisms / notes:
Photo (attach):

SERVICES & PRICING
-------------------
(Provide price ranges for each treatment offered)

Check-up:
Hygiene:
Fillings:
Root canal:
Extractions:
Crowns:
Teeth whitening (in-surgery):
Teeth whitening (take-home):
Composite bonding:
Veneers:
Invisalign:
Fixed braces:
Dental implants (single):
Dentures (full):
Dentures (partial):
Emergency consultation:
Child check-up:

NHS INFORMATION (if applicable)
-------------------------------
NHS status (accepting/not accepting/mixed):
Current NHS Band 1 price:
Current NHS Band 2 price:
Current NHS Band 3 price:
Current NHS Urgent price:

PAYMENT & FINANCE
-----------------
Payment methods accepted:
Finance provider (if applicable):
Finance terms (e.g., 0% over 12 months):
Dental insurance plans accepted:
Practice membership plan details (if applicable):
Practice membership monthly price:

PATIENT INFORMATION
-------------------
Cancellation policy:
Missed appointment fee:
First appointment duration:
Parking information:
Accessibility information:
Sedation options offered:
Nervous patient options:
Children's extras (play area, stickers, etc.):

CHATBOT PREFERENCES
-------------------
Preferred chatbot name (e.g., "Ava"):
Preferred greeting message:
Additional languages spoken by staff (optional):
Complaints contact (name and role):
Treatment coordinator (name and role):

BRAND PREFERENCES (optional)
-----------------------------
Primary brand colour (hex code, or "use default blue"):
Logo file (attach):
Any specific brand guidelines:

CURRENT NEW PATIENT OFFER (for nurture emails)
------------------------------------------------
Offer description (e.g., "Free consultation for new patients" or "20% off your first check-up"):
```

---

## Appendix: Complete Placeholder Checklist

Before going live, verify every placeholder has been replaced. Check each box:

**Practice Details**:
- [ ] `[BUSINESS_NAME]`
- [ ] `[PHONE]`
- [ ] `[EMERGENCY_PHONE]`
- [ ] `[EMAIL]`
- [ ] `[ADDRESS]` / `[ADDRESS_LINE_1]` / `[ADDRESS_LINE_2]` / `[CITY]` / `[POSTCODE]`
- [ ] `[WEBSITE_URL]`
- [ ] `[BOOKING_URL]`
- [ ] `[GOOGLE_MAPS_URL]`
- [ ] `[GOOGLE_REVIEW_URL]`
- [ ] `[PARKING_INFO]`
- [ ] `[ACCESSIBILITY_INFO]`
- [ ] `[NHS_STATUS]`
- [ ] `[YEAR_ESTABLISHED]`
- [ ] `[RATING]`
- [ ] `[REVIEW_COUNT]`

**Opening Hours**:
- [ ] `[MON_HOURS]` through `[SUN_HOURS]`
- [ ] `[BANK_HOL_HOURS]`
- [ ] `[OUT_OF_HOURS_INFO]`

**Team**:
- [ ] `[DENTIST_1_NAME]` — `[ROLE]` — `[NOTES]`
- [ ] `[DENTIST_2_NAME]` — `[ROLE]` — `[NOTES]`
- [ ] `[HYGIENIST_NAME]` — `[ROLE]` — `[NOTES]`
- [ ] `[MANAGER_NAME]` — `[ROLE]` — `[NOTES]`
- [ ] `[AUTHOR_NAME]` (blog articles)

**Pricing** (all treatments):
- [ ] `[CHECKUP_PRICE]`
- [ ] `[HYGIENE_PRICE]`
- [ ] `[FILLING_PRICE]`
- [ ] `[ROOT_CANAL_PRICE]`
- [ ] `[EXTRACTION_PRICE]`
- [ ] `[WHITENING_SURGERY_PRICE]`
- [ ] `[WHITENING_HOME_PRICE]`
- [ ] `[BONDING_PRICE]`
- [ ] `[VENEER_PRICE]`
- [ ] `[INVISALIGN_PRICE]`
- [ ] `[BRACES_PRICE]`
- [ ] `[CROWN_PRICE]`
- [ ] `[IMPLANT_PRICE]`
- [ ] `[EMERGENCY_PRICE]`
- [ ] `[CHILD_CHECKUP_PRICE]`
- [ ] `[PLAN_PRICE]`

**NHS** (remove section if fully private):
- [ ] `[NHS_BAND1]`
- [ ] `[NHS_BAND2]`
- [ ] `[NHS_BAND3]`
- [ ] `[NHS_URGENT]`

**Chatbot**:
- [ ] `[BOT_NAME]`
- [ ] `[BOT_GREETING]`
- [ ] `[PRACTICE_TYPE]`
- [ ] `[LOCATION]`
- [ ] `[CANCELLATION_POLICY]`
- [ ] `[MISSED_APPT_FEE]`
- [ ] `[TREATMENT_COORDINATOR]`
- [ ] `[FINANCE_CONTACT]`
- [ ] `[COMPLAINTS_CONTACT]`
- [ ] `[INSURANCE_ANSWER]`
- [ ] `[FINANCE_ANSWER]`
- [ ] `[ADDITIONAL_LANGUAGES]`

**Review Page**:
- [ ] `[5_STAR_PERCENT]`
- [ ] `[4_STAR_PERCENT]`
- [ ] `[3_STAR_PERCENT]`
- [ ] `[2_STAR_PERCENT]`
- [ ] `[1_STAR_PERCENT]`

---

## Appendix: Time Estimate Summary

| Phase | Estimated Hours |
|-------|----------------|
| Phase 1: Sub-Account Setup | 0.75 |
| Phase 2: Custom Fields & Tags | 0.5 |
| Phase 3: Pipeline & Calendar Setup | 0.33 |
| Phase 4: Website — 13 Pages | 14–17 |
| Phase 5: Workflows — 6 Automations | 8–10 |
| Phase 6: Email/SMS Templates | 3–4 |
| Phase 7: AI Chatbot | 4–5 |
| Phase 8: Google Review Setup | 0.33 |
| Phase 9: Testing & QA | 3–4 |
| Phase 10: Client Handoff | 2 |
| **TOTAL** | **36.9–44.9 hours** |

Realistic delivery schedule across 30 days:
- **Days 1–3**: Phases 1–3 (setup, fields, pipelines)
- **Days 4–14**: Phase 4 (website build)
- **Days 15–21**: Phases 5–7 (workflows, emails, chatbot)
- **Days 22–24**: Phase 8 (Google review setup)
- **Days 25–28**: Phase 9 (testing and QA)
- **Days 29–30**: Phase 10 (client handoff)
- **Days 31–51**: Hypercare (21 days)

---

## Appendix: Workflow Summary Table

| # | Workflow | Trigger | Messages | Duration | Success Metric |
|---|---------|---------|----------|----------|----------------|
| 1 | Appointment Reminder | Appointment booked | 2 SMS + 2 Emails | Booking → Post-visit | < 8% no-show rate |
| 2 | Review Request | Tag: appointment-completed | 2 Emails | 5 days | 8–12 reviews/month |
| 3 | Recall Reminder (6-month) | 167 days after last check-up | 2 Emails + 1 SMS | ~5 weeks | 85% recall compliance |
| 4 | New Patient Welcome | Tag: new-patient | 2 Emails (or 1 SMS) | 48 hours | 90% first-appt attendance |
| 5 | New Patient Nurture | Tag: enquiry-no-booking | 3 Emails + 1 SMS | 14 days | 30% enquiry conversion |
| 6 | Cancellation Recovery | Appointment cancelled | 1 Email + 1 SMS + Waitlist SMS | 7 days | 25% rebooking rate |
