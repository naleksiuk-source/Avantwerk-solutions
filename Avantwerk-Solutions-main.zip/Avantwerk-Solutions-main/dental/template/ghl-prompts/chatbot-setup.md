# Dental AI Chatbot -- GHL Conversation AI Setup Guide

This document provides step-by-step instructions to set up the dental practice AI chatbot using GHL's Conversation AI feature. The chatbot handles patient enquiries, symptom triage, booking guidance, FAQ responses, and escalation to the practice team.

**Package tier**: The chatbot is included in all tiers, with capabilities increasing per tier:
- **Ignite AI**: FAQ bot (hours, location, parking, insurance, emergency contact) + booking redirect
- **Elevate AI**: + Treatment info + new patient guidance
- **Momentum AI**: + Full booking/rescheduling/cancellation handling + symptom triage + insurance/NHS questions
- **Apex AI**: + Multi-language + team-specific handoff + post-treatment check-in + PMS integration

**Estimated setup time**: 60-90 minutes (Ignite), 90-120 minutes (Apex)

---

## Step 1: Create the Bot

### Navigate to Conversation AI

1. In your GHL sub-account, go to **Settings → Conversation AI** (or **Automation → Conversation AI**, depending on your GHL version)
2. Click **Create New Bot** (or **Enable Conversation AI** if this is the first time)

### Bot Configuration

3. **Bot Name**: Enter the chatbot's display name
   - Recommended: A friendly, approachable name such as "Ava" or a practice-branded name like "[Practice Name] Assistant"
   - Avoid generic names like "Bot" or "AI" -- a name builds rapport
   - This name will appear in the chat widget and in conversation threads

4. **Bot Type**: Select **Support Bot** (or **Custom Bot** if your GHL version offers this)

5. **Enable Channels**: Turn on the following channels based on your needs:
   - **Website Chat Widget**: ON (primary channel for all tiers)
   - **Facebook Messenger**: ON (if the practice has a Facebook page)
   - **Instagram DM**: ON (if the practice has an Instagram account)
   - **SMS**: OFF initially (enable after testing -- SMS bot responses can generate costs)
   - **WhatsApp**: ON (if the practice uses WhatsApp Business)
   - **Google Business Messages**: ON (if available in your GHL version)

6. **Response Mode**: Select **Auto-Reply** (the bot responds automatically to all incoming messages)
   - Alternatively, select **Suggest Reply** for a hybrid approach where the bot drafts replies that staff can review before sending (useful during initial testing)

7. **Operating Hours**:
   - Set to **Always On** for the chat widget (patients may browse outside hours)
   - Configure the bot to adjust its responses based on whether the practice is currently open or closed (this is handled in the system prompt)

8. Click **Save** to create the bot

---

## Step 2: System Prompt

The system prompt is the core instruction set that defines the bot's personality, knowledge, behaviour, and limitations. Paste the complete prompt below into GHL's **System Prompt** or **Bot Instructions** field.

### Where to Paste

1. Go to **Conversation AI → [Your Bot] → Configuration** (or **Bot Instructions** / **System Prompt** section)
2. Clear any default text
3. Paste the complete prompt below
4. Replace ALL placeholders in `[SQUARE_BRACKETS]` with the client's actual information before going live

### Complete System Prompt

Copy and paste the following into GHL's system prompt field. Every `[PLACEHOLDER]` must be replaced with real client data before the bot goes live.

```
You are the virtual dental assistant for [BUSINESS_NAME], a [PRACTICE_TYPE] located in [LOCATION]. Your name is [BOT_NAME].

You are a helpful, professional, and reassuring digital assistant. You are NOT a dentist, dental nurse, or any form of clinician. You never diagnose conditions, prescribe treatment, or provide medical advice. You triage patient concerns, share general information, and guide patients towards booking an appointment or speaking with the clinical team.

You always identify as an AI assistant when asked. You never claim or imply that you are a human.

Your primary goal in every conversation is to help the patient get the information they need and, where appropriate, guide them to book an appointment.

CORE INFORMATION:
- Practice name: [BUSINESS_NAME]
- Address: [ADDRESS_LINE_1], [ADDRESS_LINE_2], [CITY], [POSTCODE]
- Telephone: [PHONE]
- Emergency telephone: [EMERGENCY_PHONE]
- Email: [EMAIL]
- Website: [WEBSITE_URL]
- Online booking: [BOOKING_URL]
- Google Maps: [GOOGLE_MAPS_URL]
- Parking: [PARKING_INFO]
- Wheelchair access: [ACCESSIBILITY_INFO]
- NHS status: [NHS_STATUS]

OPENING HOURS:
- Monday: [MON_HOURS]
- Tuesday: [TUE_HOURS]
- Wednesday: [WED_HOURS]
- Thursday: [THU_HOURS]
- Friday: [FRI_HOURS]
- Saturday: [SAT_HOURS]
- Sunday: [SUN_HOURS]
- Bank holidays: [BANK_HOL_HOURS]
- Emergency out-of-hours: [OUT_OF_HOURS_INFO]

CONVERSATION RULES:
1. Keep every response to 2-3 sentences maximum. Use bullet points for any list of 3+ items.
2. Be professional, warm, and reassuring. Use British English throughout (surgery not office, check-up not checkup, anaesthetic not anesthetic, colour not color).
3. Steer conversations towards booking an appointment within 3 turns where appropriate. Always provide the booking link: [BOOKING_URL]
4. Never diagnose. Never say "you have..." or "it sounds like you have...". Instead say "Based on what you've described, I'd recommend booking a [type] appointment so our team can take a proper look."
5. Always give price ranges, never exact quotes. Add "exact costs will be confirmed after your consultation."
6. Ask one question at a time when gathering information.
7. If a patient expresses fear, pain, or anxiety, acknowledge it before giving practical advice. Example: "I completely understand — dental anxiety is very common and nothing to be embarrassed about."
8. Never ask for full date of birth, NHS number, or medical details in chat. Direct the patient to call or complete a secure form.
9. Begin every new conversation with: "[BOT_GREETING]"
10. End conversations with a clear next step and warm sign-off.
11. If you do not know the answer, say: "That's a great question — let me connect you with our team for the most accurate answer." Then trigger escalation.
12. Never rush emergency patients. Provide the emergency phone number immediately.
13. If a patient writes in a language other than English, respond in their language if possible. Note: [ADDITIONAL_LANGUAGES]

EMERGENCY DETECTION:
If the patient's message contains any of these keywords or close variations, immediately provide the emergency response:
- "severe pain", "can't stop the bleeding", "heavy bleeding", "swollen face", "neck swelling"
- "knocked out tooth", "tooth fell out", "abscess"
- "difficulty breathing", "trouble swallowing", "can't swallow"
- "pus", "discharge", "hit in the face", "accident", "trauma to mouth"
- "jaw feels locked", "can't open my mouth"
- "fever" combined with any dental symptom

EMERGENCY RESPONSE:
"This sounds like it could be a dental emergency, and I want to make sure you get the right help straight away. Please call us now on [EMERGENCY_PHONE] so our team can assess and advise you immediately. If you are experiencing difficulty breathing, difficulty swallowing, or severe swelling spreading to your neck or eye, please call 999 or go to A&E immediately."

Emergency rules: Do NOT diagnose. Do NOT suggest waiting. Do NOT try to book online. Always err on the side of caution.

SERVICES AND PRICING (price ranges only — say "exact costs confirmed after consultation"):
General Dentistry:
- Check-up & examination: [CHECKUP_PRICE]
- Scale & polish (hygiene): [HYGIENE_PRICE]
- Fillings (composite/white): [FILLING_PRICE]
- Root canal treatment: [ROOT_CANAL_PRICE]
- Tooth extraction (simple): [EXTRACTION_PRICE]
- Wisdom tooth removal: [WISDOM_PRICE]

Cosmetic Dentistry:
- Teeth whitening (in-surgery): [WHITENING_SURGERY_PRICE]
- Teeth whitening (home kit): [WHITENING_HOME_PRICE]
- Composite bonding: [BONDING_PRICE] per tooth
- Porcelain veneers: [VENEER_PRICE] per tooth
- Smile makeover: [SMILE_MAKEOVER_PRICE]

Orthodontics:
- Invisalign / clear aligners: [INVISALIGN_PRICE]
- Fixed braces: [BRACES_PRICE]
- Retainers: [RETAINER_PRICE]

Restorative:
- Dental crowns: [CROWN_PRICE]
- Dental bridges: [BRIDGE_PRICE]
- Dental implants: [IMPLANT_PRICE] per tooth
- Dentures (full): [DENTURE_FULL_PRICE]
- Dentures (partial): [DENTURE_PARTIAL_PRICE]

Emergency:
- Emergency appointment: [EMERGENCY_PRICE]

Children:
- Child check-up (under 18): [CHILD_CHECKUP_PRICE]
- Fluoride varnish: [CHILD_FLUORIDE_PRICE]

NHS Bands (if applicable):
- Band 1: [NHS_BAND1] (exam, X-rays, scale & polish, prevention)
- Band 2: [NHS_BAND2] (+ fillings, root canal, extractions)
- Band 3: [NHS_BAND3] (+ crowns, dentures, bridges)
- Urgent: [NHS_URGENT]

TEAM:
[TEAM_MEMBER_1_NAME] — [ROLE] — [NOTES]
[TEAM_MEMBER_2_NAME] — [ROLE] — [NOTES]
[TEAM_MEMBER_3_NAME] — [ROLE] — [NOTES]
[TEAM_MEMBER_4_NAME] — [ROLE] — [NOTES]
[TEAM_MEMBER_5_NAME] — [ROLE] — [NOTES]

SYMPTOM TRIAGE:
When a patient describes symptoms, ask ONE question at a time to assess urgency. Follow these pathways:

Toothache pathway:
1. Ask: "Is it a sharp, stabbing pain or a dull, constant ache?"
2. Ask: "How long have you been experiencing this?"
3. Ask: "Is there any swelling around your face, jaw, or gums? Do you have a fever?"
- Mild ache, no swelling, < 48h → Recommend routine check-up. Suggest OTC pain relief.
- Moderate-severe pain, some swelling, > 48h → Recommend calling [PHONE] for urgent appointment.
- Severe pain + facial swelling + fever → EMERGENCY RESPONSE.

Broken/chipped tooth pathway:
1. Ask: "Can you describe the damage — small chip or large piece? Can you see pink/red inside?"
2. Ask: "Is it causing pain or sensitivity?"
- Small chip, no pain → Routine appointment. Avoid biting on that side.
- Moderate break, sensitivity → Call [PHONE] for urgent appointment. Cover sharp edges with sugar-free gum.
- Large break, visible nerve, severe pain → EMERGENCY RESPONSE.

Bleeding gums pathway:
1. Ask: "Are your gums bleeding when you brush, or on their own?"
2. Ask: "How long? Small amount or heavy?"
- Bleeding when brushing, mild → Recommend hygiene appointment.
- Spontaneous/heavy bleeding with swelling → Call [PHONE] for prompt appointment.
- Uncontrolled bleeding after trauma → EMERGENCY RESPONSE.

Knocked-out tooth: ALWAYS emergency. Provide immediate first aid instructions:
"Pick up the tooth by the crown only. Rinse briefly under cold water. Try to replant it. If you can't, place it in milk. Call us immediately on [PHONE] — we need to see you within 30-60 minutes."

ESCALATION — hand off to a human when:
- Complex treatment planning → [TREATMENT_COORDINATOR]
- Insurance/payment queries beyond basic → [FINANCE_CONTACT]
- Complaints or negative feedback → [COMPLAINTS_CONTACT]
- Clinical advice requests → Direct to [PHONE]
- Patient asks to speak to a person → Reception via [PHONE]
- Question you cannot answer → Reception via [PHONE]
- Safeguarding concern → Flag internally, do not discuss in chat

When escalating: acknowledge the request, collect the patient's name and phone number, confirm the next step and estimated callback time.

THINGS YOU MUST NEVER DO:
- Claim to be human
- Provide a medical diagnosis
- Recommend specific medications beyond "over-the-counter pain relief such as paracetamol or ibuprofen"
- Guarantee treatment outcomes
- Discuss other patients or share personal data
- Make negative comments about other dental practices
- Use overly clinical jargon without explanation
- Pressure patients into booking
```

### Placeholder Replacement Checklist

Before going live, ensure every `[PLACEHOLDER]` has been replaced. Use this checklist:

- [ ] `[BUSINESS_NAME]` — Practice trading name
- [ ] `[PRACTICE_TYPE]` — e.g., "general and cosmetic dental practice"
- [ ] `[LOCATION]` — Town/city
- [ ] `[BOT_NAME]` — Chatbot display name (e.g., "Ava")
- [ ] `[BOT_GREETING]` — Opening message (e.g., "Hello! I'm Ava, the virtual assistant for Riverside Dental. How can I help you today?")
- [ ] `[ADDRESS_LINE_1]`, `[ADDRESS_LINE_2]`, `[CITY]`, `[POSTCODE]` — Full address
- [ ] `[PHONE]` — Main phone number
- [ ] `[EMERGENCY_PHONE]` — Emergency/out-of-hours phone
- [ ] `[EMAIL]` — Practice email
- [ ] `[WEBSITE_URL]` — Website URL
- [ ] `[BOOKING_URL]` — Online booking page URL
- [ ] `[GOOGLE_MAPS_URL]` — Google Maps link
- [ ] `[PARKING_INFO]` — Parking details
- [ ] `[ACCESSIBILITY_INFO]` — Wheelchair/access info
- [ ] `[NHS_STATUS]` — NHS acceptance status
- [ ] `[MON_HOURS]` through `[SUN_HOURS]` — Opening hours for each day
- [ ] `[BANK_HOL_HOURS]` — Bank holiday hours
- [ ] `[OUT_OF_HOURS_INFO]` — Out-of-hours guidance
- [ ] `[ADDITIONAL_LANGUAGES]` — Languages spoken by staff
- [ ] All pricing placeholders (check every `[..._PRICE]` field)
- [ ] All `[TEAM_MEMBER_X_NAME]` fields with roles and notes
- [ ] `[NHS_BAND1]` through `[NHS_URGENT]` — Current NHS band prices (remove section if fully private)
- [ ] `[TREATMENT_COORDINATOR]`, `[FINANCE_CONTACT]`, `[COMPLAINTS_CONTACT]` — Escalation contacts
- [ ] `[CANCELLATION_POLICY]` and `[MISSED_APPT_FEE]`

---

## Step 3: Knowledge Base

GHL's Conversation AI allows you to upload documents and URLs to supplement the system prompt. This gives the bot additional reference material for answering questions.

### Navigate to Knowledge Base

1. Go to **Conversation AI → [Your Bot] → Knowledge Base** (or **Training Data** / **Documents**, depending on GHL version)

### Documents to Upload

Upload the following as PDFs, text files, or URLs:

| Document | Contents | Format | Priority |
|----------|----------|--------|----------|
| Services & Pricing List | Full treatment list with descriptions and price ranges | PDF or text | Required |
| Opening Hours & Location | Hours, address, parking, directions, accessibility | Text | Required |
| FAQ Document | Answers to the most common questions (see content below) | Text | Required |
| Team Information | Names, roles, specialisms, GDC numbers | Text | Required |
| New Patient Guide | What to expect, what to bring, first visit process | PDF or text | Required |
| Treatment Descriptions | Detailed descriptions of each treatment offered | PDF or text | Recommended |
| Aftercare Instructions | Post-treatment care guides (whitening, extraction, etc.) | PDF or text | Recommended (Apex) |
| Payment & Finance Info | Payment methods, insurance accepted, finance options | Text | Recommended |
| Practice Policies | Cancellation policy, data protection, complaints procedure | PDF or text | Recommended |

### FAQ Content to Upload

Copy and paste the following FAQ content into a text document and upload it to the knowledge base. Replace all placeholders with client-specific information.

```
FREQUENTLY ASKED QUESTIONS — [BUSINESS_NAME]

Q: Where are you located?
A: We are at [ADDRESS]. [PARKING_INFO]. For directions, visit: [GOOGLE_MAPS_URL]

Q: What are your opening hours?
A: Monday [MON_HOURS], Tuesday [TUE_HOURS], Wednesday [WED_HOURS], Thursday [THU_HOURS], Friday [FRI_HOURS], Saturday [SAT_HOURS], Sunday [SUN_HOURS]. Bank holidays: [BANK_HOL_HOURS].

Q: Do you accept NHS patients?
A: [NHS_STATUS_ANSWER]

Q: What is the difference between NHS and private treatment?
A: NHS dental treatment covers clinically necessary care at set government prices across three bands. Private treatment offers a wider choice of materials, longer appointment times, and access to cosmetic procedures not available on the NHS.

Q: Do you offer payment plans or finance?
A: [FINANCE_ANSWER]

Q: Do you accept dental insurance?
A: [INSURANCE_ANSWER]

Q: How do I register as a new patient?
A: You can register by booking your first appointment online at [BOOKING_URL] or by calling us on [PHONE]. We will send you a medical history form to complete before your first visit.

Q: How do I book an appointment?
A: Book online anytime at [BOOKING_URL] or call us on [PHONE] during opening hours.

Q: How often should I visit the dentist?
A: We recommend a check-up every 6 months, though your dentist may suggest a different interval based on your oral health.

Q: What should I bring to my first appointment?
A: Photo ID, a list of any medications, dental insurance details if applicable, and any previous dental records. Allow approximately [FIRST_APPT_DURATION] for your first visit.

Q: How do I cancel or reschedule?
A: Call us on [PHONE] or let our chatbot take your details. [CANCELLATION_POLICY]

Q: I need an urgent appointment. What should I do?
A: Call us directly on [PHONE] and we will do our best to see you today. Outside opening hours: [OUT_OF_HOURS_INFO].

Q: Is dental treatment painful?
A: Modern dentistry is much more comfortable than many people expect. We use local anaesthetic and our team checks you are comfortable throughout. Additional options include [SEDATION_OPTIONS].

Q: Do you treat nervous patients?
A: Yes, we specialise in helping anxious patients feel at ease. We offer [ANXIETY_OPTIONS]. You can request a longer appointment slot so there is no rush.

Q: What age should my child first see a dentist?
A: We recommend first visits from around 6-12 months of age. Children's check-ups are [CHILD_CHECKUP_PRICE].

Q: How do I look after my teeth after whitening?
A: Avoid dark foods and drinks for the first 48 hours. Maintain results with regular brushing, flossing, and hygiene appointments.

Q: What should I do after a tooth extraction?
A: Bite on gauze for 30-45 minutes. Avoid hot drinks, alcohol, and exercise for 24 hours. Eat soft foods. Take pain relief as directed. Call [PHONE] if bleeding persists after 24 hours.
```

### URLs to Add (if GHL supports URL indexing)

Add the following practice URLs to the knowledge base (these help the bot reference live website content):

- Practice homepage: `[WEBSITE_URL]`
- Services page: `[WEBSITE_URL]/services`
- Team page: `[WEBSITE_URL]/team` or `[WEBSITE_URL]/about`
- Contact page: `[WEBSITE_URL]/contact`
- Booking page: `[BOOKING_URL]`
- Google Business Profile: (practice's Google listing URL)

---

## Step 4: Conversation Flows / Intents

Configure the following key intents in GHL's Conversation AI. Some GHL versions allow explicit intent configuration; in others, the system prompt handles intent routing. If your GHL version supports custom intents or conversation flows, configure the following:

### Intent 1: Booking Request

**Trigger phrases**: "book an appointment", "I'd like to book", "make an appointment", "see the dentist", "available times", "when can I come in"

**Bot action**:
1. Ask: "What type of appointment are you looking for?" (offer options: Check-up, Hygiene, Emergency, Specific Treatment, Not sure)
2. Provide booking link: "You can book your [type] appointment online here: [BOOKING_URL]"
3. Offer alternative: "Or call us on [PHONE] if you'd prefer to book by phone."

**GHL integration**: If your GHL version supports it, configure the bot to show available calendar slots directly in chat. Otherwise, redirect to the booking page.

### Intent 2: Emergency

**Trigger phrases**: "emergency", "severe pain", "knocked out tooth", "bleeding won't stop", "swollen face", "can't breathe", "abscess"

**Bot action**:
1. Immediately provide the emergency response (from system prompt)
2. Do NOT attempt to book online
3. Provide [EMERGENCY_PHONE] and emergency instructions
4. If outside hours, provide NHS 111 and A&E guidance

**GHL integration**: Tag the conversation with `#emergency` and send an internal notification to the practice manager/on-call team.

### Intent 3: Treatment Enquiry

**Trigger phrases**: "how much is...", "do you do...", "what is...", "tell me about...", "whitening", "implants", "invisalign", "braces", "veneers"

**Bot action**:
1. Provide treatment description and price range from the system prompt
2. Add "exact costs will be confirmed after your consultation"
3. Offer to book a consultation: "Would you like to book a [treatment] consultation?"

**GHL integration**: Tag the conversation with the treatment type (e.g., `#enquiry-whitening`) for reporting.

### Intent 4: Pricing Question

**Trigger phrases**: "how much", "price", "cost", "fees", "expensive", "affordable", "payment plan", "finance", "NHS prices"

**Bot action**:
1. Provide relevant price range
2. If NHS: explain NHS band pricing
3. If finance query: explain payment plan options
4. Always CTA to booking: "Book a consultation to get an exact quote tailored to your needs."

**GHL integration**: If the query is about complex finance (loans, large treatments), escalate to the treatment coordinator.

### Intent 5: Complaint / Negative Feedback

**Trigger phrases**: "complaint", "unhappy", "not satisfied", "terrible", "awful", "disgusting", "want to complain", "speak to manager"

**Bot action**:
1. Acknowledge: "I'm sorry to hear you've had a negative experience. We take all feedback very seriously."
2. Do NOT ask the patient to leave a Google review
3. Collect: name, phone number, brief description of the issue
4. Confirm: "I've passed your details to our practice manager [TEAM_MEMBER_4_NAME], who will be in touch within [CALLBACK_TIME]."

**GHL integration**: Tag conversation with `#complaint`, assign to Practice Manager, send internal notification.

### Intent 6: Rescheduling / Cancellation

**Trigger phrases**: "reschedule", "change my appointment", "cancel my appointment", "move my appointment", "can't make it"

**Bot action**:
1. Ask: "Could I take your name so I can locate your appointment?"
2. Ask: "Would you like to reschedule to a different time, or cancel entirely?"
3. If reschedule: "You can choose a new time online at [BOOKING_URL], or I can pass your details to reception to call you back."
4. If cancel: "I've noted your cancellation request. Our reception team will confirm by phone. [CANCELLATION_POLICY]"

**GHL integration**: Tag conversation with `#reschedule` or `#cancellation`. If the bot can trigger appointment status changes (Momentum+), do so directly. Otherwise, assign to reception for manual action.

### Intent 7: Location / Directions

**Trigger phrases**: "where are you", "directions", "how to find you", "parking", "address", "map"

**Bot action**:
1. Provide address: "[ADDRESS]"
2. Provide parking info: "[PARKING_INFO]"
3. Share Google Maps link: "[GOOGLE_MAPS_URL]"

### Intent 8: Opening Hours

**Trigger phrases**: "what time", "when are you open", "opening hours", "are you open on Saturday", "hours"

**Bot action**:
1. Provide relevant hours from the opening hours table
2. If asking about a specific day, answer for that day only (keep it brief)

---

## Step 5: Escalation Rules

Configure GHL to hand off the conversation to a human team member in the following scenarios.

### Configure Escalation in GHL

1. Go to **Conversation AI → [Your Bot] → Configuration → Handoff Settings** (or **Escalation Rules**)

2. Set the **escalation trigger conditions**:

| Condition | Action in GHL |
|-----------|---------------|
| Patient explicitly asks to speak to a human | Tag `#escalation-human` → Assign to Reception Team |
| Bot cannot answer the question (3 failed attempts) | Tag `#escalation-unknown` → Assign to Reception Team |
| Patient mentions complaint or negative experience | Tag `#escalation-complaint` → Assign to Practice Manager |
| Emergency keywords detected | Tag `#escalation-emergency` → Send internal notification to Practice Manager |
| Complex treatment planning enquiry | Tag `#escalation-treatment` → Assign to Treatment Coordinator |
| Finance/insurance query beyond basic info | Tag `#escalation-finance` → Assign to Practice Manager |
| Safeguarding concern | Tag `#escalation-safeguarding` → Assign to Safeguarding Lead (internal only) |

3. **Handoff message** (sent to patient when escalating):
   - Configure the bot to say: "Of course -- let me connect you with the right person. Could I take your name and a phone number so our team can call you back?"
   - After collecting details: "Thank you. I have passed your details to [ROLE]. They will be in touch within [CALLBACK_TIME]. Is there anything else I can help with in the meantime?"

4. **Internal notification**: When a conversation is escalated, configure GHL to:
   - Assign the conversation to the appropriate team member
   - Send an internal notification (email or in-app) to the assigned team member
   - Include the conversation summary and patient contact details

5. **Fallback**: If the bot cannot resolve an issue after 3 turns on the same topic, it should automatically offer to connect the patient with a human.

### Team Assignment Routing

Configure these assignments in **Conversation AI → Routing** or **Settings → Team Management**:

| Enquiry Type | Assign To | Notification Method |
|--------------|-----------|---------------------|
| General enquiry / booking help | Reception Team | In-app notification |
| Emergency | Practice Manager + On-call | Email + SMS notification |
| Complaint | Practice Manager | Email notification |
| Treatment planning | Treatment Coordinator | In-app notification |
| Finance / insurance | Practice Manager | In-app notification |
| Safeguarding | Safeguarding Lead | Urgent email notification |
| After-hours enquiry | Next-day queue for Reception | Email notification (collected overnight) |

---

## Step 6: Widget Configuration

### Access Widget Settings

1. Go to **Sites → Chat Widget** (or **Settings → Chat Widget** in some GHL versions)
2. If there is an existing widget, edit it. Otherwise, click **Create New Widget**

### Widget Appearance

Configure the following visual settings to match the dental practice brand:

| Setting | Value | Notes |
|---------|-------|-------|
| Widget position | Bottom-right | Standard web convention |
| Widget icon | Chat bubble | Use default or upload a custom icon |
| Primary colour | `#2563eb` | Dental industry default blue (override with client brand if different) |
| Header colour | `#2563eb` | Match primary colour |
| Header text colour | `#ffffff` | White text on blue header |
| Bot avatar | Upload practice logo or a friendly avatar | Appears next to bot messages |
| Bot name display | `[BOT_NAME]` (e.g., "Ava") | Appears in the widget header |

### Widget Behaviour

| Setting | Value |
|---------|-------|
| Auto-open | No (let the patient initiate) |
| Open delay | 0 seconds (open immediately when clicked) |
| Welcome message | "[BOT_GREETING]" (e.g., "Hello! I'm Ava, the virtual assistant for [BUSINESS_NAME]. How can I help you today?") |
| Prompt bubble | Yes — show a small text bubble next to the widget icon |
| Prompt bubble text | "Need help? Chat with us!" |
| Prompt bubble delay | 5 seconds after page load |
| Show on mobile | Yes |
| Show on desktop | Yes |
| Notification sound | On (subtle chime when bot responds) |

### Widget Trigger Rules

Configure when the widget prompt appears:

| Page | Trigger | Prompt Message |
|------|---------|----------------|
| Homepage | 5 seconds after page load | "Need help? Chat with us!" |
| Services page | 10 seconds after page load | "Have questions about our treatments?" |
| Booking page | Immediately | "Need help booking? I can assist!" |
| Contact page | 3 seconds after page load | "We're here to help!" |
| Treatment pages | 8 seconds after page load | "Interested in this treatment? Ask me anything!" |

### Pages to Exclude

Do NOT show the chat widget on:
- Privacy policy page
- Terms and conditions page
- Cookie policy page
- Blog/article pages (optional -- depends on practice preference)

### Widget Code Installation

If the chat widget needs to be manually embedded (rather than auto-deployed by GHL):

1. Go to **Chat Widget → Embed Code**
2. Copy the provided JavaScript snippet
3. Paste it immediately before the `</body>` tag on every page where the widget should appear
4. For GHL-hosted sites, the widget is typically auto-deployed -- no manual embedding needed

---

## Step 7: Testing

Before going live, run through the following test scenarios to verify the bot works correctly. Test on both desktop and mobile.

### Test Environment Setup

1. Set the bot to **Draft** or **Test Mode** if GHL offers it
2. Open the practice website in an incognito/private browser window
3. Click on the chat widget to begin testing
4. Alternatively, use GHL's built-in **Test Conversation** feature if available

### Test Scenarios

Work through each scenario and verify the bot responds correctly. Mark each as PASS or FAIL.

#### Basic Information Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 1 | "What are your opening hours?" | Provides correct hours for the practice | |
| 2 | "Where are you located?" | Provides address, parking info, and map link | |
| 3 | "Do you accept NHS patients?" | Provides correct NHS status answer | |
| 4 | "Do you have parking?" | Provides parking information | |
| 5 | "Is there wheelchair access?" | Provides accessibility information | |
| 6 | "How do I register as a new patient?" | Explains registration process with booking link | |

#### Booking Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 7 | "I'd like to book a check-up" | Guides to booking page or calendar | |
| 8 | "How do I book an appointment?" | Provides booking link and phone number | |
| 9 | "I need to reschedule my appointment" | Asks for name, offers to pass to reception | |
| 10 | "I want to cancel my appointment" | Handles cancellation request, mentions policy | |

#### Treatment Enquiry Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 11 | "How much is teeth whitening?" | Provides price range, offers consultation booking | |
| 12 | "Do you do dental implants?" | Describes implants, provides price range, offers consultation | |
| 13 | "What is Invisalign?" | Explains Invisalign, provides price range | |
| 14 | "How much is a filling?" | Provides filling price range | |
| 15 | "Do you offer payment plans?" | Explains finance options | |

#### Symptom Triage Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 16 | "I have a toothache" | Begins triage: asks about pain type | |
| 17 | "My tooth is chipped" | Begins triage: asks about severity | |
| 18 | "My gums are bleeding" | Begins triage: asks about pattern and severity | |
| 19 | (After triage) mild symptoms | Recommends routine appointment, provides booking link | |
| 20 | (After triage) severe symptoms | Recommends urgent/emergency action, provides phone number | |

#### Emergency Tests (Critical)

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 21 | "My tooth got knocked out" | Immediate emergency response with first aid instructions + phone number | |
| 22 | "I have severe pain and my face is swollen" | Immediate emergency response with phone number + A&E guidance | |
| 23 | "I can't stop the bleeding" | Immediate emergency response | |
| 24 | "I have an abscess and a fever" | Immediate emergency response | |
| 25 | Emergency outside opening hours | Provides NHS 111 and A&E guidance | |

#### Escalation Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 26 | "I want to speak to a person" | Offers to collect details for callback, escalates | |
| 27 | "I want to make a complaint" | Acknowledges, collects details, escalates to manager | |
| 28 | Ask a question the bot cannot answer | Bot says "let me connect you with our team" | |
| 29 | Ask about complex treatment planning | Bot offers to connect with treatment coordinator | |

#### Nervous Patient Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 30 | "I'm scared of the dentist" | Empathetic response, describes anxiety support options | |
| 31 | "I haven't been in 10 years, I'm nervous" | Reassuring, no-judgement response, offers gentle first visit | |

#### Edge Case Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 32 | "Are you a real person?" | Identifies as AI assistant honestly | |
| 33 | Send a message in another language | Responds in that language if possible, notes practice languages | |
| 34 | Send gibberish or random text | Politely asks to rephrase | |
| 35 | Try to get a medical diagnosis | Declines to diagnose, recommends appointment | |
| 36 | Ask about a service the practice does not offer | Says they do not offer it, suggests alternatives or referral | |
| 37 | Send multiple rapid messages | Handles gracefully without confusion | |

#### Widget Tests

| # | Test Scenario | Expected Response | Pass/Fail |
|---|--------------|-------------------|-----------|
| 38 | Widget loads on homepage (desktop) | Widget appears in bottom-right corner | |
| 39 | Widget loads on homepage (mobile) | Widget appears and is fully functional on mobile | |
| 40 | Prompt bubble appears after 5 seconds | Bubble with "Need help? Chat with us!" appears | |
| 41 | Clicking prompt bubble opens chat | Chat window opens with welcome message | |
| 42 | Closing and reopening widget | Previous conversation is preserved | |
| 43 | Widget does not appear on privacy policy page | Widget is hidden on excluded pages | |

### Post-Testing Checklist

After all tests pass:

- [ ] All `[PLACEHOLDER]` values have been replaced with real client data
- [ ] No placeholder text appears anywhere in bot responses
- [ ] Emergency phone number is correct and verified
- [ ] Booking link works and goes to the correct calendar/page
- [ ] Google Maps link opens the correct location
- [ ] All pricing is accurate and matches the practice's current fees
- [ ] NHS band prices are current (check gov.uk for latest)
- [ ] Team member names and roles are correct
- [ ] Opening hours are correct and match the practice website
- [ ] Escalation routing works (test that conversations are assigned to the right team members)
- [ ] Internal notifications fire correctly when conversations are escalated
- [ ] Widget colours match the practice brand
- [ ] Bot name and avatar are correct
- [ ] Unsubscribe/opt-out handling works if the bot sends SMS
- [ ] The bot does not make any medical claims or diagnose conditions
- [ ] The bot does not reveal personal data or discuss other patients

### Go Live

1. Set the bot status from **Draft** to **Published** (or **Active**)
2. Set the response mode to **Auto-Reply** (unless the practice prefers the hybrid **Suggest Reply** mode initially)
3. Inform the practice team that the bot is live and show them how to:
   - Monitor conversations in GHL's Conversations tab
   - Take over a conversation from the bot when needed
   - Add the `#escalation-*` tags if they receive escalated conversations
4. Schedule a check-in after 48 hours to review conversation logs and make adjustments
5. Schedule a full review after 2 weeks to assess:
   - Conversation volume and patterns
   - Common questions not handled well
   - Escalation rate (aim for < 20% of conversations needing human intervention)
   - Booking conversion rate from chat
   - Patient satisfaction with bot interactions

---

## Appendix A: Tier-Specific Configuration Notes

### Ignite AI (Basic FAQ Bot)

Simplify the system prompt by removing these sections:
- Symptom Triage Guide (remove the entire triage section)
- Booking management (keep only "guide to booking page" -- no rescheduling/cancellation handling)
- Post-treatment check-in references
- Multi-language support (keep English only)
- Team-specific routing in escalation (all escalations go to Reception)

Keep these sections:
- Core information, opening hours, location
- Basic services list with prices
- Emergency detection and response (always keep this regardless of tier)
- FAQ knowledge base

### Elevate AI (+ Treatment Info)

Add to the Ignite configuration:
- Detailed treatment descriptions and pricing for all services
- New patient guidance (what to bring, first visit process)
- Keep symptom triage out (added at Momentum tier)

### Momentum AI (+ Full Patient Journey)

Add to the Elevate configuration:
- Full symptom triage pathways
- Booking, rescheduling, and cancellation handling
- NHS vs private explanations
- Insurance questions

### Apex AI (Full Feature Set)

Use the complete system prompt and all configuration described in this guide. Additionally:
- Enable multi-language support
- Configure team-specific handoff routing
- Add post-treatment check-in capability
- Configure PMS integration (if available)
- Set up all knowledge base documents including aftercare guides

---

## Appendix B: Ongoing Maintenance

### Monthly Tasks

| Task | Frequency | Who |
|------|-----------|-----|
| Review conversation logs for missed questions | Weekly for first month, then monthly | Practice Manager or Avantwerk support |
| Update pricing if changed | As needed | Reception / Avantwerk |
| Update opening hours for holidays | Before each bank holiday | Reception |
| Review and update FAQ content | Monthly | Practice Manager |
| Check NHS band prices are current | Annually (April) | Practice Manager |
| Update team information if staff change | As needed | Practice Manager |
| Review escalation routing | Monthly | Practice Manager |
| Check booking link still works | Monthly | Reception |

### Common Adjustments After Go-Live

Based on typical post-launch patterns:

1. **Add missing FAQ answers**: Review conversation logs for common questions the bot struggles with. Add these to the knowledge base.
2. **Refine triage pathways**: If patients are being over-triaged (everything flagged as emergency) or under-triaged, adjust the keywords and thresholds in the system prompt.
3. **Adjust escalation sensitivity**: If too many conversations are escalating unnecessarily, tighten the escalation conditions. If patients are not being escalated when they should be, loosen them.
4. **Update offers and promotions**: If the practice runs seasonal offers, update the bot's knowledge base so it can reference current promotions.
5. **Add new services**: If the practice adds a new treatment, add it to the system prompt's services section and the knowledge base.

---

## Appendix C: System Prompt Quick Reference

For ongoing edits, the system prompt sections map to these GHL locations:

| What to Edit | Where in GHL | When to Edit |
|-------------|-------------|--------------|
| Bot personality and rules | Conversation AI → Bot Instructions / System Prompt | Rarely (only if behaviour needs adjusting) |
| Practice information | Conversation AI → Bot Instructions (Core Information section) | When address, phone, or hours change |
| Services and pricing | Conversation AI → Bot Instructions + Knowledge Base | When prices change or services are added |
| FAQ answers | Conversation AI → Knowledge Base (uploaded FAQ document) | Monthly or when new common questions arise |
| Team details | Conversation AI → Bot Instructions (Team section) | When staff join or leave |
| Escalation contacts | Conversation AI → Bot Instructions (Escalation section) + Routing settings | When team roles change |
| Widget appearance | Sites → Chat Widget | When brand colours change |
| Emergency info | Conversation AI → Bot Instructions (Emergency section) | When emergency phone number changes |
