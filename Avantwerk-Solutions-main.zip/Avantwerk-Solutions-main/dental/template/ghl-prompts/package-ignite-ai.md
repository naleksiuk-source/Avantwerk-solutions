# Ignite AI -- Dental Practice (UK)

**Package price**: £1,999 (£1,699 with annual subscription)
**Delivery timeline**: 14 days
**Hypercare**: 7 days
**Total estimated build time**: 10 hours

| Phase | Deliverable | Time Estimate |
|-------|-------------|---------------|
| 1 | GHL Sub-Account Setup | 30 min |
| 2 | Custom Fields & Tags | 20 min |
| 3 | Pipeline Setup | 15 min |
| 4 | Website -- 3 Pages | 4-5 hours |
| 5 | Workflows -- 2 Automations | 2 hours |
| 6 | Email/SMS Templates -- 3 Templates | 45 min |
| 7 | AI Chatbot -- Basic | 45 min |
| 8 | Testing & QA | 1 hour |
| 9 | Client Handoff | 30 min |

---

## Pre-Setup Checklist

Complete every item below before opening GHL. Missing information will block the build.

### Client Information (Required)

Collect all of the following from the client before day one. Use the **Client Information Template** in the Appendix to send as a form or questionnaire.

- [ ] Business trading name (exactly as it should appear on the website)
- [ ] Full address (line 1, line 2, city, county, postcode)
- [ ] Main telephone number (format: 020 XXXX XXXX or 01234 567890)
- [ ] Emergency/out-of-hours telephone number
- [ ] Email address (for website display and reply-to on emails)
- [ ] Opening hours for every day of the week (including bank holidays)
- [ ] Out-of-hours emergency guidance text
- [ ] Practice type (e.g., "general and cosmetic dental practice", "NHS and private dental practice")
- [ ] NHS status (accepting NHS patients, private only, mixed)
- [ ] Year established
- [ ] Google review URL (direct link -- get from Google Business Profile > Share review form)
- [ ] Current Google rating and approximate review count
- [ ] Logo files (PNG or SVG, ideally both horizontal and square versions)
- [ ] Brand colours (if the practice has existing branding; otherwise use dental defaults)
- [ ] Photos (exterior, interior, team -- if available; otherwise use placeholders)
- [ ] Team members: for each person provide name, role, qualifications, and a one-line bio
- [ ] Services offered with private pricing (use the UK price ranges from INDUSTRY.md as defaults if the client cannot provide exact figures yet)
- [ ] Dental plan details (if they offer a membership plan -- name, monthly cost, what is included)
- [ ] Finance options (0% finance threshold, provider)
- [ ] Parking information
- [ ] Wheelchair/accessibility information
- [ ] GDC registration numbers for each dentist
- [ ] CQC registration status
- [ ] Social media URLs (Facebook, Instagram, etc.)
- [ ] Any specific USPs or awards to highlight
- [ ] Cancellation policy (fee amount, notice period)
- [ ] Google Maps embed link or Place ID

### Internal Pre-requisites

- [ ] Agency GHL account has available sub-account slot
- [ ] UK SMS sending number available (or ready to provision via Twilio/LC Phone)
- [ ] Email sending domain ready to verify (practice domain or agency domain)
- [ ] Dental industry snapshot template available (if using snapshot method)
- [ ] This playbook printed or open on second monitor during build

---

## Phase 1: GHL Sub-Account Setup (30 min)

### Step 1 -- Create the Sub-Account

1. Log into the **Agency dashboard** at `app.gohighlevel.com`
2. Navigate to **Settings > Sub-Accounts > Create Sub-Account**
3. Select **Start from Scratch** (or load from Dental UK snapshot if available)
4. Fill in:
   - **Company Name**: `[BUSINESS_NAME]`
   - **Industry**: Healthcare / Dental
   - **Timezone**: Europe/London (GMT/BST)
   - **Currency**: GBP (£)
   - **Address**: `[ADDRESS]`
   - **Phone**: `[PHONE]`
   - **Email**: `[EMAIL]`
   - **Website**: Leave blank for now (will be set after pages are built)

### Step 2 -- Configure General Settings

Switch into the new sub-account, then:

1. **Settings > Business Profile**
   - Upload logo
   - Confirm business name, address, phone, email
   - Set timezone to `Europe/London`

2. **Settings > Phone Numbers**
   - Provision or assign a UK number (local area code preferred)
   - Enable two-way SMS
   - Enable call tracking if included

3. **Settings > Email Services**
   - Add sending domain: `[CLIENT_DOMAIN]` (e.g., mail.brightsmile.co.uk)
   - Add DNS records (DKIM, SPF, DMARC) -- provide these to the client or their IT contact
   - Verify domain status (may take up to 48 hours -- proceed with other phases while waiting)
   - Set default "From" name: `[BUSINESS_NAME]`
   - Set default "Reply-to": `[EMAIL]`

4. **Settings > Calendars**
   - Create a new calendar: `[BUSINESS_NAME] Appointments`
   - Set availability to match the practice's opening hours
   - Configure appointment types (see Phase 4, Booking Page for the full list)
   - Set booking buffer: 15 minutes between appointments
   - Set maximum advance booking: 90 days
   - Enable confirmation requirement: Yes (triggers the Appointment Reminder workflow)
   - Appointment types to create:

   | Appointment Type | Duration | Colour |
   |-----------------|----------|--------|
   | New Patient Check-up | 45 min | Blue |
   | Returning Patient Check-up | 30 min | Blue |
   | Hygiene Appointment | 30 min | Cyan |
   | Emergency | 20 min | Red |
   | General Consultation | 30 min | Blue |

5. **Settings > Custom Values (Location-level)**
   - `google_review_link`: `[GOOGLE_REVIEW_URL]`
   - `booking_link`: `/booking` (will update to full URL after site is published)
   - `parking_info`: `[PARKING_INFO]`

### Step 3 -- User Access

1. **Settings > Team Management**
   - Add any client team members who need access during or after build
   - For Ignite AI, typically add the practice manager with **User** role
   - Do NOT give Agency Admin access to client users

---

## Phase 2: Custom Fields & Tags (20 min)

### Custom Fields

Navigate to **Settings > Custom Fields > Contact** and create:

| Field Name | Field Type | Purpose |
|------------|-----------|---------|
| `patient_type` | Dropdown: NHS, Private | Segment patients for communications |
| `last_checkup_date` | Date | Future use (recall workflows in higher tiers) |

Navigate to **Settings > Custom Fields > Location** and create (if not already present):

| Field Name | Field Type | Value |
|------------|-----------|-------|
| `google_review_link` | URL | `[GOOGLE_REVIEW_URL]` |
| `booking_link` | URL | `/booking` |
| `parking_info` | Multi Line Text | `[PARKING_INFO]` |

### Tags

Navigate to **Settings > Tags** and create all of the following:

**Appointment Reminder workflow:**
- `appointment-booked`
- `appointment-confirmed`
- `appointment-no-show`
- `appointment-completed`

**Review Request workflow:**
- `review-requested`
- `review-clicked`
- `review-left`
- `review-requested-complete`

**General:**
- `new-patient`
- `do-not-contact`

> **Note**: Tags can also be auto-created when workflows are built. Pre-creating them ensures consistent naming and avoids duplicates.

---

## Phase 3: Pipeline Setup (15 min)

Navigate to **CRM > Pipelines** and create the following pipelines.

### Pipeline 1: Patient Appointments

| Stage | Colour | Purpose |
|-------|--------|---------|
| Booked | Blue | Appointment booked, confirmation sent |
| Confirmed | Green | Patient replied YES to reminder SMS |
| Completed | Grey | Appointment attended, thank-you sent |
| No Show | Red | Patient did not attend |

### Pipeline 2: Patient Engagement

| Stage | Colour | Purpose |
|-------|--------|---------|
| Review Requested | Blue | First review request email sent |
| Review Clicked | Green | Patient clicked the Google review link |
| Review Sequence Complete | Grey | Sequence finished (clicked or exhausted) |

---

## Phase 4: Website -- 3 Pages (4-5 hours)

### Design System Reference

| Property | Value |
|----------|-------|
| Primary Blue | #2563eb |
| Primary Hover | #1d4ed8 |
| Secondary Cyan | #06b6d4 |
| Accent Green | #10b981 |
| Page Background | #f8fafc |
| Section Background | #ffffff |
| Card Background | #f1f5f9 |
| Card Hover | #e2e8f0 |
| Heading Text | #0f172a |
| Body Text | #475569 |
| Muted Text | #94a3b8 |
| Font | DM Sans (Google Fonts) |
| Border Radius (cards) | 16px |
| Border Radius (buttons) | 12px |
| Tone | Professional, warm, trustworthy, British English |

### Placeholder Reference

| Placeholder | Example |
|-------------|---------|
| `[BUSINESS_NAME]` | Bright Smile Dental |
| `[PHONE]` | 020 1234 5678 |
| `[EMERGENCY_PHONE]` | 07700 900123 |
| `[EMAIL]` | hello@brightsmile.co.uk |
| `[ADDRESS]` | 42 High Street, London, SW1A 1AA |
| `[BOOKING_URL]` | /booking |
| `[GOOGLE_REVIEW_URL]` | https://g.page/brightsmile/review |
| `[RATING]` | 4.9 |
| `[REVIEW_COUNT]` | 280 |
| `[YEAR_ESTABLISHED]` | 2012 |

### Header & Footer (Build Once, Shared Across All Pages)

#### Header / Navigation

Build the header natively in GHL's page builder (do NOT use custom code for navigation):

1. **Logo**: Place in the top-left. Upload the client's logo. If no logo is provided, use the business name in DM Sans 700 weight.
2. **Menu items** (left to right):
   - Home (`/`)
   - Services (`/services`)
   - Book Online (`/booking`)
3. **CTA Button** (right side of nav): "Book Now" -- primary blue (#2563eb), white text, links to `/booking`
4. **Mobile**: Hamburger menu with the same items. "Book Now" button always visible.
5. **Sticky header**: Enable so navigation stays visible on scroll.

#### Footer

Build the footer natively in GHL:

1. **Column 1 -- Practice Info**:
   - Logo or business name
   - `[ADDRESS]`
   - `[PHONE]`
   - `[EMAIL]`
2. **Column 2 -- Quick Links**:
   - Home
   - Services
   - Book Online
3. **Column 3 -- Opening Hours**:
   - Monday-Friday: [MON_FRI_HOURS]
   - Saturday: [SAT_HOURS]
   - Sunday: Closed
   - Emergency: [EMERGENCY_PHONE]
4. **Bottom bar**:
   - Copyright: "(c) [CURRENT_YEAR] [BUSINESS_NAME]. All rights reserved."
   - Links: Privacy Policy | Terms of Service
   - "Powered by Avantwerk" (small, muted text)
5. **Social icons**: Link to practice Facebook, Instagram, etc. (if provided)

---

### Page 1: Homepage

**GHL Page Type**: Website Page
**URL Slug**: `/` (root)
**Sections**: 8
**Estimated build time**: 1.5-2 hours

#### GHL AI Builder Prompt

Copy and paste the entire block below into GHL's AI website builder. Replace all `[PLACEHOLDERS]` with actual client values before generating.

> Build a homepage for a dental practice called [BUSINESS_NAME]. Use a clean, clinical, trustworthy design with a light theme. The primary colour is blue #2563eb, secondary is cyan #06b6d4, accent is green #10b981. Page background is #f8fafc, cards are #f1f5f9, headings are #0f172a, body text is #475569. Use the font DM Sans from Google Fonts. British English throughout. No emojis. All content below must appear on the page exactly as written.
>
> SECTION 1 -- HERO
> Full-width hero with a subtle gradient overlay on a dental surgery background image placeholder. Left-aligned text:
> - Small badge above headline: "Trusted by [REVIEW_COUNT]+ Patients"
> - Headline (H1): "Your Smile Deserves the Best Care"
> - Subheadline: "Welcome to [BUSINESS_NAME] -- your trusted local dental practice offering NHS and private treatments for the whole family. Gentle, professional care in a modern, relaxed setting."
> - Two buttons side by side: "Book Appointment" (primary blue #2563eb, links to /booking) and "Call Us: [PHONE]" (outlined style, links to tel:[PHONE])
> - Below buttons, a small trust line: "No registration fee. New patients welcome. Evening appointments available."
>
> SECTION 2 -- TRUST BAR
> A horizontal bar with a light blue tinted background (#eff6ff). Display four trust indicators in a row, each with a number and label:
> - "[RATING] Stars" with label "Google Rating"
> - "[REVIEW_COUNT]+" with label "Happy Patients"
> - "Est. [YEAR_ESTABLISHED]" with label "Years of Experience"
> - "GDC Registered" with label "Fully Accredited"
>
> SECTION 3 -- SERVICES OVERVIEW
> Section heading (H2): "Our Treatments"
> Subtext: "Comprehensive dental care for every member of your family, from routine check-ups to advanced cosmetic treatments."
> A grid of 8 service cards (4 columns on desktop, 2 on mobile). Each card has an icon area, service name, short description, and a "from" price. The cards:
> 1. General Check-up -- "Thorough examination, digital X-rays, and personalised treatment plan." From £50
> 2. Dental Hygiene -- "Professional scale and polish to keep your gums healthy and your smile fresh." From £55
> 3. Teeth Whitening -- "Professional whitening for a brighter, more confident smile. In-surgery and take-home options." From £300
> 4. Dental Implants -- "Permanent tooth replacement that looks, feels, and functions like natural teeth." From £2,000
> 5. Invisalign -- "Nearly invisible clear aligners to straighten your teeth without metal braces." From £2,500
> 6. Cosmetic Dentistry -- "Veneers, bonding, and smile makeovers to transform your appearance." From £200
> 7. Emergency Dental -- "Same-day emergency appointments for pain, swelling, or dental trauma." From £80
> 8. Children's Dentistry -- "Gentle, fun dental care to give your child a lifetime of healthy smiles." From £40
> Each card links to /services. Cards have a white background (#ffffff), subtle border, 16px border radius, and a hover shadow effect.
>
> SECTION 4 -- WHY CHOOSE US
> Section heading (H2): "Why Patients Choose [BUSINESS_NAME]"
> Four feature cards in a row (2 columns on mobile):
> 1. "Experienced Team" -- "Our dentists have over 50 combined years of experience and hold advanced qualifications in implantology, orthodontics, and cosmetic dentistry."
> 2. "Modern Technology" -- "Digital X-rays, intraoral scanners, and laser dentistry mean faster, more comfortable treatments with better results."
> 3. "Nervous Patients Welcome" -- "We specialise in gentle dentistry. Sedation options, a calm environment, and a patient-first approach to help you feel at ease."
> 4. "Flexible Payments" -- "0% finance available on treatments over £500. Spread the cost with affordable monthly payments that suit your budget."
>
> SECTION 5 -- MEET THE TEAM (PREVIEW)
> Section heading (H2): "Meet Your Dental Team"
> Subtext: "Skilled, caring professionals dedicated to your oral health."
> Show 4 team member cards in a row. Each card has a circular image placeholder, name, role, and a one-line bio:
> 1. "[DENTIST_1_NAME]" -- "Principal Dentist" -- "BDS, MJDF RCS -- Special interest in implants and cosmetic dentistry. [X] years in practice."
> 2. "[DENTIST_2_NAME]" -- "Associate Dentist" -- "BDS -- Passionate about preventive care and nervous patient management."
> 3. "[HYGIENIST_NAME]" -- "Dental Hygienist" -- "Dip DH -- Expert in gum health, deep cleaning, and stain removal."
> 4. "[MANAGER_NAME]" -- "Practice Manager" -- "Keeping everything running smoothly so your visit is always comfortable."
>
> SECTION 6 -- PATIENT REVIEWS
> Section heading (H2): "What Our Patients Say"
> Subtext: "Rated [RATING] out of 5 from [REVIEW_COUNT]+ Google reviews."
> Three review cards. Each card has a 5-star rating display, the review text in quotes, the reviewer's first name and initial, and the treatment type:
> 1. Stars: 5. "I was terrified of the dentist but the team at [BUSINESS_NAME] made me feel completely at ease. The check-up was painless and they explained everything clearly. I actually look forward to my appointments now." -- Sarah T., General Check-up
> 2. Stars: 5. "Had my teeth whitened here and the results are incredible. Four shades brighter in just one session. The staff were professional and friendly throughout. Could not recommend more highly." -- James R., Teeth Whitening
> 3. Stars: 5. "After years of hiding my smile, I finally got Invisalign at [BUSINESS_NAME]. The whole process was seamless from consultation to final result. My confidence has completely changed." -- Emma L., Invisalign
> A "Read All Reviews" link pointing to [GOOGLE_REVIEW_URL].
>
> SECTION 7 -- BOOKING CTA BANNER
> Full-width banner with a blue gradient background (#2563eb to #1d4ed8). White text:
> - Headline (H2): "Ready to Book Your Appointment?"
> - Subtext: "New patients welcome. No registration fee. Book online in under 60 seconds or call us directly."
> - Two white buttons: "Book Online" (links to /booking) and "Call [PHONE]" (links to tel:[PHONE])
>
> SECTION 8 -- LOCATION AND OPENING HOURS
> Two-column layout. Left column:
> - Heading (H3): "Find Us"
> - Address: [ADDRESS]
> - Phone: [PHONE]
> - Email: [EMAIL]
> - A map placeholder (Google Maps embed area)
> Right column:
> - Heading (H3): "Opening Hours"
> - Monday to Friday: 8:00 AM - 6:00 PM
> - Saturday: 9:00 AM - 2:00 PM
> - Sunday: Closed
> - "Emergency? Call [EMERGENCY_PHONE] for out-of-hours dental emergencies."
>
> Make the entire page mobile responsive. Use consistent spacing (60-80px between sections). All buttons have 14px 28px padding, 12px border radius, font-weight 600, and a subtle hover lift effect.

#### Manual Build Notes

If building in GHL's drag-and-drop editor instead of AI builder:

1. Add a new Website Page, set as homepage (slug: `/`).
2. Build the header/navigation natively in GHL (see Header & Footer section above).
3. Add 8 sections using a mix of native elements and Custom Code blocks:
   - Section 1 (Hero): Custom Code block. Full-width container with background image placeholder and gradient overlay.
   - Section 2 (Trust Bar): Custom Code block or native columns. Four columns with number/label.
   - Section 3 (Services Grid): Custom Code block. 8 cards in CSS grid (4 columns desktop, 2 mobile).
   - Section 4 (Why Choose Us): Custom Code block. 4 feature cards in a grid.
   - Section 5 (Team Preview): Custom Code block. 4 team cards with circular image placeholders.
   - Section 6 (Reviews): Custom Code block. 3 review cards with star ratings.
   - Section 7 (CTA Banner): Custom Code block. Full-width gradient banner.
   - Section 8 (Location): Native 2-column row. Left: text + native Google Maps embed. Right: text for hours.
4. Build the footer natively in GHL (see Header & Footer section above).

#### Native GHL Elements Needed

- **Header Navigation**: Logo, menu (Home, Services, Book Online), "Book Now" CTA button
- **Footer**: Practice info, quick links, opening hours, copyright, social icons
- **Google Maps Embed**: Native map element in the Location section
- **Chat Widget**: GHL Conversation AI widget (bottom-right corner, present on all pages)

---

### Page 2: Services

**GHL Page Type**: Website Page
**URL Slug**: `/services`
**Sections**: 5
**Estimated build time**: 1.5-2 hours

#### GHL AI Builder Prompt

> Build a services page for a dental practice called [BUSINESS_NAME]. Use a clean, clinical design with primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> A shorter hero section (not full height) with a light blue-tinted background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Services"
> - Headline (H1): "Our Dental Treatments"
> - Subheadline: "From routine check-ups to advanced restorative and cosmetic procedures, we offer a full range of dental treatments under one roof."
>
> SECTION 2 -- SERVICE CATEGORIES
> Display services grouped by category. Each category has a heading, and the treatments listed as cards with name, description, and starting price. Use a clean card grid layout within each category (3 columns desktop, 2 tablet, 1 mobile).
>
> Category 1 -- "General Dentistry"
> - Dental Check-up: "Comprehensive oral examination including digital X-rays, oral cancer screening, and a personalised treatment plan. Recommended every 6 months." From £50
> - Dental Hygiene: "Professional scale and polish by our qualified hygienist. Removes plaque and tartar buildup, helps prevent gum disease, and leaves your teeth feeling fresh." From £55
> - Fillings: "Tooth-coloured composite fillings that blend seamlessly with your natural teeth. We remove decay and restore your tooth to full function." From £80
> - Root Canal Treatment: "Save an infected tooth with modern root canal therapy. We use rotary instruments and digital imaging for precise, comfortable treatment." From £250
> - Extractions: "Simple and surgical tooth removal performed gently under local anaesthetic. We offer sedation for anxious patients." From £100
> - Crowns: "Custom-made porcelain crowns that protect damaged teeth and restore their natural appearance. Crafted to match your existing teeth perfectly." From £400
>
> Category 2 -- "Cosmetic Dentistry"
> - Teeth Whitening: "Professional whitening for a dramatically brighter smile. Choose in-surgery power whitening for instant results or custom take-home trays for gradual improvement." From £300
> - Composite Bonding: "Reshape and repair teeth with tooth-coloured composite resin. Fix chips, gaps, and uneven edges in a single appointment with no drilling required." From £200
> - Porcelain Veneers: "Ultra-thin porcelain shells bonded to the front of your teeth for a flawless, natural-looking smile. Custom-designed for your face shape." From £500
> - Smile Makeover: "A comprehensive treatment plan combining multiple cosmetic procedures to completely transform your smile. Includes digital smile design consultation." From £2,000
>
> Category 3 -- "Orthodontics"
> - Invisalign: "The world's leading clear aligner system. Straighten your teeth discreetly with custom-made, removable aligners. Suitable for mild to complex cases." From £2,500
> - Fixed Braces: "Traditional metal and ceramic braces for reliable, predictable tooth movement. Ideal for complex orthodontic cases that need precise control." From £2,000
>
> Category 4 -- "Dental Implants"
> - Single Tooth Implant: "Replace a missing tooth with a titanium implant and porcelain crown. Looks, feels, and functions exactly like your natural tooth." From £2,000
> - Implant-Supported Bridge: "Replace multiple missing teeth with an implant-retained bridge. Eliminates the need for a removable denture." From £4,000
>
> Category 5 -- "Emergency Dental Care"
> - Emergency Consultation: "Same-day appointments for dental pain, swelling, broken teeth, or trauma. Call us and we will see you as quickly as possible." From £80
> - Emergency Treatment: "Immediate treatment to relieve pain and stabilise your condition. Follow-up care planned as part of your ongoing treatment." From £100
>
> Category 6 -- "Children's Dentistry"
> - Children's Check-up: "A gentle, fun examination tailored for children. We make dental visits a positive experience from the very first appointment." From £40
> - Fissure Sealants: "A protective coating applied to the biting surfaces of back teeth. Prevents decay in the deep grooves where brushing cannot reach." From £30
> - Fluoride Treatments: "A quick, painless fluoride application to strengthen tooth enamel and protect against cavities. Recommended for children and teenagers." From £25
>
> SECTION 3 -- TREATMENT PROCESS
> Section heading (H2): "How Your Treatment Works"
> A horizontal 4-step timeline with connecting lines between steps:
> 1. "Consultation" -- "Book your appointment online or by phone. We will discuss your concerns, examine your teeth, and take any necessary X-rays."
> 2. "Treatment Plan" -- "Your dentist will explain all available options, expected outcomes, and costs. You will receive a written treatment plan to take home."
> 3. "Treatment" -- "We carry out your treatment using the latest techniques and technology. Your comfort is our priority at every stage."
> 4. "Aftercare" -- "We provide clear aftercare instructions and schedule any follow-up appointments. Our team is always available if you have questions."
>
> SECTION 4 -- PAYMENT OPTIONS
> Section heading (H2): "Affordable Payment Options"
> Three cards:
> 1. "Pay As You Go" -- "Pay for each treatment individually at the time of your appointment. We accept cash, card, and contactless payments."
> 2. "0% Finance" -- "Spread the cost of treatments over £500 with interest-free monthly payments. Subject to status. Apply at your consultation."
> 3. "Dental Plan" -- "Join our practice membership plan from £[PLAN_PRICE]/month. Includes two check-ups, two hygiene visits, 10% off all treatments, and worldwide dental emergency cover."
>
> SECTION 5 -- CTA
> Full-width blue gradient banner (#2563eb to #1d4ed8), white text:
> - Headline: "Not Sure Which Treatment You Need?"
> - Subtext: "Book a consultation and our team will guide you to the right solution. No obligation, no pressure."
> - Button: "Book a Consultation" linking to /booking
> - Text link: "Or call us on [PHONE]"
>
> Mobile responsive. Consistent spacing. Cards have 16px border radius, subtle shadow on hover.

#### Manual Build Notes

1. Add a new Website Page with slug `/services`.
2. Section 1 (Compact Hero): Custom Code block with light blue background, breadcrumb, H1, subheadline.
3. Section 2 (Service Categories): Custom Code block. Category headings (H3) with card grids beneath. CSS grid: 3 columns desktop, 2 tablet, 1 mobile.
4. Section 3 (Treatment Process): Custom Code block. Horizontal timeline with 4 numbered steps.
5. Section 4 (Payment Options): Custom Code block. 3 cards in a row.
6. Section 5 (CTA Banner): Custom Code block. Full-width gradient.

#### Native GHL Elements Needed

- **Header/Footer**: Shared across all pages (built once).
- **Chat Widget**: GHL Conversation AI (shared across all pages).

---

### Page 3: Book Online

**GHL Page Type**: Website Page
**URL Slug**: `/booking`
**Sections**: 3
**Estimated build time**: 45 min - 1 hour

#### GHL AI Builder Prompt

> Build a Booking page for a dental practice called [BUSINESS_NAME]. Clean design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Book Online"
> - Headline (H1): "Book Your Appointment"
> - Subheadline: "Choose a time that suits you and book online in under 60 seconds. New patients welcome -- no registration fee."
>
> SECTION 2 -- BOOKING CALENDAR
> Full-width section. Centre-aligned:
> - A prominent placeholder area for the native GHL calendar widget. Display text: "[GHL NATIVE CALENDAR -- Insert the booking calendar widget here.]"
>
> Below the calendar placeholder, three info cards in a row:
> 1. "New Patients" -- "Welcome to [BUSINESS_NAME]. Your first visit includes a comprehensive examination, digital X-rays, and a personalised treatment plan. Please arrive 10 minutes early to complete registration. Bring a form of ID and your medical history if available."
> 2. "Appointment Types" -- "Select the appointment type that matches your needs. If you are unsure, choose General Consultation and we will guide you from there. Urgent issues should be booked as Emergency."
> 3. "Cancellation Policy" -- "We kindly ask for at least 24 hours' notice if you need to cancel or reschedule. Late cancellations or missed appointments may incur a fee of £[CANCELLATION_FEE]. We understand that emergencies happen -- just let us know as soon as you can."
>
> SECTION 3 -- PREFER TO CALL
> A simple section with centre-aligned text:
> - Heading (H3): "Prefer to Book by Phone?"
> - Text: "Our reception team is happy to help. Call us on [PHONE] during opening hours (Mon-Fri 8am-6pm, Sat 9am-2pm)."
> - Text: "For dental emergencies outside these hours, call [EMERGENCY_PHONE]."
> - Two buttons: "Call [PHONE]" (primary blue, links to tel:[PHONE]) and "Send Us a Message" (outlined, links to mailto:[EMAIL])
>
> Mobile responsive.

#### Manual Build Notes

1. Add a new Website Page with slug `/booking`.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Calendar + Info): Add a **native GHL Calendar widget** as the main element. Configure appointment types with durations (see table below). Below the calendar, add a Custom Code block with 3 info cards.
4. Section 3 (Phone CTA): Custom Code block.

#### Native GHL Elements Needed

- **GHL Calendar Widget**: This is the primary content of this page. Configure the following appointment types:

| Appointment Type | Duration | Notes |
|-----------------|----------|-------|
| New Patient Check-up | 45 min | Longer slot for new registrations |
| Returning Patient Check-up | 30 min | Standard check-up |
| Hygiene Appointment | 30 min | Assign to hygienist calendar |
| Emergency | 20 min | Same-day priority |
| General Consultation | 30 min | Catch-all for unsure patients |

- Wire the calendar to:
  - GHL Calendar settings (availability matches practice hours)
  - Staff assignment (if multiple practitioners)
  - Appointment Reminder workflow (triggers on booking)
- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

#### Calendar Configuration Steps

1. Go to **Settings > Calendars > [BUSINESS_NAME] Appointments**
2. Set **Availability**:
   - Monday-Friday: [MON_FRI_HOURS] (e.g., 08:00 - 18:00)
   - Saturday: [SAT_HOURS] (e.g., 09:00 - 14:00)
   - Sunday: Unavailable
3. Set **Appointment Slot Settings**:
   - Slot duration: 30 minutes (default)
   - Buffer between appointments: 15 minutes
   - Minimum scheduling notice: 2 hours
   - Maximum advance booking: 90 days
4. **Form Fields** (booking form the patient fills in):
   - First Name (required)
   - Last Name (required)
   - Email (required)
   - Phone (required)
   - Appointment Type (dropdown -- required)
   - "Is this your first visit?" (Yes/No -- optional)
   - Notes / Reason for visit (text area -- optional)
5. **Confirmation Page**:
   - Message: "Thank you, [Name]! Your appointment has been booked. You will receive a confirmation email shortly."
   - Add "Add to Calendar" buttons (Google Calendar, Apple Calendar)
6. **Notifications**:
   - Enable email notification to the practice when a new booking is made
   - Patient confirmation is handled by the Appointment Reminder workflow

---

## Phase 5: Workflows -- 2 Automations (2 hours)

### Pre-requisites Check

Before building workflows, confirm:
- [ ] Pipelines created (Phase 3)
- [ ] Tags created (Phase 2)
- [ ] Custom fields created (Phase 2)
- [ ] SMS enabled with UK number
- [ ] Email domain verified (or at least pending)
- [ ] Calendar configured with appointment types
- [ ] Email/SMS templates built (Phase 6 -- build templates first, then wire into workflows)

> **Build order tip**: Build the email/SMS templates in Phase 6 first, then return here to build the workflows and wire in the templates. This avoids having to edit workflows after the fact.

---

### Workflow 1: Appointment Reminder

**Estimated build time**: 45-60 minutes
**Trigger**: Appointment booked via GHL calendar
**Sequence**: Confirmation email > 24h SMS reminder > 2h SMS reminder > Post-visit thank you email

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation > Workflows > Create New Workflow > Start from Scratch**
2. Name the workflow: **Appointment Reminder**
3. Set workflow status to **Draft** until testing is complete

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Appointment Status**
6. Trigger filter: Appointment Status = **Booked** (or "Confirmed" if your calendar uses that as the initial status)
7. Calendar: Select **All Calendars** (or the specific practice calendar)

**Step 1 -- Add Tag + Move Pipeline:**

8. Add action: **Add Tag** > `appointment-booked`
9. Add action: **Move Pipeline** > Pipeline: Patient Appointments > Stage: Booked

**Step 2 -- Send Confirmation Email (Immediate):**

10. Add action: **Send Email**
11. Name: "Appointment Confirmation Email"
12. Use the email content from **Template 1** in Phase 6
13. Set "From": `[BUSINESS_NAME]`
14. Set "Reply-to": `[EMAIL]`

**Step 3 -- Wait Until 24 Hours Before Appointment:**

15. Add action: **Wait**
16. Wait type: **Wait until specific date/time**
17. Date: **Appointment Start Date** minus 24 hours
18. Advanced Settings: tick **Send only during business hours** and set window to 08:00-20:00. If the send time falls outside this window, send at 09:00 the next morning.

**Step 4 -- Condition: Is Appointment Still Active?**

19. Add action: **If/Else Condition**
20. Condition: Contact **does NOT have tag** `appointment-cancelled`
21. AND Contact **does NOT have tag** `appointment-no-show`
22. **If cancelled/no-show**: Add action **Remove Tag** > `appointment-booked` > **End This Path**
23. **If still active**: Continue

**Step 5 -- Send 24-Hour Reminder SMS:**

24. Add action: **Send SMS**
25. Name: "24h Appointment Reminder SMS"
26. Use the SMS content from **Template 2** in Phase 6
27. Sending window: 08:00-20:00

**Step 6 -- Wait for Reply (4 hours):**

28. Add action: **Wait** > 4 hours
29. Add action: **If/Else Condition**
30. Branch 1 -- "Replied YES": Contact replied with keyword YES or CONFIRMED
    - Add action: **Add Tag** > `appointment-confirmed`
    - Add action: **Move Pipeline** > Stage: Confirmed
31. Branch 2 -- "Replied CANCEL/NO": Contact replied with keyword CANCEL or NO
    - Add action: **Add Tag** > `appointment-cancelled`
    - **End This Path**
32. Branch 3 -- "No Reply": Proceed to next step

**Step 7 -- Wait Until 2 Hours Before Appointment:**

33. Add action: **Wait**
34. Wait type: **Wait until specific date/time**
35. Date: **Appointment Start Date** minus 2 hours
36. If 2h-before falls outside 08:00-20:00, send at 19:00 the previous evening

**Step 8 -- Condition: Is Appointment Still Active?**

37. Add action: **If/Else Condition** (same logic as Step 4)
38. **If cancelled**: End path
39. **If active**: Continue

**Step 9 -- Send 2-Hour Reminder SMS:**

40. Add action: **Send SMS**
41. Name: "2h Appointment Reminder SMS"
42. Message content:
```
Hi {{contact.first_name}}, just a quick reminder -- your appointment is in 2 hours at {{appointment.start_time}}. See you soon at [BUSINESS_NAME], [ADDRESS].
```

**Step 10 -- Wait Until After Appointment:**

43. Add action: **Wait**
44. Wait type: **Wait until specific date/time**
45. Date: **Appointment End Date** plus 2 hours

**Step 11 -- Condition: Did Patient Attend?**

46. Add action: **If/Else Condition**
47. Condition: Contact **has tag** `appointment-no-show`
48. **If no-show**: End path (no thank-you email)
49. **If attended**: Continue

**Step 12 -- Send Post-Visit Thank You Email:**

50. Add action: **Send Email**
51. Name: "Post-Visit Thank You Email"
52. Subject: `Thank you for visiting [BUSINESS_NAME], {{contact.first_name}}`
53. Body:
```
Hi {{contact.first_name}},

Thank you for visiting us today at [BUSINESS_NAME]. We hope everything went well.

If you have any questions about your treatment or aftercare, please do not hesitate to contact us on [PHONE] or reply to this email.

A few helpful reminders:
- If you experienced any numbness from anaesthetic, avoid hot drinks and food until full feeling has returned.
- Brush gently around any treated areas for the first 24 hours.
- Take any recommended pain relief as directed.

We recommend scheduling your next check-up in 6 months to keep your oral health on track. You can book online anytime.

Thank you for choosing [BUSINESS_NAME].

Warm regards,
The team at [BUSINESS_NAME]
```
54. CTA Button: "Book Your Next Appointment" > link to `/booking`
55. Add action: **Add Tag** > `appointment-completed`
56. Add action: **Move Pipeline** > Stage: Completed

**Step 13 -- End Workflow**

#### Appointment Reminder -- Testing Checklist

- [ ] Trigger fires when a new appointment is booked via online booking
- [ ] Trigger fires when a new appointment is manually created by reception
- [ ] Confirmation email sends immediately with correct merge fields
- [ ] 24h wait calculates correctly based on appointment date
- [ ] 24h SMS sends within business hours (08:00-20:00)
- [ ] Reply YES/CONFIRMED is detected and adds `appointment-confirmed` tag
- [ ] Reply CANCEL/NO is detected and ends the path
- [ ] 2h SMS sends correctly with address details
- [ ] Post-visit thank-you email does NOT send to no-shows
- [ ] Post-visit thank-you email sends approximately 2h after appointment end
- [ ] Same-day appointment (< 24h away) handles gracefully (skips 24h wait, still sends 2h reminder)
- [ ] All merge fields render correctly (no blank `{{fields}}`)
- [ ] Pipeline stages update at each key step
- [ ] Workflow exits cleanly when appointment is cancelled mid-sequence

---

### Workflow 2: Review Request

**Estimated build time**: 30-40 minutes
**Trigger**: Tag `appointment-completed` added (by Workflow 1)
**Sequence**: Wait 24h > Review request email > Wait 3 days > Follow-up email (if no click)

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation > Workflows > Create New Workflow > Start from Scratch**
2. Name the workflow: **Review Request**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `appointment-completed`

**Step 1 -- Condition: Already Reviewed or Recently Requested?**

7. Add action: **If/Else Condition**
8. Condition: Contact **has tag** `review-left`
9. OR Contact **has tag** `review-requested` (if applied within last 90 days)
10. **If tagged**: End workflow
11. **If not tagged**: Continue

**Step 2 -- Condition: Has Marketing Consent?**

12. Add action: **If/Else Condition**
13. Condition: Contact **DND (Marketing Email)** = **OFF** (marketing email is allowed)
14. **If DND is ON**: End workflow
15. **If consent given**: Continue

**Step 3 -- Wait 24 Hours:**

16. Add action: **Wait**
17. Wait time: **24 hours**
18. Advanced: If the 24h mark falls outside business hours, defer to next day at 10:00 AM

**Step 4 -- Send Review Request Email:**

19. Add action: **Send Email**
20. Name: "Review Request Email"
21. Use the email content from **Template 3** in Phase 6
22. Add action: **Add Tag** > `review-requested`
23. Add action: **Move Pipeline** > Pipeline: Patient Engagement > Stage: Review Requested
24. Enable **Link Click Tracking** in the email settings

**Step 5 -- Wait 3 Days:**

25. Add action: **Wait**
26. Wait time: **3 days** (72 hours)

**Step 6 -- Condition: Did They Click the Review Link?**

27. Add action: **If/Else Condition**
28. Condition: **Link Clicked** in the Review Request Email (use GHL's email event trigger or link tracking)
29. **If clicked**:
    - Add action: **Add Tag** > `review-clicked`
    - Add action: **Move Pipeline** > Stage: Review Clicked
    - End workflow
30. **If not clicked**: Continue

**Step 7 -- Condition: Still Has Marketing Consent?**

31. Add action: **If/Else Condition**
32. Condition: DND (Marketing Email) = OFF
33. **If unsubscribed**: End workflow
34. **If still subscribed**: Continue

**Step 8 -- Send Follow-Up Review Request Email:**

35. Add action: **Send Email**
36. Name: "Review Request Follow-Up Email"
37. Subject: `We'd love to hear from you, {{contact.first_name}}`
38. Body:
```
Hi {{contact.first_name}},

We sent you a message a few days ago asking about your recent visit to [BUSINESS_NAME]. If you have a moment, we would truly value your feedback.

Leaving a Google review takes less than 60 seconds and helps us continue providing excellent care to our community.

[BUTTON: Share Your Experience]

No worries if you would rather not -- we are just grateful to have you as a patient.

Warm regards,
The team at [BUSINESS_NAME]
```
39. CTA Button: "Share Your Experience" > link to `[GOOGLE_REVIEW_URL]`
40. Footer: Must include unsubscribe link (marketing email)

**Step 9 -- Wait 48 Hours:**

41. Add action: **Wait**
42. Wait time: **48 hours**

**Step 10 -- Condition: Did They Click?**

43. Add action: **If/Else Condition**
44. Same check as Step 6 but against the follow-up email
45. **If clicked**: Add tag `review-clicked`, end workflow
46. **If not clicked**: Continue

**Step 11 -- Mark Sequence Complete:**

47. Add action: **Add Tag** > `review-requested-complete`
48. Add action: **Move Pipeline** > Stage: Review Sequence Complete
49. End workflow

#### Review Request -- Testing Checklist

- [ ] Workflow triggers when `appointment-completed` tag is added
- [ ] Workflow does NOT trigger for contacts with `review-left` tag
- [ ] Workflow does NOT trigger for contacts with DND enabled
- [ ] 24h wait sends at appropriate time (not at 3 AM)
- [ ] Review request email renders correctly with CTA button linking to Google review
- [ ] Link click tracking is active on the review button
- [ ] Follow-up email sends 3 days after first email if no click detected
- [ ] Workflow ends after follow-up if still no click
- [ ] Tags are applied correctly at each stage
- [ ] Pipeline stages update correctly
- [ ] Unsubscribe link works and prevents future marketing emails

---

## Phase 6: Email/SMS Templates -- 3 Templates (45 min)

Build these templates in **Marketing > Emails** (for emails) and directly within workflows (for SMS). Build them BEFORE wiring into the workflows in Phase 5.

### Template 1: Appointment Confirmation (Email)

**Type**: Transactional (not marketing -- no unsubscribe link required)
**Trigger**: Sent immediately when appointment is booked

**Build in GHL:**
1. Go to **Marketing > Emails > Create New**
2. Select a clean, single-column template
3. Set the brand colours: header accent #2563eb, button #2563eb, text #0f172a/#475569
4. Upload the practice logo to the header

**Subject line:**
```
Your appointment at [BUSINESS_NAME] is confirmed
```

**Email body:**
```
Hi {{contact.first_name}},

Your appointment has been confirmed. Here are the details:

Appointment: {{appointment.calendar_name}}
Date & Time: {{appointment.start_time}}
Location: [BUSINESS_NAME], [ADDRESS]

What to bring:
- Photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)

Need to reschedule or cancel? Please give us at least 24 hours' notice by calling [PHONE].

We look forward to seeing you.

Warm regards,
The team at [BUSINESS_NAME]
```

**CTA Button:**
- Text: "View on Map"
- Link: `[GOOGLE_MAPS_URL]`
- Style: Blue #2563eb background, white text, 12px border radius

**Design notes:**
- Clean, single-column layout
- Logo at top
- Appointment details in a light blue (#eff6ff) highlighted box
- "What to bring" as a bulleted list
- Footer: practice name, address, phone number (no unsubscribe -- this is transactional)

---

### Template 2: 24h Reminder (SMS)

**Type**: Transactional
**Character limit**: Keep under 160 characters per segment where possible

**SMS content:**
```
Hi {{contact.first_name}}, this is a reminder of your appointment at [BUSINESS_NAME] tomorrow at {{appointment.start_time}}. Reply YES to confirm or call us on [PHONE] to reschedule.
```

**Notes:**
- This SMS is configured directly in the Appointment Reminder workflow (Step 5 of Workflow 1)
- Two-way SMS must be enabled for YES/CANCEL reply detection
- Sending window: 08:00-20:00 only (configured in workflow advanced settings)
- Merge fields `{{contact.first_name}}` and `{{appointment.start_time}}` must resolve correctly

---

### Template 3: Review Request (Email)

**Type**: Marketing (must include unsubscribe link)
**Trigger**: Sent 24 hours after appointment is completed

**Build in GHL:**
1. Go to **Marketing > Emails > Create New**
2. Select a clean, single-column template
3. Brand colours: header accent #2563eb, button #10b981 (green -- stands out as a positive action), text #0f172a/#475569
4. Upload practice logo

**Subject line:**
```
How was your visit, {{contact.first_name}}?
```

**Email body:**
```
Hi {{contact.first_name}},

Thank you for visiting [BUSINESS_NAME] yesterday. We hope you had a positive experience with us.

We would really appreciate it if you could take 60 seconds to share your experience on Google. Your feedback helps other patients find a dental practice they can trust, and it means a lot to our team.

[BUTTON: Leave a Review]

It is quick and easy -- just click the button above and leave a star rating with a few words about your visit.

Thank you for your support.

Warm regards,
The team at [BUSINESS_NAME]
```

**CTA Button:**
- Text: "Leave a Review"
- Link: `[GOOGLE_REVIEW_URL]`
- Style: Green #10b981 background, white text, 12px border radius
- **Enable link click tracking** (essential for the review request workflow logic)

**Design notes:**
- Clean, single-column layout
- Friendly tone -- this is a request, not a demand
- Star icons or Google logo above the button for visual context (optional)
- Footer: practice name, address, phone, **unsubscribe link** (mandatory for marketing emails)

---

## Phase 7: AI Chatbot -- Basic (45 min)

The Ignite AI chatbot is a basic FAQ bot that handles opening hours, location, parking, insurance/NHS questions, emergency contact information, and redirects patients to the online booking page.

### Step 1 -- Create the Bot

1. Navigate to **Settings > Conversation AI** (or **Automation > Conversation AI**)
2. Click **Create New Bot**
3. **Bot Name**: `[BOT_NAME]` (recommended: a friendly name like "Ava" or "[BUSINESS_NAME] Assistant")
4. **Bot Type**: Support Bot
5. **Enable Channels**:
   - Website Chat Widget: ON
   - Facebook Messenger: ON (if applicable)
   - Instagram DM: ON (if applicable)
   - SMS: OFF (enable after testing)
6. **Response Mode**: Auto-Reply
7. **Operating Hours**: Always On (the bot adjusts responses based on practice hours -- see system prompt)

### Step 2 -- System Prompt

Paste the following into GHL's **System Prompt** / **Bot Instructions** field. Replace ALL `[PLACEHOLDERS]` with actual client data before going live.

```
You are the virtual dental assistant for [BUSINESS_NAME], a [PRACTICE_TYPE] located in [CITY]. Your name is [BOT_NAME].

You are a helpful, professional, and reassuring digital assistant. You are NOT a dentist, dental nurse, or any form of clinician. You never diagnose conditions, prescribe treatment, or provide medical advice. You guide patients towards booking an appointment or speaking with the clinical team.

You always identify as an AI assistant when asked. You never claim or imply that you are a human.

Your primary goal is to help the patient get the information they need and, where appropriate, guide them to book an appointment.

CORE INFORMATION:
- Practice name: [BUSINESS_NAME]
- Address: [ADDRESS]
- Telephone: [PHONE]
- Emergency telephone: [EMERGENCY_PHONE]
- Email: [EMAIL]
- Online booking: [BOOKING_URL]
- Google Maps: [GOOGLE_MAPS_URL]
- Parking: [PARKING_INFO]
- Wheelchair access: [ACCESSIBILITY_INFO]
- NHS status: [NHS_STATUS]

OPENING HOURS:
- Monday: [MON_HOURS]
- Tuesday: [TUE_HOURS]
- Wednesday: [WED_HOURS]
- Thursday: [THU_HOURS]
- Friday: [FRI_HOURS]
- Saturday: [SAT_HOURS]
- Sunday: Closed
- Bank holidays: [BANK_HOL_HOURS]
- Emergency out-of-hours: [OUT_OF_HOURS_INFO]

CONVERSATION RULES:
1. Keep every response to 2-3 sentences maximum. Use bullet points for any list of 3+ items.
2. Be professional, warm, and reassuring. Use British English throughout (surgery not office, check-up not checkup, anaesthetic not anesthetic).
3. Steer conversations towards booking an appointment within 3 turns where appropriate. Always provide the booking link: [BOOKING_URL]
4. Never diagnose. Never say "you have..." or "it sounds like you have...". Instead say "I would recommend booking an appointment so our team can take a proper look."
5. Give price ranges only, never exact quotes. Add "exact costs will be confirmed after your consultation."
6. Ask one question at a time when gathering information.
7. If a patient expresses fear or anxiety, acknowledge it first: "I completely understand -- dental anxiety is very common and nothing to be embarrassed about."
8. Never ask for date of birth, NHS number, or medical details in chat. Direct to phone or secure form.
9. Begin every new conversation with: "[BOT_GREETING]"
10. End conversations with a clear next step and warm sign-off.
11. If you do not know the answer, say: "That is a great question -- let me connect you with our team for the most accurate answer." Then trigger escalation.
12. Never rush emergency patients. Provide the emergency phone number immediately.

EMERGENCY DETECTION:
If the patient mentions severe pain, heavy bleeding, swollen face, knocked-out tooth, abscess, difficulty breathing, trouble swallowing, pus, trauma to the mouth, jaw locked, or fever with dental symptoms:

EMERGENCY RESPONSE:
"This sounds like it could be a dental emergency. Please call us now on [EMERGENCY_PHONE] so our team can help you immediately. If you are experiencing difficulty breathing, difficulty swallowing, or severe swelling spreading to your neck or eye, please call 999 or go to A&E."

FAQ KNOWLEDGE BASE:

Q: What are your opening hours?
A: We are open Monday to Friday [MON_FRI_HOURS] and Saturday [SAT_HOURS]. We are closed on Sundays. For emergencies outside these hours, call [EMERGENCY_PHONE].

Q: Where are you located?
A: We are at [ADDRESS]. [PARKING_INFO]. You can view us on Google Maps here: [GOOGLE_MAPS_URL]

Q: Do you accept NHS patients?
A: [NHS_STATUS]. For more details, please call us on [PHONE] or book a consultation at [BOOKING_URL].

Q: How do I book an appointment?
A: You can book online 24/7 at [BOOKING_URL], or call us on [PHONE] during opening hours. Our reception team will be happy to help.

Q: How much does a check-up cost?
A: A private check-up starts from £50. Exact costs will be confirmed after your consultation. You can book online at [BOOKING_URL].

Q: Do you treat nervous patients?
A: Absolutely. We specialise in gentle dentistry and our team is experienced in helping anxious patients feel comfortable. We offer sedation options for those who need extra support. Book a consultation and let us know about your concerns -- we will take great care of you.

Q: Do you offer payment plans?
A: Yes, we offer 0% finance on treatments over £500. We also have a dental membership plan. Call us on [PHONE] for details.

Q: What should I do in a dental emergency?
A: Call us immediately on [EMERGENCY_PHONE]. If outside hours, follow the instructions on our voicemail. For life-threatening emergencies (difficulty breathing, severe bleeding), call 999.

Q: Is there parking?
A: [PARKING_INFO]

Q: Is the practice wheelchair accessible?
A: [ACCESSIBILITY_INFO]

BOOKING REDIRECT:
For any question that leads to needing an appointment, end with:
"You can book online right now at [BOOKING_URL] -- it takes less than 60 seconds. Or call us on [PHONE] if you prefer to book by phone."

ESCALATION:
Transfer to a human when:
- Complex treatment planning questions
- Insurance or payment queries beyond basic info
- Complaints or negative feedback
- Patient explicitly asks to speak to a person
- Any question you cannot answer confidently
When escalating: collect the patient's name and phone number, confirm a team member will be in touch.

THINGS YOU MUST NEVER DO:
- Claim to be human
- Provide a medical diagnosis
- Recommend specific medications (beyond "over-the-counter pain relief such as paracetamol or ibuprofen")
- Guarantee treatment outcomes
- Discuss other patients
- Make negative comments about other dental practices
- Use overly clinical jargon without explanation
- Pressure patients into booking
```

### Step 3 -- Configure the Chat Widget

1. Go to **Settings > Chat Widget** (or **Sites > Chat Widget**)
2. **Widget colour**: `#2563eb` (primary blue)
3. **Widget position**: Bottom-right
4. **Widget greeting**: `"Hello! I'm [BOT_NAME], your virtual dental assistant. How can I help you today?"`
5. **Avatar**: Upload the practice logo or a friendly avatar image
6. **Show on**: All pages
7. **Collect info before chat**: OFF for Ignite AI (keep it frictionless; higher tiers can gate with name/email)
8. **Mobile behaviour**: Full-screen overlay on mobile devices

### Step 4 -- Knowledge Base (Optional Enhancement)

If your GHL version supports a knowledge base for Conversation AI:

1. Go to **Conversation AI > Knowledge Base**
2. Add the following items:
   - Practice opening hours
   - Full service list with price ranges
   - Parking and accessibility information
   - NHS band pricing (if applicable)
   - New patient registration process
   - Cancellation policy
   - Finance/payment options
3. Upload any existing practice FAQ pages or patient information leaflets as documents

### Chatbot -- Testing Checklist

- [ ] Bot responds to greeting ("Hello", "Hi there")
- [ ] Bot provides correct opening hours when asked
- [ ] Bot provides correct address and parking info
- [ ] Bot provides correct phone number for emergencies
- [ ] Bot redirects to booking URL when patient wants an appointment
- [ ] Bot handles NHS/private question correctly
- [ ] Bot detects emergency keywords and provides emergency response
- [ ] Bot does NOT attempt to diagnose when symptoms are described
- [ ] Bot escalates when asked to speak to a human
- [ ] Bot uses British English throughout
- [ ] Widget appears on all three pages (homepage, services, booking)
- [ ] Widget works correctly on mobile
- [ ] Bot greeting displays when widget is opened

---

## Phase 8: Testing & QA (1 hour)

### Pre-Launch Testing Protocol

Complete every item below before marking the build as ready for client review.

#### Website Testing

- [ ] **Homepage loads correctly** on desktop (Chrome, Firefox, Edge)
- [ ] **Homepage loads correctly** on mobile (test on a real device or Chrome DevTools)
- [ ] **Services page** loads with all service categories and correct prices
- [ ] **Booking page** loads with calendar widget visible and functional
- [ ] **Navigation** works: all menu links go to correct pages
- [ ] **Footer** displays on all pages with correct info
- [ ] **"Book Now" button** in header links to `/booking`
- [ ] **All phone links** (`tel:`) dial the correct number on mobile
- [ ] **All email links** (`mailto:`) open email client
- [ ] **Google Maps** loads in the Location section
- [ ] **All placeholders replaced**: search every page for `[` to catch unreplaced values
- [ ] **Images**: all placeholder images have been replaced with client images (or appropriate stock)
- [ ] **Logo** displays correctly in header and footer
- [ ] **British English**: no American spellings (check for "center", "color", "organize", "check-up" vs "checkup")
- [ ] **Mobile responsiveness**: check service cards stack, text is readable, buttons are tappable
- [ ] **Page load speed**: under 3 seconds on desktop

#### Workflow Testing

- [ ] **Book a test appointment** via the online calendar
- [ ] **Confirmation email arrives** within 60 seconds of booking
- [ ] **24h reminder SMS** sends at the correct time (fast-forward by adjusting appointment time for testing)
- [ ] **Reply YES** to the 24h SMS and verify `appointment-confirmed` tag is added
- [ ] **Reply CANCEL** to the 24h SMS and verify workflow ends
- [ ] **2h reminder SMS** sends at the correct time
- [ ] **Post-visit thank-you email** sends ~2h after appointment end
- [ ] **Mark a contact as no-show** (add `appointment-no-show` tag) and verify thank-you does NOT send
- [ ] **Review request email** arrives 24h after `appointment-completed` tag
- [ ] **Click the review link** in the email and verify `review-clicked` tag is added
- [ ] **Do not click** the review link and verify the follow-up email arrives 3 days later
- [ ] **All merge fields** render correctly (no `{{blank}}` values)
- [ ] **Pipeline stages** update correctly throughout both workflows
- [ ] **DND test**: add DND to a contact and verify review request does NOT send

#### Chatbot Testing

- [ ] Open the chat widget on the homepage
- [ ] Ask: "What are your opening hours?" -- verify correct response
- [ ] Ask: "Where are you located?" -- verify address and parking info
- [ ] Ask: "I want to book an appointment" -- verify booking URL is provided
- [ ] Ask: "I have severe tooth pain and my face is swollen" -- verify emergency response
- [ ] Ask: "How much is teeth whitening?" -- verify price range (not exact quote)
- [ ] Ask: "Can I speak to someone?" -- verify escalation response
- [ ] Ask: "Are you a real person?" -- verify AI disclosure

#### Final Checks

- [ ] **GHL domain/URL** is set (either GHL subdomain or client's custom domain with DNS configured)
- [ ] **SSL certificate** is active (HTTPS)
- [ ] **Google Analytics / tracking** installed (if client requires)
- [ ] **Favicon** uploaded (practice logo)
- [ ] **Page titles and meta descriptions** set for SEO:
  - Homepage: `[BUSINESS_NAME] | Trusted Dental Care in [CITY]`
  - Services: `Dental Treatments & Pricing | [BUSINESS_NAME]`
  - Booking: `Book Your Dental Appointment Online | [BUSINESS_NAME]`

---

## Phase 9: Client Handoff (30 min)

### What to Show the Client

Schedule a 30-minute video call (or screen-share) to walk the client through:

1. **Website tour** (5 min)
   - Show all 3 pages on desktop and mobile
   - Demonstrate the booking flow end-to-end
   - Show the chat widget in action

2. **Appointment workflow demo** (5 min)
   - Show a test booking flowing through: confirmation email > 24h SMS > 2h SMS > thank-you email
   - Explain what happens when a patient replies YES/CANCEL
   - Show the pipeline view with appointment stages

3. **Review request demo** (3 min)
   - Show the review request email that goes out after appointments
   - Explain the 3-day follow-up logic
   - Show the Google review link

4. **Chatbot demo** (3 min)
   - Ask the bot a few questions live
   - Show emergency detection in action
   - Explain when it escalates to the team

5. **GHL dashboard orientation** (10 min)
   - How to view incoming appointments in the calendar
   - How to view contacts and their tags/pipeline stages
   - How to check workflow execution (Automation > Workflow > Execution Logs)
   - How to mark a patient as a no-show (add `appointment-no-show` tag)
   - How to mark a review as received (add `review-left` tag)
   - Where to find email/SMS delivery reports

6. **What is NOT included** (2 min)
   - Recall reminders (Elevate AI and above)
   - New patient welcome sequence (Elevate AI and above)
   - Lead nurture workflows (Momentum AI and above)
   - Treatment pages and blog (Momentum AI and above)
   - Explain upgrade path and pricing

7. **Hypercare period** (2 min)
   - 7 days of support starting from handoff date
   - Response time: within 4 business hours
   - Covers bug fixes, content corrections, and minor adjustments
   - Does NOT cover new features or scope changes

### Documentation to Provide

Send the client the following after the handoff call:

1. **Login credentials** for their GHL sub-account (or invite link)
2. **Quick reference card** (one page):
   - How to view appointments
   - How to mark no-shows
   - How to check workflow logs
   - Support contact for hypercare period
3. **Placeholder summary**: any remaining `[PLACEHOLDER]` values that still need real data (e.g., if team photos were not available at launch)
4. **DNS instructions** (if using a custom domain and records have not yet been set)

### Post-Handoff Checklist

- [ ] Client has logged into GHL successfully
- [ ] Client can view the calendar and appointments
- [ ] Client knows how to mark no-shows and review completions
- [ ] Email domain DNS is fully verified (check if it was pending during build)
- [ ] Hypercare start date recorded: `[HANDOFF_DATE]`
- [ ] Hypercare end date: `[HANDOFF_DATE + 7 days]`
- [ ] Set a reminder for day 3 and day 7 of hypercare to check in proactively
- [ ] Record any pending items (e.g., waiting for team photos, waiting for DNS propagation)

---

## Appendix: Client Information Template

Send this to the client before starting the build. All fields marked with * are required before work can begin.

---

**Avantwerk -- Client Information Form**
**Package: Ignite AI -- Dental Practice**

### Practice Details

| Field | Your Answer |
|-------|-------------|
| Practice name * | |
| Address line 1 * | |
| Address line 2 | |
| City * | |
| County | |
| Postcode * | |
| Main telephone * | |
| Emergency/out-of-hours telephone * | |
| Email address * | |
| Website domain (if you have one) | |
| Year established | |
| Practice type * (e.g., "general and cosmetic", "NHS and private") | |
| NHS status * (accepting NHS patients / private only / mixed) | |

### Opening Hours *

| Day | Open | Close |
|-----|------|-------|
| Monday | | |
| Tuesday | | |
| Wednesday | | |
| Thursday | | |
| Friday | | |
| Saturday | | |
| Sunday | Closed | Closed |
| Bank holidays | | |
| Out-of-hours emergency guidance | | |

### Team Members *

For each team member, provide:

| Name | Role | Qualifications | One-line bio (optional) |
|------|------|---------------|------------------------|
| | | | |
| | | | |
| | | | |
| | | | |

### Services & Pricing *

Please confirm your private pricing for each service you offer. Leave blank for services you do not provide.

| Service | Your Price (from) |
|---------|-------------------|
| Check-up & examination | |
| Dental hygiene (scale & polish) | |
| Fillings (composite) | |
| Root canal treatment | |
| Extractions (simple) | |
| Crowns | |
| Teeth whitening | |
| Composite bonding (per tooth) | |
| Porcelain veneers (per tooth) | |
| Invisalign / clear aligners | |
| Fixed braces | |
| Dental implants (per tooth) | |
| Emergency appointment | |
| Children's check-up | |
| Fissure sealants | |
| Fluoride treatment | |

**NHS Bands (if applicable):**
| Band | Price |
|------|-------|
| Band 1 | |
| Band 2 | |
| Band 3 | |
| Urgent | |

### Dental Plan (if you offer one)

| Field | Your Answer |
|-------|-------------|
| Plan name | |
| Monthly cost | |
| What is included | |

### Finance Options

| Field | Your Answer |
|-------|-------------|
| Do you offer 0% finance? | Yes / No |
| Minimum treatment value for finance | |
| Finance provider | |

### Brand & Visual

| Field | Your Answer |
|-------|-------------|
| Logo files (please attach PNG/SVG) * | |
| Brand colours (hex codes, if you have them) | |
| Photos of the practice (exterior, interior, team) | |
| Any specific images or visuals you want on the website | |

### Online Presence

| Field | Your Answer |
|-------|-------------|
| Google Business Profile URL * | |
| Google review URL (direct link) * | |
| Current Google rating | |
| Approximate number of Google reviews | |
| Facebook page URL | |
| Instagram URL | |
| Other social media | |

### Practice Information

| Field | Your Answer |
|-------|-------------|
| Parking information * | |
| Wheelchair / accessibility information * | |
| GDC registration numbers (per dentist) | |
| CQC registration status | |
| Any awards or accreditations to highlight | |
| Cancellation policy (fee amount, notice period) * | |
| Any specific USPs or things that make your practice unique | |

### Chatbot

| Field | Your Answer |
|-------|-------------|
| Preferred chatbot name (e.g., "Ava", or "[Practice] Assistant") | |
| Languages spoken by staff (other than English) | |
| Any specific FAQs patients commonly ask | |

---

**Please return this form within 3 business days so we can begin your build on schedule.**

Your Ignite AI package delivery timeline is 14 days from the date we receive all required information.

Questions? Contact us at [ACCOUNT_MANAGER_EMAIL] or [ACCOUNT_MANAGER_PHONE].
