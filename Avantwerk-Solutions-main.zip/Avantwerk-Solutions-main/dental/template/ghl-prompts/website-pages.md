# GHL Prompt Playbook — Dental Practice Website

**Industry**: Dental Practice (UK Market)
**Package Tier**: Apex AI (all 16 pages)
**Deployment**: GoHighLevel Website Builder
**Last Updated**: 2026-02-11

## How to Use This Playbook

Each page below contains:
1. **GHL AI Builder Prompt** — Copy-paste the entire quoted block into GHL's AI website builder to generate the page automatically.
2. **Manual Build Notes** — Step-by-step instructions if building in GHL's drag-and-drop editor instead.
3. **Native GHL Elements Needed** — Forms, calendars, popups, and widgets that must be added as native GHL elements (not custom code) so they wire into automations and pipelines.

## Placeholder Reference

All prompts use these placeholders. Replace with client values during deployment:

| Placeholder | Example Value |
|-------------|---------------|
| `[BUSINESS_NAME]` | Bright Smile Dental |
| `[PHONE]` | 020 1234 5678 |
| `[EMERGENCY_PHONE]` | 07700 900123 |
| `[EMAIL]` | hello@brightsmile.co.uk |
| `[ADDRESS]` | 42 High Street, London, SW1A 1AA |
| `[BOOKING_URL]` | /booking |
| `[GOOGLE_REVIEW_URL]` | https://g.page/brightsmile/review |
| `[RATING]` | 4.9 |
| `[REVIEW_COUNT]` | 280 |
| `[YEAR_ESTABLISHED]` | 2012 |

## Design System

| Property | Value |
|----------|-------|
| Primary Blue | #2563eb |
| Primary Hover | #1d4ed8 |
| Secondary Cyan | #06b6d4 |
| Accent Green | #10b981 |
| Page Background | #f8fafc |
| Section Background | #ffffff |
| Card Background | #f1f5f9 |
| Card Hover | #e2e8f0 |
| Heading Text | #0f172a |
| Body Text | #475569 |
| Muted Text | #94a3b8 |
| Font | DM Sans (Google Fonts) |
| Border Radius (cards) | 16px |
| Border Radius (buttons) | 12px |
| Tone | Professional, warm, trustworthy, British English |

---

## Page 1: Homepage
**GHL Page Type**: Website Page
**URL Slug**: / (root)
**Sections**: 8

### GHL AI Builder Prompt

> Build a homepage for a dental practice called [BUSINESS_NAME]. Use a clean, clinical, trustworthy design with a light theme. The primary colour is blue #2563eb, secondary is cyan #06b6d4, accent is green #10b981. Page background is #f8fafc, cards are #f1f5f9, headings are #0f172a, body text is #475569. Use the font DM Sans from Google Fonts. British English throughout. No emojis. All content below must appear on the page exactly as written.
>
> SECTION 1 — HERO
> Full-width hero with a subtle gradient overlay on a dental surgery background image placeholder. Left-aligned text:
> - Small badge above headline: "Trusted by [REVIEW_COUNT]+ Patients"
> - Headline (H1): "Your Smile Deserves the Best Care"
> - Subheadline: "Welcome to [BUSINESS_NAME] — your trusted local dental practice offering NHS and private treatments for the whole family. Gentle, professional care in a modern, relaxed setting."
> - Two buttons side by side: "Book Appointment" (primary blue #2563eb, links to [BOOKING_URL]) and "Call Us: [PHONE]" (outlined style, links to tel:[PHONE])
> - Below buttons, a small trust line: "No registration fee. New patients welcome. Evening appointments available."
>
> SECTION 2 — TRUST BAR
> A horizontal bar with a light blue tinted background (#eff6ff). Display four trust indicators in a row, each with a number and label:
> - "[RATING] Stars" with label "Google Rating"
> - "[REVIEW_COUNT]+" with label "Happy Patients"
> - "Est. [YEAR_ESTABLISHED]" with label "Years of Experience"
> - "GDC Registered" with label "Fully Accredited"
>
> SECTION 3 — SERVICES OVERVIEW
> Section heading (H2): "Our Treatments"
> Subtext: "Comprehensive dental care for every member of your family, from routine check-ups to advanced cosmetic treatments."
> A grid of 8 service cards (4 columns on desktop, 2 on mobile). Each card has an icon area, service name, short description, and a "from" price. The cards:
> 1. General Check-up — "Thorough examination, digital X-rays, and personalised treatment plan." From £50
> 2. Dental Hygiene — "Professional scale and polish to keep your gums healthy and your smile fresh." From £55
> 3. Teeth Whitening — "Professional whitening for a brighter, more confident smile. In-surgery and take-home options." From £300
> 4. Dental Implants — "Permanent tooth replacement that looks, feels, and functions like natural teeth." From £2,000
> 5. Invisalign — "Nearly invisible clear aligners to straighten your teeth without metal braces." From £2,500
> 6. Cosmetic Dentistry — "Veneers, bonding, and smile makeovers to transform your appearance." From £200
> 7. Emergency Dental — "Same-day emergency appointments for pain, swelling, or dental trauma." From £80
> 8. Children's Dentistry — "Gentle, fun dental care to give your child a lifetime of healthy smiles." From £40
> Each card links to the relevant service page. Cards have a white background (#ffffff), subtle border, 16px border radius, and a hover shadow effect.
>
> SECTION 4 — WHY CHOOSE US
> Section heading (H2): "Why Patients Choose [BUSINESS_NAME]"
> Four feature cards in a row (2 columns on mobile):
> 1. "Experienced Team" — "Our dentists have over 50 combined years of experience and hold advanced qualifications in implantology, orthodontics, and cosmetic dentistry."
> 2. "Modern Technology" — "Digital X-rays, intraoral scanners, and laser dentistry mean faster, more comfortable treatments with better results."
> 3. "Nervous Patients Welcome" — "We specialise in gentle dentistry. Sedation options, a calm environment, and a patient-first approach to help you feel at ease."
> 4. "Flexible Payments" — "0% finance available on treatments over £500. Spread the cost with affordable monthly payments that suit your budget."
>
> SECTION 5 — MEET THE TEAM (PREVIEW)
> Section heading (H2): "Meet Your Dental Team"
> Subtext: "Skilled, caring professionals dedicated to your oral health."
> Show 4 team member cards in a row. Each card has a circular image placeholder, name, role, and a one-line bio:
> 1. "[DENTIST_1_NAME]" — "Principal Dentist" — "BDS, MJDF RCS — Special interest in implants and cosmetic dentistry. [X] years in practice."
> 2. "[DENTIST_2_NAME]" — "Associate Dentist" — "BDS — Passionate about preventive care and nervous patient management."
> 3. "[HYGIENIST_NAME]" — "Dental Hygienist" — "Dip DH — Expert in gum health, deep cleaning, and stain removal."
> 4. "[MANAGER_NAME]" — "Practice Manager" — "Keeping everything running smoothly so your visit is always comfortable."
> A "Meet the Full Team" link below pointing to /about.
>
> SECTION 6 — PATIENT REVIEWS
> Section heading (H2): "What Our Patients Say"
> Subtext: "Rated [RATING] out of 5 from [REVIEW_COUNT]+ Google reviews."
> Three review cards. Each card has a 5-star rating display, the review text in quotes, the reviewer's first name and initial, and the treatment type:
> 1. Stars: 5. "I was terrified of the dentist but the team at [BUSINESS_NAME] made me feel completely at ease. The check-up was painless and they explained everything clearly. I actually look forward to my appointments now." — Sarah T., General Check-up
> 2. Stars: 5. "Had my teeth whitened here and the results are incredible. Four shades brighter in just one session. The staff were professional and friendly throughout. Could not recommend more highly." — James R., Teeth Whitening
> 3. Stars: 5. "After years of hiding my smile, I finally got Invisalign at [BUSINESS_NAME]. The whole process was seamless from consultation to final result. My confidence has completely changed." — Emma L., Invisalign
> A "Read All Reviews" link pointing to /reviews, and a "Leave a Review" link pointing to [GOOGLE_REVIEW_URL].
>
> SECTION 7 — BOOKING CTA BANNER
> Full-width banner with a blue gradient background (#2563eb to #1d4ed8). White text:
> - Headline (H2): "Ready to Book Your Appointment?"
> - Subtext: "New patients welcome. No registration fee. Book online in under 60 seconds or call us directly."
> - Two white buttons: "Book Online" (links to [BOOKING_URL]) and "Call [PHONE]" (links to tel:[PHONE])
>
> SECTION 8 — LOCATION AND OPENING HOURS
> Two-column layout. Left column:
> - Heading (H3): "Find Us"
> - Address: [ADDRESS]
> - Phone: [PHONE]
> - Email: [EMAIL]
> - A map placeholder (Google Maps embed area)
> Right column:
> - Heading (H3): "Opening Hours"
> - Monday to Friday: 8:00 AM - 6:00 PM
> - Saturday: 9:00 AM - 2:00 PM
> - Sunday: Closed
> - "Emergency? Call [EMERGENCY_PHONE] for out-of-hours dental emergencies."
>
> Make the entire page mobile responsive. Use consistent spacing (60-80px between sections). All buttons have 14px 28px padding, 12px border radius, font-weight 600, and a subtle hover lift effect.

### Manual Build Notes

1. Add a new Website Page, set as homepage (slug: /).
2. Build the header/navigation natively in GHL with logo, menu links (Home, Services, About, Reviews, Blog, Contact, Book Online), and a "Book Now" CTA button in the nav.
3. Add 8 sections using a mix of native elements and Custom Code blocks:
   - Section 1 (Hero): Custom Code block. Use a full-width container with background image placeholder and gradient overlay. Structure the headline, subheadline, buttons, and trust line as HTML/CSS.
   - Section 2 (Trust Bar): Custom Code block or native columns. Four columns with icon/number/label.
   - Section 3 (Services Grid): Custom Code block. 8 cards in a CSS grid (4 columns desktop, 2 mobile). Each card is a clickable link to the service page.
   - Section 4 (Why Choose Us): Custom Code block. 4 feature cards in a grid.
   - Section 5 (Team Preview): Custom Code block. 4 team cards with circular image placeholders.
   - Section 6 (Reviews): Custom Code block. 3 review cards with star ratings.
   - Section 7 (CTA Banner): Custom Code block. Full-width gradient banner.
   - Section 8 (Location): Native 2-column row. Left: text + native map embed. Right: text for hours.
4. Build the footer natively in GHL with practice name, address, phone, email, social links, legal links (Privacy Policy, Terms), and copyright line.

### Native GHL Elements Needed

- **Header Navigation**: Logo, menu links (Home, Services, About, Reviews, Blog, Contact), "Book Now" CTA button linking to /booking.
- **Footer**: Practice info, social links, legal page links.
- **Google Maps Embed**: Native map element in the Location section.
- **Chat Widget**: GHL Conversation AI widget (bottom-right corner, present on all pages).

---

## Page 2: Services
**GHL Page Type**: Website Page
**URL Slug**: /services
**Sections**: 5

### GHL AI Builder Prompt

> Build a services page for a dental practice called [BUSINESS_NAME]. Use a clean, clinical design with primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO
> A shorter hero section (not full height) with a light blue-tinted background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Services"
> - Headline (H1): "Our Dental Treatments"
> - Subheadline: "From routine check-ups to advanced restorative and cosmetic procedures, we offer a full range of dental treatments under one roof."
>
> SECTION 2 — SERVICE CATEGORIES
> Display services grouped by category. Each category has a heading, and the treatments listed as cards with name, description, and starting price. Use a clean card grid layout within each category.
>
> Category 1 — "General Dentistry"
> - Dental Check-up: "Comprehensive oral examination including digital X-rays, oral cancer screening, and a personalised treatment plan. Recommended every 6 months." From £50
> - Dental Hygiene: "Professional scale and polish by our qualified hygienist. Removes plaque and tartar buildup, helps prevent gum disease, and leaves your teeth feeling fresh." From £55
> - Fillings: "Tooth-coloured composite fillings that blend seamlessly with your natural teeth. We remove decay and restore your tooth to full function." From £80
> - Root Canal Treatment: "Save an infected tooth with modern root canal therapy. We use rotary instruments and digital imaging for precise, comfortable treatment." From £250
> - Extractions: "Simple and surgical tooth removal performed gently under local anaesthetic. We offer sedation for anxious patients." From £100
> - Crowns: "Custom-made porcelain crowns that protect damaged teeth and restore their natural appearance. Crafted to match your existing teeth perfectly." From £400
>
> Category 2 — "Cosmetic Dentistry"
> - Teeth Whitening: "Professional whitening for a dramatically brighter smile. Choose in-surgery power whitening for instant results or custom take-home trays for gradual improvement." From £300. Link: /teeth-whitening
> - Composite Bonding: "Reshape and repair teeth with tooth-coloured composite resin. Fix chips, gaps, and uneven edges in a single appointment with no drilling required." From £200
> - Porcelain Veneers: "Ultra-thin porcelain shells bonded to the front of your teeth for a flawless, natural-looking smile. Custom-designed for your face shape." From £500
> - Smile Makeover: "A comprehensive treatment plan combining multiple cosmetic procedures to completely transform your smile. Includes digital smile design consultation." From £2,000. Link: /cosmetic-dentistry
>
> Category 3 — "Orthodontics"
> - Invisalign: "The world's leading clear aligner system. Straighten your teeth discreetly with custom-made, removable aligners. Suitable for mild to complex cases." From £2,500. Link: /invisalign
> - Fixed Braces: "Traditional metal and ceramic braces for reliable, predictable tooth movement. Ideal for complex orthodontic cases that need precise control." From £2,000
>
> Category 4 — "Dental Implants"
> - Single Tooth Implant: "Replace a missing tooth with a titanium implant and porcelain crown. Looks, feels, and functions exactly like your natural tooth." From £2,000. Link: /dental-implants
> - Implant-Supported Bridge: "Replace multiple missing teeth with an implant-retained bridge. Eliminates the need for a removable denture." From £4,000. Link: /dental-implants
> - All-on-4 Implants: "A full arch of fixed teeth supported by just four implants. Transform from dentures to permanent teeth in a single day." From £8,000. Link: /dental-implants
>
> Category 5 — "Emergency Dental Care"
> - Emergency Consultation: "Same-day appointments for dental pain, swelling, broken teeth, or trauma. Call us and we will see you as quickly as possible." From £80. Link: /emergency
> - Emergency Treatment: "Immediate treatment to relieve pain and stabilise your condition. Follow-up care planned as part of your ongoing treatment." From £100
>
> Category 6 — "Children's Dentistry"
> - Children's Check-up: "A gentle, fun examination tailored for children. We make dental visits a positive experience from the very first appointment." From £40
> - Fissure Sealants: "A protective coating applied to the biting surfaces of back teeth. Prevents decay in the deep grooves where brushing cannot reach." From £30
> - Fluoride Treatments: "A quick, painless fluoride application to strengthen tooth enamel and protect against cavities. Recommended for children and teenagers." From £25
>
> SECTION 3 — TREATMENT PROCESS
> Section heading (H2): "How Your Treatment Works"
> A horizontal 4-step timeline with connecting lines between steps:
> 1. "Consultation" — "Book your appointment online or by phone. We will discuss your concerns, examine your teeth, and take any necessary X-rays."
> 2. "Treatment Plan" — "Your dentist will explain all available options, expected outcomes, and costs. You will receive a written treatment plan to take home."
> 3. "Treatment" — "We carry out your treatment using the latest techniques and technology. Your comfort is our priority at every stage."
> 4. "Aftercare" — "We provide clear aftercare instructions and schedule any follow-up appointments. Our team is always available if you have questions."
>
> SECTION 4 — PAYMENT OPTIONS
> Section heading (H2): "Affordable Payment Options"
> Three cards:
> 1. "Pay As You Go" — "Pay for each treatment individually at the time of your appointment. We accept cash, card, and contactless payments."
> 2. "0% Finance" — "Spread the cost of treatments over £500 with interest-free monthly payments. Subject to status. Apply at your consultation."
> 3. "Dental Plan" — "Join our practice membership plan from £[PLAN_PRICE]/month. Includes two check-ups, two hygiene visits, 10% off all treatments, and worldwide dental emergency cover."
>
> SECTION 5 — CTA
> Full-width blue gradient banner (#2563eb to #1d4ed8), white text:
> - Headline: "Not Sure Which Treatment You Need?"
> - Subtext: "Book a consultation and our team will guide you to the right solution. No obligation, no pressure."
> - Button: "Book a Consultation" linking to [BOOKING_URL]
> - Text link: "Or call us on [PHONE]"
>
> Mobile responsive. Consistent spacing. Cards have 16px border radius, subtle shadow on hover.

### Manual Build Notes

1. Add a new Website Page with slug /services.
2. Section 1 (Compact Hero): Custom Code block with light blue background, breadcrumb, H1, and subheadline.
3. Section 2 (Service Categories): Custom Code block. Use category headings (H3) with card grids beneath each. Each card shows treatment name, description, price, and optional link to a dedicated page. Use CSS grid: 3 columns desktop, 2 tablet, 1 mobile.
4. Section 3 (Treatment Process): Custom Code block. Horizontal timeline with 4 numbered steps, connecting line, step title, and description.
5. Section 4 (Payment Options): Custom Code block. 3 cards in a row.
6. Section 5 (CTA Banner): Custom Code block. Full-width gradient banner.

### Native GHL Elements Needed

- **Header/Footer**: Shared across all pages (built once).
- **Chat Widget**: GHL Conversation AI (shared across all pages).

---

## Page 3: About Us
**GHL Page Type**: Website Page
**URL Slug**: /about
**Sections**: 7

### GHL AI Builder Prompt

> Build an About Us page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO
> Shorter hero with light blue-tinted background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > About Us"
> - Headline (H1): "About [BUSINESS_NAME]"
> - Subheadline: "A modern dental practice built on trust, expertise, and genuine patient care."
>
> SECTION 2 — PRACTICE STORY
> Two-column layout. Left column: a large image placeholder (interior of a modern dental practice). Right column:
> - Heading (H2): "Our Story"
> - Paragraph 1: "[BUSINESS_NAME] was founded in [YEAR_ESTABLISHED] with a simple belief: everyone deserves access to high-quality dental care in a comfortable, welcoming environment. What started as a small family practice has grown into one of the most trusted dental clinics in the area."
> - Paragraph 2: "Over the years, we have invested in the latest dental technology, expanded our team of specialist clinicians, and built a reputation for clinical excellence combined with genuine warmth. We treat every patient as an individual, taking the time to listen, explain, and deliver the best possible outcome."
> - Paragraph 3: "Whether you are visiting for a routine check-up or a life-changing smile makeover, you will experience the same standard of care: thorough, gentle, and always focused on you."
>
> SECTION 3 — OUR VALUES
> Section heading (H2): "What We Stand For"
> Four value cards in a row (2 on mobile):
> 1. "Clinical Excellence" — "We hold ourselves to the highest clinical standards. Our dentists pursue ongoing professional development and use evidence-based techniques to deliver outstanding results."
> 2. "Patient-First Care" — "Your comfort, concerns, and goals are at the centre of everything we do. We never rush, never pressure, and always explain your options clearly."
> 3. "Honest Communication" — "No jargon, no hidden costs, no surprises. We give you straightforward advice and transparent pricing so you can make informed decisions about your care."
> 4. "Continuous Innovation" — "We invest in modern equipment and training to offer you the most effective, comfortable treatments available. From digital X-rays to laser dentistry, we stay at the forefront."
>
> SECTION 4 — FULL TEAM
> Section heading (H2): "Meet the Team"
> Subtext: "The people behind your smile."
> A grid of 6 team member cards (3 columns desktop, 2 mobile). Each card has a portrait image placeholder (square with rounded corners), name, role, qualifications, and a 2-sentence bio:
> 1. "[DENTIST_1_NAME]" — "Principal Dentist, BDS, MJDF RCS (Eng)" — "Qualified from [UNIVERSITY] in [YEAR] and has a special interest in dental implants and cosmetic dentistry. Committed to making every patient feel confident and comfortable in the chair."
> 2. "[DENTIST_2_NAME]" — "Associate Dentist, BDS" — "Joined [BUSINESS_NAME] in [YEAR] with a passion for preventive and minimally invasive dentistry. Known for a calm, reassuring manner that puts nervous patients at ease."
> 3. "[DENTIST_3_NAME]" — "Associate Dentist, BDS, MSc" — "Specialist interest in orthodontics and Invisalign. Has helped hundreds of patients achieve straighter, healthier smiles."
> 4. "[HYGIENIST_NAME]" — "Dental Hygienist, Dip Dental Hygiene" — "Expert in periodontal care and preventive treatments. Passionate about educating patients on effective oral hygiene techniques."
> 5. "[NURSE_NAME]" — "Senior Dental Nurse, National Diploma" — "Experienced dental nurse who ensures every procedure runs smoothly. Always on hand with a reassuring word and a warm smile."
> 6. "[MANAGER_NAME]" — "Practice Manager" — "Keeps the practice running seamlessly behind the scenes. Handles scheduling, patient queries, and ensures every visit is a positive experience."
>
> SECTION 5 — FACILITIES
> Section heading (H2): "Our Facilities"
> A three-column layout with image placeholders and descriptions:
> 1. "Modern Treatment Rooms" — "Spacious, well-equipped surgeries with the latest dental chairs, digital X-ray units, and intraoral cameras."
> 2. "Comfortable Waiting Area" — "A relaxing reception area with complimentary refreshments, free Wi-Fi, and a dedicated children's corner."
> 3. "Accessible Practice" — "Step-free access throughout, ground-floor treatment rooms, and free on-site parking for all patients."
>
> SECTION 6 — ACCREDITATIONS
> Section heading (H2): "Accreditations and Memberships"
> A horizontal row of accreditation badges/logos (display as image placeholders with labels):
> - GDC (General Dental Council) — "All our dentists are registered with the GDC."
> - CQC (Care Quality Commission) — "Inspected and rated by the CQC."
> - BDA (British Dental Association) — "Proud members of the BDA."
> - Invisalign Provider — "Certified Invisalign provider."
> - Denplan — "Registered Denplan practice."
>
> SECTION 7 — JOIN US CTA
> Full-width banner with light blue background (#eff6ff):
> - Heading (H2): "Join the [BUSINESS_NAME] Family"
> - Subtext: "New patients are always welcome. Register today and experience the difference that genuine, expert dental care makes."
> - Two buttons: "Book Your First Visit" (primary blue, links to [BOOKING_URL]) and "Contact Us" (outlined, links to /contact)
>
> Mobile responsive. Consistent 60-80px section spacing.

### Manual Build Notes

1. Add a new Website Page with slug /about.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Practice Story): Native 2-column row. Left: image element. Right: Custom Code block with heading and paragraphs.
4. Section 3 (Values): Custom Code block. 4 cards in CSS grid.
5. Section 4 (Team): Custom Code block. 6 cards in CSS grid (3 columns desktop).
6. Section 5 (Facilities): Custom Code block. 3 columns with image placeholders.
7. Section 6 (Accreditations): Custom Code block. Horizontal row of logo placeholders with labels.
8. Section 7 (Join Us CTA): Custom Code block. Light background banner.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 4: Contact
**GHL Page Type**: Website Page
**URL Slug**: /contact
**Sections**: 4

### GHL AI Builder Prompt

> Build a Contact page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Contact"
> - Headline (H1): "Get in Touch"
> - Subheadline: "We would love to hear from you. Reach out by phone, email, or simply fill in the form below."
>
> SECTION 2 — CONTACT METHODS AND FORM
> Two-column layout.
> Left column — Contact Details:
> - Heading (H3): "Contact Details"
> - Phone: [PHONE] (clickable tel: link) — "Mon-Fri 8am-6pm, Sat 9am-2pm"
> - Email: [EMAIL] (clickable mailto: link) — "We aim to reply within 24 hours"
> - WhatsApp: [PHONE] — "Message us for quick queries"
> - Emergency: [EMERGENCY_PHONE] — "Out-of-hours dental emergencies only"
> - Address: [ADDRESS]
>
> Right column — Contact Form:
> - A placeholder area for a native GHL contact form. Display text: "[GHL NATIVE FORM — Insert here. Fields: First Name, Last Name, Email, Phone, Subject (dropdown: General Enquiry, New Patient Registration, Appointment Query, Treatment Question, Complaint, Other), Message (textarea). Submit button: Send Message]"
>
> SECTION 3 — MAP AND DIRECTIONS
> Full-width section:
> - Heading (H3): "How to Find Us"
> - A large map placeholder (Google Maps embed area for [ADDRESS])
> - Below the map, three info cards in a row:
>   1. "By Car" — "Free on-site parking available for all patients. The practice is located on [STREET] with easy access from [MAIN_ROAD]."
>   2. "By Public Transport" — "The nearest station is [STATION], a [X]-minute walk from the practice. Bus routes [ROUTES] stop nearby."
>   3. "Accessibility" — "Step-free access throughout the practice. Ground-floor treatment rooms. Please let us know in advance if you have any specific accessibility requirements."
>
> SECTION 4 — OPENING HOURS
> Section with a clean table or card layout:
> - Heading (H3): "Opening Hours"
> - Monday: 8:00 AM - 6:00 PM
> - Tuesday: 8:00 AM - 6:00 PM
> - Wednesday: 8:00 AM - 6:00 PM
> - Thursday: 8:00 AM - 6:00 PM
> - Friday: 8:00 AM - 6:00 PM
> - Saturday: 9:00 AM - 2:00 PM
> - Sunday: Closed
> - Note below: "For dental emergencies outside these hours, call [EMERGENCY_PHONE]."
> - CTA button: "Book an Appointment" linking to [BOOKING_URL]
>
> Mobile responsive. Form placeholder should be clearly marked for native GHL form insertion.

### Manual Build Notes

1. Add a new Website Page with slug /contact.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Contact + Form): Native 2-column row. Left column: Custom Code block with contact details. Right column: Native GHL Form element with fields — First Name, Last Name, Email, Phone, Subject (dropdown), Message (textarea), Submit button.
4. Section 3 (Map): Native Google Maps element for the map. Custom Code block for the three info cards below it.
5. Section 4 (Opening Hours): Custom Code block with a styled table and CTA button.

### Native GHL Elements Needed

- **GHL Contact Form**: First Name (text), Last Name (text), Email (email), Phone (phone), Subject (dropdown: General Enquiry, New Patient Registration, Appointment Query, Treatment Question, Complaint, Other), Message (textarea). Submit button text: "Send Message". Wire to a pipeline or tag for follow-up workflow.
- **Google Maps Embed**: Native map element with practice address.
- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 5: Book Online
**GHL Page Type**: Website Page
**URL Slug**: /booking
**Sections**: 3

### GHL AI Builder Prompt

> Build a Booking page for a dental practice called [BUSINESS_NAME]. Clean design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Book Online"
> - Headline (H1): "Book Your Appointment"
> - Subheadline: "Choose a time that suits you and book online in under 60 seconds. New patients welcome — no registration fee."
>
> SECTION 2 — BOOKING CALENDAR
> Full-width section. Centre-aligned:
> - A prominent placeholder area for the native GHL calendar widget. Display text: "[GHL NATIVE CALENDAR — Insert the booking calendar widget here. Configure appointment types: New Patient Check-up (45 min), Returning Patient Check-up (30 min), Hygiene Appointment (30 min), Emergency (20 min), Consultation (30 min), Teeth Whitening Consultation (20 min), Invisalign Consultation (30 min), Implant Consultation (30 min).]"
>
> Below the calendar placeholder, three info cards in a row:
> 1. "New Patients" — "Welcome to [BUSINESS_NAME]. Your first visit includes a comprehensive examination, digital X-rays, and a personalised treatment plan. Please arrive 10 minutes early to complete registration. Bring a form of ID and your medical history if available."
> 2. "Appointment Types" — "Select the appointment type that matches your needs. If you are unsure, choose General Consultation and we will guide you from there. Urgent issues should be booked as Emergency."
> 3. "Cancellation Policy" — "We kindly ask for at least 24 hours notice if you need to cancel or reschedule. Late cancellations or missed appointments may incur a fee of £25. We understand that emergencies happen — just let us know as soon as you can."
>
> SECTION 3 — PREFER TO CALL
> A simple section with centre-aligned text:
> - Heading (H3): "Prefer to Book by Phone?"
> - Text: "Our reception team is happy to help. Call us on [PHONE] during opening hours (Mon-Fri 8am-6pm, Sat 9am-2pm)."
> - Text: "For dental emergencies outside these hours, call [EMERGENCY_PHONE]."
> - Two buttons: "Call [PHONE]" (primary blue, links to tel:[PHONE]) and "Send us a Message" (outlined, links to /contact)
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /booking.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Calendar + Info): Add a native GHL Calendar widget as the main element. Configure appointment types with durations. Below the calendar, add a Custom Code block with 3 info cards.
4. Section 3 (Phone CTA): Custom Code block.

### Native GHL Elements Needed

- **GHL Calendar Widget**: This is the primary content of this page. Configure appointment types:
  - New Patient Check-up (45 min)
  - Returning Patient Check-up (30 min)
  - Hygiene Appointment (30 min)
  - Emergency (20 min)
  - General Consultation (30 min)
  - Teeth Whitening Consultation (20 min)
  - Invisalign Consultation (30 min)
  - Implant Consultation (30 min)
- Wire calendar to GHL Calendar settings, staff availability, and confirmation workflow.
- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 6: Reviews / Testimonials
**GHL Page Type**: Website Page
**URL Slug**: /reviews
**Sections**: 5

### GHL AI Builder Prompt

> Build a Reviews page for a dental practice called [BUSINESS_NAME]. Clean design. Primary blue #2563eb, accent green #10b981, page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — COMPACT HERO WITH RATING
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Reviews"
> - Headline (H1): "Patient Reviews"
> - Large rating display: "[RATING] out of 5" with 5 star icons (filled to match rating)
> - Subheadline: "Based on [REVIEW_COUNT]+ verified Google reviews"
> - "Leave a Review" button linking to [GOOGLE_REVIEW_URL]
>
> SECTION 2 — RATING BREAKDOWN
> A visual breakdown of ratings with horizontal bars:
> - 5 stars: [5_STAR_PERCENT]% — (longest bar, green #10b981)
> - 4 stars: [4_STAR_PERCENT]% — (shorter bar)
> - 3 stars: [3_STAR_PERCENT]% — (shorter bar)
> - 2 stars: [2_STAR_PERCENT]% — (minimal bar)
> - 1 star: [1_STAR_PERCENT]% — (minimal bar)
> Display this as a compact card to the side or above the reviews grid.
>
> SECTION 3 — REVIEW CARDS
> A grid of 9 review cards (3 columns desktop, 1 mobile). Each card has a star rating (shown as filled stars), the review text, reviewer name (first name and last initial), and the treatment category. All reviews are 5 stars unless noted:
>
> 1. Stars: 5. Treatment: General Check-up. "I have been coming to [BUSINESS_NAME] for three years now and the standard of care has been consistently excellent. The check-ups are thorough, the hygienist is brilliant, and the reception team always greets me with a smile. I would not go anywhere else." — David M.
>
> 2. Stars: 5. Treatment: Teeth Whitening. "Had professional whitening and I am over the moon with the results. My teeth are noticeably brighter and the whole process was much more comfortable than I expected. The team talked me through every step." — Priya K.
>
> 3. Stars: 5. Treatment: Dental Implants. "After losing a tooth in an accident, I was devastated. The implant process at [BUSINESS_NAME] was life-changing. From the initial consultation to the final crown fitting, the care was outstanding. You genuinely cannot tell it is not my real tooth." — Robert H.
>
> 4. Stars: 5. Treatment: Nervous Patient. "I avoided the dentist for over eight years because of anxiety. A friend recommended [BUSINESS_NAME] and I am so glad I listened. They were incredibly patient, explained everything beforehand, and I felt completely safe. I have now had all my treatment completed and I actually do not dread going anymore." — Claire S.
>
> 5. Stars: 5. Treatment: Children's Dentistry. "Both my children love coming here. The staff are wonderful with kids — they make it fun and never scary. My five-year-old actually asks when her next appointment is. That tells you everything." — Michael T.
>
> 6. Stars: 5. Treatment: Emergency. "Woke up on a Saturday morning with agonising toothache. Called [BUSINESS_NAME] and they got me in within the hour. The dentist was calm, reassuring, and sorted the problem quickly. I cannot thank them enough for that level of care at short notice." — Sophie W.
>
> 7. Stars: 5. Treatment: Hygiene. "The best hygienist I have ever visited. Thorough but gentle, and she gave me really practical advice about my brushing technique. My gums have never been healthier since I started coming here regularly." — Angela P.
>
> 8. Stars: 5. Treatment: Cosmetic Dentistry. "Had composite bonding on my front teeth and the transformation is amazing. They look completely natural. The dentist had a real eye for detail and took the time to get the shape and shade absolutely perfect." — Tom R.
>
> 9. Stars: 5. Treatment: Invisalign. "Finished my Invisalign treatment last month and I could not be happier. The whole journey from scan to final retainer was well-organised. Regular check-ins kept me motivated. My smile is exactly what I hoped for." — Hannah J.
>
> SECTION 4 — VIDEO TESTIMONIALS
> Section heading (H2): "Video Testimonials"
> Subtext: "Hear directly from our patients about their experience."
> Three video placeholder cards in a row. Each has a thumbnail placeholder with a play button overlay, patient first name, and treatment type:
> 1. "[VIDEO_PATIENT_1]" — Smile Makeover Journey
> 2. "[VIDEO_PATIENT_2]" — Overcoming Dental Anxiety
> 3. "[VIDEO_PATIENT_3]" — My Implant Experience
>
> SECTION 5 — CTA
> Centre-aligned:
> - Heading (H2): "Ready to Experience the Difference?"
> - Subtext: "Join [REVIEW_COUNT]+ happy patients. Book your appointment today."
> - Two buttons: "Book Appointment" (primary blue, links to [BOOKING_URL]) and "Leave a Review" (outlined, links to [GOOGLE_REVIEW_URL])
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /reviews.
2. Section 1 (Hero): Custom Code block with rating display and star icons.
3. Section 2 (Breakdown): Custom Code block with horizontal bar chart using CSS widths for percentage bars.
4. Section 3 (Reviews): Custom Code block. 9 cards in CSS grid (3 columns desktop).
5. Section 4 (Video): Custom Code block. 3 video placeholder cards. Replace with native video embeds or Wistia/YouTube embeds during client deployment.
6. Section 5 (CTA): Custom Code block.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.
- **Video Embeds**: If client provides video testimonials, embed using native video element or YouTube/Vimeo embed.

---

## Page 7: FAQ
**GHL Page Type**: Website Page
**URL Slug**: /faq
**Sections**: 3

### GHL AI Builder Prompt

> Build an FAQ page for a dental practice called [BUSINESS_NAME]. Clean design. Primary blue #2563eb, page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis. All FAQ answers must be included in full as written below.
>
> SECTION 1 — COMPACT HERO
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > FAQ"
> - Headline (H1): "Frequently Asked Questions"
> - Subheadline: "Find answers to the most common questions about our practice, treatments, and appointments."
>
> SECTION 2 — ACCORDION FAQS
> Display all questions as expandable accordions, grouped by category. Each category has a heading. The first question in each category should be expanded by default. All others collapsed.
>
> CATEGORY: "General"
>
> Q1: "Are you accepting new patients?"
> A1: "Yes, we are always welcoming new patients. You can register by booking your first appointment online at [BOOKING_URL] or by calling us on [PHONE]. There is no registration fee. At your first visit, we will carry out a comprehensive examination, take any necessary X-rays, and discuss a treatment plan tailored to you."
>
> Q2: "Do you offer NHS treatments?"
> A2: "We offer both NHS and private treatments. NHS dental care covers essential treatments at government-set prices. Private treatments give you access to our full range of services, premium materials, and cosmetic options. Our team will always explain which treatments are available on the NHS and help you choose the option that suits you best."
>
> Q3: "What should I bring to my first appointment?"
> A3: "Please bring a form of photo ID, any relevant medical history or medication list, and details of your previous dentist if you have them. If you are an NHS patient, please bring your NHS exemption certificate if applicable. We recommend arriving 10 minutes early to complete registration paperwork."
>
> Q4: "Do you treat nervous patients?"
> A4: "Absolutely. We understand that dental anxiety is very common and we take it seriously. Our team is trained in anxiety management techniques and we offer a range of options including a gentle, step-by-step approach, sedation options, and extra time for your appointments. Please let us know about your concerns when booking so we can prepare accordingly."
>
> Q5: "Is the practice accessible?"
> A5: "Yes. We have step-free access throughout the practice, ground-floor treatment rooms, and accessible facilities. Free on-site parking is available. If you have any specific accessibility requirements, please let us know when booking and we will do our best to accommodate you."
>
> Q6: "What payment methods do you accept?"
> A6: "We accept cash, debit cards, credit cards, and contactless payments. For treatments over £500, we offer 0% finance options to help you spread the cost with affordable monthly payments. Our practice membership plan is also available from £[PLAN_PRICE] per month."
>
> Q7: "Do you have a dental membership plan?"
> A7: "Yes. Our practice membership plan covers two check-ups, two hygiene appointments, and 10% off all other treatments for a fixed monthly fee of £[PLAN_PRICE]. It also includes worldwide dental emergency cover. Ask at reception or contact us for full details."
>
> CATEGORY: "Appointments"
>
> Q8: "How do I book an appointment?"
> A8: "You can book online at [BOOKING_URL] at any time, call us on [PHONE] during opening hours (Monday to Friday 8am-6pm, Saturday 9am-2pm), or send us a message through our website contact form. Online booking lets you see available times and choose the appointment type that suits your needs."
>
> Q9: "What are your opening hours?"
> A9: "We are open Monday to Friday 8:00 AM to 6:00 PM and Saturday 9:00 AM to 2:00 PM. We are closed on Sundays and bank holidays. For dental emergencies outside these hours, please call our emergency line on [EMERGENCY_PHONE]."
>
> Q10: "What is your cancellation policy?"
> A10: "We kindly ask for at least 24 hours notice if you need to cancel or reschedule your appointment. Late cancellations or missed appointments may incur a charge of £25. We understand that unexpected situations arise — please just let us know as soon as possible and we will do our best to accommodate you."
>
> Q11: "How often should I visit the dentist?"
> A11: "We recommend a dental check-up every six months. Regular visits allow us to catch any issues early, monitor your oral health, and carry out preventive treatments like professional cleaning. Your dentist may recommend more or less frequent visits depending on your individual needs."
>
> Q12: "Can I request a specific dentist?"
> A12: "Yes, you can request a specific dentist when booking your appointment. We will do our best to schedule you with your preferred clinician, though availability may vary. If your preferred dentist is not available at your chosen time, our reception team will suggest the nearest alternative."
>
> Q13: "Do you offer evening or weekend appointments?"
> A13: "We offer Saturday morning appointments from 9am to 2pm. We do not currently offer evening appointments, but we have availability throughout the day Monday to Friday. If you have difficulty attending during standard hours, please contact us and we will try to find a time that works for you."
>
> CATEGORY: "Treatments and Costs"
>
> Q14: "How much does a check-up cost?"
> A14: "A standard dental check-up starts from £50 for private patients. NHS check-ups are charged at the current NHS Band 1 rate. The check-up includes a comprehensive oral examination, digital X-rays if needed, oral cancer screening, and a personalised treatment plan."
>
> Q15: "How much does teeth whitening cost?"
> A15: "Professional teeth whitening starts from £300 for take-home trays and from £400 for in-surgery power whitening. We also offer a combined package (in-surgery plus take-home) from £500. Prices may vary depending on your individual needs. Book a free whitening consultation to discuss your options."
>
> Q16: "How much do dental implants cost?"
> A16: "A single dental implant starts from £2,000, which includes the implant, abutment, and porcelain crown. Implant-supported bridges start from £4,000 and All-on-4 full arch implants from £8,000. We offer 0% finance on all implant treatments. Book a free implant consultation to get a personalised treatment plan and quote."
>
> Q17: "Do you offer 0% finance?"
> A17: "Yes, we offer 0% interest finance on treatments over £500. You can spread the cost over 6 to 12 months with affordable monthly payments. Finance is subject to status and approval. Speak to our team at your consultation for full details and to apply."
>
> Q18: "What is included in a hygiene appointment?"
> A18: "A dental hygiene appointment includes a professional scale and polish to remove plaque, tartar, and stains. Your hygienist will also assess your gum health, provide personalised oral hygiene advice, and may apply fluoride treatment if appropriate. Regular hygiene visits are essential for preventing gum disease."
>
> Q19: "Are cosmetic treatments available on the NHS?"
> A19: "Cosmetic treatments such as teeth whitening, veneers, and bonding are not available on the NHS. These are provided as private treatments. We offer flexible payment options including 0% finance to help make cosmetic dentistry accessible and affordable."
>
> Q20: "How long does Invisalign treatment take?"
> A20: "Invisalign treatment typically takes 6 to 18 months depending on the complexity of your case. Invisalign Lite (for mild cases) can take as little as 3 to 6 months. Your dentist will give you a personalised timeline at your consultation, along with a digital preview of your expected results."
>
> CATEGORY: "Children's Dentistry"
>
> Q21: "At what age should my child first visit the dentist?"
> A21: "We recommend bringing your child for their first dental visit around their first birthday, or when their first teeth start to appear. Early visits help your child become familiar with the dental environment in a relaxed, pressure-free way and allow us to monitor their development from the start."
>
> Q22: "Are children's check-ups free on the NHS?"
> A22: "Yes, all NHS dental treatment is free for children under 18 (and under 19 if in full-time education). This includes check-ups, fillings, extractions, and other necessary treatments. We welcome children of all ages and our team is experienced in making dental visits fun and positive."
>
> Q23: "What are fissure sealants?"
> A23: "Fissure sealants are a thin protective coating applied to the biting surfaces of back teeth (molars). They seal the deep grooves where food and bacteria can collect, significantly reducing the risk of decay. The procedure is quick, painless, and highly effective. We recommend sealants for children as soon as their adult molars come through, typically around age 6 and again at age 12."
>
> Q24: "How do you handle anxious children?"
> A24: "We take a gentle, child-friendly approach. Our team is trained to work with anxious young patients using techniques such as tell-show-do (explaining each step in simple terms before we do it), distraction, positive reinforcement, and allowing the child to set the pace. We never force treatment. For very anxious children, we can discuss additional options with you."
>
> CATEGORY: "Emergency Dental Care"
>
> Q25: "What counts as a dental emergency?"
> A25: "A dental emergency includes severe toothache that painkillers cannot control, a knocked-out or broken tooth, significant swelling in your face or gums, bleeding that will not stop, or damage to a crown or filling that is causing pain. If you are unsure whether your situation is an emergency, call us on [PHONE] (or [EMERGENCY_PHONE] outside hours) and we will advise you."
>
> Q26: "Do you offer same-day emergency appointments?"
> A26: "Yes, we keep emergency slots available every day during opening hours. Call us on [PHONE] as early as possible and we will do our best to see you the same day. If you call outside opening hours, please contact our emergency line on [EMERGENCY_PHONE]."
>
> Q27: "How much does an emergency appointment cost?"
> A27: "An emergency consultation starts from £80, which includes assessment, X-rays if needed, and advice. Emergency treatment (such as temporary fillings, drainage of an abscess, or emergency extractions) starts from £100 depending on the treatment required. We will always explain costs before proceeding."
>
> Q28: "What should I do if I knock out a tooth?"
> A28: "Pick up the tooth by the crown (the white part), not the root. If it is dirty, rinse it gently with milk or saliva — do not scrub it or use water. Try to push the tooth back into the socket and hold it in place by biting on a clean cloth. If you cannot reinsert it, place the tooth in a glass of milk or hold it inside your cheek. Get to us or an emergency dentist as quickly as possible — ideally within 30 minutes. The faster you act, the better the chance of saving the tooth."
>
> NOTE FOR DEVELOPERS: Add FAQ schema (JSON-LD) structured data to this page for SEO. Include all 28 questions and answers in FAQPage schema format. This should be added as a script tag in the page head or within a Custom Code block.
>
> SECTION 3 — CONTACT CTA
> Centre-aligned:
> - Heading (H2): "Still Have Questions?"
> - Subtext: "Our friendly team is happy to help. Get in touch and we will get back to you within 24 hours."
> - Two buttons: "Contact Us" (primary blue, links to /contact) and "Book Appointment" (outlined, links to [BOOKING_URL])
>
> Mobile responsive. Accordions should have smooth expand/collapse animation.

### Manual Build Notes

1. Add a new Website Page with slug /faq.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (FAQs): Custom Code block with JavaScript accordion functionality. Group questions under category headings. Each question is a clickable header that toggles the answer visibility. Include smooth CSS transitions. First question in each category open by default.
4. Add a separate Custom Code block (or script in page settings) for FAQ schema JSON-LD structured data.
5. Section 3 (CTA): Custom Code block.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.
- **SEO Settings**: Add FAQ schema JSON-LD in page head or custom code. Set meta title: "FAQ | [BUSINESS_NAME] — Your Questions Answered". Meta description: "Find answers to common questions about dental treatments, appointments, costs, and more at [BUSINESS_NAME]."

---

## Page 8: Teeth Whitening
**GHL Page Type**: Website Page
**URL Slug**: /teeth-whitening
**Sections**: 8

### GHL AI Builder Prompt

> Build a Teeth Whitening treatment page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO
> Full-width hero with a bright, clean background. Centre-aligned:
> - Breadcrumb: "Home > Services > Teeth Whitening"
> - Headline (H1): "Professional Teeth Whitening"
> - Subheadline: "Achieve a brighter, more confident smile with safe, effective professional whitening at [BUSINESS_NAME]. Results in as little as one visit."
> - Two buttons: "Book a Whitening Consultation" (primary blue, links to [BOOKING_URL]) and "Call [PHONE]" (outlined)
>
> SECTION 2 — WHAT IS WHITENING
> Two-column layout. Left: image placeholder (smiling patient, before/after concept). Right:
> - Heading (H2): "What Is Professional Teeth Whitening?"
> - Paragraph: "Professional teeth whitening is a safe, clinically supervised treatment that lightens the natural colour of your teeth without removing any enamel. Unlike over-the-counter products, professional whitening uses higher-concentration gels applied by a qualified dental professional, delivering dramatically better and longer-lasting results."
> - Paragraph: "At [BUSINESS_NAME], we offer both in-surgery power whitening for immediate results and custom take-home whitening kits for a more gradual approach. Your dentist will recommend the best option based on your goals, sensitivity levels, and lifestyle."
> - Paragraph: "Treatment begins with a consultation to assess your suitability and discuss your desired shade. We create custom-fitted whitening trays that perfectly match your teeth, ensuring even coverage and minimal gum irritation."
>
> SECTION 3 — BENEFITS
> Section heading (H2): "Benefits of Professional Whitening"
> Four benefit cards in a row:
> 1. "Clinically Proven Results" — "Professional whitening can lighten your teeth by up to eight shades. Results are dramatically more effective than any shop-bought product."
> 2. "Safe and Supervised" — "Carried out under the care of a qualified dentist, professional whitening is safe for your enamel and gums when performed correctly."
> 3. "Fast and Convenient" — "In-surgery whitening delivers visible results in a single 60-minute appointment. Take-home kits work gradually over 2 to 3 weeks."
> 4. "Long-Lasting" — "With good oral hygiene and occasional top-ups, professional whitening results can last 12 to 18 months or longer."
>
> SECTION 4 — PROCESS TIMELINE
> Section heading (H2): "How It Works"
> A horizontal 4-step timeline:
> 1. "Consultation" — "We assess your teeth, discuss your goals, and recommend the best whitening option for you. We also take a shade reading so you can see the improvement."
> 2. "Custom Trays" — "We take impressions of your teeth and create precision-fitted whitening trays. These ensure the gel contacts every surface evenly."
> 3. "Whitening" — "For in-surgery: we apply professional-grade gel and activate it with a special light for 60 minutes. For take-home: you wear your trays with gel for 30-60 minutes daily for 2-3 weeks."
> 4. "Aftercare" — "We review your results and provide aftercare advice to maintain your new shade. Top-up gel syringes are available for periodic refreshing."
>
> SECTION 5 — PRICING
> Section heading (H2): "Whitening Pricing"
> Three pricing cards side by side:
> 1. "In-Surgery Power Whitening" — Price: £400 — "Professional-strength gel activated by LED light. One 60-minute session. Immediate results of up to 8 shades lighter. Ideal for special occasions or fast results."
> 2. "Take-Home Whitening Kit" — Price: £300 — "Custom-fitted trays and professional gel. Wear 30-60 minutes daily for 2-3 weeks. Gradual, natural-looking results. Keep your trays for future top-ups."
> 3. "Combined Package" — Price: £500 — Badge: "Best Value" — "In-surgery session for instant brightness plus a take-home kit for maintenance and top-ups. The most comprehensive whitening solution."
> Below the cards: "0% finance available on all whitening treatments. Free initial consultation included."
>
> SECTION 6 — FAQS
> Section heading (H2): "Whitening FAQs"
> Five accordion FAQs:
>
> Q1: "Is teeth whitening safe?"
> A1: "Yes, professional teeth whitening is safe when performed by a qualified dentist. The products we use are clinically tested and approved for dental use. Some patients experience temporary sensitivity during or after treatment, which resolves within a few days. Over-the-counter whitening products and treatments from non-dental providers carry more risk of damage to enamel and gums."
>
> Q2: "How long do whitening results last?"
> A2: "Results typically last 12 to 18 months with good oral hygiene. Avoiding heavy staining from tea, coffee, red wine, and smoking will help maintain your results for longer. Periodic top-ups using your take-home trays can extend your results further."
>
> Q3: "Will whitening make my teeth sensitive?"
> A3: "Some patients experience mild, temporary sensitivity during whitening treatment. This usually subsides within 24 to 48 hours. We use desensitising products and can adjust the treatment protocol to minimise any discomfort. If you already have sensitive teeth, let us know at your consultation so we can plan accordingly."
>
> Q4: "Can I whiten my teeth if I have crowns or veneers?"
> A4: "Whitening treatment only works on natural tooth enamel. Crowns, veneers, and fillings will not change colour. If you have visible restorations, we will discuss this at your consultation and may recommend replacing them after whitening to ensure a uniform shade."
>
> Q5: "Why is professional whitening better than shop-bought kits?"
> A5: "Professional whitening uses higher-concentration gels that deliver faster, more dramatic results. Custom-fitted trays ensure even coverage and protect your gums. A dentist supervises your treatment, checks for any underlying issues first, and adjusts the approach to minimise sensitivity. Shop-bought products use generic trays and lower-strength gels that often produce uneven or disappointing results."
>
> SECTION 7 — BEFORE AND AFTER
> Section heading (H2): "Real Results"
> Subtext: "See the difference professional whitening makes. These are real patient results from [BUSINESS_NAME]."
> Three before/after image placeholder pairs in a row. Each has a "Before" image placeholder and an "After" image placeholder side by side, with a patient first name and shade improvement below:
> 1. "[PATIENT_1_NAME]" — "6 shades lighter"
> 2. "[PATIENT_2_NAME]" — "5 shades lighter"
> 3. "[PATIENT_3_NAME]" — "8 shades lighter"
>
> SECTION 8 — TESTIMONIAL AND CTA
> A testimonial card with a quote, name, and star rating:
> "I was sceptical about whitening but the results speak for themselves. My teeth are six shades brighter and I cannot stop smiling. The team at [BUSINESS_NAME] made the whole process comfortable and straightforward. Worth every penny." — Laura D., 5 stars
>
> Below, a CTA:
> - Heading (H2): "Ready for a Brighter Smile?"
> - Subtext: "Book your free whitening consultation today."
> - Button: "Book Consultation" (primary blue, links to [BOOKING_URL])
> - Text link: "Or call us on [PHONE]"
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /teeth-whitening.
2. Build 8 sections using Custom Code blocks for all sections.
3. Image placeholders: mark clearly for client to replace with actual before/after photos and treatment images.
4. Pricing cards: ensure the "Best Value" badge on the Combined Package is visually distinct (e.g., accent green #10b981 badge).

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 9: Dental Implants
**GHL Page Type**: Website Page
**URL Slug**: /dental-implants
**Sections**: 8

### GHL AI Builder Prompt

> Build a Dental Implants treatment page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO
> Full-width hero. Centre-aligned:
> - Breadcrumb: "Home > Services > Dental Implants"
> - Headline (H1): "Dental Implants"
> - Subheadline: "Permanent, natural-looking tooth replacement. Restore your smile, your confidence, and your ability to eat and speak comfortably."
> - Two buttons: "Book a Free Implant Consultation" (primary blue, links to [BOOKING_URL]) and "Call [PHONE]" (outlined)
>
> SECTION 2 — WHAT ARE IMPLANTS
> Two-column layout. Left: image placeholder (implant diagram or cross-section illustration). Right:
> - Heading (H2): "What Are Dental Implants?"
> - Paragraph: "A dental implant is a small titanium post that is surgically placed into the jawbone to replace the root of a missing tooth. Once the implant has integrated with the bone (a process called osseointegration, which takes 3 to 6 months), a custom-made porcelain crown is attached on top."
> - Paragraph: "The result is a replacement tooth that looks, feels, and functions exactly like a natural tooth. Unlike dentures, implants are fixed in place — there is no slipping, no adhesive, and no removal for cleaning. Unlike bridges, implants do not require the adjacent healthy teeth to be filed down."
> - Paragraph: "At [BUSINESS_NAME], our experienced implant dentist uses 3D imaging and guided surgery techniques to plan and place implants with precision, ensuring predictable results and a comfortable experience."
>
> SECTION 3 — BENEFITS
> Section heading (H2): "Why Choose Dental Implants?"
> Five benefit cards (3 columns top row, 2 centred bottom row):
> 1. "Look Natural" — "Implant crowns are custom-matched to your surrounding teeth in shape, size, and shade. No one will know the difference."
> 2. "Feel Natural" — "Because implants fuse with your jawbone, they feel like your own teeth. Eat, speak, and smile with complete confidence."
> 3. "Preserve Bone" — "When you lose a tooth, the jawbone begins to shrink. Implants stimulate the bone just like natural roots, preventing bone loss and maintaining your facial structure."
> 4. "Long-Lasting" — "With proper care, dental implants can last a lifetime. They are the most durable and reliable tooth replacement option available."
> 5. "Protect Healthy Teeth" — "Unlike bridges, implants stand alone. There is no need to grind down neighbouring healthy teeth to support the restoration."
>
> SECTION 4 — PROCESS TIMELINE
> Section heading (H2): "The Implant Process"
> A horizontal 6-step timeline:
> 1. "Free Consultation" — "We assess your suitability with a thorough examination, 3D CT scan, and discussion of your options and goals. No obligation."
> 2. "Treatment Planning" — "Using digital imaging, we create a precise surgical plan. We discuss the timeline, costs, and answer all your questions."
> 3. "Implant Placement" — "The titanium implant is placed into the jawbone under local anaesthetic. The procedure typically takes 30 to 60 minutes per implant. Sedation is available."
> 4. "Healing Period" — "The implant integrates with the bone over 3 to 6 months. A temporary tooth can be worn during this time so you are never without a smile."
> 5. "Abutment and Impression" — "Once healed, a small connector (abutment) is attached and we take impressions for your custom crown."
> 6. "Final Crown" — "Your porcelain crown is fitted, adjusted for perfect bite and appearance. You leave with a complete, permanent, natural-looking tooth."
>
> SECTION 5 — PRICING
> Section heading (H2): "Implant Pricing"
> Three pricing cards:
> 1. "Single Tooth Implant" — Price: From £2,000 — "Includes titanium implant, abutment, and porcelain crown. Ideal for replacing one missing tooth."
> 2. "Implant-Supported Bridge" — Price: From £4,000 — "Two implants supporting a bridge of 3 or more teeth. Replaces multiple adjacent missing teeth without a denture."
> 3. "All-on-4 Full Arch" — Price: From £8,000 — "A complete arch of fixed teeth supported by just 4 implants. The permanent alternative to full dentures. Same-day teeth available."
> Below: "Free consultation included. 0% finance available on all implant treatments."
>
> SECTION 6 — FAQS
> Section heading (H2): "Implant FAQs"
> Five accordion FAQs:
>
> Q1: "Am I suitable for dental implants?"
> A1: "Most adults with good general health are suitable for dental implants. You need sufficient jawbone density to support the implant, which we assess with a 3D CT scan at your consultation. If bone loss has occurred, bone grafting may be possible to build up the area. Smokers and patients with uncontrolled diabetes may face higher risks, which we will discuss honestly at your consultation."
>
> Q2: "Is the procedure painful?"
> A2: "Implant placement is carried out under local anaesthetic, so you should not feel pain during the procedure. Most patients report that it is less uncomfortable than they expected — often less so than a tooth extraction. After the procedure, mild discomfort and swelling are normal for a few days and can be managed with over-the-counter painkillers. Sedation is available if you are anxious."
>
> Q3: "How long do dental implants last?"
> A3: "The titanium implant itself can last a lifetime with proper care. The porcelain crown on top typically lasts 10 to 15 years before it may need replacing due to normal wear. Regular dental check-ups, good oral hygiene, and avoiding habits like teeth grinding will help maximise the lifespan of your implants."
>
> Q4: "Can I have implants if I wear dentures?"
> A4: "Yes, many of our patients switch from removable dentures to fixed implant-supported teeth. The All-on-4 treatment is specifically designed for patients who have lost all their teeth in one or both arches. It provides a fixed, permanent set of teeth that eliminates the need for denture adhesive and the discomfort of loose dentures."
>
> Q5: "What is the success rate of dental implants?"
> A5: "Dental implants have one of the highest success rates of any surgical procedure — typically 95% to 98% over 10 years. Success depends on factors including the surgeon's experience, patient health, oral hygiene, and implant placement technique. At [BUSINESS_NAME], our implant dentist uses guided surgery and 3D planning to maximise precision and predictability."
>
> SECTION 7 — BEFORE AND AFTER
> Section heading (H2): "Real Patient Results"
> Subtext: "See how dental implants have transformed our patients' smiles."
> Three before/after placeholder pairs:
> 1. "[PATIENT_1_NAME]" — "Single implant — front tooth"
> 2. "[PATIENT_2_NAME]" — "Implant bridge — 3 missing teeth"
> 3. "[PATIENT_3_NAME]" — "All-on-4 — full arch restoration"
>
> SECTION 8 — TESTIMONIAL AND CTA
> Testimonial card:
> "I put off getting an implant for years because I was nervous about the procedure. I wish I had done it sooner. The team at [BUSINESS_NAME] were incredible from start to finish. The whole process was far more comfortable than I imagined, and the final result looks completely natural. I forget it is not my real tooth." — Mark G., 5 stars
>
> CTA:
> - Heading (H2): "Ready to Restore Your Smile?"
> - Subtext: "Book your free implant consultation today. No obligation."
> - Button: "Book Free Consultation" (primary blue, links to [BOOKING_URL])
> - Text link: "Or call us on [PHONE]"
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /dental-implants.
2. Build 8 sections using Custom Code blocks.
3. The 6-step timeline may need a scrollable horizontal layout on mobile or a vertical stack.
4. Before/after placeholders: clearly mark for client photo replacement.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 10: Invisalign
**GHL Page Type**: Website Page
**URL Slug**: /invisalign
**Sections**: 8

### GHL AI Builder Prompt

> Build an Invisalign treatment page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO
> Full-width hero. Centre-aligned:
> - Breadcrumb: "Home > Services > Invisalign"
> - Headline (H1): "Invisalign Clear Aligners"
> - Subheadline: "Straighten your teeth discreetly with the world's most advanced clear aligner system. No metal braces. No lifestyle compromises."
> - Two buttons: "Book a Free Invisalign Consultation" (primary blue, links to [BOOKING_URL]) and "Call [PHONE]" (outlined)
>
> SECTION 2 — WHAT IS INVISALIGN
> Two-column layout. Left: image placeholder (clear aligner being held or worn). Right:
> - Heading (H2): "What Is Invisalign?"
> - Paragraph: "Invisalign is the world's leading clear aligner system, used to straighten teeth without traditional metal braces. Instead of brackets and wires, Invisalign uses a series of custom-made, virtually invisible plastic trays that gradually move your teeth into their ideal position."
> - Paragraph: "Each set of aligners is worn for 1 to 2 weeks before moving to the next set in the series. The aligners are removable, so you can eat, drink, brush, and floss normally. Most people will not even notice you are wearing them."
> - Paragraph: "At [BUSINESS_NAME], we are a certified Invisalign provider. Your treatment starts with a digital scan (no messy impressions) and includes a 3D simulation showing you exactly how your teeth will move and what your final result will look like — before you even begin."
>
> SECTION 3 — BENEFITS
> Section heading (H2): "Why Choose Invisalign?"
> Five benefit cards:
> 1. "Nearly Invisible" — "Clear, transparent aligners that are virtually undetectable when worn. Straighten your teeth without anyone knowing."
> 2. "Removable" — "Take your aligners out to eat, drink, brush, and floss. No food restrictions. No difficulty cleaning your teeth."
> 3. "Comfortable" — "Smooth, custom-fitted plastic with no sharp wires or brackets. Gentle, consistent pressure moves your teeth gradually."
> 4. "Predictable Results" — "Advanced 3D planning shows your expected outcome before treatment starts. You will see exactly how your smile will look."
> 5. "Fewer Appointments" — "Check-ups are typically every 6 to 8 weeks. Less chair time than traditional braces, fitting around your busy schedule."
>
> SECTION 4 — PROCESS
> Section heading (H2): "How Invisalign Works"
> A horizontal 5-step timeline:
> 1. "Free Consultation" — "We assess your teeth, discuss your goals, and confirm you are a suitable candidate for Invisalign."
> 2. "Digital Scan" — "We take a precise 3D digital scan of your teeth. No messy impressions. You will see a simulation of your expected results on screen."
> 3. "Custom Aligners" — "Your bespoke aligners are manufactured using advanced 3D printing technology and delivered to the practice."
> 4. "Wear and Progress" — "You wear each set of aligners for 20-22 hours per day, changing to a new set every 1-2 weeks. Regular check-ups monitor your progress."
> 5. "Retainers" — "Once your teeth have reached their final position, you wear retainers to maintain your beautiful new smile long-term."
>
> SECTION 5 — PRICING
> Section heading (H2): "Invisalign Pricing"
> Three pricing cards:
> 1. "Invisalign Lite" — Price: From £2,500 — "For mild to moderate cases. Up to 14 aligners. Ideal for minor crowding, small gaps, or relapse after previous orthodontic treatment. Treatment time: 3 to 6 months."
> 2. "Invisalign Comprehensive" — Price: From £3,500 — Badge: "Most Popular" — "For moderate to complex cases. Unlimited aligners until your treatment goal is achieved. Suitable for crowding, spacing, overbite, underbite, and crossbite. Treatment time: 12 to 18 months."
> 3. "Monthly Payment Plan" — Price: From £80/month — "Spread the cost with 0% finance. Subject to status. Apply at your consultation."
> Below: "Free consultation included. No obligation. See your expected results before you commit."
>
> SECTION 6 — FAQS
> Section heading (H2): "Invisalign FAQs"
> Five accordion FAQs:
>
> Q1: "How long does Invisalign treatment take?"
> A1: "Treatment time varies depending on the complexity of your case. Invisalign Lite for mild cases typically takes 3 to 6 months. Invisalign Comprehensive for more complex cases takes 12 to 18 months. Your dentist will give you an estimated timeline at your free consultation."
>
> Q2: "Does Invisalign hurt?"
> A2: "Most patients experience mild pressure or tightness for the first day or two after switching to a new set of aligners. This is a sign that the aligners are working. The discomfort is generally much less than traditional braces and can be managed with over-the-counter painkillers if needed."
>
> Q3: "Can I eat normally with Invisalign?"
> A3: "Yes. One of the biggest advantages of Invisalign is that the aligners are removable. You take them out to eat and drink (anything other than water), so there are no food restrictions. Simply brush your teeth before putting your aligners back in."
>
> Q4: "How often do I need to wear the aligners?"
> A4: "For the best results, you should wear your aligners for 20 to 22 hours per day. Remove them only for eating, drinking (anything other than water), and brushing your teeth. Compliance is important — wearing them less than recommended may extend your treatment time or affect your results."
>
> Q5: "Am I suitable for Invisalign?"
> A5: "Invisalign can treat a wide range of orthodontic issues including crowding, spacing, overbite, underbite, crossbite, and open bite. The best way to find out if you are suitable is to book a free consultation. We will examine your teeth, take a scan, and let you know whether Invisalign is the right option for you."
>
> SECTION 7 — BEFORE AND AFTER
> Section heading (H2): "Invisalign Results"
> Three before/after placeholder pairs:
> 1. "[PATIENT_1_NAME]" — "Crowding corrected — 8 months"
> 2. "[PATIENT_2_NAME]" — "Gap closure — 5 months"
> 3. "[PATIENT_3_NAME]" — "Overbite correction — 14 months"
>
> SECTION 8 — TESTIMONIAL AND CTA
> Testimonial:
> "I always wanted straighter teeth but could not face the thought of metal braces as an adult. Invisalign was the perfect solution. Nobody at work even noticed I was having treatment. Twelve months later, I have the smile I have always wanted. The team at [BUSINESS_NAME] made it so easy." — Olivia S., 5 stars
>
> CTA:
> - Heading (H2): "Start Your Invisalign Journey"
> - Subtext: "Book your free consultation and see your new smile before you begin."
> - Button: "Book Free Consultation" (primary blue, links to [BOOKING_URL])
> - Text link: "Or call us on [PHONE]"
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /invisalign.
2. Build 8 sections using Custom Code blocks.
3. Mark all before/after image areas as placeholders for client photos.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 11: Cosmetic Dentistry
**GHL Page Type**: Website Page
**URL Slug**: /cosmetic-dentistry
**Sections**: 5

### GHL AI Builder Prompt

> Build a Cosmetic Dentistry overview page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO
> Full-width hero. Centre-aligned:
> - Breadcrumb: "Home > Services > Cosmetic Dentistry"
> - Headline (H1): "Cosmetic Dentistry"
> - Subheadline: "Transform your smile with expert cosmetic treatments tailored to your goals. From subtle enhancements to complete smile makeovers."
> - Two buttons: "Book a Cosmetic Consultation" (primary blue, links to [BOOKING_URL]) and "Call [PHONE]" (outlined)
>
> SECTION 2 — TREATMENT OVERVIEW CARDS
> Section heading (H2): "Our Cosmetic Treatments"
> Subtext: "Every smile is unique. We offer a range of cosmetic treatments that can be combined to achieve your perfect result."
> Five treatment cards (large cards, each with image placeholder, heading, description, starting price, and link):
>
> 1. Image placeholder. "Teeth Whitening" — "Professional whitening that lightens your teeth by up to eight shades. Choose fast in-surgery treatment or convenient take-home kits with custom-fitted trays." — From £300 — Link: /teeth-whitening
>
> 2. Image placeholder. "Composite Bonding" — "Reshape chipped, cracked, or uneven teeth in a single appointment with tooth-coloured composite resin. No drilling, no injections, and an immediate transformation. Results are natural-looking and can last 5 to 7 years with care." — From £200
>
> 3. Image placeholder. "Porcelain Veneers" — "Ultra-thin porcelain shells custom-crafted and bonded to the front of your teeth. Veneers correct chips, stains, gaps, and misalignment for a flawless, natural appearance. They are stain-resistant and can last 10 to 15 years." — From £500
>
> 4. Image placeholder. "Smile Makeover" — "A comprehensive, personalised treatment plan that combines multiple cosmetic procedures to completely transform your smile. Begins with a digital smile design consultation where you see your predicted results before any treatment starts." — From £2,000
>
> 5. Image placeholder. "Gum Contouring" — "Reshape an uneven or excessive gum line to create a more balanced, symmetrical smile. This gentle laser procedure removes excess gum tissue with minimal discomfort and a fast recovery time." — From £300
>
> SECTION 3 — SMILE MAKEOVER PROCESS
> Section heading (H2): "Your Smile Makeover Journey"
> A horizontal 4-step timeline:
> 1. "Smile Consultation" — "We listen to your goals, assess your teeth, and discuss the options. Photographs and digital scans allow us to design your new smile together."
> 2. "Digital Smile Design" — "Using advanced software, we create a 3D preview of your expected results. You see your new smile before committing to any treatment."
> 3. "Tailored Treatment Plan" — "We recommend the combination of treatments that will achieve your goals most effectively. Clear pricing, timeline, and finance options are provided."
> 4. "Your New Smile" — "Treatment is delivered over one or more appointments depending on the plan. The final result is a confident, natural smile that you are proud to show."
>
> SECTION 4 — FAQS
> Section heading (H2): "Cosmetic Dentistry FAQs"
> Four accordion FAQs:
>
> Q1: "Is cosmetic dentistry painful?"
> A1: "Most cosmetic treatments involve minimal or no discomfort. Procedures like composite bonding and whitening are usually painless. Veneers require light preparation of the tooth surface, which is done under local anaesthetic. Your comfort is always our priority, and we will discuss what to expect at every stage."
>
> Q2: "How do I know which treatment is right for me?"
> A2: "The best way to find out is to book a cosmetic consultation. Your dentist will assess your teeth, listen to your goals, and recommend the treatments that will give you the results you are looking for. There is no pressure and no obligation."
>
> Q3: "Can cosmetic treatments be combined?"
> A3: "Absolutely. In fact, the best cosmetic results often come from combining treatments. For example, whitening to brighten your overall shade, bonding to fix a chipped tooth, and a veneer on a discoloured tooth can work together to create a beautiful, cohesive result. This is what a smile makeover is all about."
>
> Q4: "Is finance available for cosmetic treatments?"
> A4: "Yes, we offer 0% finance on cosmetic treatments over £500. You can spread the cost over 6 to 12 months with no interest. This makes even comprehensive smile makeovers affordable. Speak to our team at your consultation for details."
>
> SECTION 5 — CTA
> Full-width blue gradient banner:
> - Heading (H2): "Ready to Love Your Smile?"
> - Subtext: "Book a free cosmetic consultation and let us help you design the smile you have always wanted."
> - Button: "Book Consultation" (white button, links to [BOOKING_URL])
> - Text: "Or call us on [PHONE]"
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /cosmetic-dentistry.
2. Build 5 sections using Custom Code blocks.
3. Treatment cards should be larger than standard cards to accommodate image placeholders and longer descriptions.
4. Link the Teeth Whitening card to /teeth-whitening.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 12: Emergency Dental
**GHL Page Type**: Website Page
**URL Slug**: /emergency
**Sections**: 7

### GHL AI Builder Prompt

> Build an Emergency Dental page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Use red #ef4444 as an accent for urgent elements. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — URGENT BANNER
> A prominent, full-width banner at the top with a red (#ef4444) background and white text:
> - Large text: "Dental Emergency?"
> - Subtext: "Call us now for same-day emergency appointments."
> - Very large phone number: [EMERGENCY_PHONE] (clickable tel: link)
> - Opening hours note: "Mon-Fri 8am-6pm, Sat 9am-2pm. Out-of-hours: call the number above for our emergency line."
>
> SECTION 2 — COMPACT HERO
> Below the urgent banner:
> - Breadcrumb: "Home > Emergency Dental"
> - Headline (H1): "Emergency Dental Care"
> - Subheadline: "We keep same-day emergency appointments available every day. If you are in pain, have swelling, or have suffered dental trauma, call us immediately and we will see you as quickly as possible."
>
> SECTION 3 — COMMON EMERGENCIES
> Section heading (H2): "Common Dental Emergencies"
> A list of common emergencies, each with a short description. Display as cards or a clear list:
> 1. "Severe Toothache" — "Persistent, throbbing pain that over-the-counter painkillers cannot control. May indicate infection, abscess, or nerve damage."
> 2. "Knocked-Out Tooth" — "A tooth that has been completely dislodged from its socket due to impact or trauma. Time is critical — seek help within 30 minutes."
> 3. "Broken or Chipped Tooth" — "A tooth that has fractured, cracked, or had a piece break off. May cause sharp edges, sensitivity, or pain."
> 4. "Lost Crown or Filling" — "A filling or crown that has come loose or fallen out, exposing the underlying tooth to sensitivity and further damage."
> 5. "Dental Abscess" — "Swelling in the gum or face, often accompanied by a bad taste, fever, or difficulty swallowing. Requires urgent treatment."
> 6. "Bleeding That Will Not Stop" — "Persistent bleeding from the gums, extraction site, or mouth injury that does not stop after applying pressure for 15 minutes."
> 7. "Damaged Brace or Wire" — "A broken bracket, loose wire, or orthodontic appliance causing pain or irritation inside the mouth."
>
> SECTION 4 — FIRST AID ADVICE
> Section heading (H2): "What to Do Before You Reach Us"
> Four advice cards:
> 1. "Toothache" — "Rinse your mouth with warm salt water. Take ibuprofen or paracetamol (not aspirin) for pain relief. Do not place aspirin directly on the gum. Apply a cold compress to the outside of your cheek if there is swelling."
> 2. "Knocked-Out Tooth" — "Pick up the tooth by the crown (white part), not the root. Rinse gently with milk if dirty. Try to push it back into the socket and bite down on a clean cloth. If you cannot reinsert it, place it in milk. Get to us within 30 minutes for the best chance of saving it."
> 3. "Broken Tooth" — "Rinse your mouth with warm water. If there is bleeding, apply gentle pressure with gauze. Use a cold compress on the outside of your cheek. Save any broken pieces. Avoid chewing on the affected side."
> 4. "Swelling" — "Apply a cold compress to the outside of your face (20 minutes on, 20 minutes off). Do not apply heat. Take recommended painkillers. If swelling is severe, spreading, or you have difficulty breathing or swallowing, go to A&E immediately."
>
> SECTION 5 — PRICING
> Section heading (H2): "Emergency Pricing"
> Two cards:
> 1. "Emergency Consultation" — Price: From £80 — "Includes examination, X-rays if needed, diagnosis, and treatment advice. Your dentist will explain all options and costs before any treatment begins."
> 2. "Emergency Treatment" — Price: From £100 — "Treatment to relieve pain and stabilise your condition. May include temporary fillings, drainage of abscess, emergency extraction, or prescription medication. Follow-up treatment planned separately."
> Below: "We will always discuss costs with you before proceeding with any treatment."
>
> SECTION 6 — WHEN A&E VS WHEN TO CALL US
> Section heading (H2): "When to Call Us vs When to Go to A&E"
> Two-column layout:
> Left column — "Call [BUSINESS_NAME]":
> - Severe toothache
> - Broken or chipped tooth
> - Lost filling or crown
> - Knocked-out tooth
> - Dental abscess (without breathing difficulty)
> - Bleeding from a recent extraction
> - Damaged brace or wire
>
> Right column — "Go to A&E":
> - Difficulty breathing or swallowing due to swelling
> - Heavy, uncontrollable bleeding from the mouth
> - Suspected broken jaw
> - Facial injury with deep wounds requiring stitches
> - Severe allergic reaction following dental treatment
>
> Below: "If you are unsure, call us on [EMERGENCY_PHONE] and we will advise you."
>
> SECTION 7 — OUT OF HOURS AND CTA
> Section heading (H2): "Out-of-Hours Emergencies"
> - Text: "Our emergency line is available outside standard opening hours. Call [EMERGENCY_PHONE] and follow the recorded instructions. For life-threatening emergencies, always call 999 or go to your nearest A&E."
> - Text: "NHS 111 can also provide out-of-hours dental advice and direct you to an emergency dental service in your area."
>
> CTA:
> - Heading (H2): "In Pain Right Now?"
> - Two large buttons: "Call [EMERGENCY_PHONE]" (red #ef4444 background, white text, links to tel:[EMERGENCY_PHONE]) and "Book Online" (primary blue, links to [BOOKING_URL])
>
> Mobile responsive. The urgent banner and phone number should be highly prominent and easily tappable on mobile.

### Manual Build Notes

1. Add a new Website Page with slug /emergency.
2. Section 1 (Urgent Banner): Custom Code block with red background (#ef4444), large font phone number.
3. Sections 2-7: Custom Code blocks.
4. Ensure the emergency phone number is a clickable tel: link for mobile users.
5. The red accent colour should only be used on this page for urgency elements; the rest of the page still uses blue #2563eb as primary.

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared. Consider configuring the chatbot to detect emergency keywords and display the emergency phone number prominently.

---

## Page 13: Blog Index
**GHL Page Type**: Website Page
**URL Slug**: /blog
**Sections**: 4

### GHL AI Builder Prompt

> Build a Blog Index page for a dental practice called [BUSINESS_NAME]. Clean design. Primary blue #2563eb, page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 — HERO
> Compact hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Blog"
> - Headline (H1): "Dental Health Blog"
> - Subheadline: "Expert advice, treatment guides, and oral health tips from the [BUSINESS_NAME] team."
>
> SECTION 2 — FEATURED ARTICLE
> A large featured article card spanning the full width. Two-column layout:
> Left: large image placeholder.
> Right:
> - Badge: "Featured" (blue #2563eb background, white text)
> - Category: "Prevention"
> - Headline (H2, linked): "5 Daily Habits for Healthier Teeth"
> - Excerpt: "Small changes to your daily routine can make a big difference to your oral health. Our dentists share five simple, evidence-based habits that protect your teeth and gums for life."
> - Meta: "5 min read" and "[AUTHOR_NAME], [DATE]"
> - Link: /blog/daily-habits
>
> SECTION 3 — ARTICLE GRID
> Section heading (H2): "Latest Articles"
> Three article cards in a row (1 column on mobile). Each card has an image placeholder, category badge, headline, excerpt (2 lines), read time, and link:
>
> 1. Category: "Cosmetic". Headline: "Everything You Need to Know About Teeth Whitening". Excerpt: "A comprehensive guide to professional whitening options, costs, and what to expect from your treatment." 7 min read. Link: /blog/whitening-guide
>
> 2. Category: "Family". Headline: "Your Child's First Dental Visit: What to Expect". Excerpt: "Preparing your little one for their first trip to the dentist. Tips to make it a positive experience for the whole family." 6 min read. Link: /blog/childs-first-visit
>
> 3. Category: "General". Headline: "Coming Soon". Excerpt: "More articles from our dental team are on the way. Check back soon for the latest advice and insights." [PLACEHOLDER]
>
> SECTION 4 — NEWSLETTER SIGNUP
> A full-width section with a light blue background (#eff6ff):
> - Heading (H2): "Stay Informed"
> - Subtext: "Subscribe to our newsletter for dental health tips, practice news, and exclusive offers delivered to your inbox."
> - A placeholder for a native GHL form: "[GHL NATIVE FORM — Insert here. Fields: First Name, Email. Submit button: Subscribe. Tag contact as 'Newsletter Subscriber'.]"
> - Small text: "We respect your privacy. Unsubscribe at any time."
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /blog.
2. Section 1 (Hero): Custom Code block.
3. Section 2 (Featured Article): Custom Code block with two-column layout.
4. Section 3 (Article Grid): Custom Code block with 3 cards.
5. Section 4 (Newsletter): Native GHL form element with First Name and Email fields. Tag subscribers as "Newsletter Subscriber" for workflow automation.

### Native GHL Elements Needed

- **GHL Newsletter Form**: First Name (text), Email (email). Submit button: "Subscribe". Add tag "Newsletter Subscriber" on submission. Wire to a welcome email workflow.
- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 14: Blog Article — 5 Daily Habits for Healthier Teeth
**GHL Page Type**: Website Page
**URL Slug**: /blog/daily-habits
**Sections**: 4

### GHL AI Builder Prompt

> Build a blog article page for a dental practice called [BUSINESS_NAME]. Clean, readable design optimised for long-form content. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis. Maximum content width 720px centred on the page for readability.
>
> SECTION 1 — ARTICLE HEADER
> - Breadcrumb: "Home > Blog > 5 Daily Habits for Healthier Teeth"
> - Category badge: "Prevention" (blue #2563eb)
> - Headline (H1): "5 Daily Habits for Healthier Teeth"
> - Meta line: "By [AUTHOR_NAME] | [DATE] | 5 min read"
> - Featured image placeholder (full width of content area)
>
> SECTION 2 — ARTICLE BODY
> Full article content in clean, readable typography:
>
> Introduction paragraph:
> "Your oral health is not just about what happens in the dental chair. The habits you practise every day at home have the biggest impact on the long-term health of your teeth and gums. The good news is that protecting your smile does not require anything complicated or expensive. Here are five simple, evidence-based habits that our dentists at [BUSINESS_NAME] recommend to every patient."
>
> Subheading (H2): "1. Brush Twice a Day with Fluoride Toothpaste"
> "It sounds obvious, but many people do not brush effectively. Use a soft-bristled toothbrush (electric is even better) and a fluoride toothpaste. Brush for a full two minutes, covering all surfaces — front, back, and biting surfaces of every tooth. Hold the brush at a 45-degree angle to your gum line and use gentle, circular motions rather than aggressive back-and-forth scrubbing."
> "Replace your toothbrush or brush head every three months, or sooner if the bristles are frayed. Brushing too hard or using a hard-bristled brush can damage your enamel and gums over time."
> "When to brush: Brush first thing in the morning (before or after breakfast, but if after, wait at least 30 minutes if you have eaten acidic foods) and last thing at night before bed."
>
> Subheading (H2): "2. Floss or Use Interdental Brushes Every Day"
> "Your toothbrush only cleans about 60% of the tooth surface. The spaces between your teeth harbour plaque and bacteria that brushing alone cannot reach. Flossing or using interdental brushes once a day removes this debris and significantly reduces your risk of gum disease and cavities between teeth."
> "If you find traditional floss difficult to use, try interdental brushes (such as TePe brushes), a water flosser, or floss picks. The best tool is the one you will actually use consistently. Ask your hygienist at your next visit for a personalised recommendation based on the spacing of your teeth."
>
> Subheading (H2): "3. Limit Sugary and Acidic Food and Drinks"
> "Every time you consume sugar, the bacteria in your mouth produce acid that attacks your tooth enamel. This acid attack lasts for about 30 minutes after eating or drinking. Frequent snacking on sugary foods or sipping sugary drinks throughout the day keeps your teeth under constant acid attack."
> "The key is not necessarily to eliminate sugar entirely, but to reduce the frequency of exposure. Have sugary treats with meals rather than as separate snacks. Choose water over fizzy drinks, fruit juice, and sports drinks. If you do have something acidic (citrus fruit, vinegar-based dressings, fruit juice), wait at least 30 minutes before brushing, as your enamel is temporarily softened by the acid."
>
> Subheading (H2): "4. Drink Plenty of Water"
> "Water is the best drink for your teeth. It washes away food particles and bacteria, dilutes the acids produced by oral bacteria, and keeps your mouth hydrated. A dry mouth (caused by dehydration, medication, or mouth breathing) creates an environment where bacteria thrive and decay accelerates."
> "If your tap water is fluoridated, drinking it provides an additional layer of protection for your enamel. Try to sip water throughout the day, especially after meals and snacks."
>
> Subheading (H2): "5. Do Not Skip Your Dental Check-ups"
> "Even with excellent home care, you need regular professional check-ups to catch issues that you cannot see or feel. Many dental problems — including early decay, gum disease, and oral cancer — develop painlessly in their early stages. By the time you notice symptoms, more extensive (and expensive) treatment may be needed."
> "We recommend a check-up every six months. Your dentist will examine your teeth, gums, and soft tissues, take any necessary X-rays, and carry out an oral cancer screening. Your hygienist will remove any plaque and tartar buildup that home brushing has missed."
> "Regular visits are the most cost-effective way to maintain your oral health. Prevention is always simpler, more comfortable, and cheaper than treatment."
>
> Closing paragraph:
> "Small, consistent habits make the biggest difference to your dental health. Start with these five and you will be giving your teeth and gums the best possible care between visits to [BUSINESS_NAME]. If you have any questions about your oral hygiene routine, our team is always happy to help at your next appointment."
>
> SECTION 3 — RELATED ARTICLES
> Section heading (H3): "You Might Also Like"
> Two article cards side by side:
> 1. "Everything You Need to Know About Teeth Whitening" — Category: Cosmetic — 7 min read — Link: /blog/whitening-guide
> 2. "Your Child's First Dental Visit: What to Expect" — Category: Family — 6 min read — Link: /blog/childs-first-visit
>
> SECTION 4 — CTA
> Centre-aligned:
> - Heading (H3): "Time for a Check-up?"
> - Subtext: "Book your next appointment with [BUSINESS_NAME]."
> - Button: "Book Appointment" (primary blue, links to [BOOKING_URL])
>
> Mobile responsive. Article text should be comfortable to read at 16-18px on desktop.

### Manual Build Notes

1. Add a new Website Page with slug /blog/daily-habits.
2. Section 1 (Header): Custom Code block with breadcrumb, category badge, H1, meta, and image placeholder.
3. Section 2 (Body): Custom Code block with the full article text. Use proper heading hierarchy (H2 for subheadings). Ensure content width is constrained to 720px for readability.
4. Section 3 (Related): Custom Code block with 2 article cards.
5. Section 4 (CTA): Custom Code block.
6. Set SEO meta: Title: "5 Daily Habits for Healthier Teeth | [BUSINESS_NAME] Blog". Description: "Our dentists share five evidence-based habits for better oral health. Simple daily changes to protect your teeth and gums."

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 15: Blog Article — Everything About Teeth Whitening
**GHL Page Type**: Website Page
**URL Slug**: /blog/whitening-guide
**Sections**: 4

### GHL AI Builder Prompt

> Build a blog article page for a dental practice called [BUSINESS_NAME]. Clean, readable design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis. Maximum content width 720px centred.
>
> SECTION 1 — ARTICLE HEADER
> - Breadcrumb: "Home > Blog > Everything About Teeth Whitening"
> - Category badge: "Cosmetic" (cyan #06b6d4)
> - Headline (H1): "Everything You Need to Know About Teeth Whitening"
> - Meta: "By [AUTHOR_NAME] | [DATE] | 7 min read"
> - Featured image placeholder
>
> SECTION 2 — ARTICLE BODY
>
> Introduction:
> "A brighter smile can make a remarkable difference to your confidence and the way you present yourself to the world. Teeth whitening is one of the most popular cosmetic dental treatments in the UK, and for good reason — it is safe, effective, and delivers visible results quickly. But with so many options available, from professional treatments to shop-bought products, it can be difficult to know what actually works and what is worth your money. This guide covers everything you need to make an informed decision."
>
> Subheading (H2): "Why Do Teeth Become Discoloured?"
> "Tooth discolouration falls into two categories: extrinsic (surface stains) and intrinsic (internal discolouration)."
> "Extrinsic stains are caused by things that come into contact with your teeth. The most common culprits are tea, coffee, red wine, tobacco, and highly pigmented foods like curries, berries, and soy sauce. These stains sit on the surface of the enamel and can often be reduced with professional cleaning and polishing."
> "Intrinsic discolouration occurs within the tooth structure itself. It can be caused by ageing (enamel thins over time, revealing the naturally yellow dentine beneath), certain medications (particularly tetracycline antibiotics taken during childhood), excessive fluoride exposure, or trauma to the tooth. These stains cannot be removed by surface cleaning alone — they require whitening treatment to lighten."
>
> Subheading (H2): "Professional vs Shop-Bought Whitening"
> "The most important thing to understand is that professional whitening and over-the-counter products are not the same thing."
> "Professional whitening uses higher-concentration hydrogen peroxide or carbamide peroxide gels (up to 6% hydrogen peroxide in the UK, as regulated by the EU Cosmetics Directive). These are applied by a qualified dentist or using custom-fitted trays. The results are significantly more effective, more even, and longer-lasting."
> "Shop-bought whitening products — strips, pens, toothpastes, LED kits sold online — use much lower concentrations (typically 0.1% hydrogen peroxide or none at all). They may remove some surface stains, but they cannot change the intrinsic colour of your teeth. The generic, one-size-fits-all trays often included with these products can cause uneven whitening and gum irritation."
> "Whitening treatments offered by beauticians, salons, and mobile operators are illegal in the UK if performed by someone who is not a registered dental professional. These unregulated treatments carry serious risks including chemical burns, uneven results, and enamel damage."
>
> Subheading (H2): "Types of Professional Whitening"
> "At [BUSINESS_NAME], we offer two professional whitening methods:"
> "In-surgery power whitening (from £400): A high-concentration whitening gel is applied to your teeth in the dental chair and activated with a special LED light. The entire appointment takes about 60 minutes and delivers immediate results — typically 4 to 8 shades lighter in a single session. This is ideal if you want fast results, perhaps before a special occasion."
> "Take-home whitening (from £300): We create custom-fitted whitening trays from impressions of your teeth. You apply a professional-strength whitening gel to the trays and wear them for 30 to 60 minutes per day (or overnight, depending on the product) for 2 to 3 weeks. The results build gradually and are just as effective as in-surgery whitening. You keep the trays for future top-ups."
> "Combined package (from £500): An in-surgery session for an immediate boost, followed by a take-home kit for maintenance and additional whitening. This is our most popular option and offers the best long-term value."
>
> Subheading (H2): "What to Expect During Treatment"
> "Before any whitening treatment, your dentist will carry out an examination to ensure your teeth are healthy and suitable for whitening. Any decay, gum disease, or sensitivity issues should be treated first."
> "Whitening does not work on crowns, veneers, fillings, or other dental restorations — these will remain their current colour. If you have visible restorations, your dentist will discuss this with you and may recommend replacing them after whitening to match your new shade."
> "During in-surgery whitening, a protective barrier is applied to your gums before the gel is placed on your teeth. You will sit comfortably while the light activates the gel. The process is painless, though some patients feel a mild tingling sensation."
> "Some patients experience temporary tooth sensitivity during or after whitening. This is normal and typically resolves within 24 to 48 hours. Using a sensitive toothpaste for a week before and after treatment can help minimise this."
>
> Subheading (H2): "How Long Do Results Last?"
> "Professional whitening results typically last 12 to 18 months, though this varies depending on your diet and habits. Tea, coffee, red wine, and tobacco will gradually re-stain your teeth over time."
> "To maintain your results: brush twice daily with a whitening toothpaste, avoid heavy staining immediately after treatment, use a straw for cold staining drinks, attend regular hygiene appointments for professional cleaning, and use your take-home trays for periodic top-ups (we can supply additional gel syringes)."
>
> Subheading (H2): "Is Whitening Safe?"
> "Yes, professional teeth whitening is safe when performed by a qualified dental professional. The products used in UK dental practices are regulated, clinically tested, and approved for dental use. Your dentist assesses your suitability before treatment and monitors the process to ensure your safety."
> "The main side effect is temporary sensitivity, which affects some patients during or shortly after treatment. This is not harmful and resolves on its own. Serious complications from professional whitening are extremely rare."
>
> Subheading (H2): "How Much Does Whitening Cost?"
> "At [BUSINESS_NAME]:"
> "- In-surgery power whitening: from £400"
> "- Take-home whitening kit: from £300"
> "- Combined package: from £500"
> "All whitening treatments include a free initial consultation. We offer 0% finance on treatments over £500, so you can spread the cost with affordable monthly payments."
>
> Closing:
> "Teeth whitening is one of the simplest ways to transform your appearance and boost your confidence. If you are considering it, the most important step is to start with a professional consultation so your dentist can assess your teeth, discuss your goals, and recommend the best approach for you."
> "Ready to get started? Book your free whitening consultation at [BUSINESS_NAME] by visiting [BOOKING_URL] or calling [PHONE]."
>
> SECTION 3 — RELATED ARTICLES
> Heading (H3): "You Might Also Like"
> Two cards:
> 1. "5 Daily Habits for Healthier Teeth" — Prevention — 5 min read — /blog/daily-habits
> 2. "Your Child's First Dental Visit" — Family — 6 min read — /blog/childs-first-visit
>
> SECTION 4 — CTA
> - Heading (H3): "Interested in Teeth Whitening?"
> - Subtext: "Book a free consultation to discuss your options."
> - Button: "Book Whitening Consultation" (primary blue, links to [BOOKING_URL])
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /blog/whitening-guide.
2. Section 1 (Header): Custom Code block.
3. Section 2 (Body): Custom Code block with full article. Constrain width to 720px.
4. Section 3 (Related): Custom Code block with 2 article cards.
5. Section 4 (CTA): Custom Code block.
6. SEO meta: Title: "Everything About Teeth Whitening | [BUSINESS_NAME] Blog". Description: "Your complete guide to professional teeth whitening: types, costs, results, and what to expect. Expert advice from [BUSINESS_NAME]."

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Page 16: Blog Article — Your Child's First Dental Visit
**GHL Page Type**: Website Page
**URL Slug**: /blog/childs-first-visit
**Sections**: 4

### GHL AI Builder Prompt

> Build a blog article page for a dental practice called [BUSINESS_NAME]. Clean, readable design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis. Maximum content width 720px centred.
>
> SECTION 1 — ARTICLE HEADER
> - Breadcrumb: "Home > Blog > Your Child's First Dental Visit"
> - Category badge: "Family" (green #10b981)
> - Headline (H1): "Your Child's First Dental Visit: What to Expect"
> - Meta: "By [AUTHOR_NAME] | [DATE] | 6 min read"
> - Featured image placeholder
>
> SECTION 2 — ARTICLE BODY
>
> Introduction:
> "Taking your child to the dentist for the first time is an important milestone. It sets the tone for their relationship with dental care for years to come. A positive first experience helps build good habits and confidence, while a negative one can create anxiety that lasts well into adulthood. The good news is that with a little preparation, your child's first dental visit can be a genuinely enjoyable experience for both of you. Here is everything you need to know."
>
> Subheading (H2): "When Should My Child First Visit the Dentist?"
> "The British Society of Paediatric Dentistry recommends that children visit the dentist by their first birthday, or within six months of their first tooth appearing — whichever comes first. This may seem early, but there are good reasons for it."
> "Early visits allow the dentist to check that teeth and jaws are developing normally, identify any potential issues before they become problems, and — most importantly — help your child become comfortable with the dental environment in a relaxed, pressure-free way. At this age, the 'examination' is really just a quick, gentle look while your child sits on your lap."
>
> Subheading (H2): "How to Prepare Your Child"
> "Preparation depends on your child's age, but here are some general tips:"
> "Keep it casual and positive. Talk about the visit in simple, upbeat terms. Avoid using words like 'hurt', 'needle', 'drill', or 'pain' — even in reassuring phrases like 'it will not hurt'. Children pick up on these words and may become anxious. Instead, explain that the dentist is going to 'count your teeth' and 'make sure they are healthy'."
> "Read a children's book about going to the dentist. There are many excellent picture books that normalise the experience in a fun, child-friendly way. Reading one together in the days before the visit can help your child know what to expect."
> "Play pretend. Let your child practise being a dentist with a teddy bear or doll. Open teddy's mouth, count teddy's teeth, and praise teddy for being so brave. Role-playing reduces uncertainty and builds familiarity."
> "Avoid transferring your own anxiety. If you are nervous about the dentist yourself, try not to let your child sense this. Children are remarkably perceptive. Stay calm, positive, and matter-of-fact."
> "Choose the right time of day. Book the appointment at a time when your child is usually well-rested and fed. A tired, hungry child is far more likely to be irritable and uncooperative."
>
> Subheading (H2): "What Happens at the First Visit"
> "The first visit is deliberately short and gentle. At [BUSINESS_NAME], a typical first visit for a young child includes:"
> "A warm welcome from our team. Our reception staff are experienced with young children and will help your child feel at ease from the moment you arrive."
> "A chat with the dentist. Your dentist will ask about your child's general health, diet, brushing habits, and any concerns you may have. This is a great opportunity to ask questions."
> "A gentle examination. For very young children (under 2), this is usually done with your child sitting on your lap. The dentist will gently look at the teeth, gums, and bite using a small mirror and a gloved finger. No instruments, no X-rays, and no treatment at this stage."
> "Advice and guidance. Your dentist will give you age-appropriate advice on brushing techniques, fluoride toothpaste, diet, thumb-sucking, dummies, and when to expect new teeth."
> "A reward. Because every young visitor deserves a sticker."
>
> Subheading (H2): "Tips for a Positive Experience"
> "Arrive early so your child can get comfortable in the waiting area. We have a dedicated children's corner with books and activities."
> "Let the dental team lead. Our clinicians are trained in child-friendly communication techniques. They will explain things to your child in age-appropriate language and set the pace based on your child's comfort level."
> "Stay positive afterwards. Praise your child for their bravery regardless of how the visit went. Avoid saying things like 'see, it was not scary' as this reinforces the idea that it was supposed to be scary. Simply say 'well done, you did brilliantly'."
> "Make it routine. Regular visits (every six months) normalise the experience. The more familiar the environment and the team become, the more relaxed your child will be."
>
> Subheading (H2): "Common Concerns from Parents"
>
> "My child will not open their mouth."
> "This is completely normal, especially for very young children. Our dentists are patient and skilled at working with reluctant little ones. Sometimes we just look at the teeth while the child smiles or laughs. The important thing is that the experience is positive — we never force anything. There will always be another visit."
>
> "My child is very anxious."
> "Please let us know when you book so we can allow extra time and prepare accordingly. We use a 'tell-show-do' approach: we explain what we are going to do in simple terms, show the child any instruments we will use, and then proceed gently. Building trust takes time, and we are happy to go at your child's pace."
>
> "Are X-rays safe for children?"
> "We only take X-rays when clinically necessary, and we use digital X-rays which emit very low levels of radiation. For most young children, X-rays are not needed at the first few visits. When they are required (usually from around age 5-6), the dose is extremely small and the benefits of early detection far outweigh the negligible risk."
>
> Subheading (H2): "Is Children's Dental Treatment Free?"
> "Yes. All NHS dental treatment is free for children under 18 (and under 19 if in full-time education). This includes check-ups, fillings, extractions, and other necessary treatments. You do not need to pay anything or have an exemption certificate."
>
> Closing:
> "Your child's first dental visit is the beginning of a lifetime of good oral health. By starting early, keeping it positive, and visiting regularly, you are giving your child the best possible foundation for healthy teeth and a confident smile. At [BUSINESS_NAME], we love welcoming young patients and our team is dedicated to making every visit a happy one."
> "Ready to book your child's first visit? Book online at [BOOKING_URL] or call us on [PHONE]."
>
> SECTION 3 — RELATED ARTICLES
> Heading (H3): "You Might Also Like"
> Two cards:
> 1. "5 Daily Habits for Healthier Teeth" — Prevention — 5 min read — /blog/daily-habits
> 2. "Everything About Teeth Whitening" — Cosmetic — 7 min read — /blog/whitening-guide
>
> SECTION 4 — CTA
> - Heading (H3): "Book Your Child's First Visit"
> - Subtext: "New patients welcome. No registration fee. Our team will make it a great experience."
> - Button: "Book Appointment" (primary blue, links to [BOOKING_URL])
>
> Mobile responsive.

### Manual Build Notes

1. Add a new Website Page with slug /blog/childs-first-visit.
2. Section 1 (Header): Custom Code block.
3. Section 2 (Body): Custom Code block with full article. Constrain width to 720px.
4. Section 3 (Related): Custom Code block with 2 article cards.
5. Section 4 (CTA): Custom Code block.
6. SEO meta: Title: "Your Child's First Dental Visit | [BUSINESS_NAME] Blog". Description: "What to expect, how to prepare, and tips for a positive experience. A parent's complete guide from [BUSINESS_NAME]."

### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Appendix: Page Summary Table

| Page | Slug | Tier | Sections | Native GHL Elements |
|------|------|------|----------|---------------------|
| 1. Homepage | / | Ignite AI+ | 8 | Header, footer, map, chat |
| 2. Services | /services | Ignite AI+ | 5 | Header, footer, chat |
| 3. About Us | /about | Elevate AI+ | 7 | Header, footer, chat |
| 4. Contact | /contact | Elevate AI+ | 4 | Header, footer, contact form, map, chat |
| 5. Book Online | /booking | Ignite AI+ | 3 | Header, footer, calendar widget, chat |
| 6. Reviews | /reviews | Momentum AI+ | 5 | Header, footer, chat |
| 7. FAQ | /faq | Apex AI | 3 | Header, footer, chat |
| 8. Teeth Whitening | /teeth-whitening | Momentum AI+ | 8 | Header, footer, chat |
| 9. Dental Implants | /dental-implants | Momentum AI+ | 8 | Header, footer, chat |
| 10. Invisalign | /invisalign | Momentum AI+ | 8 | Header, footer, chat |
| 11. Cosmetic Dentistry | /cosmetic-dentistry | Apex AI | 5 | Header, footer, chat |
| 12. Emergency Dental | /emergency | Apex AI | 7 | Header, footer, chat |
| 13. Blog Index | /blog | Momentum AI+ | 4 | Header, footer, newsletter form, chat |
| 14. Blog: Daily Habits | /blog/daily-habits | Momentum AI+ | 4 | Header, footer, chat |
| 15. Blog: Whitening Guide | /blog/whitening-guide | Momentum AI+ | 4 | Header, footer, chat |
| 16. Blog: First Visit | /blog/childs-first-visit | Momentum AI+ | 4 | Header, footer, chat |

## Appendix: Shared Native GHL Setup

These elements are built once and applied across all pages:

### Header Navigation
- Logo (left)
- Menu links: Home, Services (dropdown: General, Cosmetic, Orthodontics, Implants, Emergency, Children's), About, Reviews, Blog, Contact
- CTA button (right): "Book Now" linking to /booking
- Mobile: hamburger menu with full navigation
- Sticky on scroll

### Footer
- Four columns:
  1. Practice name, address, phone, email
  2. Quick links: Home, Services, About, Reviews, Blog, Contact, Book Online
  3. Treatments: Check-up, Whitening, Implants, Invisalign, Cosmetic, Emergency
  4. Opening Hours: Mon-Fri 8-6, Sat 9-2, Sun Closed
- Bottom bar: Copyright "[BUSINESS_NAME] [YEAR]. All rights reserved." | Privacy Policy | Terms | Cookie Policy
- Social icons: Facebook, Instagram, Google (linking to [GOOGLE_REVIEW_URL])

### Chat Widget
- GHL Conversation AI widget
- Position: bottom-right corner
- Greeting: "Hello! How can we help you today?"
- Configured to answer: opening hours, location, parking, services, pricing, NHS questions, booking redirect
- Escalation: transfers to reception for complex queries

### SEO Defaults
- Meta title format: "[Page Title] | [BUSINESS_NAME] — Dental Practice in [LOCATION]"
- All pages include Open Graph tags
- FAQ page includes FAQ schema JSON-LD
- Blog articles include Article schema JSON-LD
- Sitemap submitted to Google Search Console
