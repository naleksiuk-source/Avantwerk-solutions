# Dental Practice — GHL Workflow Setup Prompts

This document provides step-by-step GHL (GoHighLevel) build instructions for all 8 dental practice automation workflows. Follow each section in order to build the workflow inside GHL's Automation → Workflows builder.

**Before you begin**: Ensure the GHL sub-account has SMS enabled with a registered UK sender number (two-way SMS required), email sending domain verified, and the Google review link stored in Location settings.

---

## Global Pre-requisites (Create These First)

Before building any workflow, set up the following shared infrastructure in GHL.

### Pipelines

Create these pipelines in **CRM → Pipelines**:

| Pipeline | Stages |
|----------|--------|
| Patient Appointments | Booked → Confirmed → Completed → No Show |
| Patient Engagement | Review Requested → Review Clicked → Review Sequence Complete |
| Recall Management | Recall Due → Recall Booked → Overdue - Manual Follow-up |
| New Patient Journey | New Registration → Welcomed |
| Lead Nurture | New Enquiry → Converted → Cold Lead |
| Cancellation Recovery | Cancelled → Rebooked → Not Recovered |
| Treatment Plan Conversion | Plan Presented → Accepted → Pending - Manual Review |

### Custom Fields

Create these in **Settings → Custom Fields → Contact**:

| Field Name | Field Type | Used By |
|------------|-----------|---------|
| `last_checkup_date` | Date | Recall Reminder |
| `enquiry_source` | Dropdown (Website Form, Chatbot, Phone, Social Media) | New Patient Nurture |
| `enquiry_interest` | Single Line Text | New Patient Nurture |
| `new_patient_offer` | Single Line Text | New Patient Nurture |
| `cancellation_reason` | Dropdown (Schedule Conflict, Cost, Found Another Dentist, Feeling Better, Other) | Cancellation Recovery |
| `treatment_plan_type` | Dropdown (Implant, Invisalign, Crown, Whitening, Veneer, Bonding, Bridge, Root Canal, Other) | Treatment Plan Follow-up |
| `treatment_plan_value` | Number (Currency) | Treatment Plan Follow-up |
| `treatment_plan_date` | Date | Treatment Plan Follow-up |
| `treating_dentist` | Single Line Text | Treatment Plan Follow-up |
| `payment_plan_available` | Dropdown (Yes, No) | Treatment Plan Follow-up |
| `patient_type` | Dropdown (NHS, Private) | Recall Reminder, New Patient Welcome |
| `birthday_offer_code` | Single Line Text | Birthday/Loyalty |
| `birthday_offer_description` | Single Line Text | Birthday/Loyalty |
| `birthday_offer_expiry` | Date | Birthday/Loyalty |
| `waitlist` | Dropdown (Yes, No) | Cancellation Recovery |
| `waitlist_preference` | Multi Line Text | Cancellation Recovery |

Create these in **Settings → Custom Fields → Location** (if not already present):

| Field Name | Field Type | Notes |
|------------|-----------|-------|
| `google_review_link` | URL | Direct Google review URL for the practice |
| `booking_link` | URL | Online booking page URL |
| `parking_info` | Multi Line Text | Parking instructions |

### Tags

Create all of the following tags in **Settings → Tags** (or they will be auto-created by workflows):

**Appointment Reminder**: `appointment-booked`, `appointment-confirmed`, `appointment-no-show`, `appointment-completed`

**Review Request**: `review-requested`, `review-clicked`, `review-left`, `review-requested-complete`

**Recall Reminder**: `recall-due`, `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-booked`, `recall-sequence-complete`, `recall-overdue`

**New Patient Welcome**: `new-patient`, `welcome-email-sent`, `welcome-followup-sent`, `new-patient-welcomed`

**New Patient Nurture**: `enquiry-no-booking`, `nurture-email-1-sent`, `nurture-sms-sent`, `nurture-email-2-sent`, `nurture-email-3-sent`, `nurture-converted`, `nurture-sequence-complete`, `nurture-cold`

**Cancellation Recovery**: `appointment-cancelled`, `recovery-sms-sent`, `recovery-email-sent`, `waitlist-notified`, `cancellation-rebooked`, `cancellation-recovered`, `cancellation-recovery-complete`

**Birthday/Loyalty**: `birthday-triggered`, `birthday-email-sent`, `birthday-offer-redeemed`, `birthday-complete`

**Treatment Plan Follow-up**: `treatment-plan-presented`, `tp-checkin-sent`, `tp-reminder-sent`, `tp-reengage-sent`, `treatment-plan-accepted`, `treatment-plan-declined`, `treatment-plan-followup-complete`

**General**: `inactive-patient`, `do-not-contact`, `frequent-canceller`

---

## Workflow 1: Appointment Reminder

**Package tier**: Ignite AI (included in all tiers)
**Estimated build time**: 45-60 minutes

### Pre-requisites
- Pipeline: Patient Appointments (with stages: Booked, Confirmed, Completed, No Show)
- Tags: `appointment-booked`, `appointment-confirmed`, `appointment-no-show`, `appointment-completed`
- GHL Calendar set up with appointment types (Check-up, Hygiene, etc.)
- Two-way SMS enabled on the sub-account
- Email templates built (see Email/SMS Content below)

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **Appointment Reminder**
3. Set workflow status to **Draft** until testing is complete

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Appointment Status**
6. Trigger filter: Appointment Status = **Booked** (or "Confirmed" if your calendar uses that as the initial status)
7. Calendar: Select **All Calendars** (or specific calendars if needed)

**Step 1 — Add Tag + Move Pipeline:**

8. Add action: **Add Tag** → `appointment-booked`
9. Add action: **Move Pipeline** → Pipeline: Patient Appointments → Stage: Booked

**Step 2 — Send Confirmation Email (Immediate):**

10. Add action: **Send Email**
11. Name: "Appointment Confirmation Email"
12. Use the email content from the **Appointment Confirmation Email** section below
13. Set "From": Practice Name
14. Set "Reply-to": Practice email address

**Step 3 — Condition: Is Appointment More Than 24h Away?**

15. Add action: **If/Else Condition**
16. Branch name: "Appointment > 24h away?"
17. Condition: **Appointment Start Date/Time** is more than 24 hours from now
    - In GHL, use a **Wait** action with "Wait until event start date" minus 24 hours. If the appointment is less than 24h away, the wait resolves immediately.
18. **If appointment < 24h away**: Route to the 2-hour reminder path (Step 7 below)
19. **If appointment >= 24h away**: Continue to Step 4

**Step 4 — Wait Until 24 Hours Before Appointment:**

20. Add action: **Wait**
21. Wait type: **Wait until specific date/time**
22. Date: **Appointment Start Date** minus 24 hours
23. Under Advanced Settings, tick **Wait only during business hours** and set window to 08:00-20:00. If the send time falls outside this window, it will send at the next 09:00.

**Step 5 — Condition: Is Appointment Still Active?**

24. Add action: **If/Else Condition**
25. Condition: Contact **does NOT have tag** `appointment-cancelled`
26. AND Contact **does NOT have tag** `appointment-no-show`
27. **If cancelled/rescheduled**: Add action **Remove Tag** → `appointment-booked` → **End This Path**
28. **If still active**: Continue

**Step 6 — Send 24-Hour Reminder SMS:**

29. Add action: **Send SMS**
30. Name: "24h Appointment Reminder SMS"
31. Use SMS content from the **24h Reminder SMS** section below
32. Sending window: 08:00-20:00 (configure under Advanced Settings)

**Step 7 — Condition: Wait for Reply (4 Hours):**

33. Add action: **Wait**
34. Wait time: **4 hours**
35. Add action: **If/Else Condition**
36. Branch 1 — "Replied YES": Contact replied with keyword YES or CONFIRMED
    - Add action: **Add Tag** → `appointment-confirmed`
    - Add action: **Move Pipeline** → Stage: Confirmed
37. Branch 2 — "Replied CANCEL/NO": Contact replied with keyword CANCEL or NO
    - Add action: **Add to Workflow** → Cancellation Recovery workflow
    - **End This Path**
38. Branch 3 — "No Reply": Proceed to next step

**Step 8 — Wait Until 2 Hours Before Appointment:**

39. Add action: **Wait**
40. Wait type: **Wait until specific date/time**
41. Date: **Appointment Start Date** minus 2 hours
42. Business hours constraint: if 2h-before falls outside 08:00-20:00, send at 19:00 the previous evening

**Step 9 — Condition: Is Appointment Still Active?**

43. Add action: **If/Else Condition** (same as Step 5)
44. **If cancelled**: End path
45. **If active**: Continue

**Step 10 — Send 2-Hour Reminder SMS:**

46. Add action: **Send SMS**
47. Name: "2h Appointment Reminder SMS"
48. Use SMS content from the **2h Reminder SMS** section below

**Step 11 — Wait Until After Appointment:**

49. Add action: **Wait**
50. Wait type: **Wait until specific date/time**
51. Date: **Appointment End Date** plus 2 hours (total: appointment time + 1h buffer + 2h post-visit)

**Step 12 — Condition: Did Patient Attend?**

52. Add action: **If/Else Condition**
53. Condition: Contact **has tag** `appointment-no-show`
54. **If no-show**: End path (no thank-you email)
55. **If attended**: Continue

**Step 13 — Send Post-Visit Thank You Email:**

56. Add action: **Send Email**
57. Name: "Post-Visit Thank You Email"
58. Use email content from the **Post-Visit Thank You** section below
59. Add action: **Add Tag** → `appointment-completed`
60. Add action: **Move Pipeline** → Stage: Completed

**Step 14 — End Workflow**

### Email/SMS Content

#### Appointment Confirmation Email
- **Subject**: Your appointment at {{location.name}} is confirmed
- **Body**:
```
Hi {{contact.first_name}},

Your appointment has been confirmed. Here are the details:

Appointment: {{appointment.calendar_name}}
Date & Time: {{appointment.start_time}}
Location: {{location.name}}, {{location.address}}

What to bring:
- Photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)

Need to reschedule or cancel? Please give us at least 24 hours' notice by calling {{location.phone}}.

We look forward to seeing you.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "View on Map" → link to Google Maps URL of the practice

#### 24h Reminder SMS
- **Message**:
```
Hi {{contact.first_name}}, this is a reminder of your appointment at {{location.name}} tomorrow at {{appointment.start_time}}. Reply YES to confirm or call us on {{location.phone}} to reschedule.
```

#### 2h Reminder SMS
- **Message**:
```
Hi {{contact.first_name}}, just a quick reminder -- your appointment is in 2 hours at {{appointment.start_time}}. See you soon at {{location.name}}, {{location.address}}.
```

#### Post-Visit Thank You Email
- **Subject**: Thank you for visiting {{location.name}}, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

Thank you for visiting us today at {{location.name}}. We hope everything went well.

If you have any questions about your treatment or aftercare, please do not hesitate to contact us on {{location.phone}} or reply to this email.

A few helpful reminders:
- If you experienced any numbness from anaesthetic, avoid hot drinks and food until full feeling has returned.
- Brush gently around any treated areas for the first 24 hours.
- Take any recommended pain relief as directed.

We recommend scheduling your next check-up in 6 months to keep your oral health on track. You can book online anytime.

Thank you for choosing {{location.name}}.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your Next Appointment" → link to {{location.booking_link}}

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `appointment-booked` | Tag | Entry tag, applied on trigger |
| `appointment-confirmed` | Tag | Applied when patient replies YES |
| `appointment-no-show` | Tag | Applied externally (reception marks no-show) |
| `appointment-completed` | Tag | Applied at end of workflow after attendance |
| `{{appointment.start_time}}` | System field | GHL appointment date/time |
| `{{appointment.calendar_name}}` | System field | Appointment type name |

### Testing Checklist
- [ ] Trigger fires when a new appointment is booked via online booking
- [ ] Trigger fires when a new appointment is manually created by reception
- [ ] Confirmation email sends immediately with correct merge fields
- [ ] 24h wait calculates correctly based on appointment date
- [ ] 24h SMS sends within business hours (08:00-20:00)
- [ ] Reply YES/CONFIRMED is detected and adds `appointment-confirmed` tag
- [ ] Reply CANCEL/NO triggers the Cancellation Recovery workflow
- [ ] 2h SMS sends correctly with address details
- [ ] Post-visit thank-you email does NOT send to no-shows
- [ ] Post-visit thank-you email sends approximately 2h after appointment end
- [ ] Same-day appointment (< 2h away) skips reminder SMS steps and sends only confirmation
- [ ] All merge fields render correctly (no blank {{fields}})
- [ ] Pipeline stages update at each key step
- [ ] Workflow exits cleanly when appointment is cancelled mid-sequence

---

## Workflow 2: Review Request

**Package tier**: Ignite AI (included in all tiers)
**Estimated build time**: 30-40 minutes

### Pre-requisites
- Pipeline: Patient Engagement (stages: Review Requested, Review Clicked, Review Sequence Complete)
- Tags: `appointment-completed`, `review-requested`, `review-clicked`, `review-left`, `review-requested-complete`
- Google review direct link stored in Location custom field `google_review_link`
- Email templates built (see below)
- Marketing consent tracking enabled on contacts

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **Review Request**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `appointment-completed`

**Step 1 — Condition: Already Reviewed or Recently Requested?**

7. Add action: **If/Else Condition**
8. Condition: Contact **has tag** `review-left`
9. OR Contact **has tag** `review-requested` (check if applied within last 90 days — use a date-based custom field or tag date filter if available in your GHL version)
10. **If tagged**: End workflow (exit)
11. **If not tagged**: Continue

**Step 2 — Condition: Has Marketing Consent?**

12. Add action: **If/Else Condition**
13. Condition: Contact **DND (Marketing Email)** = **OFF** (i.e., marketing email is allowed)
14. **If no consent / DND is ON**: End workflow
15. **If consent given**: Continue

**Step 3 — Wait 24 Hours:**

16. Add action: **Wait**
17. Wait time: **24 hours**
18. Advanced: If the 24h mark falls outside business hours, defer to next day at 10:00 AM

**Step 4 — Send Review Request Email:**

19. Add action: **Send Email**
20. Name: "Review Request Email"
21. Use the email content from the **Review Request Email** section below
22. Add action: **Add Tag** → `review-requested`
23. Enable **Link Click Tracking** in the email settings so GHL tracks clicks on the review link

**Step 5 — Wait 3 Days (72 hours):**

24. Add action: **Wait**
25. Wait time: **3 days**

**Step 6 — Condition: Did They Click the Review Link?**

26. Add action: **If/Else Condition**
27. Condition: **Link Clicked** in the Review Request Email (use GHL's email event trigger or link tracking)
28. **If clicked**:
    - Add action: **Add Tag** → `review-clicked`
    - Add action: **Move Pipeline** → Stage: Review Clicked
    - End workflow
29. **If not clicked**: Continue

**Step 7 — Condition: Still Has Marketing Consent?**

30. Add action: **If/Else Condition**
31. Condition: DND (Marketing Email) = OFF
32. **If unsubscribed**: End workflow
33. **If still subscribed**: Continue

**Step 8 — Send Follow-Up Review Request Email:**

34. Add action: **Send Email**
35. Name: "Review Request Follow-Up Email"
36. Use the email content from the **Review Request Follow-Up** section below

**Step 9 — Wait 48 Hours:**

37. Add action: **Wait**
38. Wait time: **48 hours**

**Step 10 — Condition: Did They Click the Review Link?**

39. Add action: **If/Else Condition**
40. Same check as Step 6 but against the follow-up email
41. **If clicked**: Add tag `review-clicked`, end workflow
42. **If not clicked**: Continue

**Step 11 — Mark Sequence Complete:**

43. Add action: **Add Tag** → `review-requested-complete`
44. Add action: **Move Pipeline** → Stage: Review Sequence Complete
45. End workflow

### Email/SMS Content

#### Review Request Email
- **Subject**: How was your visit, {{contact.first_name}}?
- **Body**:
```
Hi {{contact.first_name}},

Thank you for visiting {{location.name}} yesterday. We hope you had a positive experience with us.

We would really appreciate it if you could take 60 seconds to share your experience on Google. Your feedback helps other patients find a dental practice they can trust, and it means a lot to our team.

[BUTTON: Leave a Review]

It is quick and easy -- just click the button above and leave a star rating with a few words about your visit.

Thank you for your support.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Leave a Review" → link to `{{location.google_review_link}}`
- **Footer**: Must include unsubscribe link (marketing email)

#### Review Request Follow-Up Email
- **Subject**: We'd love to hear from you, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

We sent you a message a few days ago asking about your recent visit to {{location.name}}. If you have a moment, we would truly value your feedback.

Leaving a Google review takes less than 60 seconds and helps us continue providing excellent care to our community.

[BUTTON: Share Your Experience]

No worries if you would rather not -- we are just grateful to have you as a patient.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Share Your Experience" → link to `{{location.google_review_link}}`
- **Footer**: Must include unsubscribe link (marketing email)

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `appointment-completed` | Tag | Trigger tag (set by Appointment Reminder workflow) |
| `review-requested` | Tag | Applied after first email sent |
| `review-clicked` | Tag | Applied when Google review link is clicked |
| `review-left` | Tag | Applied manually by reception when review is confirmed on Google |
| `review-requested-complete` | Tag | Applied at end of sequence |
| `google_review_link` | Location Custom Field | Direct Google review URL |

### Testing Checklist
- [ ] Trigger fires when `appointment-completed` tag is added
- [ ] Workflow exits if contact already has `review-left` tag
- [ ] Workflow exits if contact already has `review-requested` tag (within 90 days)
- [ ] Workflow exits if contact has no marketing consent / DND is ON
- [ ] First email sends 24 hours after trigger with correct merge fields
- [ ] Google review link in the email is correct and clickable
- [ ] Link click tracking detects when the review CTA is clicked
- [ ] Follow-up email does NOT send if first email link was clicked
- [ ] Follow-up email sends 3 days after the first email
- [ ] Unsubscribe link works in both emails
- [ ] Pipeline stages update correctly
- [ ] Sequence completes and tags are applied after both emails are exhausted without clicks

---

## Workflow 3: 6-Month Recall Reminder

**Package tier**: Elevate AI
**Estimated build time**: 50-60 minutes

### Pre-requisites
- Pipeline: Recall Management (stages: Recall Due, Recall Booked, Overdue - Manual Follow-up)
- Tags: `recall-due`, `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-booked`, `recall-sequence-complete`, `recall-overdue`
- Custom field: `last_checkup_date` (Date type) — must be populated after every check-up
- Location custom field: `booking_link`
- Email + SMS templates built (see below)
- Marketing consent tracking enabled

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **6-Month Recall Reminder**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Date Based** (or **Custom Date Reminder**)
6. Custom field: `last_checkup_date`
7. Trigger: **167 days after** the custom field date (5 months and 2 weeks)
8. Time of day: **09:00 AM**

**Step 1 — Add Tag + Move Pipeline:**

9. Add action: **Add Tag** → `recall-due`
10. Add action: **Move Pipeline** → Pipeline: Recall Management → Stage: Recall Due

**Step 2 — Condition: Future Appointment Already Booked?**

11. Add action: **If/Else Condition**
12. Condition: Contact **has a future appointment** in GHL calendar
    - In GHL, you can check this using: Contact → has appointment → in the future
    - Alternatively, check if contact has tag `appointment-booked`
13. **If future appointment exists**:
    - Add action: **Add Tag** → `recall-booked`
    - End workflow
14. **If no future appointment**: Continue

**Step 3 — Condition: Has Marketing Consent?**

15. Add action: **If/Else Condition**
16. Condition: Contact DND (Marketing Email) = OFF
17. **If no consent**: Skip to Step 6 (SMS path)
18. **If consent**: Continue

**Step 4 — Send First Recall Email:**

19. Add action: **Send Email**
20. Name: "Recall Reminder Email 1"
21. Use content from the **Recall Reminder Email 1** section below
22. Add action: **Add Tag** → `recall-email-1-sent`

**Step 5 — Wait 14 Days:**

23. Add action: **Wait**
24. Wait time: **14 days**

**Step 6 — Condition: Has Patient Booked?**

25. Add action: **If/Else Condition**
26. Condition: Contact **has tag** `appointment-booked` OR contact has a future appointment
27. **If booked**:
    - Add action: **Add Tag** → `recall-booked`
    - Add action: **Remove Tag** → `recall-due`
    - Add action: **Move Pipeline** → Stage: Recall Booked
    - End workflow
28. **If not booked**: Continue

**Step 7 — Condition: Not in Another Active Workflow?**

29. Add action: **If/Else Condition**
30. Condition: Contact is **NOT** currently in **New Patient Nurture** workflow AND **NOT** in **Cancellation Recovery** workflow
31. **If in another workflow**: Wait 14 days, then re-check. If still in another workflow, end this path.
32. **If not in another workflow**: Continue

**Step 8 — Send Recall SMS:**

33. Add action: **Send SMS**
34. Name: "Recall Reminder SMS"
35. Use content from the **Recall Reminder SMS** section below
36. Sending window: 09:00-19:00
37. Add action: **Add Tag** → `recall-sms-sent`

**Step 9 — Wait 14 Days:**

38. Add action: **Wait**
39. Wait time: **14 days**

**Step 10 — Condition: Has Patient Booked?**

40. Repeat the same check as Step 6
41. **If booked**: Tag `recall-booked`, remove `recall-due`, move pipeline, end workflow
42. **If not booked**: Continue

**Step 11 — Condition: Still Has Marketing Consent?**

43. Add action: **If/Else Condition**
44. Condition: DND (Marketing Email) = OFF
45. **If unsubscribed**: Add tag `recall-sequence-complete`, end workflow
46. **If still subscribed**: Continue

**Step 12 — Send Final Recall Email:**

47. Add action: **Send Email**
48. Name: "Recall Reminder Final Email"
49. Use content from the **Recall Reminder Final Email** section below
50. Add action: **Add Tag** → `recall-email-2-sent`

**Step 13 — Wait 7 Days:**

51. Add action: **Wait**
52. Wait time: **7 days**

**Step 14 — Condition: Final Booking Check:**

53. Repeat booking check
54. **If booked**: Tag `recall-booked`, remove `recall-due`, end workflow
55. **If not booked**: Continue

**Step 15 — Mark for Manual Follow-up:**

56. Add action: **Add Tag** → `recall-sequence-complete`
57. Add action: **Add Tag** → `recall-overdue`
58. Add action: **Move Pipeline** → Stage: Overdue - Manual Follow-up
59. Add action: **Create Task** (Internal Notification)
    - Task name: "Manual recall follow-up needed"
    - Description: "{{contact.first_name}} {{contact.last_name}} did not respond to automated recall sequence. Last check-up: {{custom_field.last_checkup_date}}. Please call to schedule."
    - Assign to: Reception team / Practice Manager
60. End workflow

### Email/SMS Content

#### Recall Reminder Email 1
- **Subject**: Time for your check-up, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

It has been almost 6 months since your last check-up at {{location.name}}, and it is time to book your next one.

Regular check-ups are the best way to keep your teeth and gums healthy. They allow us to spot potential issues early -- when they are quicker, simpler, and less costly to treat.

We also recommend combining your check-up with a hygiene appointment to keep your smile looking and feeling its best.

[BUTTON: Book Your Check-up]

You can book online at any time, or call us on {{location.phone}} during opening hours.

We look forward to seeing you.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your Check-up" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

#### Recall Reminder SMS
- **Message**:
```
Hi {{contact.first_name}}, it's been nearly 6 months since your last check-up at {{location.name}}. Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out.
```

#### Recall Reminder Final Email
- **Subject**: Don't miss your check-up, {{contact.first_name}} -- it's overdue
- **Body**:
```
Hi {{contact.first_name}},

Your 6-month check-up at {{location.name}} is now overdue, and we wanted to reach out one more time.

Regular dental check-ups are essential for:
- Early detection of decay, gum disease, and oral cancer
- Preventing small issues from becoming complex (and costly) treatments
- Keeping your teeth and gums in the best possible condition

We have availability this week and would love to get you booked in. It only takes a few minutes.

[BUTTON: Book Now]

If you have any concerns or questions, please do not hesitate to call us on {{location.phone}}. Our team is always happy to help.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Now" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `recall-due` | Tag | Entry tag, workflow trigger |
| `recall-email-1-sent` | Tag | Tracks first email sent |
| `recall-sms-sent` | Tag | Tracks SMS sent |
| `recall-email-2-sent` | Tag | Tracks final email sent |
| `recall-booked` | Tag | Patient booked (success) |
| `recall-sequence-complete` | Tag | Sequence finished without booking |
| `recall-overdue` | Tag | Flagged for manual follow-up |
| `last_checkup_date` | Custom Field (Date) | Trigger date — must be updated after each check-up |
| `booking_link` | Location Custom Field | Online booking URL |

### Testing Checklist
- [ ] Trigger fires 167 days after `last_checkup_date` is set
- [ ] Trigger fires at 09:00 AM
- [ ] Workflow exits immediately if patient already has a future appointment booked
- [ ] Workflow exits if no marketing consent
- [ ] First email sends with correct merge fields and working booking link
- [ ] 14-day wait between email and SMS is accurate
- [ ] SMS sends within 09:00-19:00 window only
- [ ] SMS includes STOP opt-out text
- [ ] Booking check correctly detects newly booked appointments at each stage
- [ ] Final email has appropriate urgency tone
- [ ] Manual follow-up task is created for non-responders
- [ ] Pipeline stages update at each transition
- [ ] Overlap prevention works (defers if contact is in Nurture or Cancellation Recovery)
- [ ] Unsubscribe link works in all emails
- [ ] `last_checkup_date` update after next check-up resets the cycle for another 167 days

---

## Workflow 4: New Patient Welcome

**Package tier**: Elevate AI
**Estimated build time**: 35-45 minutes

### Pre-requisites
- Pipeline: New Patient Journey (stages: New Registration, Welcomed)
- Tags: `new-patient`, `welcome-email-sent`, `welcome-followup-sent`, `new-patient-welcomed`
- Location custom fields: `booking_link`, `parking_info`
- Email templates built (see below)

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **New Patient Welcome**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `new-patient`

**Step 1 — Move Pipeline:**

7. Add action: **Move Pipeline** → Pipeline: New Patient Journey → Stage: New Registration

**Step 2 — Condition: Has Valid Email?**

8. Add action: **If/Else Condition**
9. Condition: Contact **Email** is **not empty**
10. **If no email**: Go to SMS Welcome path (Step 2b)
11. **If email exists**: Continue to Step 3

**Step 2b — SMS Welcome (No Email Path):**

12. Add action: **Send SMS**
13. Name: "New Patient Welcome SMS"
14. Use content from the **New Patient Welcome SMS** section below
15. Add action: **Add Tag** → `welcome-email-sent`
16. Skip to Step 7 (Mark Complete)

**Step 3 — Send Welcome Email (Immediate):**

17. Add action: **Send Email** (set to send immediately -- no wait/delay)
18. Name: "New Patient Welcome Email"
19. Use content from the **New Patient Welcome Email** section below
20. Add action: **Add Tag** → `welcome-email-sent`

**Step 4 — Wait 48 Hours:**

21. Add action: **Wait**
22. Wait time: **48 hours**
23. Advanced: If 48h falls on a Sunday, defer to Monday 09:00

**Step 5 — Condition: Has First Appointment Been Booked?**

24. Add action: **If/Else Condition**
25. Condition: Contact **has tag** `appointment-booked` OR has a future appointment
26. **If booked**: Go to Step 6a (Follow-up with appointment context)
27. **If not booked**: Go to Step 6b (Follow-up with booking nudge)

**Step 6a — Send Follow-Up Email (Booked Path):**

28. Add action: **Send Email**
29. Name: "New Patient Follow-Up (Booked)"
30. Use content from the **Welcome Follow-Up -- Booked** section below
31. Add action: **Add Tag** → `welcome-followup-sent`
32. Continue to Step 7

**Step 6b — Send Follow-Up Email (Not Booked Path):**

33. Add action: **Send Email**
34. Name: "New Patient Follow-Up (Not Booked)"
35. Use content from the **Welcome Follow-Up -- Not Booked** section below
36. Add action: **Add Tag** → `welcome-followup-sent`
37. Continue to Step 7

**Step 7 — Mark Welcome Sequence Complete:**

38. Add action: **Add Tag** → `new-patient-welcomed`
39. Add action: **Move Pipeline** → Stage: Welcomed
40. End workflow

### Email/SMS Content

#### New Patient Welcome Email
- **Subject**: Welcome to {{location.name}}, {{contact.first_name}}!
- **Body**:
```
Hi {{contact.first_name}},

Welcome to {{location.name}}! We are delighted to have you join our practice and look forward to taking great care of your dental health.

Here is everything you need to know before your first visit:

WHAT TO EXPECT
Your first appointment will take approximately 45 minutes to an hour. We will carry out a thorough examination, take any necessary X-rays, and discuss your dental health and any concerns you may have. There is no pressure for any treatment on your first visit.

WHAT TO BRING
- A form of photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)
- Any previous dental records or X-rays (if you have them)

FINDING US
{{location.name}} is located at {{location.address}}.
Parking: {{location.parking_info}}

[BUTTON: Get Directions]

BOOK YOUR FIRST APPOINTMENT
If you have not already booked your first visit, you can do so online -- it only takes a minute.

[BUTTON: Book Now]

Alternatively, call us on {{location.phone}} and our reception team will be happy to help.

If you have any questions at all, simply reply to this email or give us a ring. We are here to help.

Warm regards,
The team at {{location.name}}
```
- **CTA Button 1**: "Get Directions" → link to Google Maps URL
- **CTA Button 2**: "Book Now" → link to `{{location.booking_link}}`

#### New Patient Welcome SMS
- **Message**:
```
Welcome to {{location.name}}, {{contact.first_name}}! We're looking forward to seeing you. If you have any questions before your first visit, call us on {{location.phone}} or book online: {{location.booking_link}}
```

#### Welcome Follow-Up -- Booked
- **Subject**: Your first appointment at {{location.name}} -- a quick reminder
- **Body**:
```
Hi {{contact.first_name}},

Just a quick note to confirm we are looking forward to seeing you at your upcoming appointment.

As a reminder, please bring:
- Photo ID
- A list of any medications
- Insurance details (if applicable)

If you have any questions before your visit, reply to this email or call us on {{location.phone}}. Our team is friendly and here to make you comfortable.

See you soon!

Warm regards,
The team at {{location.name}}
```

#### Welcome Follow-Up -- Not Booked
- **Subject**: Ready to book your first visit, {{contact.first_name}}?
- **Body**:
```
Hi {{contact.first_name}},

We noticed you have not yet booked your first appointment at {{location.name}} and wanted to check in.

Booking is quick and easy -- it takes less than a minute online:

[BUTTON: Book Your First Visit]

Whether you need a routine check-up or have a specific concern, we are here to help. We offer:
- Comprehensive new patient examinations
- Flexible appointment times, including early mornings and evenings
- A relaxed, no-pressure environment

Not sure what type of appointment to book? Call us on {{location.phone}} and our reception team will guide you.

We look forward to welcoming you to the practice.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your First Visit" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (this email is marketing as it promotes a new booking)

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `new-patient` | Tag | Trigger tag (set by registration form, receptionist, or chatbot) |
| `welcome-email-sent` | Tag | Tracks welcome message sent |
| `welcome-followup-sent` | Tag | Tracks follow-up sent |
| `new-patient-welcomed` | Tag | Marks sequence as complete |
| `parking_info` | Location Custom Field | Parking instructions for welcome email |

### Testing Checklist
- [ ] Trigger fires when `new-patient` tag is added manually
- [ ] Trigger fires when registration form is submitted (if form adds the tag)
- [ ] Welcome email sends within 5 minutes of registration (immediate action, no delay)
- [ ] SMS welcome sends correctly when contact has no email address
- [ ] 48-hour follow-up sends on time
- [ ] Follow-up correctly branches based on whether appointment is booked or not
- [ ] Booked path sends the "appointment context" version
- [ ] Not-booked path sends the "booking nudge" version with unsubscribe link
- [ ] Google Maps link and booking link are both correct and clickable
- [ ] Parking information renders correctly from location custom field
- [ ] Pipeline stages update (New Registration → Welcomed)
- [ ] Duplicate contacts (already existing patients) do not trigger the workflow
- [ ] If contact is also in New Patient Nurture, the welcome workflow takes priority

---

## Workflow 5: New Patient Nurture (Enquiry to Booking)

**Package tier**: Momentum AI
**Estimated build time**: 55-70 minutes

### Pre-requisites
- Pipeline: Lead Nurture (stages: New Enquiry, Converted, Cold Lead)
- Tags: `enquiry-no-booking`, `nurture-email-1-sent`, `nurture-sms-sent`, `nurture-email-2-sent`, `nurture-email-3-sent`, `nurture-converted`, `nurture-sequence-complete`, `nurture-cold`
- Custom fields: `enquiry_source`, `enquiry_interest`, `new_patient_offer`
- Location custom field: `booking_link`
- Email + SMS templates built (see below)
- Marketing consent tracking enabled
- `new_patient_offer` field pre-populated with current offer text (e.g., "Free consultation for new patients" or "20% off your first check-up")

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **New Patient Nurture**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `enquiry-no-booking`
7. Note: This tag should be applied when a website enquiry form is submitted, a chatbot conversation ends without booking, or a missed call is logged without a resulting appointment

**Step 1 — Condition: Already a Patient or Has Booking?**

8. Add action: **If/Else Condition**
9. Condition: Contact **has tag** `new-patient` OR contact **has tag** `appointment-booked`
10. **If yes**: End workflow (already converted)
11. **If no**: Continue

**Step 2 — Move Pipeline:**

12. Add action: **Move Pipeline** → Pipeline: Lead Nurture → Stage: New Enquiry

**Step 3 — Condition: Has Valid Email?**

13. Add action: **If/Else Condition**
14. Condition: Contact **Email** is **not empty**
15. **If no email**: Skip to Step 5 (SMS)
16. **If email exists**: Continue

**Step 4 — Wait 1 Hour:**

17. Add action: **Wait**
18. Wait time: **1 hour**
19. Advanced: If 1h falls outside 08:00-20:00, defer to next 09:00

**Step 5 — Send Initial Nurture Email:**

20. Add action: **Send Email**
21. Name: "Nurture Email 1 -- Enquiry Acknowledgement"
22. Use content from the **Nurture Email 1** section below
23. Add action: **Add Tag** → `nurture-email-1-sent`

**Step 6 — Wait 23 Hours (Total ~24h from Enquiry):**

24. Add action: **Wait**
25. Wait time: **23 hours**
26. Sending window: 09:00-19:00

**Step 7 — Condition: Has Patient Booked?**

27. Add action: **If/Else Condition**
28. Condition: Contact **has tag** `appointment-booked` OR `new-patient`
29. **If booked**:
    - Add action: **Add Tag** → `nurture-converted`
    - Add action: **Move Pipeline** → Stage: Converted
    - End workflow
30. **If not booked**: Continue

**Step 8 — Send SMS Nudge:**

31. Add action: **Send SMS**
32. Name: "Nurture SMS Nudge"
33. Use content from the **Nurture SMS** section below
34. Sending window: 09:00-19:00
35. Add action: **Add Tag** → `nurture-sms-sent`

**Step 9 — Wait 2 Days (Total ~3 Days from Enquiry):**

36. Add action: **Wait**
37. Wait time: **2 days**

**Step 10 — Condition: Has Patient Booked?**

38. Repeat booking check (same as Step 7)
39. **If booked**: Tag `nurture-converted`, move pipeline, end workflow
40. **If not booked**: Continue

**Step 11 — Condition: Still Has Marketing Consent?**

41. Add action: **If/Else Condition**
42. Condition: DND (Marketing Email) = OFF
43. **If unsubscribed**: Add tag `nurture-sequence-complete`, end workflow
44. **If subscribed**: Continue

**Step 12 — Send Offer Email:**

45. Add action: **Send Email**
46. Name: "Nurture Email 2 -- Special Offer"
47. Use content from the **Nurture Email 2 (Offer)** section below
48. Add action: **Add Tag** → `nurture-email-2-sent`

**Step 13 — Wait 4 Days (Total ~7 Days from Enquiry):**

49. Add action: **Wait**
50. Wait time: **4 days**

**Step 14 — Condition: Has Patient Booked?**

51. Repeat booking check
52. **If booked**: Tag `nurture-converted`, move pipeline, end workflow
53. **If not booked**: Continue

**Step 15 — Condition: Still Has Marketing Consent?**

54. Repeat consent check
55. **If unsubscribed**: Tag `nurture-sequence-complete`, end workflow
56. **If subscribed**: Continue

**Step 16 — Send Final Push Email:**

57. Add action: **Send Email**
58. Name: "Nurture Email 3 -- Final Push"
59. Use content from the **Nurture Email 3 (Final)** section below
60. Add action: **Add Tag** → `nurture-email-3-sent`

**Step 17 — Wait 7 Days (Total ~14 Days from Enquiry):**

61. Add action: **Wait**
62. Wait time: **7 days**

**Step 18 — Condition: Final Booking Check:**

63. Repeat booking check
64. **If booked**: Tag `nurture-converted`, move pipeline, end workflow
65. **If not booked**: Continue

**Step 19 — Mark Lead as Cold:**

66. Add action: **Add Tag** → `nurture-sequence-complete`
67. Add action: **Add Tag** → `nurture-cold`
68. Add action: **Move Pipeline** → Stage: Cold Lead
69. Add action: **Create Task** (Internal Notification)
    - Task name: "Cold lead -- manual outreach"
    - Description: "{{contact.first_name}} {{contact.last_name}} enquired about {{custom_field.enquiry_interest}} from {{custom_field.enquiry_source}}. No booking after 14-day nurture sequence. Consider manual outreach in 30 days."
    - Assign to: Reception team
70. End workflow

### Email/SMS Content

#### Nurture Email 1 -- Enquiry Acknowledgement
- **Subject**: Thanks for your enquiry, {{contact.first_name}} -- here's how we can help
- **Body**:
```
Hi {{contact.first_name}},

Thank you for getting in touch with {{location.name}}. We are glad you are considering us for your dental care.

We are a modern dental practice committed to providing exceptional care in a comfortable, welcoming environment. Here is what sets us apart:

- State-of-the-art equipment and techniques
- A friendly, experienced team
- Flexible appointment times including early mornings and evenings
- A gentle, patient-first approach

We would love to welcome you for your first visit. Booking online takes less than a minute:

[BUTTON: Book Your Appointment]

Prefer to chat first? Call us on {{location.phone}} during opening hours and our team will be happy to answer any questions.

We look forward to hearing from you.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your Appointment" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link

#### Nurture SMS
- **Message**:
```
Hi {{contact.first_name}}, we noticed you were looking into dental care at {{location.name}}. We'd love to help! Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out.
```

#### Nurture Email 2 -- Special Offer
- **Subject**: A special welcome offer for you, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

We hope you are doing well. We wanted to let you know about a special offer for new patients at {{location.name}}:

{{custom_field.new_patient_offer}}

Our patients love us -- here is what they are saying:

"Fantastic practice! The team made me feel so at ease from the moment I walked in. Could not recommend them more highly." -- Recent Google Review

We have availability this week and would love to get you booked in.

[BUTTON: Book Now & Claim Your Offer]

This offer is available for a limited time, so do not miss out.

Call {{location.phone}} or book online -- whichever suits you best.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Now & Claim Your Offer" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link

#### Nurture Email 3 -- Final Push
- **Subject**: Still thinking about it, {{contact.first_name}}?
- **Body**:
```
Hi {{contact.first_name}},

We understand that choosing a new dental practice is an important decision, and we do not want to rush you.

We just wanted to reassure you that at {{location.name}}:

- We offer transparent pricing with no surprises
- Nervous patients are always welcome -- we will go at your pace
- We offer flexible scheduling to fit around your commitments
- Payment plans are available for larger treatments

Whenever you are ready, we are here for you. Your first step is just a click away:

[BUTTON: Book When You're Ready]

Or if you have questions, just reply to this email and our team will get back to you promptly.

We hope to welcome you to the practice soon.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book When You're Ready" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `enquiry-no-booking` | Tag | Trigger tag (set by enquiry form, chatbot, or missed call handler) |
| `nurture-email-1-sent` | Tag | Tracks first email |
| `nurture-sms-sent` | Tag | Tracks SMS |
| `nurture-email-2-sent` | Tag | Tracks offer email |
| `nurture-email-3-sent` | Tag | Tracks final email |
| `nurture-converted` | Tag | Patient booked (success) |
| `nurture-sequence-complete` | Tag | Sequence finished |
| `nurture-cold` | Tag | Lead did not convert |
| `enquiry_source` | Custom Field (Dropdown) | Where the enquiry came from |
| `enquiry_interest` | Custom Field (Text) | What service/treatment they asked about |
| `new_patient_offer` | Custom Field (Text) | Current new patient offer text |

### Testing Checklist
- [ ] Trigger fires when `enquiry-no-booking` tag is added
- [ ] Workflow exits if contact already has `new-patient` or `appointment-booked` tag
- [ ] First email sends 1 hour after enquiry (or next 09:00 if outside business hours)
- [ ] SMS sends at the 24-hour mark within 09:00-19:00 window
- [ ] SMS includes STOP opt-out text
- [ ] Booking check at each stage correctly detects newly booked appointments
- [ ] Offer email references `new_patient_offer` custom field correctly
- [ ] If `new_patient_offer` is empty, the email still renders gracefully (test this)
- [ ] Final email has a warm, no-pressure tone
- [ ] Cold lead task is created for non-converters after 14 days
- [ ] Pipeline stages update correctly throughout
- [ ] Contact who books at any stage exits the workflow and gets `nurture-converted` tag
- [ ] Contact who registers as new patient (tag `new-patient`) exits the workflow
- [ ] Unsubscribe link works in all 3 emails and the SMS STOP keyword removes consent
- [ ] Workflow does NOT trigger if contact is already in Recall or Cancellation Recovery workflow

---

## Workflow 6: Cancellation Recovery

**Package tier**: Momentum AI
**Estimated build time**: 50-60 minutes

### Pre-requisites
- Pipeline: Cancellation Recovery (stages: Cancelled, Rebooked, Not Recovered)
- Tags: `appointment-cancelled`, `recovery-sms-sent`, `recovery-email-sent`, `waitlist-notified`, `cancellation-rebooked`, `cancellation-recovered`, `cancellation-recovery-complete`
- Custom field: `cancellation_reason`
- Custom fields: `waitlist`, `waitlist_preference`
- Location custom field: `booking_link`
- Email + SMS templates built (see below)

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **Cancellation Recovery**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Appointment Status**
6. Appointment Status: **Cancelled**
7. Calendar: Select **All Calendars**

**Step 1 — Add Tag + Move Pipeline:**

8. Add action: **Add Tag** → `appointment-cancelled`
9. Add action: **Move Pipeline** → Pipeline: Cancellation Recovery → Stage: Cancelled

**Step 2 — Condition: Short-Notice Cancellation?**

10. Add action: **If/Else Condition**
11. Condition: The appointment was within the next 2 hours
    - In GHL, check if the original appointment start time is less than 2 hours from the current time
    - This may require using a date/time comparison condition or custom value
12. **If within 2 hours**: Skip to Step 9 (Waitlist Fill only)
13. **If more than 2 hours away**: Continue

**Step 3 — Condition: Already Rebooked?**

14. Add action: **If/Else Condition**
15. Condition: Contact has a **future appointment** in GHL calendar (i.e., they cancelled and immediately rebooked a different time)
16. **If rebooked**: Add tag `cancellation-rebooked`, end workflow
17. **If not rebooked**: Continue

**Step 4 — Wait 1 Hour:**

18. Add action: **Wait**
19. Wait time: **1 hour**
20. Sending window: 08:00-20:00 (if 1h falls outside, defer to next 09:00)

**Step 5 — Send Rebooking SMS:**

21. Add action: **Send SMS**
22. Name: "Cancellation Recovery SMS"
23. Use content from the **Cancellation Recovery SMS** section below
24. Sending window: 08:00-20:00
25. Add action: **Add Tag** → `recovery-sms-sent`

**Step 6 — Wait 23 Hours (Total ~24h from Cancellation):**

26. Add action: **Wait**
27. Wait time: **23 hours**

**Step 7 — Condition: Has Patient Rebooked?**

28. Add action: **If/Else Condition**
29. Condition: Contact **has tag** `appointment-booked` OR has a future appointment
30. **If rebooked**:
    - Add action: **Add Tag** → `cancellation-rebooked`
    - Add action: **Add Tag** → `cancellation-recovered`
    - Add action: **Move Pipeline** → Stage: Rebooked
    - End workflow
31. **If not rebooked**: Continue

**Step 8 — Send Rebooking Email:**

32. Add action: **Send Email**
33. Name: "Cancellation Recovery Email"
34. Use content from the **Cancellation Recovery Email** section below
35. Add action: **Add Tag** → `recovery-email-sent`

**Step 9 — Waitlist Fill (Parallel Track):**

This step runs in parallel with patient recovery. If you reached this step from the short-notice cancellation branch (Step 2), this is the only action.

36. Add action: **If/Else Condition**
37. Condition: The cancelled appointment slot was within the next 7 days
38. **If more than 7 days away**: Skip waitlist (slot may fill naturally)
39. **If within 7 days**: Continue

**Step 10 — Send Waitlist Notification SMS:**

40. Identify contacts with custom field `waitlist` = Yes
    - In GHL, you may need a separate sub-workflow or use a "Send to Segment" action
    - Alternatively, create a separate mini-workflow triggered by `appointment-cancelled` that filters waitlist contacts
41. Add action: **Send SMS** to waitlist contacts (up to 5)
42. Name: "Waitlist Notification SMS"
43. Use content from the **Waitlist Notification SMS** section below
44. Sending window: 08:00-20:00
45. Add tag `waitlist-notified` to each contact messaged

**Step 11 — Wait Until 7 Days After Cancellation:**

46. Add action: **Wait**
47. Wait time: Total of **7 days** from the cancellation trigger

**Step 12 — Final Rebooking Check:**

48. Add action: **If/Else Condition**
49. Condition: Contact has tag `appointment-booked` or has a future appointment
50. **If rebooked**:
    - Add tags: `cancellation-rebooked`, `cancellation-recovered`
    - Move pipeline: Stage: Rebooked
    - End workflow
51. **If not rebooked**: Continue

**Step 13 — Mark Recovery Complete:**

52. Add action: **Add Tag** → `cancellation-recovery-complete`
53. Add action: **Move Pipeline** → Stage: Not Recovered
54. End workflow

### Email/SMS Content

#### Cancellation Recovery SMS
- **Message**:
```
Hi {{contact.first_name}}, we're sorry you had to cancel your appointment at {{location.name}}. We'd love to get you rebooked -- choose a new time: {{location.booking_link}} or call {{location.phone}}.
```

#### Cancellation Recovery Email
- **Subject**: Let's get you rescheduled, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

We understand that things come up, and we are sorry you had to cancel your appointment at {{location.name}}.

Your dental health is important, and we would love to get you rescheduled as soon as possible. Rebooking is quick and easy:

[BUTTON: Rebook Your Appointment]

We have availability this week, including evenings, so there is sure to be a time that works for you.

If you need to discuss anything or would prefer to rebook by phone, call us on {{location.phone}} and our team will be happy to help.

We look forward to seeing you soon.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Rebook Your Appointment" → link to `{{location.booking_link}}`

#### Waitlist Notification SMS
- **Message**:
```
Hi {{contact.first_name}}, a dental appointment slot has just opened up at {{location.name}}. Want it? Book now: {{location.booking_link}} or call {{location.phone}}. First come, first served!
```

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `appointment-cancelled` | Tag | Entry tag, set by trigger |
| `recovery-sms-sent` | Tag | Tracks recovery SMS |
| `recovery-email-sent` | Tag | Tracks recovery email |
| `waitlist-notified` | Tag | Applied to waitlist contacts who were notified |
| `cancellation-rebooked` | Tag | Patient rebooked |
| `cancellation-recovered` | Tag | Recovery successful |
| `cancellation-recovery-complete` | Tag | Sequence finished |
| `cancellation_reason` | Custom Field (Dropdown) | Why the patient cancelled |
| `waitlist` | Custom Field (Dropdown) | Whether patient opted into waitlist |
| `waitlist_preference` | Custom Field (Text) | Preferred days/times/treatment types |

### Testing Checklist
- [ ] Trigger fires when appointment status changes to "Cancelled"
- [ ] Short-notice cancellation (< 2h) skips patient outreach and goes straight to waitlist
- [ ] Workflow exits if patient immediately rebooks a different time
- [ ] Recovery SMS sends 1 hour after cancellation (within business hours)
- [ ] Recovery email sends approximately 24 hours after cancellation
- [ ] Rebooking check correctly detects new appointments at each stage
- [ ] Waitlist notification SMS sends to contacts with `waitlist = Yes`
- [ ] Waitlist SMS only fires for slots within 7 days
- [ ] Pipeline stages update correctly (Cancelled → Rebooked or Not Recovered)
- [ ] Workflow does not conflict with Appointment Reminder workflow (reminder should have already exited)
- [ ] Recovery SMS and email booking links work correctly
- [ ] `cancellation_reason` is captured (if GHL cancellation dropdown is configured)

---

## Workflow 7: Birthday & Loyalty

**Package tier**: Apex AI
**Estimated build time**: 25-35 minutes

### Pre-requisites
- Pipeline: Patient Engagement (reuse from Review Request, or create a separate pipeline)
- Tags: `birthday-triggered`, `birthday-email-sent`, `birthday-offer-redeemed`, `birthday-complete`
- Custom fields: `birthday_offer_code`, `birthday_offer_description`, `birthday_offer_expiry`
- Contact field: `date_of_birth` (standard GHL field)
- Location custom field: `booking_link`
- `birthday_offer_description` pre-populated in Location settings (e.g., "10% off teeth whitening")
- Email template built (see below)
- Marketing consent tracking enabled

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **Birthday & Loyalty**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Date Based** (or **Birthday Trigger** if available in your GHL version)
6. Field: **Date of Birth** → Matches today (day and month)
7. Important: This trigger must be configured to fire **annually** (not one-time)
8. Time: **09:00 AM**

**Step 1 — Add Tag:**

9. Add action: **Add Tag** → `birthday-triggered`

**Step 2 — Condition: Active Patient?**

10. Add action: **If/Else Condition**
11. Condition: Contact **does NOT have tag** `inactive-patient` AND **does NOT have tag** `do-not-contact`
12. **Additional check** (recommended): Contact has had an appointment in the last 18 months
    - Use a date-based condition on `last_checkup_date` or last appointment date
13. **If inactive or do-not-contact**: End workflow
14. **If active**: Continue

**Step 3 — Condition: Has Marketing Consent?**

15. Add action: **If/Else Condition**
16. Condition: DND (Marketing Email) = OFF
17. **If no consent**: End workflow
18. **If consent**: Continue

**Step 4 — Set Birthday Offer Custom Fields:**

19. Add action: **Update Contact Field**
20. Set `birthday_offer_code` to a unique value (e.g., `BDAY-{{contact.first_name}}-2026` or use a static code like `BIRTHDAY10`)
21. Set `birthday_offer_expiry` to **today + 30 days**
22. Ensure `birthday_offer_description` is already populated (this is a Location-level field, e.g., "10% off professional teeth whitening")

**Step 5 — Send Birthday Greeting Email:**

23. Add action: **Send Email**
24. Name: "Birthday Greeting Email"
25. Schedule: Ensure it sends at **09:00 AM** (the trigger time should handle this)
26. Use content from the **Birthday Greeting Email** section below
27. Add action: **Add Tag** → `birthday-email-sent`

**Step 6 — Wait 30 Days (Offer Expiry Window):**

28. Add action: **Wait**
29. Wait time: **30 days**

**Step 7 — Condition: Offer Redeemed?**

30. Add action: **If/Else Condition**
31. Condition: Contact **has tag** `birthday-offer-redeemed`
    - This tag is applied manually by reception when the patient uses the birthday code at booking or checkout
32. **If redeemed**: Add tag `birthday-complete`, end workflow
33. **If not redeemed**: Continue

**Step 8 — Mark Complete:**

34. Add action: **Add Tag** → `birthday-complete`
35. Add action: **Remove Tag** → `birthday-triggered` (clean up so next year's trigger works)
36. End workflow

### Email/SMS Content

#### Birthday Greeting Email
- **Subject**: Happy Birthday, {{contact.first_name}}! A gift from {{location.name}}
- **Body**:
```
Hi {{contact.first_name}},

Happy Birthday from everyone at {{location.name}}! We hope you have a wonderful day.

To celebrate, we would like to offer you a special birthday treat:

{{custom_field.birthday_offer_description}}

Your personal offer code: {{custom_field.birthday_offer_code}}
Valid until: {{custom_field.birthday_offer_expiry}}

To redeem, simply book an appointment and mention your birthday code, or quote it when you call.

[BUTTON: Treat Yourself]

From all of us at {{location.name}} -- have a fantastic birthday!

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Treat Yourself" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `birthday-triggered` | Tag | Annual trigger tag |
| `birthday-email-sent` | Tag | Tracks email sent |
| `birthday-offer-redeemed` | Tag | Applied manually when code is used |
| `birthday-complete` | Tag | Marks the cycle as complete |
| `date_of_birth` | Standard GHL Field | Trigger field |
| `birthday_offer_code` | Custom Field (Text) | Unique offer code |
| `birthday_offer_description` | Custom Field (Text) | Offer description text |
| `birthday_offer_expiry` | Custom Field (Date) | Offer expiry date |

### Testing Checklist
- [ ] Trigger fires on the correct date (matching day and month of `date_of_birth`)
- [ ] Trigger fires annually, not just once
- [ ] Email sends at 09:00 AM on the patient's birthday
- [ ] Workflow exits for inactive patients (no appointment in 18 months)
- [ ] Workflow exits for contacts without marketing consent
- [ ] Birthday offer code renders correctly in the email
- [ ] Offer expiry date is set to 30 days from the birthday
- [ ] `birthday-offer-redeemed` tag detection works (test manually adding the tag)
- [ ] `birthday-triggered` tag is removed after completion (allows re-trigger next year)
- [ ] Unsubscribe link works
- [ ] Email does NOT include the patient's age or birth year
- [ ] For children (under 16), consider whether the email is appropriate (may need separate template)

---

## Workflow 8: Treatment Plan Follow-up

**Package tier**: Apex AI
**Estimated build time**: 50-65 minutes

### Pre-requisites
- Pipeline: Treatment Plan Conversion (stages: Plan Presented, Accepted, Pending - Manual Review)
- Tags: `treatment-plan-presented`, `tp-checkin-sent`, `tp-reminder-sent`, `tp-reengage-sent`, `treatment-plan-accepted`, `treatment-plan-declined`, `treatment-plan-followup-complete`
- Custom fields: `treatment_plan_type`, `treatment_plan_value`, `treatment_plan_date`, `treating_dentist`, `payment_plan_available`
- Location custom field: `booking_link`
- Email templates built (see below)
- Note: The `treatment-plan-presented` tag and custom fields are typically set manually by the clinical team via a GHL form after a consultation

### GHL Workflow Builder -- Step by Step

1. Go to **Automation → Workflows → Create New Workflow → Start from Scratch**
2. Name the workflow: **Treatment Plan Follow-up**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `treatment-plan-presented`

**Step 1 — Condition: Already Accepted?**

7. Add action: **If/Else Condition**
8. Condition: Contact **has tag** `treatment-plan-accepted`
9. **If already accepted**: End workflow
10. **If not accepted**: Continue

**Step 2 — Move Pipeline:**

11. Add action: **Move Pipeline** → Pipeline: Treatment Plan Conversion → Stage: Plan Presented

**Step 3 — Condition: Has Valid Email?**

12. Add action: **If/Else Condition**
13. Condition: Contact **Email** is **not empty**
14. **If no email**:
    - Add action: **Create Task** → "Call {{contact.first_name}} {{contact.last_name}} re: treatment plan follow-up -- no email on file"
    - End workflow
15. **If email exists**: Continue

**Step 4 — Wait 48 Hours:**

16. Add action: **Wait**
17. Wait time: **48 hours**
18. Advanced: If 48h falls on a Sunday, defer to Monday 10:00

**Step 5 — Condition: Has Patient Booked Treatment?**

19. Add action: **If/Else Condition**
20. Condition: Contact **has tag** `treatment-plan-accepted` OR has a future appointment tagged with the relevant treatment type
21. **If booked**:
    - Add action: **Add Tag** → `treatment-plan-accepted`
    - Add action: **Move Pipeline** → Stage: Accepted
    - End workflow
22. **If not booked**: Continue

**Step 6 — Send 48-Hour Check-in Email:**

23. Add action: **Send Email**
24. Name: "Treatment Plan Check-in (48h)"
25. Use content from the **Treatment Plan Check-in** section below
26. Add action: **Add Tag** → `tp-checkin-sent`

**Step 7 — Internal Notification for High-Value Plans:**

27. Add action: **If/Else Condition**
28. Condition: `treatment_plan_value` is greater than 2000
29. **If high-value**:
    - Add action: **Create Task** → "High-value treatment plan ({{custom_field.treatment_plan_value}}) for {{contact.first_name}} {{contact.last_name}}. Treatment: {{custom_field.treatment_plan_type}}. Please follow up with a personal call."
    - Assign to: Treatment Coordinator
30. **If standard value**: Continue without notification

**Step 8 — Wait 5 Days (Total ~7 Days):**

31. Add action: **Wait**
32. Wait time: **5 days**

**Step 9 — Condition: Has Patient Booked?**

33. Repeat booking check
34. **If booked**: Tag `treatment-plan-accepted`, move pipeline, end workflow
35. **If not booked**: Continue

**Step 10 — Condition: Still Active Contact?**

36. Add action: **If/Else Condition**
37. Condition: Contact has NOT unsubscribed AND does NOT have `do-not-contact` tag
38. **If unsubscribed/DNC**: Add tag `treatment-plan-followup-complete`, end workflow
39. **If active**: Continue

**Step 11 — Send 7-Day Reminder Email:**

40. Add action: **Send Email**
41. Name: "Treatment Plan Reminder (7 days)"
42. Use content from the **Treatment Plan Reminder** section below
43. Add action: **Add Tag** → `tp-reminder-sent`

**Step 12 — Wait 23 Days (Total ~30 Days):**

44. Add action: **Wait**
45. Wait time: **23 days**

**Step 13 — Condition: Has Patient Booked?**

46. Repeat booking check
47. **If booked**: Tag `treatment-plan-accepted`, move pipeline, end workflow
48. **If not booked**: Continue

**Step 14 — Condition: Still Active Contact?**

49. Repeat unsubscribe/DNC check
50. **If unsubscribed/DNC**: Tag `treatment-plan-followup-complete`, end workflow
51. **If active**: Continue

**Step 15 — Send 30-Day Re-engagement Email:**

52. Add action: **Send Email**
53. Name: "Treatment Plan Re-engage (30 days)"
54. Use content from the **Treatment Plan Re-engage** section below
55. Add action: **Add Tag** → `tp-reengage-sent`

**Step 16 — Wait 14 Days (Total ~44 Days):**

56. Add action: **Wait**
57. Wait time: **14 days**

**Step 17 — Final Booking Check:**

58. Repeat booking check
59. **If booked**: Tag `treatment-plan-accepted`, move pipeline, end workflow
60. **If not booked**: Continue

**Step 18 — Mark Sequence Complete:**

61. Add action: **Add Tag** → `treatment-plan-followup-complete`
62. Add action: **Move Pipeline** → Stage: Pending - Manual Review
63. Add action: **Create Task** (Internal Notification)
    - Task name: "Treatment plan follow-up complete -- manual review needed"
    - Description: "{{contact.first_name}} {{contact.last_name}} has not booked after 44-day follow-up sequence. Treatment: {{custom_field.treatment_plan_type}} ({{custom_field.treatment_plan_value}}). Presented by {{custom_field.treating_dentist}} on {{custom_field.treatment_plan_date}}. Consider: manual call, revised treatment plan, or mark as declined."
    - Assign to: Treatment Coordinator / Practice Manager
64. End workflow

### Email/SMS Content

#### Treatment Plan Check-in (48 hours)
- **Subject**: Following up on your treatment plan, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

After your consultation with {{custom_field.treating_dentist}} on {{custom_field.treatment_plan_date}}, we wanted to check in and see if you have any questions about your treatment plan.

We understand that {{custom_field.treatment_plan_type}} is an important decision, and we want you to feel completely informed and comfortable before going ahead.

If you have any questions about the procedure, the recovery process, or the costs, we are here to help. You can:

- Reply to this email with your questions
- Call us on {{location.phone}} to speak with the team
- Book a follow-up consultation to discuss further (no charge)

[BUTTON: Book Your Treatment]

We are here whenever you are ready.

Warm regards,
The team at {{location.name}}
```
- **Additional line if `payment_plan_available` = Yes:**
```
We also offer flexible payment plans to help make treatment more manageable. Ask us for details.
```
- **CTA Button**: "Book Your Treatment" → link to `{{location.booking_link}}`
- Note: This is a transactional email (follow-up to a clinical consultation). No unsubscribe required.

#### Treatment Plan Reminder (7 days)
- **Subject**: Your {{custom_field.treatment_plan_type}} treatment -- what you need to know
- **Body**:
```
Hi {{contact.first_name}},

We wanted to share some helpful information about {{custom_field.treatment_plan_type}} to help you with your decision.

WHY PATIENTS CHOOSE THIS TREATMENT:
- Modern techniques make the procedure more comfortable than ever
- Results can significantly improve both your oral health and confidence
- Our experienced team has helped hundreds of patients with similar treatments

WHAT TO EXPECT:
Your dentist {{custom_field.treating_dentist}} will guide you through every step of the process, from preparation through to aftercare. You will know exactly what is happening at every stage.

MAKING IT AFFORDABLE:
We believe that everyone deserves access to excellent dental care. We offer flexible payment plans so you can spread the cost into manageable monthly instalments.

[BUTTON: Book Your Treatment]

If you would like to discuss your options further, call us on {{location.phone}} or reply to this email. There is no pressure -- we are simply here to help.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your Treatment" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

#### Treatment Plan Re-engage (30 days)
- **Subject**: We're here when you're ready, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

It has been about a month since we discussed your treatment plan, and we wanted to check in one more time.

We completely understand if now is not the right time -- life gets busy, and these decisions should not be rushed.

However, we wanted to gently mention that in some cases, delaying treatment can allow the issue to progress, which may make it more complex and costly to address later. Your dentist {{custom_field.treating_dentist}} would be happy to discuss this further if you have any concerns.

If cost or timing is a factor, we are flexible:
- Payment plans are available to spread the cost
- We can explore alternative treatment options
- We are happy to revise the plan to suit your circumstances

Your treatment plan is here whenever you are ready. Just get in touch and we will pick up where we left off.

[BUTTON: Book When You're Ready]

Or call us on {{location.phone}} to chat with the team.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book When You're Ready" → link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

### Tags & Custom Fields Required
| Name | Type | Purpose |
|------|------|---------|
| `treatment-plan-presented` | Tag | Trigger tag (set by clinical team via form) |
| `tp-checkin-sent` | Tag | Tracks 48h check-in |
| `tp-reminder-sent` | Tag | Tracks 7-day reminder |
| `tp-reengage-sent` | Tag | Tracks 30-day re-engagement |
| `treatment-plan-accepted` | Tag | Patient booked treatment (success) |
| `treatment-plan-declined` | Tag | Patient explicitly declined |
| `treatment-plan-followup-complete` | Tag | Sequence finished |
| `treatment_plan_type` | Custom Field (Dropdown) | Treatment type |
| `treatment_plan_value` | Custom Field (Number/Currency) | Estimated cost |
| `treatment_plan_date` | Custom Field (Date) | Date plan was presented |
| `treating_dentist` | Custom Field (Text) | Dentist who presented plan |
| `payment_plan_available` | Custom Field (Dropdown) | Whether payment plans are offered |

### Testing Checklist
- [ ] Trigger fires when `treatment-plan-presented` tag is added
- [ ] Workflow exits if `treatment-plan-accepted` tag already exists
- [ ] Internal task is created when contact has no email (manual follow-up path)
- [ ] 48h check-in email sends with correct treatment type and dentist name
- [ ] Payment plan line appears ONLY when `payment_plan_available` = Yes
- [ ] High-value plan (> GBP 2,000) generates internal notification for treatment coordinator
- [ ] 7-day reminder email sends with appropriate treatment-specific content
- [ ] 30-day re-engage email sends with warm, no-pressure tone
- [ ] Booking check at each stage correctly detects accepted treatment plans
- [ ] Email subject lines do NOT reveal specific treatment details (GDPR health data consideration)
- [ ] Pipeline stages update at each transition
- [ ] Final internal task includes all relevant details (patient name, treatment type, value, date, dentist)
- [ ] Unsubscribe link works on marketing emails (7-day reminder, 30-day re-engage)
- [ ] 48h check-in email does NOT have unsubscribe link (transactional)
- [ ] If patient explicitly declines (replies or calls), reception can add `treatment-plan-declined` tag to exit workflow
- [ ] Multiple concurrent treatment plans trigger separate workflow instances without email overload

---

## Quick Reference: Workflow Summary Table

| # | Workflow | Package | Trigger | Messages | Duration | Success Metric |
|---|---------|---------|---------|----------|----------|----------------|
| 1 | Appointment Reminder | Ignite AI | Appointment booked | 2 SMS + 2 Emails | Booking → Post-visit | < 8% no-show rate |
| 2 | Review Request | Ignite AI | Tag: appointment-completed | 2 Emails | 5 days | 8-12 reviews/month |
| 3 | Recall Reminder | Elevate AI | 167 days after last check-up | 2 Emails + 1 SMS | ~5 weeks | 85% recall compliance |
| 4 | New Patient Welcome | Elevate AI | Tag: new-patient | 2 Emails (or 1 SMS) | 48 hours | 90% first-appt attendance |
| 5 | New Patient Nurture | Momentum AI | Tag: enquiry-no-booking | 3 Emails + 1 SMS | 14 days | 30% enquiry conversion |
| 6 | Cancellation Recovery | Momentum AI | Appointment cancelled | 1 Email + 1 SMS + Waitlist SMS | 7 days | 25% rebooking rate |
| 7 | Birthday/Loyalty | Apex AI | Date of birth = today | 1 Email | 30 days (offer window) | 15% offer redemption |
| 8 | Treatment Plan Follow-up | Apex AI | Tag: treatment-plan-presented | 3 Emails | 44 days | 40% plan acceptance |

---

## Recommended Build Order

Build the workflows in this order to handle tag dependencies correctly:

1. **Appointment Reminder** (creates `appointment-completed` tag used by Review Request)
2. **Review Request** (depends on `appointment-completed` tag)
3. **New Patient Welcome** (standalone, but interacts with Nurture)
4. **New Patient Nurture** (should check for `new-patient` tag from Welcome)
5. **Cancellation Recovery** (referenced by Appointment Reminder's reply handling)
6. **Recall Reminder** (depends on `last_checkup_date` being populated by Appointment Reminder completion)
7. **Birthday/Loyalty** (standalone)
8. **Treatment Plan Follow-up** (standalone)

---

## Workflow Interaction Rules

To avoid message fatigue, follow these priority and overlap rules:

| If Patient Is In... | And Enters... | Action |
|---------------------|---------------|--------|
| New Patient Nurture | New Patient Welcome | Exit Nurture, Welcome takes priority |
| Recall Reminder | Cancellation Recovery | Pause Recall for 14 days |
| Recall Reminder | New Patient Nurture | Defer Recall start by 14 days |
| Any workflow | Birthday/Loyalty | Both can run; space emails 4h apart |
| Treatment Plan Follow-up | Cancellation Recovery | Recovery takes priority (time-sensitive) |
| Review Request | Any other workflow | Pause Review Request if another email is due within 48h |

Configure these using GHL's "Contact is NOT in Workflow" conditions at workflow entry points.
