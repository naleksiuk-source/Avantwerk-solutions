# Elevate AI -- Dental Practice (UK)

**Package price**: £2,499 (£2,099 with annual subscription)
**Delivery timeline**: 21 days
**Hypercare**: 14 days
**Total estimated build time**: 18-22 hours

This is a self-contained execution playbook. Every page, workflow, email, SMS, and chatbot setup can be built from this single document. No external references required.

---

## Placeholder Reference

All content uses `[PLACEHOLDER]` format. Replace with client values during deployment.

| Placeholder | Example Value | Where Used |
|-------------|---------------|------------|
| `[BUSINESS_NAME]` | Bright Smile Dental | Everywhere |
| `[PHONE]` | 020 1234 5678 | Everywhere |
| `[EMERGENCY_PHONE]` | 07700 900123 | Website, chatbot, emails |
| `[EMAIL]` | hello@brightsmile.co.uk | Website, emails |
| `[ADDRESS]` | 42 High Street, London, SW1A 1AA | Website, emails, chatbot |
| `[BOOKING_URL]` | /booking | Website, emails, SMS |
| `[GOOGLE_MAPS_URL]` | https://maps.google.com/... | Website, chatbot |
| `[GOOGLE_REVIEW_URL]` | https://g.page/brightsmile/review | Review request emails |
| `[RATING]` | 4.9 | Website |
| `[REVIEW_COUNT]` | 280 | Website |
| `[YEAR_ESTABLISHED]` | 2012 | Website |
| `[DENTIST_1_NAME]` | Dr James Patterson | Website, chatbot |
| `[DENTIST_2_NAME]` | Dr Sarah Chen | Website, chatbot |
| `[HYGIENIST_NAME]` | Lisa Morgan | Website, chatbot |
| `[MANAGER_NAME]` | Karen Williams | Website, chatbot |
| `[BOT_NAME]` | Ava | Chatbot |
| `[PARKING_INFO]` | Free on-site parking... | Website, chatbot, emails |
| `[MON_HOURS]` through `[SUN_HOURS]` | 8:00 AM - 6:00 PM | Website, chatbot |
| `[STATION]` | Highbury & Islington | Website |
| `[MAIN_ROAD]` | the A1 | Website |
| `[ROUTES]` | 19, 4, 236 | Website |
| `[PLAN_PRICE]` | 15.99 | Website |

## Design System

| Property | Value |
|----------|-------|
| Primary Blue | `#2563eb` |
| Primary Hover | `#1d4ed8` |
| Secondary Cyan | `#06b6d4` |
| Accent Green | `#10b981` |
| Page Background | `#f8fafc` |
| Section Background | `#ffffff` |
| Card Background | `#f1f5f9` |
| Card Hover | `#e2e8f0` |
| Heading Text | `#0f172a` |
| Body Text | `#475569` |
| Muted Text | `#94a3b8` |
| Text on Primary | `#ffffff` |
| Border | `rgba(0,0,0,0.08)` |
| Font | DM Sans (Google Fonts) |
| Border Radius (cards) | 16px |
| Border Radius (buttons) | 12px |
| Border Radius (inputs) | 12px |
| Button Padding | 14px 28px |
| Button Font Weight | 600 |
| Section Spacing | 60-80px |
| Tone | Professional, warm, trustworthy, British English |

---

## Pre-Setup Checklist

Complete every item before building anything in GHL.

### Client Information Gathered

- [ ] Business trading name
- [ ] Full address (including postcode)
- [ ] Main phone number
- [ ] Emergency / out-of-hours phone number
- [ ] Email address
- [ ] Opening hours for each day of the week (including bank holidays)
- [ ] Logo file (SVG or high-res PNG, light and dark versions)
- [ ] Brand colours (if the client has their own -- otherwise use dental defaults)
- [ ] Google Business Profile URL and direct review link
- [ ] Google Maps embed URL
- [ ] Current Google rating and review count
- [ ] Year established
- [ ] NHS status (accepting / not accepting / private only)
- [ ] Parking and accessibility information
- [ ] Nearest public transport (station, bus routes)
- [ ] Team member names, roles, qualifications, and short bios (minimum 4)
- [ ] Team member headshot photos
- [ ] Practice interior and exterior photos (minimum 3)
- [ ] Service list with current private prices (all treatments offered)
- [ ] NHS band prices (if applicable)
- [ ] Payment plan / finance details (provider, terms, minimum spend)
- [ ] Dental plan membership details and monthly price (if offered)
- [ ] Cancellation policy text
- [ ] Sedation / anxiety options offered
- [ ] Insurance providers accepted
- [ ] Languages spoken by staff
- [ ] Current patient offer for new patients (if any)
- [ ] Preferred chatbot name

### GHL Sub-Account Ready

- [ ] Sub-account created in GHL agency
- [ ] Named: "TEMPLATE -- Dental UK" (or client-specific name)
- [ ] Email sending domain verified (SPF, DKIM, DMARC)
- [ ] SMS enabled with UK sender number (two-way SMS)
- [ ] Phone number connected for call tracking (if included)
- [ ] Custom domain connected (or GHL default subdomain set)
- [ ] Stripe / payment integration configured (if collecting payments)
- [ ] Google Business Profile connected (for review link tracking)

---

## Phase 1: GHL Sub-Account Setup (30 min)

### Step 1 -- General Settings

1. Go to **Settings --> Business Info**
2. Enter:
   - Business Name: `[BUSINESS_NAME]`
   - Address: `[ADDRESS]`
   - Phone: `[PHONE]`
   - Email: `[EMAIL]`
   - Website: `[WEBSITE_URL]`
   - Timezone: `Europe/London`
   - Logo: Upload client logo

### Step 2 -- Email Configuration

1. Go to **Settings --> Email Services**
2. Verify sending domain is authenticated (SPF, DKIM records)
3. Set default "From" name: `[BUSINESS_NAME]`
4. Set default "Reply-to": `[EMAIL]`
5. Upload email logo (practice logo, max 200px wide)
6. Test with a send to your own address

### Step 3 -- SMS Configuration

1. Go to **Settings --> Phone Numbers**
2. Confirm UK number is active and two-way SMS is enabled
3. Register SMS sender ID as `[BUSINESS_NAME]` (max 11 characters)
4. Set SMS sending window: 08:00-20:00 (compliance)

### Step 4 -- Calendar Setup

1. Go to **Calendars --> Calendar Settings**
2. Create the following appointment types:

| Appointment Type | Duration | Buffer | Colour |
|------------------|----------|--------|--------|
| New Patient Check-up | 45 min | 15 min | Blue |
| Returning Patient Check-up | 30 min | 10 min | Blue |
| Hygiene Appointment | 30 min | 10 min | Cyan |
| Emergency | 20 min | 10 min | Red |
| General Consultation | 30 min | 10 min | Blue |
| Teeth Whitening Consultation | 20 min | 10 min | Green |
| Invisalign Consultation | 30 min | 15 min | Green |
| Implant Consultation | 30 min | 15 min | Green |

3. Set availability to match practice opening hours
4. Enable online booking confirmation emails
5. Enable patient notifications (email + SMS)
6. Set cancellation policy notice period: 24 hours

---

## Phase 2: Custom Fields & Tags (30 min)

### Custom Fields

Create these in **Settings --> Custom Fields --> Contact**:

| Field Name | Field Type | Used By |
|------------|-----------|---------|
| `last_checkup_date` | Date | Recall Reminder workflow |
| `patient_type` | Dropdown: NHS, Private | Recall Reminder, New Patient Welcome |
| `enquiry_source` | Dropdown: Website Form, Chatbot, Phone, Social Media | Reporting |
| `enquiry_interest` | Single Line Text | Reporting |

Create these in **Settings --> Custom Fields --> Location** (if not already present):

| Field Name | Field Type | Notes |
|------------|-----------|-------|
| `google_review_link` | URL | Direct Google review URL for the practice |
| `booking_link` | URL | Online booking page URL |
| `parking_info` | Multi Line Text | Parking instructions for welcome email |

### Tags

Create all of the following tags in **Settings --> Tags**:

**Appointment Reminder**: `appointment-booked`, `appointment-confirmed`, `appointment-no-show`, `appointment-completed`

**Review Request**: `review-requested`, `review-clicked`, `review-left`, `review-requested-complete`

**Recall Reminder**: `recall-due`, `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-booked`, `recall-sequence-complete`, `recall-overdue`

**New Patient Welcome**: `new-patient`, `welcome-email-sent`, `welcome-followup-sent`, `new-patient-welcomed`

**General**: `inactive-patient`, `do-not-contact`

---

## Phase 3: Pipeline Setup (20 min)

Create these pipelines in **CRM --> Pipelines**:

| Pipeline | Stages |
|----------|--------|
| Patient Appointments | Booked --> Confirmed --> Completed --> No Show |
| Patient Engagement | Review Requested --> Review Clicked --> Review Sequence Complete |
| Recall Management | Recall Due --> Recall Booked --> Overdue - Manual Follow-up |
| New Patient Journey | New Registration --> Welcomed |

---

## Phase 4: Website -- 5 Pages (6-8 hours)

### Header & Footer (Built Once, Shared Across All Pages)

Build the header and footer as **native GHL elements** so they appear on every page automatically.

#### Header Configuration

1. Go to **Sites --> Website Builder --> Global Sections --> Header**
2. Layout: Logo left, navigation centre, CTA button right
3. Navigation links:
   - Home (/)
   - Services (/services)
   - About (/about)
   - Contact (/contact)
   - Book Online (/booking)
4. CTA button in header: "Book Now" -- primary blue `#2563eb`, links to `/booking`
5. Mobile: Hamburger menu with all links, "Book Now" button prominent
6. Header background: `#ffffff`
7. Header text colour: `#0f172a`
8. Upload logo (practice logo)

#### Footer Configuration

1. Go to **Sites --> Website Builder --> Global Sections --> Footer**
2. Three-column layout:
   - **Column 1**: Practice name, address, phone, email
   - **Column 2**: Quick links -- Home, Services, About, Contact, Book Online, Privacy Policy, Terms
   - **Column 3**: Opening hours summary, social media icons
3. Below columns: Copyright line -- "(c) [YEAR] [BUSINESS_NAME]. All rights reserved."
4. Footer background: `#0f172a` (dark)
5. Footer text colour: `#94a3b8`
6. Footer link colour: `#cbd5e1`, hover: `#ffffff`

---

### Page 1: Homepage (1.5-2 hours)

**GHL Page Type**: Website Page
**URL Slug**: `/` (root)
**Sections**: 8

#### GHL AI Builder Prompt

> Build a homepage for a dental practice called [BUSINESS_NAME]. Use a clean, clinical, trustworthy design with a light theme. The primary colour is blue #2563eb, secondary is cyan #06b6d4, accent is green #10b981. Page background is #f8fafc, cards are #f1f5f9, headings are #0f172a, body text is #475569. Use the font DM Sans from Google Fonts. British English throughout. No emojis. All content below must appear on the page exactly as written.
>
> SECTION 1 -- HERO
> Full-width hero with a subtle gradient overlay on a dental surgery background image placeholder. Left-aligned text:
> - Small badge above headline: "Trusted by [REVIEW_COUNT]+ Patients"
> - Headline (H1): "Your Smile Deserves the Best Care"
> - Subheadline: "Welcome to [BUSINESS_NAME] -- your trusted local dental practice offering NHS and private treatments for the whole family. Gentle, professional care in a modern, relaxed setting."
> - Two buttons side by side: "Book Appointment" (primary blue #2563eb, links to [BOOKING_URL]) and "Call Us: [PHONE]" (outlined style, links to tel:[PHONE])
> - Below buttons, a small trust line: "No registration fee. New patients welcome. Evening appointments available."
>
> SECTION 2 -- TRUST BAR
> A horizontal bar with a light blue tinted background (#eff6ff). Display four trust indicators in a row, each with a number and label:
> - "[RATING] Stars" with label "Google Rating"
> - "[REVIEW_COUNT]+" with label "Happy Patients"
> - "Est. [YEAR_ESTABLISHED]" with label "Years of Experience"
> - "GDC Registered" with label "Fully Accredited"
>
> SECTION 3 -- SERVICES OVERVIEW
> Section heading (H2): "Our Treatments"
> Subtext: "Comprehensive dental care for every member of your family, from routine check-ups to advanced cosmetic treatments."
> A grid of 8 service cards (4 columns on desktop, 2 on mobile). Each card has an icon area, service name, short description, and a "from" price. The cards:
> 1. General Check-up -- "Thorough examination, digital X-rays, and personalised treatment plan." From £50
> 2. Dental Hygiene -- "Professional scale and polish to keep your gums healthy and your smile fresh." From £55
> 3. Teeth Whitening -- "Professional whitening for a brighter, more confident smile. In-surgery and take-home options." From £300
> 4. Dental Implants -- "Permanent tooth replacement that looks, feels, and functions like natural teeth." From £2,000
> 5. Invisalign -- "Nearly invisible clear aligners to straighten your teeth without metal braces." From £2,500
> 6. Cosmetic Dentistry -- "Veneers, bonding, and smile makeovers to transform your appearance." From £200
> 7. Emergency Dental -- "Same-day emergency appointments for pain, swelling, or dental trauma." From £80
> 8. Children's Dentistry -- "Gentle, fun dental care to give your child a lifetime of healthy smiles." From £40
> Each card links to /services. Cards have a white background (#ffffff), subtle border, 16px border radius, and a hover shadow effect.
>
> SECTION 4 -- WHY CHOOSE US
> Section heading (H2): "Why Patients Choose [BUSINESS_NAME]"
> Four feature cards in a row (2 columns on mobile):
> 1. "Experienced Team" -- "Our dentists have over 50 combined years of experience and hold advanced qualifications in implantology, orthodontics, and cosmetic dentistry."
> 2. "Modern Technology" -- "Digital X-rays, intraoral scanners, and laser dentistry mean faster, more comfortable treatments with better results."
> 3. "Nervous Patients Welcome" -- "We specialise in gentle dentistry. Sedation options, a calm environment, and a patient-first approach to help you feel at ease."
> 4. "Flexible Payments" -- "0% finance available on treatments over £500. Spread the cost with affordable monthly payments that suit your budget."
>
> SECTION 5 -- MEET THE TEAM (PREVIEW)
> Section heading (H2): "Meet Your Dental Team"
> Subtext: "Skilled, caring professionals dedicated to your oral health."
> Show 4 team member cards in a row. Each card has a circular image placeholder, name, role, and a one-line bio:
> 1. "[DENTIST_1_NAME]" -- "Principal Dentist" -- "BDS, MJDF RCS -- Special interest in implants and cosmetic dentistry. [X] years in practice."
> 2. "[DENTIST_2_NAME]" -- "Associate Dentist" -- "BDS -- Passionate about preventive care and nervous patient management."
> 3. "[HYGIENIST_NAME]" -- "Dental Hygienist" -- "Dip DH -- Expert in gum health, deep cleaning, and stain removal."
> 4. "[MANAGER_NAME]" -- "Practice Manager" -- "Keeping everything running smoothly so your visit is always comfortable."
> A "Meet the Full Team" link below pointing to /about.
>
> SECTION 6 -- PATIENT REVIEWS
> Section heading (H2): "What Our Patients Say"
> Subtext: "Rated [RATING] out of 5 from [REVIEW_COUNT]+ Google reviews."
> Three review cards. Each card has a 5-star rating display, the review text in quotes, the reviewer's first name and initial, and the treatment type:
> 1. Stars: 5. "I was terrified of the dentist but the team at [BUSINESS_NAME] made me feel completely at ease. The check-up was painless and they explained everything clearly. I actually look forward to my appointments now." -- Sarah T., General Check-up
> 2. Stars: 5. "Had my teeth whitened here and the results are incredible. Four shades brighter in just one session. The staff were professional and friendly throughout. Could not recommend more highly." -- James R., Teeth Whitening
> 3. Stars: 5. "After years of hiding my smile, I finally got Invisalign at [BUSINESS_NAME]. The whole process was seamless from consultation to final result. My confidence has completely changed." -- Emma L., Invisalign
>
> SECTION 7 -- BOOKING CTA BANNER
> Full-width banner with a blue gradient background (#2563eb to #1d4ed8). White text:
> - Headline (H2): "Ready to Book Your Appointment?"
> - Subtext: "New patients welcome. No registration fee. Book online in under 60 seconds or call us directly."
> - Two white buttons: "Book Online" (links to [BOOKING_URL]) and "Call [PHONE]" (links to tel:[PHONE])
>
> SECTION 8 -- LOCATION AND OPENING HOURS
> Two-column layout. Left column:
> - Heading (H3): "Find Us"
> - Address: [ADDRESS]
> - Phone: [PHONE]
> - Email: [EMAIL]
> - A map placeholder (Google Maps embed area)
> Right column:
> - Heading (H3): "Opening Hours"
> - Monday to Friday: 8:00 AM - 6:00 PM
> - Saturday: 9:00 AM - 2:00 PM
> - Sunday: Closed
> - "Emergency? Call [EMERGENCY_PHONE] for out-of-hours dental emergencies."
>
> Make the entire page mobile responsive. Use consistent spacing (60-80px between sections). All buttons have 14px 28px padding, 12px border radius, font-weight 600, and a subtle hover lift effect.

#### Manual Build Notes

1. Add a new Website Page, set as homepage (slug: `/`).
2. Build the header/navigation natively in GHL (done once, shared).
3. Add 8 sections using a mix of native elements and Custom Code blocks:
   - Section 1 (Hero): Custom Code block.
   - Section 2 (Trust Bar): Custom Code block or native columns.
   - Section 3 (Services Grid): Custom Code block. 8 cards in CSS grid.
   - Section 4 (Why Choose Us): Custom Code block. 4 feature cards.
   - Section 5 (Team Preview): Custom Code block. 4 team cards with circular images.
   - Section 6 (Reviews): Custom Code block. 3 review cards with star ratings.
   - Section 7 (CTA Banner): Custom Code block. Full-width gradient banner.
   - Section 8 (Location): Native 2-column row. Left: text + native map embed. Right: text for hours.
4. Build the footer natively in GHL (done once, shared).

#### Native GHL Elements Needed

- **Header Navigation**: Logo, menu links (Home, Services, About, Contact, Book Online), "Book Now" CTA button linking to /booking.
- **Footer**: Practice info, social links, legal page links.
- **Google Maps Embed**: Native map element in the Location section.
- **Chat Widget**: GHL Conversation AI widget (bottom-right corner, present on all pages).

---

### Page 2: Services (1.5-2 hours)

**GHL Page Type**: Website Page
**URL Slug**: `/services`
**Sections**: 5

#### GHL AI Builder Prompt

> Build a services page for a dental practice called [BUSINESS_NAME]. Use a clean, clinical design with primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> A shorter hero section (not full height) with a light blue-tinted background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Services"
> - Headline (H1): "Our Dental Treatments"
> - Subheadline: "From routine check-ups to advanced restorative and cosmetic procedures, we offer a full range of dental treatments under one roof."
>
> SECTION 2 -- SERVICE CATEGORIES
> Display services grouped by category. Each category has a heading, and the treatments listed as cards with name, description, and starting price. Use a clean card grid layout within each category.
>
> Category 1 -- "General Dentistry"
> - Dental Check-up: "Comprehensive oral examination including digital X-rays, oral cancer screening, and a personalised treatment plan. Recommended every 6 months." From £50
> - Dental Hygiene: "Professional scale and polish by our qualified hygienist. Removes plaque and tartar buildup, helps prevent gum disease, and leaves your teeth feeling fresh." From £55
> - Fillings: "Tooth-coloured composite fillings that blend seamlessly with your natural teeth. We remove decay and restore your tooth to full function." From £80
> - Root Canal Treatment: "Save an infected tooth with modern root canal therapy. We use rotary instruments and digital imaging for precise, comfortable treatment." From £250
> - Extractions: "Simple and surgical tooth removal performed gently under local anaesthetic. We offer sedation for anxious patients." From £100
> - Crowns: "Custom-made porcelain crowns that protect damaged teeth and restore their natural appearance. Crafted to match your existing teeth perfectly." From £400
>
> Category 2 -- "Cosmetic Dentistry"
> - Teeth Whitening: "Professional whitening for a dramatically brighter smile. Choose in-surgery power whitening for instant results or custom take-home trays for gradual improvement." From £300
> - Composite Bonding: "Reshape and repair teeth with tooth-coloured composite resin. Fix chips, gaps, and uneven edges in a single appointment with no drilling required." From £200
> - Porcelain Veneers: "Ultra-thin porcelain shells bonded to the front of your teeth for a flawless, natural-looking smile. Custom-designed for your face shape." From £500
> - Smile Makeover: "A comprehensive treatment plan combining multiple cosmetic procedures to completely transform your smile. Includes digital smile design consultation." From £2,000
>
> Category 3 -- "Orthodontics"
> - Invisalign: "The world's leading clear aligner system. Straighten your teeth discreetly with custom-made, removable aligners. Suitable for mild to complex cases." From £2,500
> - Fixed Braces: "Traditional metal and ceramic braces for reliable, predictable tooth movement. Ideal for complex orthodontic cases that need precise control." From £2,000
>
> Category 4 -- "Dental Implants"
> - Single Tooth Implant: "Replace a missing tooth with a titanium implant and porcelain crown. Looks, feels, and functions exactly like your natural tooth." From £2,000
> - Implant-Supported Bridge: "Replace multiple missing teeth with an implant-retained bridge. Eliminates the need for a removable denture." From £4,000
>
> Category 5 -- "Emergency Dental Care"
> - Emergency Consultation: "Same-day appointments for dental pain, swelling, broken teeth, or trauma. Call us and we will see you as quickly as possible." From £80
> - Emergency Treatment: "Immediate treatment to relieve pain and stabilise your condition. Follow-up care planned as part of your ongoing treatment." From £100
>
> Category 6 -- "Children's Dentistry"
> - Children's Check-up: "A gentle, fun examination tailored for children. We make dental visits a positive experience from the very first appointment." From £40
> - Fissure Sealants: "A protective coating applied to the biting surfaces of back teeth. Prevents decay in the deep grooves where brushing cannot reach." From £30
> - Fluoride Treatments: "A quick, painless fluoride application to strengthen tooth enamel and protect against cavities. Recommended for children and teenagers." From £25
>
> SECTION 3 -- TREATMENT PROCESS
> Section heading (H2): "How Your Treatment Works"
> A horizontal 4-step timeline with connecting lines between steps:
> 1. "Consultation" -- "Book your appointment online or by phone. We will discuss your concerns, examine your teeth, and take any necessary X-rays."
> 2. "Treatment Plan" -- "Your dentist will explain all available options, expected outcomes, and costs. You will receive a written treatment plan to take home."
> 3. "Treatment" -- "We carry out your treatment using the latest techniques and technology. Your comfort is our priority at every stage."
> 4. "Aftercare" -- "We provide clear aftercare instructions and schedule any follow-up appointments. Our team is always available if you have questions."
>
> SECTION 4 -- PAYMENT OPTIONS
> Section heading (H2): "Affordable Payment Options"
> Three cards:
> 1. "Pay As You Go" -- "Pay for each treatment individually at the time of your appointment. We accept cash, card, and contactless payments."
> 2. "0% Finance" -- "Spread the cost of treatments over £500 with interest-free monthly payments. Subject to status. Apply at your consultation."
> 3. "Dental Plan" -- "Join our practice membership plan from £[PLAN_PRICE]/month. Includes two check-ups, two hygiene visits, 10% off all treatments, and worldwide dental emergency cover."
>
> SECTION 5 -- CTA
> Full-width blue gradient banner (#2563eb to #1d4ed8), white text:
> - Headline: "Not Sure Which Treatment You Need?"
> - Subtext: "Book a consultation and our team will guide you to the right solution. No obligation, no pressure."
> - Button: "Book a Consultation" linking to [BOOKING_URL]
> - Text link: "Or call us on [PHONE]"
>
> Mobile responsive. Consistent spacing. Cards have 16px border radius, subtle shadow on hover.

#### Manual Build Notes

1. Add a new Website Page with slug `/services`.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Service Categories): Custom Code block. Category headings (H3) with card grids. 3 columns desktop, 2 tablet, 1 mobile.
4. Section 3 (Treatment Process): Custom Code block. Horizontal timeline.
5. Section 4 (Payment Options): Custom Code block. 3 cards.
6. Section 5 (CTA Banner): Custom Code block. Full-width gradient.

#### Native GHL Elements Needed

- **Header/Footer**: Shared across all pages (built once).
- **Chat Widget**: GHL Conversation AI (shared across all pages).

---

### Page 3: About Us (1-1.5 hours)

**GHL Page Type**: Website Page
**URL Slug**: `/about`
**Sections**: 6

#### GHL AI Builder Prompt

> Build an About Us page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, secondary cyan #06b6d4, accent green #10b981. Page background #f8fafc, cards #f1f5f9, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Shorter hero with light blue-tinted background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > About Us"
> - Headline (H1): "About [BUSINESS_NAME]"
> - Subheadline: "A modern dental practice built on trust, expertise, and genuine patient care."
>
> SECTION 2 -- PRACTICE STORY
> Two-column layout. Left column: a large image placeholder (interior of a modern dental practice). Right column:
> - Heading (H2): "Our Story"
> - Paragraph 1: "[BUSINESS_NAME] was founded in [YEAR_ESTABLISHED] with a simple belief: everyone deserves access to high-quality dental care in a comfortable, welcoming environment. What started as a small family practice has grown into one of the most trusted dental clinics in the area."
> - Paragraph 2: "Over the years, we have invested in the latest dental technology, expanded our team of specialist clinicians, and built a reputation for clinical excellence combined with genuine warmth. We treat every patient as an individual, taking the time to listen, explain, and deliver the best possible outcome."
> - Paragraph 3: "Whether you are visiting for a routine check-up or a life-changing smile makeover, you will experience the same standard of care: thorough, gentle, and always focused on you."
>
> SECTION 3 -- OUR VALUES
> Section heading (H2): "What We Stand For"
> Four value cards in a row (2 on mobile):
> 1. "Clinical Excellence" -- "We hold ourselves to the highest clinical standards. Our dentists pursue ongoing professional development and use evidence-based techniques to deliver outstanding results."
> 2. "Patient-First Care" -- "Your comfort, concerns, and goals are at the centre of everything we do. We never rush, never pressure, and always explain your options clearly."
> 3. "Honest Communication" -- "No jargon, no hidden costs, no surprises. We give you straightforward advice and transparent pricing so you can make informed decisions about your care."
> 4. "Continuous Innovation" -- "We invest in modern equipment and training to offer you the most effective, comfortable treatments available. From digital X-rays to laser dentistry, we stay at the forefront."
>
> SECTION 4 -- FULL TEAM
> Section heading (H2): "Meet the Team"
> Subtext: "The people behind your smile."
> A grid of 4 team member cards (2 columns desktop, 1 mobile). Each card has a portrait image placeholder (square with rounded corners), name, role, qualifications, and a 2-sentence bio:
> 1. "[DENTIST_1_NAME]" -- "Principal Dentist, BDS, MJDF RCS (Eng)" -- "Qualified from [UNIVERSITY] in [YEAR] and has a special interest in dental implants and cosmetic dentistry. Committed to making every patient feel confident and comfortable in the chair."
> 2. "[DENTIST_2_NAME]" -- "Associate Dentist, BDS" -- "Joined [BUSINESS_NAME] in [YEAR] with a passion for preventive and minimally invasive dentistry. Known for a calm, reassuring manner that puts nervous patients at ease."
> 3. "[HYGIENIST_NAME]" -- "Dental Hygienist, Dip Dental Hygiene" -- "Expert in periodontal care and preventive treatments. Passionate about educating patients on effective oral hygiene techniques."
> 4. "[MANAGER_NAME]" -- "Practice Manager" -- "Keeps the practice running seamlessly behind the scenes. Handles scheduling, patient queries, and ensures every visit is a positive experience."
>
> SECTION 5 -- ACCREDITATIONS
> Section heading (H2): "Accreditations and Memberships"
> A horizontal row of accreditation badges/logos (display as image placeholders with labels):
> - GDC (General Dental Council) -- "All our dentists are registered with the GDC."
> - CQC (Care Quality Commission) -- "Inspected and rated by the CQC."
> - BDA (British Dental Association) -- "Proud members of the BDA."
> - Invisalign Provider -- "Certified Invisalign provider."
>
> SECTION 6 -- JOIN US CTA
> Full-width banner with light blue background (#eff6ff):
> - Heading (H2): "Join the [BUSINESS_NAME] Family"
> - Subtext: "New patients are always welcome. Register today and experience the difference that genuine, expert dental care makes."
> - Two buttons: "Book Your First Visit" (primary blue, links to [BOOKING_URL]) and "Contact Us" (outlined, links to /contact)
>
> Mobile responsive. Consistent 60-80px section spacing.

#### Manual Build Notes

1. Add a new Website Page with slug `/about`.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Practice Story): Native 2-column row. Left: image element. Right: Custom Code block.
4. Section 3 (Values): Custom Code block. 4 cards in CSS grid.
5. Section 4 (Team): Custom Code block. 4 cards in CSS grid.
6. Section 5 (Accreditations): Custom Code block. Horizontal row of logo placeholders.
7. Section 6 (Join Us CTA): Custom Code block.

#### Native GHL Elements Needed

- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

### Page 4: Contact (1-1.5 hours)

**GHL Page Type**: Website Page
**URL Slug**: `/contact`
**Sections**: 4

#### GHL AI Builder Prompt

> Build a Contact page for a dental practice called [BUSINESS_NAME]. Clean, clinical design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Contact"
> - Headline (H1): "Get in Touch"
> - Subheadline: "We would love to hear from you. Reach out by phone, email, or simply fill in the form below."
>
> SECTION 2 -- CONTACT METHODS AND FORM
> Two-column layout.
> Left column -- Contact Details:
> - Heading (H3): "Contact Details"
> - Phone: [PHONE] (clickable tel: link) -- "Mon-Fri 8am-6pm, Sat 9am-2pm"
> - Email: [EMAIL] (clickable mailto: link) -- "We aim to reply within 24 hours"
> - WhatsApp: [PHONE] -- "Message us for quick queries"
> - Emergency: [EMERGENCY_PHONE] -- "Out-of-hours dental emergencies only"
> - Address: [ADDRESS]
>
> Right column -- Contact Form:
> - A placeholder area for a native GHL contact form. Display text: "[GHL NATIVE FORM -- Insert here. Fields: First Name, Last Name, Email, Phone, Subject (dropdown: General Enquiry, New Patient Registration, Appointment Query, Treatment Question, Complaint, Other), Message (textarea). Submit button: Send Message]"
>
> SECTION 3 -- MAP AND DIRECTIONS
> Full-width section:
> - Heading (H3): "How to Find Us"
> - A large map placeholder (Google Maps embed area for [ADDRESS])
> - Below the map, three info cards in a row:
>   1. "By Car" -- "Free on-site parking available for all patients. The practice is located on [STREET] with easy access from [MAIN_ROAD]."
>   2. "By Public Transport" -- "The nearest station is [STATION], a [X]-minute walk from the practice. Bus routes [ROUTES] stop nearby."
>   3. "Accessibility" -- "Step-free access throughout the practice. Ground-floor treatment rooms. Please let us know in advance if you have any specific accessibility requirements."
>
> SECTION 4 -- OPENING HOURS
> Section with a clean table or card layout:
> - Heading (H3): "Opening Hours"
> - Monday: 8:00 AM - 6:00 PM
> - Tuesday: 8:00 AM - 6:00 PM
> - Wednesday: 8:00 AM - 6:00 PM
> - Thursday: 8:00 AM - 6:00 PM
> - Friday: 8:00 AM - 6:00 PM
> - Saturday: 9:00 AM - 2:00 PM
> - Sunday: Closed
> - Note below: "For dental emergencies outside these hours, call [EMERGENCY_PHONE]."
> - CTA button: "Book an Appointment" linking to [BOOKING_URL]
>
> Mobile responsive. Form placeholder should be clearly marked for native GHL form insertion.

#### Manual Build Notes

1. Add a new Website Page with slug `/contact`.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Contact + Form): Native 2-column row. Left: Custom Code block with contact details. Right: **Native GHL Form element**.
4. Section 3 (Map): Native Google Maps element. Custom Code block for info cards.
5. Section 4 (Opening Hours): Custom Code block.

#### Native GHL Elements Needed

- **GHL Contact Form**: First Name (text), Last Name (text), Email (email), Phone (phone), Subject (dropdown: General Enquiry, New Patient Registration, Appointment Query, Treatment Question, Complaint, Other), Message (textarea). Submit button text: "Send Message". Wire form submission to add tag `enquiry-contact-form` and assign to reception pipeline.
- **Google Maps Embed**: Native map element with practice address.
- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

### Page 5: Book Online (45 min - 1 hour)

**GHL Page Type**: Website Page
**URL Slug**: `/booking`
**Sections**: 3

#### GHL AI Builder Prompt

> Build a Booking page for a dental practice called [BUSINESS_NAME]. Clean design. Primary blue #2563eb, page background #f8fafc, headings #0f172a, body text #475569. Font: DM Sans. British English. No emojis.
>
> SECTION 1 -- COMPACT HERO
> Shorter hero, light blue background (#eff6ff). Centre-aligned:
> - Breadcrumb: "Home > Book Online"
> - Headline (H1): "Book Your Appointment"
> - Subheadline: "Choose a time that suits you and book online in under 60 seconds. New patients welcome -- no registration fee."
>
> SECTION 2 -- BOOKING CALENDAR
> Full-width section. Centre-aligned:
> - A prominent placeholder area for the native GHL calendar widget. Display text: "[GHL NATIVE CALENDAR -- Insert the booking calendar widget here. Configure appointment types: New Patient Check-up (45 min), Returning Patient Check-up (30 min), Hygiene Appointment (30 min), Emergency (20 min), Consultation (30 min), Teeth Whitening Consultation (20 min), Invisalign Consultation (30 min), Implant Consultation (30 min).]"
>
> Below the calendar placeholder, three info cards in a row:
> 1. "New Patients" -- "Welcome to [BUSINESS_NAME]. Your first visit includes a comprehensive examination, digital X-rays, and a personalised treatment plan. Please arrive 10 minutes early to complete registration. Bring a form of ID and your medical history if available."
> 2. "Appointment Types" -- "Select the appointment type that matches your needs. If you are unsure, choose General Consultation and we will guide you from there. Urgent issues should be booked as Emergency."
> 3. "Cancellation Policy" -- "We kindly ask for at least 24 hours notice if you need to cancel or reschedule. Late cancellations or missed appointments may incur a fee of £25. We understand that emergencies happen -- just let us know as soon as you can."
>
> SECTION 3 -- PREFER TO CALL
> A simple section with centre-aligned text:
> - Heading (H3): "Prefer to Book by Phone?"
> - Text: "Our reception team is happy to help. Call us on [PHONE] during opening hours (Mon-Fri 8am-6pm, Sat 9am-2pm)."
> - Text: "For dental emergencies outside these hours, call [EMERGENCY_PHONE]."
> - Two buttons: "Call [PHONE]" (primary blue, links to tel:[PHONE]) and "Send us a Message" (outlined, links to /contact)
>
> Mobile responsive.

#### Manual Build Notes

1. Add a new Website Page with slug `/booking`.
2. Section 1 (Compact Hero): Custom Code block.
3. Section 2 (Calendar + Info): Add a **native GHL Calendar widget** as the main element. Configure appointment types. Below the calendar, add a Custom Code block with 3 info cards.
4. Section 3 (Phone CTA): Custom Code block.

#### Native GHL Elements Needed

- **GHL Calendar Widget**: This is the primary content of this page. Configure appointment types:
  - New Patient Check-up (45 min)
  - Returning Patient Check-up (30 min)
  - Hygiene Appointment (30 min)
  - Emergency (20 min)
  - General Consultation (30 min)
  - Teeth Whitening Consultation (20 min)
  - Invisalign Consultation (30 min)
  - Implant Consultation (30 min)
- Wire calendar to GHL Calendar settings, staff availability, and the Appointment Reminder workflow.
- **Header/Footer**: Shared.
- **Chat Widget**: Shared.

---

## Phase 5: Workflows -- 4 Automations (4-5 hours)

Build the workflows in this order to handle tag dependencies correctly:

1. **Appointment Reminder** (creates `appointment-completed` tag used by Review Request)
2. **Review Request** (depends on `appointment-completed` tag)
3. **New Patient Welcome** (standalone, but interacts with Recall)
4. **6-Month Recall Reminder** (depends on `last_checkup_date` being populated)

---

### Workflow 1: Appointment Reminder (45-60 min)

**Trigger**: Appointment booked in GHL calendar
**Messages**: 1 confirmation email + 2 SMS reminders + 1 post-visit thank-you email
**Duration**: From booking through to post-visit

#### Pre-requisites

- Pipeline: Patient Appointments (Booked --> Confirmed --> Completed --> No Show)
- Tags: `appointment-booked`, `appointment-confirmed`, `appointment-no-show`, `appointment-completed`
- GHL Calendar set up with appointment types
- Two-way SMS enabled
- Email templates built (below)

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation --> Workflows --> Create New Workflow --> Start from Scratch**
2. Name the workflow: **Appointment Reminder**
3. Set workflow status to **Draft** until testing is complete

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Appointment Status**
6. Trigger filter: Appointment Status = **Booked**
7. Calendar: Select **All Calendars**

**Step 1 -- Add Tag + Move Pipeline:**

8. Add action: **Add Tag** --> `appointment-booked`
9. Add action: **Move Pipeline** --> Pipeline: Patient Appointments --> Stage: Booked

**Step 2 -- Send Confirmation Email (Immediate):**

10. Add action: **Send Email**
11. Name: "Appointment Confirmation Email"
12. Use the Appointment Confirmation Email content below
13. Set "From": `[BUSINESS_NAME]`
14. Set "Reply-to": `[EMAIL]`

**Step 3 -- Wait Until 24 Hours Before Appointment:**

15. Add action: **Wait**
16. Wait type: **Wait until specific date/time**
17. Date: **Appointment Start Date** minus 24 hours
18. Advanced: Tick **Wait only during business hours** and set window to 08:00-20:00. If the send time falls outside this window, it will send at next 09:00.
19. Note: If the appointment is less than 24 hours away, the wait resolves immediately.

**Step 4 -- Condition: Is Appointment Still Active?**

20. Add action: **If/Else Condition**
21. Condition: Contact **does NOT have tag** `appointment-cancelled` AND Contact **does NOT have tag** `appointment-no-show`
22. **If cancelled/rescheduled**: Add action **Remove Tag** --> `appointment-booked` --> **End This Path**
23. **If still active**: Continue

**Step 5 -- Send 24-Hour Reminder SMS:**

24. Add action: **Send SMS**
25. Name: "24h Appointment Reminder SMS"
26. Use the 24h Reminder SMS content below
27. Sending window: 08:00-20:00

**Step 6 -- Wait for Reply (4 Hours):**

28. Add action: **Wait**
29. Wait time: **4 hours**
30. Add action: **If/Else Condition**
31. Branch 1 -- "Replied YES": Contact replied with keyword YES or CONFIRMED
    - Add action: **Add Tag** --> `appointment-confirmed`
    - Add action: **Move Pipeline** --> Stage: Confirmed
32. Branch 2 -- "Replied CANCEL/NO": Contact replied with keyword CANCEL or NO
    - **End This Path** (manual handling or future Cancellation Recovery)
33. Branch 3 -- "No Reply": Proceed to next step

**Step 7 -- Wait Until 2 Hours Before Appointment:**

34. Add action: **Wait**
35. Wait type: **Wait until specific date/time**
36. Date: **Appointment Start Date** minus 2 hours
37. Business hours: If 2h-before falls outside 08:00-20:00, send at 19:00 the previous evening

**Step 8 -- Condition: Is Appointment Still Active?**

38. Add action: **If/Else Condition** (same as Step 4)
39. **If cancelled**: End path
40. **If active**: Continue

**Step 9 -- Send 2-Hour Reminder SMS:**

41. Add action: **Send SMS**
42. Name: "2h Appointment Reminder SMS"
43. Use the 2h Reminder SMS content below

**Step 10 -- Wait Until After Appointment:**

44. Add action: **Wait**
45. Wait type: **Wait until specific date/time**
46. Date: **Appointment End Date** plus 2 hours

**Step 11 -- Condition: Did Patient Attend?**

47. Add action: **If/Else Condition**
48. Condition: Contact **has tag** `appointment-no-show`
49. **If no-show**: End path (no thank-you email)
50. **If attended**: Continue

**Step 12 -- Send Post-Visit Thank You Email:**

51. Add action: **Send Email**
52. Name: "Post-Visit Thank You Email"
53. Use the Post-Visit Thank You content below
54. Add action: **Add Tag** --> `appointment-completed`
55. Add action: **Move Pipeline** --> Stage: Completed

**Step 13 -- End Workflow**

#### Email/SMS Content

##### Appointment Confirmation Email

- **Subject**: Your appointment at {{location.name}} is confirmed
- **Body**:
```
Hi {{contact.first_name}},

Your appointment has been confirmed. Here are the details:

Appointment: {{appointment.calendar_name}}
Date & Time: {{appointment.start_time}}
Location: {{location.name}}, {{location.address}}

What to bring:
- Photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)

Need to reschedule or cancel? Please give us at least 24 hours' notice by calling {{location.phone}}.

We look forward to seeing you.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "View on Map" --> link to Google Maps URL of the practice

##### 24h Reminder SMS

- **Message**:
```
Hi {{contact.first_name}}, this is a reminder of your appointment at {{location.name}} tomorrow at {{appointment.start_time}}. Reply YES to confirm or call us on {{location.phone}} to reschedule.
```

##### 2h Reminder SMS

- **Message**:
```
Hi {{contact.first_name}}, just a quick reminder -- your appointment is in 2 hours at {{appointment.start_time}}. See you soon at {{location.name}}, {{location.address}}.
```

##### Post-Visit Thank You Email

- **Subject**: Thank you for visiting {{location.name}}, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

Thank you for visiting us today at {{location.name}}. We hope everything went well.

If you have any questions about your treatment or aftercare, please do not hesitate to contact us on {{location.phone}} or reply to this email.

A few helpful reminders:
- If you experienced any numbness from anaesthetic, avoid hot drinks and food until full feeling has returned.
- Brush gently around any treated areas for the first 24 hours.
- Take any recommended pain relief as directed.

We recommend scheduling your next check-up in 6 months to keep your oral health on track. You can book online anytime.

Thank you for choosing {{location.name}}.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your Next Appointment" --> link to `{{location.booking_link}}`

#### Testing Checklist

- [ ] Trigger fires when a new appointment is booked via online booking
- [ ] Trigger fires when a new appointment is manually created by reception
- [ ] Confirmation email sends immediately with correct merge fields
- [ ] 24h wait calculates correctly based on appointment date
- [ ] 24h SMS sends within business hours (08:00-20:00)
- [ ] Reply YES/CONFIRMED is detected and adds `appointment-confirmed` tag
- [ ] Reply CANCEL/NO ends the path
- [ ] 2h SMS sends correctly with address details
- [ ] Post-visit thank-you email does NOT send to no-shows
- [ ] Post-visit thank-you email sends approximately 2h after appointment end
- [ ] Same-day appointment (< 2h away) skips reminder SMS steps and sends only confirmation
- [ ] All merge fields render correctly (no blank {{fields}})
- [ ] Pipeline stages update at each key step
- [ ] Workflow exits cleanly when appointment is cancelled mid-sequence

---

### Workflow 2: Review Request (30-40 min)

**Trigger**: Tag `appointment-completed` added (by Appointment Reminder workflow)
**Messages**: 2 emails
**Duration**: 5 days

#### Pre-requisites

- Pipeline: Patient Engagement (Review Requested --> Review Clicked --> Review Sequence Complete)
- Tags: `appointment-completed`, `review-requested`, `review-clicked`, `review-left`, `review-requested-complete`
- Google review direct link stored in Location custom field `google_review_link`
- Marketing consent tracking enabled

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation --> Workflows --> Create New Workflow --> Start from Scratch**
2. Name the workflow: **Review Request**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `appointment-completed`

**Step 1 -- Condition: Already Reviewed or Recently Requested?**

7. Add action: **If/Else Condition**
8. Condition: Contact **has tag** `review-left` OR Contact **has tag** `review-requested`
9. **If tagged**: End workflow (exit)
10. **If not tagged**: Continue

**Step 2 -- Condition: Has Marketing Consent?**

11. Add action: **If/Else Condition**
12. Condition: Contact **DND (Marketing Email)** = **OFF**
13. **If no consent / DND is ON**: End workflow
14. **If consent given**: Continue

**Step 3 -- Wait 24 Hours:**

15. Add action: **Wait**
16. Wait time: **24 hours**
17. Advanced: If the 24h mark falls outside business hours, defer to next day at 10:00 AM

**Step 4 -- Send Review Request Email:**

18. Add action: **Send Email**
19. Name: "Review Request Email"
20. Use the Review Request Email content below
21. Add action: **Add Tag** --> `review-requested`
22. Enable **Link Click Tracking**

**Step 5 -- Wait 3 Days (72 hours):**

23. Add action: **Wait**
24. Wait time: **3 days**

**Step 6 -- Condition: Did They Click the Review Link?**

25. Add action: **If/Else Condition**
26. Condition: **Link Clicked** in the Review Request Email
27. **If clicked**:
    - Add action: **Add Tag** --> `review-clicked`
    - Add action: **Move Pipeline** --> Stage: Review Clicked
    - End workflow
28. **If not clicked**: Continue

**Step 7 -- Condition: Still Has Marketing Consent?**

29. Add action: **If/Else Condition**
30. Condition: DND (Marketing Email) = OFF
31. **If unsubscribed**: End workflow
32. **If still subscribed**: Continue

**Step 8 -- Send Follow-Up Review Request Email:**

33. Add action: **Send Email**
34. Name: "Review Request Follow-Up Email"
35. Use the Review Request Follow-Up content below

**Step 9 -- Wait 48 Hours:**

36. Add action: **Wait**
37. Wait time: **48 hours**

**Step 10 -- Condition: Did They Click the Review Link?**

38. Add action: **If/Else Condition**
39. Same check as Step 6 but against the follow-up email
40. **If clicked**: Add tag `review-clicked`, end workflow
41. **If not clicked**: Continue

**Step 11 -- Mark Sequence Complete:**

42. Add action: **Add Tag** --> `review-requested-complete`
43. Add action: **Move Pipeline** --> Stage: Review Sequence Complete
44. End workflow

#### Email/SMS Content

##### Review Request Email

- **Subject**: How was your visit, {{contact.first_name}}?
- **Body**:
```
Hi {{contact.first_name}},

Thank you for visiting {{location.name}} yesterday. We hope you had a positive experience with us.

We would really appreciate it if you could take 60 seconds to share your experience on Google. Your feedback helps other patients find a dental practice they can trust, and it means a lot to our team.

[BUTTON: Leave a Review]

It is quick and easy -- just click the button above and leave a star rating with a few words about your visit.

Thank you for your support.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Leave a Review" --> link to `{{location.google_review_link}}`
- **Footer**: Must include unsubscribe link (marketing email)

##### Review Request Follow-Up Email

- **Subject**: We'd love to hear from you, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

We sent you a message a few days ago asking about your recent visit to {{location.name}}. If you have a moment, we would truly value your feedback.

Leaving a Google review takes less than 60 seconds and helps us continue providing excellent care to our community.

[BUTTON: Share Your Experience]

No worries if you would rather not -- we are just grateful to have you as a patient.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Share Your Experience" --> link to `{{location.google_review_link}}`
- **Footer**: Must include unsubscribe link (marketing email)

#### Testing Checklist

- [ ] Trigger fires when `appointment-completed` tag is added
- [ ] Workflow exits if contact already has `review-left` tag
- [ ] Workflow exits if contact already has `review-requested` tag
- [ ] Workflow exits if contact has no marketing consent / DND is ON
- [ ] First email sends 24 hours after trigger with correct merge fields
- [ ] Google review link in the email is correct and clickable
- [ ] Link click tracking detects when the review CTA is clicked
- [ ] Follow-up email does NOT send if first email link was clicked
- [ ] Follow-up email sends 3 days after the first email
- [ ] Unsubscribe link works in both emails
- [ ] Pipeline stages update correctly
- [ ] Sequence completes and tags are applied after both emails are exhausted without clicks

---

### Workflow 3: 6-Month Recall Reminder (50-60 min)

**Trigger**: 167 days (5 months, 2 weeks) after `last_checkup_date`
**Messages**: 2 emails + 1 SMS
**Duration**: ~5 weeks

#### Pre-requisites

- Pipeline: Recall Management (Recall Due --> Recall Booked --> Overdue - Manual Follow-up)
- Tags: `recall-due`, `recall-email-1-sent`, `recall-sms-sent`, `recall-email-2-sent`, `recall-booked`, `recall-sequence-complete`, `recall-overdue`
- Custom field: `last_checkup_date` (Date type) -- must be populated after every check-up
- Location custom field: `booking_link`
- Marketing consent tracking enabled

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation --> Workflows --> Create New Workflow --> Start from Scratch**
2. Name the workflow: **6-Month Recall Reminder**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Date Based** (or **Custom Date Reminder**)
6. Custom field: `last_checkup_date`
7. Trigger: **167 days after** the custom field date (5 months and 2 weeks)
8. Time of day: **09:00 AM**

**Step 1 -- Add Tag + Move Pipeline:**

9. Add action: **Add Tag** --> `recall-due`
10. Add action: **Move Pipeline** --> Pipeline: Recall Management --> Stage: Recall Due

**Step 2 -- Condition: Future Appointment Already Booked?**

11. Add action: **If/Else Condition**
12. Condition: Contact **has a future appointment** in GHL calendar (or has tag `appointment-booked`)
13. **If future appointment exists**: Add tag `recall-booked`, end workflow
14. **If no future appointment**: Continue

**Step 3 -- Condition: Has Marketing Consent?**

15. Add action: **If/Else Condition**
16. Condition: Contact DND (Marketing Email) = OFF
17. **If no consent**: Skip to Step 6 (SMS path)
18. **If consent**: Continue

**Step 4 -- Send First Recall Email:**

19. Add action: **Send Email**
20. Name: "Recall Reminder Email 1"
21. Use the Recall Reminder Email 1 content below
22. Add action: **Add Tag** --> `recall-email-1-sent`

**Step 5 -- Wait 14 Days:**

23. Add action: **Wait**
24. Wait time: **14 days**

**Step 6 -- Condition: Has Patient Booked?**

25. Add action: **If/Else Condition**
26. Condition: Contact **has tag** `appointment-booked` OR contact has a future appointment
27. **If booked**: Add tag `recall-booked`, remove tag `recall-due`, move pipeline to Recall Booked, end workflow
28. **If not booked**: Continue

**Step 7 -- Send Recall SMS:**

29. Add action: **Send SMS**
30. Name: "Recall Reminder SMS"
31. Use the Recall Reminder SMS content below
32. Sending window: 09:00-19:00
33. Add action: **Add Tag** --> `recall-sms-sent`

**Step 8 -- Wait 14 Days:**

34. Add action: **Wait**
35. Wait time: **14 days**

**Step 9 -- Condition: Has Patient Booked?**

36. Repeat the same check as Step 6
37. **If booked**: Tag `recall-booked`, remove `recall-due`, move pipeline, end workflow
38. **If not booked**: Continue

**Step 10 -- Condition: Still Has Marketing Consent?**

39. Add action: **If/Else Condition**
40. Condition: DND (Marketing Email) = OFF
41. **If unsubscribed**: Add tag `recall-sequence-complete`, end workflow
42. **If still subscribed**: Continue

**Step 11 -- Send Final Recall Email:**

43. Add action: **Send Email**
44. Name: "Recall Reminder Final Email"
45. Use the Recall Reminder Final Email content below
46. Add action: **Add Tag** --> `recall-email-2-sent`

**Step 12 -- Wait 7 Days:**

47. Add action: **Wait**
48. Wait time: **7 days**

**Step 13 -- Condition: Final Booking Check:**

49. Repeat booking check
50. **If booked**: Tag `recall-booked`, remove `recall-due`, end workflow
51. **If not booked**: Continue

**Step 14 -- Mark for Manual Follow-up:**

52. Add action: **Add Tag** --> `recall-sequence-complete`
53. Add action: **Add Tag** --> `recall-overdue`
54. Add action: **Move Pipeline** --> Stage: Overdue - Manual Follow-up
55. Add action: **Create Task** (Internal Notification)
    - Task name: "Manual recall follow-up needed"
    - Description: "{{contact.first_name}} {{contact.last_name}} did not respond to automated recall sequence. Last check-up: {{custom_field.last_checkup_date}}. Please call to schedule."
    - Assign to: Reception team / Practice Manager
56. End workflow

#### Email/SMS Content

##### Recall Reminder Email 1

- **Subject**: Time for your check-up, {{contact.first_name}}
- **Body**:
```
Hi {{contact.first_name}},

It has been almost 6 months since your last check-up at {{location.name}}, and it is time to book your next one.

Regular check-ups are the best way to keep your teeth and gums healthy. They allow us to spot potential issues early -- when they are quicker, simpler, and less costly to treat.

We also recommend combining your check-up with a hygiene appointment to keep your smile looking and feeling its best.

[BUTTON: Book Your Check-up]

You can book online at any time, or call us on {{location.phone}} during opening hours.

We look forward to seeing you.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your Check-up" --> link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

##### Recall Reminder SMS

- **Message**:
```
Hi {{contact.first_name}}, it's been nearly 6 months since your last check-up at {{location.name}}. Book online: {{location.booking_link}} or call {{location.phone}}. Reply STOP to opt out.
```

##### Recall Reminder Final Email

- **Subject**: Don't miss your check-up, {{contact.first_name}} -- it's overdue
- **Body**:
```
Hi {{contact.first_name}},

Your 6-month check-up at {{location.name}} is now overdue, and we wanted to reach out one more time.

Regular dental check-ups are essential for:
- Early detection of decay, gum disease, and oral cancer
- Preventing small issues from becoming complex (and costly) treatments
- Keeping your teeth and gums in the best possible condition

We have availability this week and would love to get you booked in. It only takes a few minutes.

[BUTTON: Book Now]

If you have any concerns or questions, please do not hesitate to call us on {{location.phone}}. Our team is always happy to help.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Now" --> link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (marketing email)

#### Testing Checklist

- [ ] Trigger fires 167 days after `last_checkup_date` is set
- [ ] Trigger fires at 09:00 AM
- [ ] Workflow exits immediately if patient already has a future appointment booked
- [ ] Workflow exits if no marketing consent
- [ ] First email sends with correct merge fields and working booking link
- [ ] 14-day wait between email and SMS is accurate
- [ ] SMS sends within 09:00-19:00 window only
- [ ] SMS includes STOP opt-out text
- [ ] Booking check correctly detects newly booked appointments at each stage
- [ ] Final email has appropriate urgency tone
- [ ] Manual follow-up task is created for non-responders
- [ ] Pipeline stages update at each transition
- [ ] Unsubscribe link works in all emails
- [ ] `last_checkup_date` update after next check-up resets the cycle for another 167 days

---

### Workflow 4: New Patient Welcome (35-45 min)

**Trigger**: Tag `new-patient` added (by registration form, receptionist, or chatbot)
**Messages**: 1 welcome email (or SMS) + 1 follow-up email (branched)
**Duration**: 48 hours

#### Pre-requisites

- Pipeline: New Patient Journey (New Registration --> Welcomed)
- Tags: `new-patient`, `welcome-email-sent`, `welcome-followup-sent`, `new-patient-welcomed`
- Location custom fields: `booking_link`, `parking_info`

#### GHL Workflow Builder -- Step by Step

1. Go to **Automation --> Workflows --> Create New Workflow --> Start from Scratch**
2. Name the workflow: **New Patient Welcome**
3. Set workflow status to **Draft**

**Trigger Configuration:**

4. Click **Add New Trigger**
5. Trigger type: **Tag Added**
6. Tag: `new-patient`

**Step 1 -- Move Pipeline:**

7. Add action: **Move Pipeline** --> Pipeline: New Patient Journey --> Stage: New Registration

**Step 2 -- Condition: Has Valid Email?**

8. Add action: **If/Else Condition**
9. Condition: Contact **Email** is **not empty**
10. **If no email**: Go to SMS Welcome path (Step 2b)
11. **If email exists**: Continue to Step 3

**Step 2b -- SMS Welcome (No Email Path):**

12. Add action: **Send SMS**
13. Name: "New Patient Welcome SMS"
14. Use the New Patient Welcome SMS content below
15. Add action: **Add Tag** --> `welcome-email-sent`
16. Skip to Step 7 (Mark Complete)

**Step 3 -- Send Welcome Email (Immediate):**

17. Add action: **Send Email** (no wait/delay)
18. Name: "New Patient Welcome Email"
19. Use the New Patient Welcome Email content below
20. Add action: **Add Tag** --> `welcome-email-sent`

**Step 4 -- Wait 48 Hours:**

21. Add action: **Wait**
22. Wait time: **48 hours**
23. Advanced: If 48h falls on a Sunday, defer to Monday 09:00

**Step 5 -- Condition: Has First Appointment Been Booked?**

24. Add action: **If/Else Condition**
25. Condition: Contact **has tag** `appointment-booked` OR has a future appointment
26. **If booked**: Go to Step 6a (Follow-up with appointment context)
27. **If not booked**: Go to Step 6b (Follow-up with booking nudge)

**Step 6a -- Send Follow-Up Email (Booked Path):**

28. Add action: **Send Email**
29. Name: "New Patient Follow-Up (Booked)"
30. Use the Welcome Follow-Up -- Booked content below
31. Add action: **Add Tag** --> `welcome-followup-sent`
32. Continue to Step 7

**Step 6b -- Send Follow-Up Email (Not Booked Path):**

33. Add action: **Send Email**
34. Name: "New Patient Follow-Up (Not Booked)"
35. Use the Welcome Follow-Up -- Not Booked content below
36. Add action: **Add Tag** --> `welcome-followup-sent`
37. Continue to Step 7

**Step 7 -- Mark Welcome Sequence Complete:**

38. Add action: **Add Tag** --> `new-patient-welcomed`
39. Add action: **Move Pipeline** --> Stage: Welcomed
40. End workflow

#### Email/SMS Content

##### New Patient Welcome Email

- **Subject**: Welcome to {{location.name}}, {{contact.first_name}}!
- **Body**:
```
Hi {{contact.first_name}},

Welcome to {{location.name}}! We are delighted to have you join our practice and look forward to taking great care of your dental health.

Here is everything you need to know before your first visit:

WHAT TO EXPECT
Your first appointment will take approximately 45 minutes to an hour. We will carry out a thorough examination, take any necessary X-rays, and discuss your dental health and any concerns you may have. There is no pressure for any treatment on your first visit.

WHAT TO BRING
- A form of photo ID
- A list of any medications you are currently taking
- Dental insurance details (if applicable)
- Any previous dental records or X-rays (if you have them)

FINDING US
{{location.name}} is located at {{location.address}}.
Parking: {{location.parking_info}}

[BUTTON: Get Directions]

BOOK YOUR FIRST APPOINTMENT
If you have not already booked your first visit, you can do so online -- it only takes a minute.

[BUTTON: Book Now]

Alternatively, call us on {{location.phone}} and our reception team will be happy to help.

If you have any questions at all, simply reply to this email or give us a ring. We are here to help.

Warm regards,
The team at {{location.name}}
```
- **CTA Button 1**: "Get Directions" --> link to Google Maps URL
- **CTA Button 2**: "Book Now" --> link to `{{location.booking_link}}`

##### New Patient Welcome SMS

- **Message**:
```
Welcome to {{location.name}}, {{contact.first_name}}! We're looking forward to seeing you. If you have any questions before your first visit, call us on {{location.phone}} or book online: {{location.booking_link}}
```

##### Welcome Follow-Up -- Booked

- **Subject**: Your first appointment at {{location.name}} -- a quick reminder
- **Body**:
```
Hi {{contact.first_name}},

Just a quick note to confirm we are looking forward to seeing you at your upcoming appointment.

As a reminder, please bring:
- Photo ID
- A list of any medications
- Insurance details (if applicable)

If you have any questions before your visit, reply to this email or call us on {{location.phone}}. Our team is friendly and here to make you comfortable.

See you soon!

Warm regards,
The team at {{location.name}}
```

##### Welcome Follow-Up -- Not Booked

- **Subject**: Ready to book your first visit, {{contact.first_name}}?
- **Body**:
```
Hi {{contact.first_name}},

We noticed you have not yet booked your first appointment at {{location.name}} and wanted to check in.

Booking is quick and easy -- it takes less than a minute online:

[BUTTON: Book Your First Visit]

Whether you need a routine check-up or have a specific concern, we are here to help. We offer:
- Comprehensive new patient examinations
- Flexible appointment times, including early mornings and evenings
- A relaxed, no-pressure environment

Not sure what type of appointment to book? Call us on {{location.phone}} and our reception team will guide you.

We look forward to welcoming you to the practice.

Warm regards,
The team at {{location.name}}
```
- **CTA Button**: "Book Your First Visit" --> link to `{{location.booking_link}}`
- **Footer**: Include unsubscribe link (this email promotes a new booking)

#### Testing Checklist

- [ ] Trigger fires when `new-patient` tag is added manually
- [ ] Trigger fires when registration form is submitted (if form adds the tag)
- [ ] Welcome email sends within 5 minutes of registration
- [ ] SMS welcome sends correctly when contact has no email address
- [ ] 48-hour follow-up sends on time
- [ ] Follow-up correctly branches based on whether appointment is booked or not
- [ ] Booked path sends the "appointment context" version
- [ ] Not-booked path sends the "booking nudge" version with unsubscribe link
- [ ] Google Maps link and booking link are both correct and clickable
- [ ] Parking information renders correctly from location custom field
- [ ] Pipeline stages update (New Registration --> Welcomed)
- [ ] Duplicate contacts (already existing patients) do not trigger the workflow

---

## Phase 6: Email/SMS Templates -- 6 Templates (1-1.5 hours)

The email and SMS content is embedded in the workflow instructions above. This section provides a consolidated reference for building all 6 templates in GHL's email builder.

### How to Build Email Templates in GHL

1. Go to **Marketing --> Emails --> Templates**
2. Click **Create New Template**
3. Select **Code** or **Drag & Drop** builder
4. For Code builder: paste the HTML below. For Drag & Drop: recreate the layout manually
5. Set template name, subject line, and preview text
6. Test send to your own email before activating

### Email Design Standards

All emails follow these design rules:

| Property | Value |
|----------|-------|
| Max width | 600px |
| Background | #f8fafc |
| Content area background | #ffffff |
| Heading colour | #0f172a |
| Body text colour | #475569 |
| CTA button background | #2563eb |
| CTA button hover | #1d4ed8 |
| CTA button text | #ffffff |
| CTA button padding | 14px 28px |
| CTA button border-radius | 12px |
| Font | DM Sans (with Arial, sans-serif fallback) |
| Logo | Top of email, centred, max 180px wide |
| Footer | Unsubscribe link, practice address, phone |

### Template 1: Appointment Confirmation (Email)

- **Template Name**: Appointment Confirmation
- **Subject**: Your appointment at {{location.name}} is confirmed
- **Preview Text**: Here are your appointment details
- **Type**: Transactional
- **Content**: See Workflow 1, Appointment Confirmation Email section above
- **Merge Fields Used**: `{{contact.first_name}}`, `{{appointment.calendar_name}}`, `{{appointment.start_time}}`, `{{location.name}}`, `{{location.address}}`, `{{location.phone}}`
- **CTA**: "View on Map" --> Google Maps URL
- **Unsubscribe**: Not required (transactional)

### Template 2: 24h Reminder (SMS)

- **Template Name**: 24h Appointment Reminder
- **Type**: Transactional
- **Content**: See Workflow 1, 24h Reminder SMS section above
- **Character Count**: ~195 characters (1 SMS segment)
- **Merge Fields Used**: `{{contact.first_name}}`, `{{location.name}}`, `{{appointment.start_time}}`, `{{location.phone}}`

### Template 3: Review Request (Email)

- **Template Name**: Review Request
- **Subject**: How was your visit, {{contact.first_name}}?
- **Preview Text**: We would love to hear your feedback
- **Type**: Marketing
- **Content**: See Workflow 2, Review Request Email section above
- **Merge Fields Used**: `{{contact.first_name}}`, `{{location.name}}`, `{{location.google_review_link}}`
- **CTA**: "Leave a Review" --> `{{location.google_review_link}}`
- **Unsubscribe**: Required (marketing email)

### Template 4: Recall Reminder 1 (Email)

- **Template Name**: Recall Reminder - First
- **Subject**: Time for your check-up, {{contact.first_name}}
- **Preview Text**: It has been 6 months since your last visit
- **Type**: Marketing
- **Content**: See Workflow 3, Recall Reminder Email 1 section above
- **Merge Fields Used**: `{{contact.first_name}}`, `{{location.name}}`, `{{location.phone}}`, `{{location.booking_link}}`
- **CTA**: "Book Your Check-up" --> `{{location.booking_link}}`
- **Unsubscribe**: Required (marketing email)

### Template 5: Recall Reminder 2 (SMS)

- **Template Name**: Recall Reminder SMS
- **Type**: Marketing
- **Content**: See Workflow 3, Recall Reminder SMS section above
- **Character Count**: ~195 characters (1 SMS segment)
- **Merge Fields Used**: `{{contact.first_name}}`, `{{location.name}}`, `{{location.booking_link}}`, `{{location.phone}}`
- **Must include**: "Reply STOP to opt out" (marketing SMS requirement)

### Template 6: Recall Final (Email)

- **Template Name**: Recall Reminder - Final
- **Subject**: Don't miss your check-up, {{contact.first_name}} -- it's overdue
- **Preview Text**: Your check-up is overdue -- book now
- **Type**: Marketing
- **Content**: See Workflow 3, Recall Reminder Final Email section above
- **Merge Fields Used**: `{{contact.first_name}}`, `{{location.name}}`, `{{location.phone}}`, `{{location.booking_link}}`
- **CTA**: "Book Now" --> `{{location.booking_link}}`
- **Unsubscribe**: Required (marketing email)

### Additional Templates (Built as Part of Workflows)

These templates are also created during the workflow build but are not counted in the "6 templates" deliverable as they are secondary/conditional messages:

| Template | Type | Used By |
|----------|------|---------|
| 2h Reminder SMS | Transactional | Workflow 1 |
| Post-Visit Thank You Email | Transactional | Workflow 1 |
| Review Request Follow-Up Email | Marketing | Workflow 2 |
| New Patient Welcome Email | Transactional | Workflow 4 |
| New Patient Welcome SMS | Transactional | Workflow 4 |
| Welcome Follow-Up (Booked) Email | Transactional | Workflow 4 |
| Welcome Follow-Up (Not Booked) Email | Marketing | Workflow 4 |

---

## Phase 7: AI Chatbot -- Enhanced (90-120 min)

The Elevate AI chatbot includes everything from Ignite AI (FAQ + booking redirect) plus detailed treatment information and new patient guidance.

### Step 1: Create the Bot

1. Go to **Settings --> Conversation AI** (or **Automation --> Conversation AI**)
2. Click **Create New Bot**
3. Bot Name: `[BOT_NAME]` (e.g., "Ava")
4. Bot Type: **Support Bot**
5. Enable Channels:
   - Website Chat Widget: ON
   - Facebook Messenger: ON (if practice has a Facebook page)
   - Instagram DM: ON (if practice has Instagram)
   - SMS: OFF (enable after testing)
   - WhatsApp: ON (if practice uses WhatsApp Business)
6. Response Mode: **Auto-Reply**
7. Operating Hours: **Always On**
8. Click **Save**

### Step 2: System Prompt

Paste the following complete system prompt into GHL's **System Prompt** or **Bot Instructions** field. Replace ALL `[PLACEHOLDER]` values with client data before going live.

```
You are the virtual dental assistant for [BUSINESS_NAME], a [PRACTICE_TYPE] located in [LOCATION]. Your name is [BOT_NAME].

You are a helpful, professional, and reassuring digital assistant. You are NOT a dentist, dental nurse, or any form of clinician. You never diagnose conditions, prescribe treatment, or provide medical advice. You share general information about treatments and services, and guide patients towards booking an appointment or speaking with the clinical team.

You always identify as an AI assistant when asked. You never claim or imply that you are a human.

Your primary goal in every conversation is to help the patient get the information they need and, where appropriate, guide them to book an appointment.

CORE INFORMATION:
- Practice name: [BUSINESS_NAME]
- Address: [ADDRESS_LINE_1], [ADDRESS_LINE_2], [CITY], [POSTCODE]
- Telephone: [PHONE]
- Emergency telephone: [EMERGENCY_PHONE]
- Email: [EMAIL]
- Website: [WEBSITE_URL]
- Online booking: [BOOKING_URL]
- Google Maps: [GOOGLE_MAPS_URL]
- Parking: [PARKING_INFO]
- Wheelchair access: [ACCESSIBILITY_INFO]
- NHS status: [NHS_STATUS]

OPENING HOURS:
- Monday: [MON_HOURS]
- Tuesday: [TUE_HOURS]
- Wednesday: [WED_HOURS]
- Thursday: [THU_HOURS]
- Friday: [FRI_HOURS]
- Saturday: [SAT_HOURS]
- Sunday: [SUN_HOURS]
- Bank holidays: [BANK_HOL_HOURS]
- Emergency out-of-hours: [OUT_OF_HOURS_INFO]

CONVERSATION RULES:
1. Keep every response to 2-3 sentences maximum. Use bullet points for any list of 3+ items.
2. Be professional, warm, and reassuring. Use British English throughout (surgery not office, check-up not checkup, anaesthetic not anesthetic, colour not color).
3. Steer conversations towards booking an appointment within 3 turns where appropriate. Always provide the booking link: [BOOKING_URL]
4. Never diagnose. Never say "you have..." or "it sounds like you have...". Instead say "Based on what you've described, I'd recommend booking a [type] appointment so our team can take a proper look."
5. Always give price ranges, never exact quotes. Add "exact costs will be confirmed after your consultation."
6. Ask one question at a time when gathering information.
7. If a patient expresses fear, pain, or anxiety, acknowledge it before giving practical advice. Example: "I completely understand -- dental anxiety is very common and nothing to be embarrassed about."
8. Never ask for full date of birth, NHS number, or medical details in chat. Direct the patient to call or complete a secure form.
9. Begin every new conversation with: "[BOT_GREETING]"
10. End conversations with a clear next step and warm sign-off.
11. If you do not know the answer, say: "That's a great question -- let me connect you with our team for the most accurate answer." Then trigger escalation.
12. Never rush emergency patients. Provide the emergency phone number immediately.

EMERGENCY DETECTION:
If the patient's message contains any of these keywords or close variations, immediately provide the emergency response:
- "severe pain", "can't stop the bleeding", "heavy bleeding", "swollen face", "neck swelling"
- "knocked out tooth", "tooth fell out", "abscess"
- "difficulty breathing", "trouble swallowing", "can't swallow"
- "pus", "discharge", "hit in the face", "accident", "trauma to mouth"
- "jaw feels locked", "can't open my mouth"
- "fever" combined with any dental symptom

EMERGENCY RESPONSE:
"This sounds like it could be a dental emergency, and I want to make sure you get the right help straight away. Please call us now on [EMERGENCY_PHONE] so our team can assess and advise you immediately. If you are experiencing difficulty breathing, difficulty swallowing, or severe swelling spreading to your neck or eye, please call 999 or go to A&E immediately."

Emergency rules: Do NOT diagnose. Do NOT suggest waiting. Do NOT try to book online. Always err on the side of caution.

SERVICES AND PRICING (price ranges only -- say "exact costs confirmed after consultation"):

General Dentistry:
- Check-up & examination: £50-80
- Scale & polish (hygiene): £55-75
- Fillings (composite/white): £80-200
- Root canal treatment: £250-600
- Tooth extraction (simple): £100-200
- Wisdom tooth removal: £200-400
- Crowns: £400-700

Cosmetic Dentistry:
- Teeth whitening (in-surgery): £300-600
- Teeth whitening (home kit): £200-350
- Composite bonding: £200-400 per tooth
- Porcelain veneers: £500-1,000 per tooth
- Smile makeover: from £2,000

Orthodontics:
- Invisalign / clear aligners: £2,500-5,500
- Fixed braces: from £2,000

Dental Implants:
- Single dental implant: £2,000-3,000 per tooth
- Implant-supported bridge: from £4,000

Emergency:
- Emergency appointment: £80-150

Children:
- Children's check-up: from £40
- Fissure sealants: from £30
- Fluoride varnish: from £25

TREATMENT INFORMATION (Elevate AI -- detailed descriptions for patient enquiries):

Teeth Whitening:
We offer two whitening options. In-surgery power whitening takes about 90 minutes and delivers dramatic results in a single visit. Custom take-home trays provide gradual whitening over 2-3 weeks using professional-strength gel. Both methods are safe, effective, and supervised by our dental team. Results typically last 12-18 months with good care. Touch-up treatments are available. Price range: £200-600.

Dental Implants:
A dental implant is a titanium post placed into the jawbone to replace a missing tooth root. Once healed (usually 3-6 months), a custom porcelain crown is fitted on top. The result looks, feels, and functions exactly like a natural tooth. Implants can also support bridges or dentures for multiple missing teeth. Success rates exceed 95% in healthy patients. A CT scan and consultation are required first. Price range: £2,000-3,000 per single implant.

Invisalign / Clear Aligners:
Invisalign uses a series of custom-made, nearly invisible removable aligners to gradually straighten your teeth. Treatment typically takes 6-18 months depending on complexity. Aligners are changed every 1-2 weeks and should be worn for 20-22 hours per day. Suitable for mild to moderate crowding, spacing, and bite issues. A free consultation including a digital scan is available to see if you are a candidate. Price range: £2,500-5,500.

Composite Bonding:
A non-invasive cosmetic treatment where tooth-coloured resin is sculpted onto your teeth to fix chips, gaps, or uneven edges. The procedure is quick (30-60 minutes per tooth), painless (no drilling or anaesthetic needed in most cases), and delivers immediate results. Bonding typically lasts 5-7 years with good care. Price range: £200-400 per tooth.

Porcelain Veneers:
Ultra-thin porcelain shells custom-made and bonded to the front surface of your teeth. Veneers can correct colour, shape, size, and alignment issues for a completely transformed smile. The process takes 2-3 appointments: consultation, preparation, and fitting. Veneers typically last 10-15 years. Price range: £500-1,000 per tooth.

Root Canal Treatment:
A procedure to save a tooth that has become infected or severely decayed. The infected nerve tissue is carefully removed, the canals are cleaned and shaped, and the tooth is sealed. Contrary to popular belief, modern root canal treatment is no more uncomfortable than having a filling. A crown is usually recommended afterwards to protect the treated tooth. Price range: £250-600.

Dental Crowns:
A custom-made porcelain cap that covers and protects a damaged, weakened, or heavily filled tooth. Crowns restore the tooth's strength, shape, and appearance. The process takes 2 appointments: preparation and fitting (with a temporary crown in between). Modern crowns are matched precisely to your natural teeth. Price range: £400-700.

Children's Dentistry:
We make dental visits fun and positive for children of all ages. We recommend first visits from around 6-12 months of age. Children's check-ups include a gentle examination, oral hygiene advice, and fluoride varnish if appropriate. We offer fissure sealants to protect back teeth from decay. Our team is experienced at putting nervous children at ease.

NEW PATIENT GUIDANCE (Elevate AI):

When a new patient asks about registering or visiting for the first time, provide the following information:

Registration process:
"Registering with us is easy. You can book your first appointment online at [BOOKING_URL] or call us on [PHONE]. We will send you a short medical history form to complete before your visit. There is no registration fee."

What to expect at your first visit:
"Your first appointment will take approximately 45 minutes to an hour. Your dentist will carry out a thorough examination, take any necessary X-rays, and discuss your dental health and any concerns. There is no pressure for any treatment on your first visit -- it is all about understanding your needs and creating a plan."

What to bring:
"Please bring a form of photo ID, a list of any medications you are currently taking, dental insurance details if applicable, and any previous dental records or X-rays if you have them."

Finding the practice:
"We are located at [ADDRESS]. [PARKING_INFO]. For directions, visit [GOOGLE_MAPS_URL]."

Choosing between NHS and private (if applicable):
"[NHS_STATUS]. NHS dental treatment covers clinically necessary care at set government prices across three bands. Private treatment offers a wider choice of materials, longer appointment times, and access to cosmetic procedures. Our team can advise you on the best option during your consultation."

TEAM:
[TEAM_MEMBER_1_NAME] -- [ROLE] -- [NOTES]
[TEAM_MEMBER_2_NAME] -- [ROLE] -- [NOTES]
[TEAM_MEMBER_3_NAME] -- [ROLE] -- [NOTES]
[TEAM_MEMBER_4_NAME] -- [ROLE] -- [NOTES]

ESCALATION -- hand off to a human when:
- Complex treatment planning requests
- Insurance/payment queries beyond basic information
- Complaints or negative feedback
- Clinical advice requests (beyond general information)
- Patient asks to speak to a person
- Question you cannot answer
- Safeguarding concern (flag internally, do not discuss in chat)

When escalating: acknowledge the request, collect the patient's name and phone number, confirm the next step and estimated callback time.

THINGS YOU MUST NEVER DO:
- Claim to be human
- Provide a medical diagnosis
- Recommend specific medications beyond "over-the-counter pain relief such as paracetamol or ibuprofen"
- Guarantee treatment outcomes
- Discuss other patients or share personal data
- Make negative comments about other dental practices
- Use overly clinical jargon without explanation
- Pressure patients into booking
```

### Step 3: Knowledge Base

Upload these documents to **Conversation AI --> Knowledge Base**:

| Document | Contents | Format | Priority |
|----------|----------|--------|----------|
| Services & Pricing List | Full treatment list with descriptions and price ranges | PDF or text | Required |
| Opening Hours & Location | Hours, address, parking, directions, accessibility | Text | Required |
| FAQ Document | See FAQ content below | Text | Required |
| Team Information | Names, roles, specialisms, GDC numbers | Text | Required |
| New Patient Guide | What to expect, what to bring, first visit process | PDF or text | Required |
| Treatment Descriptions | Detailed descriptions of each treatment offered | PDF or text | Required |

#### FAQ Content to Upload

```
FREQUENTLY ASKED QUESTIONS -- [BUSINESS_NAME]

Q: Where are you located?
A: We are at [ADDRESS]. [PARKING_INFO]. For directions, visit: [GOOGLE_MAPS_URL]

Q: What are your opening hours?
A: Monday [MON_HOURS], Tuesday [TUE_HOURS], Wednesday [WED_HOURS], Thursday [THU_HOURS], Friday [FRI_HOURS], Saturday [SAT_HOURS], Sunday [SUN_HOURS]. Bank holidays: [BANK_HOL_HOURS].

Q: Do you accept NHS patients?
A: [NHS_STATUS_ANSWER]

Q: What is the difference between NHS and private treatment?
A: NHS dental treatment covers clinically necessary care at set government prices across three bands. Private treatment offers a wider choice of materials, longer appointment times, and access to cosmetic procedures not available on the NHS.

Q: Do you offer payment plans or finance?
A: [FINANCE_ANSWER]

Q: Do you accept dental insurance?
A: [INSURANCE_ANSWER]

Q: How do I register as a new patient?
A: You can register by booking your first appointment online at [BOOKING_URL] or by calling us on [PHONE]. We will send you a medical history form to complete before your first visit.

Q: How do I book an appointment?
A: Book online anytime at [BOOKING_URL] or call us on [PHONE] during opening hours.

Q: How often should I visit the dentist?
A: We recommend a check-up every 6 months, though your dentist may suggest a different interval based on your oral health.

Q: What should I bring to my first appointment?
A: Photo ID, a list of any medications, dental insurance details if applicable, and any previous dental records. Allow approximately 45 minutes to an hour for your first visit.

Q: How do I cancel or reschedule?
A: Call us on [PHONE] or message our chatbot. We ask for at least 24 hours notice. Late cancellations may incur a fee of £25.

Q: I need an urgent appointment. What should I do?
A: Call us directly on [PHONE] and we will do our best to see you today. Outside opening hours: [OUT_OF_HOURS_INFO].

Q: Is dental treatment painful?
A: Modern dentistry is much more comfortable than many people expect. We use local anaesthetic and our team checks you are comfortable throughout. Additional options include [SEDATION_OPTIONS].

Q: Do you treat nervous patients?
A: Yes, we specialise in helping anxious patients feel at ease. We offer [ANXIETY_OPTIONS]. You can request a longer appointment slot so there is no rush.

Q: What age should my child first see a dentist?
A: We recommend first visits from around 6-12 months of age. Children's check-ups are from £40.

Q: How much does teeth whitening cost?
A: Professional teeth whitening ranges from £200-600 depending on the method chosen. In-surgery power whitening provides instant results; custom take-home trays offer gradual improvement. Exact costs are confirmed at your consultation.

Q: Do you do dental implants?
A: Yes, we offer single tooth implants (from £2,000), implant-supported bridges, and full-arch solutions. A consultation and CT scan are needed first to assess suitability.

Q: What is Invisalign and how much does it cost?
A: Invisalign uses custom-made, nearly invisible removable aligners to straighten teeth. Treatment typically takes 6-18 months. Prices range from £2,500-5,500 depending on complexity. We offer free initial consultations.

Q: How long does composite bonding last?
A: Composite bonding typically lasts 5-7 years with good oral hygiene. It can be repaired or replaced easily.

Q: How long do veneers last?
A: Porcelain veneers typically last 10-15 years with good care.
```

### Step 4: Widget Configuration

1. Go to **Sites --> Chat Widget**
2. Configure:

| Setting | Value |
|---------|-------|
| Position | Bottom-right |
| Primary colour | `#2563eb` |
| Header colour | `#2563eb` |
| Header text colour | `#ffffff` |
| Bot avatar | Upload practice logo or friendly avatar |
| Bot name | `[BOT_NAME]` |
| Auto-open | No |
| Welcome message | `[BOT_GREETING]` |
| Prompt bubble | Yes |
| Prompt bubble text | "Need help? Chat with us!" |
| Prompt bubble delay | 5 seconds |
| Show on mobile | Yes |
| Show on desktop | Yes |

3. Page-specific prompts:

| Page | Trigger | Prompt Message |
|------|---------|----------------|
| Homepage | 5 seconds | "Need help? Chat with us!" |
| Services page | 10 seconds | "Have questions about our treatments?" |
| Booking page | Immediately | "Need help booking? I can assist!" |
| Contact page | 3 seconds | "We're here to help!" |

4. Exclude widget from: Privacy Policy, Terms and Conditions, Cookie Policy pages.

### Step 5: Escalation Rules

1. Go to **Conversation AI --> Configuration --> Handoff Settings**
2. Configure:

| Condition | Tag | Assign To |
|-----------|-----|-----------|
| Patient asks to speak to a human | `#escalation-human` | Reception Team |
| Bot cannot answer (3 failed attempts) | `#escalation-unknown` | Reception Team |
| Complaint or negative experience | `#escalation-complaint` | Practice Manager |
| Emergency keywords detected | `#escalation-emergency` | Practice Manager (notification) |
| Complex treatment planning | `#escalation-treatment` | Reception Team |

3. Handoff message: "Of course -- let me connect you with the right person. Could I take your name and a phone number so our team can call you back?"
4. Configure internal notifications for all escalated conversations.

### Chatbot Placeholder Replacement Checklist

Before going live, verify every `[PLACEHOLDER]` has been replaced:

- [ ] `[BUSINESS_NAME]`, `[PRACTICE_TYPE]`, `[LOCATION]`
- [ ] `[BOT_NAME]`, `[BOT_GREETING]`
- [ ] `[ADDRESS_LINE_1]`, `[ADDRESS_LINE_2]`, `[CITY]`, `[POSTCODE]`
- [ ] `[PHONE]`, `[EMERGENCY_PHONE]`, `[EMAIL]`
- [ ] `[WEBSITE_URL]`, `[BOOKING_URL]`, `[GOOGLE_MAPS_URL]`
- [ ] `[PARKING_INFO]`, `[ACCESSIBILITY_INFO]`, `[NHS_STATUS]`
- [ ] `[MON_HOURS]` through `[SUN_HOURS]`, `[BANK_HOL_HOURS]`, `[OUT_OF_HOURS_INFO]`
- [ ] All `[TEAM_MEMBER_X_NAME]` entries with roles and notes
- [ ] `[NHS_STATUS_ANSWER]`, `[FINANCE_ANSWER]`, `[INSURANCE_ANSWER]`
- [ ] `[SEDATION_OPTIONS]`, `[ANXIETY_OPTIONS]`

---

## Phase 8: Testing & QA (2-3 hours)

### Website Testing

Test each page on desktop (Chrome, Firefox, Safari) and mobile (iOS Safari, Android Chrome).

| # | Test | Expected | Pass/Fail |
|---|------|----------|-----------|
| 1 | Homepage loads correctly | All 8 sections render, images appear, no broken layout | |
| 2 | Services page loads correctly | All 6 categories display, prices show, cards render | |
| 3 | About page loads correctly | Story, values, team, accreditations all render | |
| 4 | Contact page loads correctly | Contact details, form, map, hours all render | |
| 5 | Booking page loads correctly | Calendar widget loads and shows available slots | |
| 6 | Navigation works | All menu links navigate to correct pages | |
| 7 | "Book Now" CTA | Navigates to /booking from every page | |
| 8 | Phone links | tel: links open phone dialler on mobile | |
| 9 | Email links | mailto: links open email client | |
| 10 | Google Maps | Map displays correct location | |
| 11 | Mobile responsive | All pages render correctly on mobile | |
| 12 | Contact form submission | Form submits, data appears in GHL contacts | |
| 13 | Calendar booking | Can complete a test booking end-to-end | |
| 14 | Chat widget | Widget appears on all pages (except excluded) | |
| 15 | Page load speed | All pages load under 3 seconds | |
| 16 | No placeholder text visible | No `[PLACEHOLDER]` text appears anywhere | |

### Workflow Testing

For each workflow, create a test contact and run through the complete sequence.

#### Workflow 1: Appointment Reminder

- [ ] Book a test appointment --> confirmation email received
- [ ] 24h SMS fires at correct time
- [ ] Reply YES --> `appointment-confirmed` tag added
- [ ] 2h SMS fires at correct time
- [ ] Post-visit thank-you sends after appointment (when not marked no-show)
- [ ] No-show tag prevents thank-you email
- [ ] Pipeline stages update correctly
- [ ] All merge fields render (no blank values)

#### Workflow 2: Review Request

- [ ] Add `appointment-completed` tag --> workflow starts
- [ ] Review email sends 24h later
- [ ] Google review link works and opens correct page
- [ ] Follow-up sends 3 days later (if link not clicked)
- [ ] Link click detection works
- [ ] Unsubscribe link functions

#### Workflow 3: 6-Month Recall Reminder

- [ ] Set `last_checkup_date` to 167 days ago --> workflow triggers
- [ ] First email sends with correct content
- [ ] SMS sends 14 days later (within hours window)
- [ ] Final email sends 14 days after SMS
- [ ] Booking at any stage exits workflow correctly
- [ ] Non-responders get manual follow-up task
- [ ] STOP keyword in SMS works

#### Workflow 4: New Patient Welcome

- [ ] Add `new-patient` tag --> welcome email sends immediately
- [ ] Parking info renders from location custom field
- [ ] 48h follow-up sends (booked version if appointment exists)
- [ ] 48h follow-up sends (not-booked version if no appointment)
- [ ] SMS path works for contacts without email

### Chatbot Testing

| # | Test | Expected | Pass/Fail |
|---|------|----------|-----------|
| 1 | "What are your opening hours?" | Correct hours displayed | |
| 2 | "Where are you located?" | Address, parking, map link | |
| 3 | "How do I register as a new patient?" | Registration process + booking link | |
| 4 | "What should I bring to my first appointment?" | Full list: ID, medications, insurance, records | |
| 5 | "How much is teeth whitening?" | Price range £200-600 + consultation CTA | |
| 6 | "Do you do dental implants?" | Description, price range, consultation offer | |
| 7 | "What is Invisalign?" | Description, duration, price range | |
| 8 | "How much is a check-up?" | Price range £50-80 | |
| 9 | "Do you accept NHS patients?" | Correct NHS status | |
| 10 | "My tooth got knocked out" | Immediate emergency response + phone number | |
| 11 | "I have severe pain and swelling" | Emergency response + A&E guidance | |
| 12 | "I'm scared of the dentist" | Empathetic response + anxiety support | |
| 13 | "I want to speak to a person" | Offers to collect details, escalates | |
| 14 | "I want to make a complaint" | Acknowledges, collects details, escalates | |
| 15 | "Are you a real person?" | Identifies as AI assistant | |
| 16 | Widget appears on homepage | Bottom-right, correct colour | |
| 17 | Widget hidden on privacy policy | Widget not present | |
| 18 | Mobile chat works | Full functionality on mobile | |

### Email Deliverability Testing

- [ ] Send test emails to Gmail, Outlook, Yahoo, and Apple Mail
- [ ] Check spam score (aim for under 3.0 in Mail Tester)
- [ ] Verify SPF, DKIM, DMARC all pass
- [ ] CTA buttons render correctly in all clients
- [ ] Images load (or show alt text)
- [ ] Unsubscribe links work
- [ ] Mobile rendering is correct

---

## Phase 9: Client Handoff (1-2 hours)

### Handoff Deliverables

Provide the client with:

1. **Login credentials** for their GHL sub-account
2. **Quick-start guide** covering:
   - How to log in
   - How to view and manage appointments
   - How to view incoming contacts and form submissions
   - How to monitor chatbot conversations and take over when needed
   - How to mark appointments as completed or no-show
   - How to add the `new-patient` tag for walk-in registrations
3. **Website URLs** for all 5 pages
4. **Workflow summary** -- what each automation does and when it triggers
5. **Email/SMS template list** -- what gets sent and when
6. **Chatbot capabilities overview** -- what it can and cannot do

### Handoff Call Agenda (30-45 min video call)

1. Walk through the website (5 min)
2. Demonstrate the booking flow end-to-end (5 min)
3. Show the chatbot in action (5 min)
4. Explain each workflow with examples (10 min)
5. Show how to manage contacts, appointments, and conversations in GHL (10 min)
6. Answer questions (5-10 min)
7. Confirm hypercare period and support channel

### Hypercare Period (14 Days)

During hypercare:
- Monitor all workflows daily for the first 3 days, then every 2-3 days
- Review chatbot conversation logs every 48 hours
- Check email deliverability (open rates, bounce rates)
- Respond to client questions within 4 business hours
- Make adjustments to chatbot responses based on real conversations
- Fix any workflow issues immediately
- Weekly check-in call (2 calls during 14-day hypercare)

### Post-Hypercare Handoff

At the end of hypercare:
- Provide a summary report: emails sent, open rates, SMS delivered, chatbot conversations, bookings generated
- Confirm the client is comfortable managing the system independently
- Transition to standard Avantwerk subscription support
- Save the sub-account as a GHL Snapshot (if not already done)

---

## Appendix: Client Information Template

Copy this template and fill in for each new Elevate AI dental client. This becomes the basis for replacing all `[PLACEHOLDER]` values throughout the build.

```
CLIENT INFORMATION -- DENTAL PRACTICE (UK)
===========================================

BUSINESS DETAILS
Business Name:
Trading Name (if different):
Company Registration Number:
CQC Registration Number:
Year Established:

LOCATION
Address Line 1:
Address Line 2:
City:
Postcode:
Google Maps URL:
Parking Information:
Public Transport (nearest station):
Public Transport (bus routes):
Wheelchair Access Details:

CONTACT
Main Phone:
Emergency / Out-of-Hours Phone:
Email:
Website URL:
WhatsApp Number:

OPENING HOURS
Monday:
Tuesday:
Wednesday:
Thursday:
Friday:
Saturday:
Sunday:
Bank Holidays:
Out-of-Hours Information:

ONLINE PRESENCE
Google Business Profile URL:
Google Review Direct Link:
Current Google Rating:
Current Review Count:
Facebook Page URL:
Instagram Handle:

CLINICAL
NHS Status (Accepting/Not Accepting/Private Only):
NHS Band Prices (if applicable):
  Band 1:
  Band 2:
  Band 3:
  Urgent:
Sedation Options Offered:
Anxiety/Nervous Patient Options:
Insurance Providers Accepted:

TEAM
Dentist 1 -- Name:
  Role:
  Qualifications:
  Bio (2 sentences):
  GDC Number:

Dentist 2 -- Name:
  Role:
  Qualifications:
  Bio (2 sentences):
  GDC Number:

Hygienist -- Name:
  Qualifications:
  Bio (2 sentences):
  GDC Number:

Practice Manager -- Name:
  Bio (2 sentences):

Additional Team Members:

SERVICES AND PRICING (Private)
Check-up:
Hygiene:
Fillings:
Root Canal:
Extractions:
Crowns:
Teeth Whitening (in-surgery):
Teeth Whitening (home kit):
Composite Bonding:
Porcelain Veneers:
Smile Makeover:
Invisalign:
Fixed Braces:
Single Implant:
Emergency Appointment:
Children's Check-up:
Fissure Sealants:
Fluoride Treatment:
Other Services:

PAYMENT
Finance Provider:
Finance Terms (0%, minimum spend):
Dental Plan Name:
Dental Plan Monthly Price:
Payment Methods Accepted:

POLICIES
Cancellation Policy:
Missed Appointment Fee:
Data Protection / GDPR Notice:

BRANDING
Primary Brand Colour:
Secondary Brand Colour:
Logo File(s) Provided:
Preferred Chatbot Name:
Chatbot Greeting Message:
Languages Spoken:

CURRENT PATIENT OFFER (if any):
```

---

## Build Timeline Summary

| Phase | Task | Estimated Time | Day |
|-------|------|---------------|-----|
| 1 | GHL Sub-Account Setup | 30 min | Day 1 |
| 2 | Custom Fields & Tags | 30 min | Day 1 |
| 3 | Pipeline Setup | 20 min | Day 1 |
| 4 | Website -- 5 Pages | 6-8 hours | Days 2-5 |
| 5 | Workflows -- 4 Automations | 4-5 hours | Days 6-9 |
| 6 | Email/SMS Templates | 1-1.5 hours | Day 10 |
| 7 | AI Chatbot -- Enhanced | 1.5-2 hours | Day 11 |
| 8 | Testing & QA | 2-3 hours | Days 12-14 |
| 9 | Client Handoff | 1-2 hours | Day 15-16 |
| -- | Buffer / Revisions | -- | Days 17-21 |
| **Total** | | **18-22 hours** | **21 days** |

---

## Workflow Interaction Rules

To avoid message fatigue, enforce these overlap rules:

| If Patient Is In... | And Enters... | Action |
|---------------------|---------------|--------|
| Recall Reminder | Any other workflow | Pause Recall for 14 days |
| Any workflow | New Patient Welcome | Welcome takes priority |
| Review Request | Any other email-sending workflow | Pause Review Request if another email is due within 48h |

Configure these using GHL's "Contact is NOT in Workflow" conditions at workflow entry points.

---

## Elevate AI -- What Is Included vs Excluded

### Included in Elevate AI

- 5-page website (Homepage, Services, About, Contact, Booking)
- Header and footer (shared across all pages)
- Native GHL contact form (Contact page)
- Native GHL calendar widget (Booking page)
- 4 workflows (Appointment Reminder, Review Request, Recall Reminder, New Patient Welcome)
- 6 email/SMS templates (plus additional supporting templates within workflows)
- Enhanced AI chatbot (FAQ + treatment info + new patient guidance)
- Custom fields, tags, and pipelines as documented
- Testing and QA
- Client handoff call
- 14-day hypercare

### NOT Included (Available in Higher Tiers)

- Individual treatment pages (Momentum AI)
- Reviews/testimonials page (Momentum AI)
- Blog/news section (Momentum AI)
- New Patient Nurture workflow (Momentum AI)
- Cancellation Recovery workflow (Momentum AI)
- Full symptom triage in chatbot (Momentum AI)
- Booking/rescheduling/cancellation handling in chatbot (Momentum AI)
- Birthday & Loyalty workflow (Apex AI)
- Treatment Plan Follow-up workflow (Apex AI)
- Multi-language chatbot support (Apex AI)
- Team-specific handoff routing (Apex AI)
- Custom reporting dashboard (Apex AI)
- Staff training session (Apex AI)
