# Avantwerk Solutions — Client Deliverable Templates

This workspace contains ready-to-deploy industry solution templates for Avantwerk implementation packages. Each industry has a "golden master" template that can be snapshotted for new clients via GHL.

## Relationship to Main Workspace
- Pricing reference: see `C:\Users\bartk\OneDrive\Avantwerk\CLAUDE.md`
- This workspace builds **client deliverables**, NOT Avantwerk/Bennovate platform pages
- Client websites use their OWN branding (industry-appropriate), NOT the Avantwerk dark theme

## Implementation Packages (what clients buy)
| Package | UK Price | PL Price | Delivery | Hypercare |
|---------|----------|----------|----------|-----------|
| Ignite AI | £1,999 | 8,999 zł | 14 days | 7 days |
| Elevate AI | £2,499 | 11,499 zł | 21 days | 14 days |
| Momentum AI ★ | £2,999 | 13,999 zł | 30 days | 21 days |
| Apex AI | £3,999 | 17,999 zł | 45-60 days | 30 days |

With annual subscription: £300-600 / 1,500-3,000 zł discount on implementation.

## Workspace Structure
```
_shared/          — Reusable components, styles, palettes, workflow templates, email shells
  palettes/       — Industry default color palettes (JSON)
_markets/         — Market configs (pricing, legal entity, locale per country)
{industry}/       — One folder per vertical (dental, veterinary, doctors, etc.)
  INDUSTRY.md     — Domain knowledge, pain points, terminology, niches
  deliverables.md — What each package tier includes for this industry
  template/       — Golden master (snapshotable via GHL Snapshots)
    website/      — GHL section HTML per market (uk/, pl/)
    workflows/    — Automation workflow specs + GHL setup docs
    emails/       — Email/SMS templates per market
    chatbot/      — AI agent system prompts per market
  clients/        — Real deployments (cloned from template/)
    {client-name}/
      CLIENT.md   — Client-specific notes, brand overrides, contacts
```

---

## CRITICAL: Client Branding Rules

### DO NOT use Avantwerk branding for client websites
Client websites are the CLIENT'S business — not Avantwerk marketing pages. Each industry has its own default palette. Client-specific brand overrides go in `CLIENT.md`.

### Industry Default Palettes
Defined in `_shared/palettes/{industry}.json`. Defaults:

| Industry | Primary | Secondary | Page bg | Card bg | Text | Feel |
|----------|---------|-----------|---------|---------|------|------|
| Dental | Blue #2563eb | Cyan #06b6d4 | #f8fafc | #ffffff | #0f172a | Clean, clinical, trustworthy |
| Veterinary | Green #059669 | Amber #f59e0b | #fffbeb | #ffffff | #0f172a | Warm, caring, natural |
| Doctors | Deep blue #1d4ed8 | Teal #0891b2 | #ffffff | #f8fafc | #0f172a | Authoritative, modern |
| Dark premium | Emerald #10b981 | Blue #3b82f6 | #0a0f1f | #1e293b | #ffffff | Optional high-end variant |

### CSS Custom Properties (mandatory)
ALL website HTML must use CSS custom properties for theming. Place at the top of every HTML section:

```css
:root {
  /* Brand — override these per client */
  --brand-primary: #2563eb;
  --brand-primary-hover: #1d4ed8;
  --brand-primary-light: rgba(37,99,235,0.08);
  --brand-secondary: #06b6d4;
  --brand-accent: #10b981;

  /* Backgrounds */
  --bg-page: #f8fafc;
  --bg-section: #ffffff;
  --bg-card: #f1f5f9;
  --bg-card-hover: #e2e8f0;

  /* Text */
  --text-heading: #0f172a;
  --text-body: #475569;
  --text-muted: #94a3b8;
  --text-on-primary: #ffffff;

  /* Borders & shadows */
  --border-color: rgba(0,0,0,0.08);
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
  --shadow-md: 0 4px 16px rgba(0,0,0,0.08);
  --shadow-lg: 0 12px 40px rgba(0,0,0,0.10);

  /* Radius */
  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 16px;
  --radius-full: 100px;
}
```

Then reference ONLY variables in all styling:
```css
.btn-primary { background: var(--brand-primary); color: var(--text-on-primary); }
.card { background: var(--bg-card); border: 1px solid var(--border-color); }
h1, h2, h3 { color: var(--text-heading); }
p { color: var(--text-body); }
```

### Client Brand Override
When deploying for a specific client, override the variables in `CLIENT.md`:
```markdown
## Brand Override
--brand-primary: #1a73e8  (client's blue from their logo)
--brand-primary-hover: #1557b0
--bg-page: #ffffff
```

### When to Ask vs Use Defaults
- **Template building**: Always use the industry default palette from `_shared/palettes/`
- **Client deployment**: Check if CLIENT.md has brand overrides → if yes, apply them; if not, keep industry defaults
- **Never assume Avantwerk colors** for client websites

---

## GHL Deployment Architecture

### Deployment Method: GHL Snapshots
We use an Agency GHL account with sub-accounts. The deployment workflow:

```
1. Build a "TEMPLATE — [Industry] [Market]" sub-account in GHL
2. Build pages using GHL's page builder:
   - Header/footer → native GHL elements (nav, footer widgets)
   - Forms/calendars → native GHL elements (wired to pipelines)
   - Content sections → paste our HTML into Custom Code blocks
3. Build workflows natively in GHL (using our .md specs as blueprints)
4. Set up email templates, pipelines, tags, custom fields, calendars
5. Save as GHL Snapshot
6. For each new client:
   → Create sub-account → Load snapshot → Customize (name, logo, colors, phone)
```

### Website HTML = Section Blocks, NOT Full Pages
Each HTML file is a **pasteable GHL code block section**, not a full standalone page:
- NO `<html>`, `<head>`, `<body>` wrappers (GHL provides those)
- NO header/navigation (built natively in GHL page builder)
- NO footer (built natively in GHL page builder)
- NO forms (use native GHL form elements — they wire to automations)
- NO calendar embeds (use native GHL calendar widget)
- Each file = one section (hero, services grid, team, testimonials, CTA, etc.)
- Include the DM Sans font import and CSS variables at the top of each section
- Keep sections independent — any section can be used on any page

### What Goes Native in GHL vs Custom Code

| Element | Build in GHL natively | Why |
|---------|----------------------|-----|
| Header/nav | Yes | Menu links, mobile hamburger, logo placement |
| Footer | Yes | Contact info, social links, legal links |
| Forms | Yes | Wires to pipelines, triggers workflows |
| Calendar booking | Yes | Connects to GHL calendar, availability |
| Popups/modals | Yes | Exit intent, scroll triggers, etc. |
| Chat widget | Yes | GHL conversation AI / live chat |
| Hero sections | Custom Code block | Complex animations, custom design |
| Service grids | Custom Code block | Custom card layouts |
| Team sections | Custom Code block | Custom profile cards |
| Testimonials | Custom Code block | Custom review cards |
| FAQ accordions | Custom Code block | Interactive JS |
| Blog articles | Custom Code block | Long-form content |
| CTA banners | Custom Code block | Custom gradients/design |
| Pricing tables | Custom Code block | Complex tier layouts |

---

## Typography
- Font: DM Sans (Google Fonts)
- Import at top of every section: `<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">`
- H1: 2.5rem/700, H2: 2rem/700, H3: 1.5rem/600, Body: 1rem/400, Small: 0.875rem/400

## Component Specs
- **Buttons**: padding 14px 28px, border-radius var(--radius-md), font-weight 600, hover translateY(-2px) + shadow
- **Cards**: bg var(--bg-card), border 1px solid var(--border-color), radius var(--radius-lg), padding 24px, hover shadow
- **Inputs**: bg var(--bg-section), border 1px solid var(--border-color), radius var(--radius-md), padding 14px 16px, focus: brand color + glow
- **Badges**: padding 6px 12px, radius var(--radius-sm), font-size 0.8rem, weight 600

## Translation Rules
- NEVER translate subscription plan names: SoloPreneur, Core, SmartFlow, ScaleUp, Nexus
- NEVER translate implementation package names: Ignite AI, Elevate AI, Momentum AI, Apex AI
- Client business names stay as-is across locales

## Workflow Documentation Format
Document workflows as Markdown specs (blueprints for building in GHL). Include:
1. **Trigger**: What starts the workflow (form submission, tag added, appointment booked)
2. **Steps**: Sequential actions with timing (wait 1h → send SMS → wait 24h → send email)
3. **Conditions**: If/else branches (e.g., if opened email → path A, else → path B)
4. **Templates**: Reference the email/SMS template files used
5. **GHL Setup Notes**: Which pipeline, tags, custom fields needed

## Email Template Format
- Self-contained HTML (inline CSS) — match the CLIENT's brand, not Avantwerk's
- Responsive for mobile email clients
- Use {{contact.first_name}}, {{appointment.date}} GHL merge fields
- Include both HTML version and plain-text fallback
- Market-appropriate: UK English or Polish
- Use client brand colors for CTA buttons and accents

## Chatbot Prompt Format
- Markdown system prompt for the AI agent
- Include: role, business context, services offered, booking process, FAQ answers
- Tone: professional but warm, industry-appropriate
- Language: match the market (English for UK, Polish for PL)
- Always include escalation path (transfer to human when needed)

## Deploying for a Client (Snapshot Workflow)
1. Create new GHL sub-account for the client
2. Load the industry snapshot (e.g., "TEMPLATE — Dental UK")
3. Copy `{industry}/template/` → `{industry}/clients/{client-name}/` in this workspace
4. Create `CLIENT.md` with their specifics (business name, phone, address, brand overrides)
5. Find-and-replace placeholder values: [BUSINESS_NAME], [PHONE], [ADDRESS], etc.
6. Apply brand overrides (CSS variables) if client has their own colors
7. Customize services, pricing, team info in GHL
8. Update email templates with client details
9. Test all workflows end-to-end
10. Keep template/ untouched as the snapshotable master

## Adding a New Industry
1. Create `{industry}/` folder with the standard structure
2. Create a palette in `_shared/palettes/{industry}.json`
3. Research and write `INDUSTRY.md` (use industry-researcher agent)
4. Define `deliverables.md` with package tier mappings
5. Build template/website/ sections for each market
6. Document workflows, create emails, write chatbot prompts
7. Have QA agent review the complete deliverable set
8. Build the GHL template sub-account and save Snapshot

## Adding a New Market
1. Add `_markets/{country}.json` with pricing, legal, locale
2. Add `{country}/` subfolder to website/, emails/, chatbot/ in each industry template
3. Translate content (respecting translation rules above)
