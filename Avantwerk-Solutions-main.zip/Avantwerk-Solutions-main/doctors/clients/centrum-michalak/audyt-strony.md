# Audyt strony centrummichalak.pl
**Data:** 12 lutego 2026
**Przygotowano przez:** Avantwerk

---

## Ogolna ocena: 5.8 / 10

Centrum Medyczne Michalak ma **silna reputacje** (5.0/5 na ZnanyLekarz, 463 opinie) i szerokie spektrum uslug, ale strona internetowa **nie wykorzystuje tego potencjalu**. Glowne problemy: fragmentacja obecnosci online (2 domeny), brak automatyzacji, slaba sciezka konwersji i brak sklep online mimo posiadania podstrony /sklep/.

---

## 1. Design i UX — 5/10

| Problem | Wplyw |
|---------|-------|
| Strona blokuje automatyczne crawlery (403 Forbidden) | Moze blokowac tez boty Google — krytyczny problem SEO |
| Dwie domeny: centrummichalak.pl + lukaszmichalak.pl (redirect) | Fragmentacja autorytetu SEO, mylace dla pacjentow |
| Podstrona /sklep/ istnieje ale "Brak produktow w koszyku" | Pusta strona e-commerce — negatywne wrazenie |
| Brak wyraznej sciezki uzytkownika do rezerwacji | Pacjent musi szukac, jak umowic wizyte |
| Rezerwacja rozproszona: ZnanyLekarz + Booksy + telefon | 3 rozne systemy — brak jednego zrodla prawdy |

**Rekomendacja:** Jedna strona z czytelna sciezka: usluga → cennik → rezerwacja. Likwidacja pustego sklepu lub wypelnienie go produktami (kosmetyki, suplementy). Konsolidacja rezerwacji w jednym systemie.

---

## 2. Szybkosc i wydajnosc — 4/10

| Problem | Wplyw |
|---------|-------|
| WordPress z WooCommerce (sklep) = ciezka infrastruktura | Wolne ladowanie, szczegolnie na mobile |
| Blokowanie botow (403) sugeruje agresywny WAF/firewall | Moze blokowac Googlebot — katastrofa dla SEO |
| Prawdopodobnie niezoptymalizowane obrazy (standard WordPress) | Dlugi czas ladowania na urzadzeniach mobilnych |
| WooCommerce laduje skrypty nawet na podstronach bez sklepu | Niepotrzebne obciazenie |

**Rekomendacja:** Migracja na lekka platforme (GHL) z zoptymalizowanym HTML. Weryfikacja czy Googlebot moze indeksowac strone (Search Console). Optymalizacja obrazow + lazy loading.

---

## 3. Tresc — 6/10

| Problem | Wplyw |
|---------|-------|
| Podstrona /sklep/ pusta — brak produktow | Strona istnieje w nawigacji ale nie sluzy celowi |
| Brak szczegolowych opisow zabiegow na stronie | Pacjent musi szukac informacji na Booksy/ZnanyLekarz |
| Brak sekcji FAQ | Wiecej telefonow, brak odpowiedzi na czeste pytania |
| Zespol: 3+ specjalistow ale brak profili na stronie | Brak budowania zaufania, pacjent idzie na ZnanyLekarz |
| Brak bloga / artykulow edukacyjnych | Minimalna aktywnosc contentowa, stracony potencjal SEO |
| Silne opinie (5.0, 463 recenzje) — brak na stronie | Najcenniejszy asset nie jest wyeksponowany |

**Rekomendacja:** Dodanie profili lekarzy i specjalistow (dr Lukasz Michalak, Dominika Pakula, Monika Wojciechow-Gazel, Beata Michalak). Wyeksponowanie opinii z ZnanyLekarz. Sekcja FAQ. Blog z artykulami o zabiegach.

---

## 4. SEO — 4/10

| Element | Stan | Ocena |
|---------|------|-------|
| Indeksowalnosc (crawlability) | Blokada 403 — moze blokowac boty | KRYTYCZNE |
| Dwie domeny (link equity split) | lukaszmichalak.pl → redirect | Slabo |
| Schema markup | Prawdopodobnie brak (WordPress default) | Slabo |
| Frazy lokalne ("medycyna estetyczna Wroclaw") | Brak dedykowanych landing pages | Slabo |
| Google Business Profile | 5.0/5, 463 opinii na ZnanyLekarz — GBP nieznany | Do weryfikacji |
| Podstrony specjalizacji | Ortopeda Wroclaw istnieje | Srednie |
| Alt text na obrazach | Nieznany — standard WordPress | Do weryfikacji |
| Core Web Vitals | Prawdopodobnie niskie (WordPress + WooCommerce) | Slabo |
| Linkowanie wewnetrzne | Minimalne (brak bloga, brak cross-links) | Slabo |
| Mapa witryny | Auto (WordPress/Yoast) | OK |

**Rekomendacja:** Pilna weryfikacja czy Googlebot moze indeksowac strone. Schema MedicalClinic + Physician JSON-LD. Dedykowane landing pages na kluczowe frazy: "medycyna estetyczna Wroclaw", "ortopeda Wroclaw", "laserowe usuwanie wlosow Wroclaw". Optymalizacja Google Business Profile.

---

## 5. Rezerwacja online — 5/10

| Problem | Wplyw |
|---------|-------|
| **3 systemy rownoczesnie**: ZnanyLekarz, Booksy, telefon | Pacjent nie wie, ktorego uzyc; brak jednego zrodla prawdy |
| Na stronie /umow-wizyte/ — nieznana implementacja | Moze byc formularz kontaktowy zamiast kalendarza |
| ZnanyLekarz: "basic profile" — brak pelnej integracji | Minimalna obecnosc na najwiekszej platformie |
| Booksy: 18 opinii vs ZnanyLekarz: 463 — niespojnosc | Rozproszenie social proof |
| Brak automatycznych potwierdzen i przypomnien (wlasny system) | Wiecej no-shows |
| Booksy wymaga 6h notice na zmiany — sztywne | Frustracja pacjentow |

**Rekomendacja:** Centralny system rezerwacji (GHL) z kalendarzem na stronie + automatyczne potwierdzenia SMS/email. Link do jednego systemu z ZnanyLekarz i Google Business Profile.

---

## 6. Automatyzacja i marketing — 1/10

| Brak | Konsekwencja |
|------|-------------|
| Brak przypomnien o wizytach (wlasny system) | Wiecej no-shows; na Booksy jest, ale nie na stronie |
| Brak follow-up po zabiegu | Brak monitorowania satysfakcji |
| Brak automatycznych prosb o opinie Google | 463 opinii na ZnanyLekarz, ale ile na Google? |
| Brak nurturingu nowych pacjentow | Zapytania bez odpowiedzi = utraceni pacjenci |
| Brak kampanii recall (powtorne zabiegi) | Utracony przychod — zabiegi estetyczne wymagaja serii |
| Brak automatyzacji sklepu (porzucone koszyki, follow-up) | Sklep istnieje ale jest martwy |
| Brak odzyskiwania anulacji | Puste sloty w kalendarzu |
| Instagram @centrummedycznemichalak — jedyny kanal social | Brak zintegrowanej strategii digital |

**Rekomendacja:** Wdrozenie 10+ automatycznych procesow: przypomnienia, follow-up po zabiegu, recall na serie zabiegow (np. laser co 4-6 tyg), nurturing, prosby o opinie, odzyskiwanie anulacji.

---

## 7. Zgodnosc prawna (RODO) — 3/10

| Problem | Wplyw |
|---------|-------|
| Brak widocznej polityki prywatnosci (nie mozna zweryfikowac — 403) | Prawdopodobnie niepelna |
| Brak polityki cookies | Wymagane prawnie (RODO + Prawo telekomunikacyjne) |
| Brak warunkow uzytkowania | Brak ochrony prawnej, szczegolnie dla sklepu |
| Brak strony Podmiot Odpowiedzialny | Wymagane dla dzialalnosci medycznej |
| Dane medyczne = dane szczegolne (Art. 9 RODO) | Najwyzszy poziom ochrony — wymaga jasnych podstaw prawnych |
| Sklep WooCommerce — regulamin sklepu? | Prawdopodobnie brakuje regulaminu sprzedazy |

**Rekomendacja:** 4 kompletne strony prawne RODO: Polityka Prywatnosci (z uwzglednieniem danych medycznych), Warunki Uzytkowania, Polityka Cookies, Podmiot Odpowiedzialny (Izba Lekarska, NIP, REGON, ubezpieczenie OC). Jesli sklep zostaje — regulamin sprzedazy.

---

## 8. E-commerce / Sklep — 2/10

| Problem | Wplyw |
|---------|-------|
| Podstrona /sklep/ w nawigacji — brak produktow | Negatywne wrazenie, wrazenie niedokonczenia |
| WooCommerce zainstalowany ale nieaktywny/pusty | Niepotrzebne obciazenie strony |
| Brak jasnej strategii: co sprzedawac online? | Potencjal nieokreslony |
| Brak regulaminu sklepu, polityki zwrotow | Wymagane prawnie dla e-commerce |

**Rekomendacja:** Decyzja strategiczna — albo uruchomic sklep (kosmetyki, suplementy, vouchery na zabiegi, pakiety zabiegow) albo usunac podstrone. Vouchery i pakiety zabiegow maja najwyzszy potencjal.

---

## 9. Mobile — 6/10

| Element | Ocena |
|---------|-------|
| Responsywnosc (WordPress) | Prawdopodobnie dobra |
| Touch targets (przyciski CTA) | Do weryfikacji |
| Szybkosc na mobile | Slaba — WordPress + WooCommerce |
| Rezerwacja mobile | Booksy dziala dobrze na mobile; strona — nieznane |

**Rekomendacja:** Mobile-first redesign. Prominentny przycisk "Umow wizyte" sticky na mobile. Quick-tap do telefonu. Szybsze ladowanie.

---

## 10. Obecnosc online i social proof — 6/10

| Platforma | Stan | Ocena |
|-----------|------|-------|
| ZnanyLekarz | 5.0/5, 463 opinie — basic profile | Swietne opinie, slaba integracja |
| Booksy | 5.0/5, 18 opinii | Dobry system rezerwacji |
| Instagram | @centrummedycznemichalak — aktywny | Jedyny kanal social |
| Google Business | Nieznany — do weryfikacji | Krytyczny dla local SEO |
| Facebook | /centrummichalak — istnieje | Do weryfikacji |
| Strona www | centrummichalak.pl | Slaba konwersja |

**Rekomendacja:** Zoptymalizowanie Google Business Profile (jesli nie zrobione). Wyeksponowanie opinii ZnanyLekarz na stronie. Rozbudowa o Facebook i TikTok (zabiegi estetyczne = wizualny content).

---

## Podsumowanie kluczowych usprawnien

| Priorytet | Usprawnienie | Wplyw biznesowy |
|-----------|-------------|----------------|
| KRYTYCZNY | Weryfikacja indeksowalnosci (403 blokada) | Jesli Google nie indeksuje — zero SEO |
| KRYTYCZNY | Konsolidacja rezerwacji w jednym systemie | -chaos, +konwersje, jedno zrodlo danych |
| KRYTYCZNY | Usunac lub uruchomic sklep /sklep/ | Pusta strona szkodzi wiarygodnosci |
| WYSOKI | Automatyczne przypomnienia SMS/email | -no-shows, +przychod |
| WYSOKI | Follow-up po zabiegach + recall na serie | +przychod z powracajacych pacjentow |
| WYSOKI | Prosby o opinie Google po wizycie | +reputacja, +SEO lokalne |
| WYSOKI | 4+ strony prawne RODO | Zgodnosc, brak ryzyka kar |
| WYSOKI | Schema MedicalClinic + Physician JSON-LD | +widocznosc w Google |
| SREDNI | Profile lekarzy i specjalistow na stronie | +zaufanie, +E-E-A-T |
| SREDNI | Landing pages na kluczowe frazy lokalne | +ruch organiczny |
| SREDNI | Wyeksponowanie 463 opinii ZnanyLekarz | +social proof, +konwersje |
| SREDNI | Chatbot AI — odpowiedzi 24/7 | -obciazenie recepcji, +konwersje po godzinach |
| NISKI | Blog / artykuly edukacyjne | +SEO dlugoterminowe, +autorytet |
| NISKI | Strategia social media (TikTok, Reels) | +swiadomosc marki, zabiegi estetyczne = wizualny content |

---

## Rekomendowany pakiet: Momentum AI (7 499 zl)

Centrum Medyczne Michalak to ugruntowana praktyka z doskonalymi opiniami i szerokim spektrum uslug. Kluczowe potrzeby to:
- **Konsolidacja** rezerwacji i obecnosci online (7+ stron)
- **Automatyzacja** przypomnien, follow-upow, recall na serie zabiegow
- **SEO lokalne** — landing pages na "medycyna estetyczna Wroclaw", "ortopeda Wroclaw"
- **Chatbot AI** — odpowiedzi na pytania o zabiegi, ceny, rezerwacja 24/7

Momentum AI pokrywa wszystkie te potrzeby. Apex AI (9 999 zl) byloby uzasadnione jesli klinika chce:
- Osobne strony profili kazdego lekarza/specjalisty
- Pelna biblioteke zabiegow (laser, RF, ICOONE, mesoterapia itd.)
- Integracje z obecnymi systemami (Booksy, ZnanyLekarz)
- Multi-language (pacjenci zagraniczni we Wroclawiu)

---

*Szczegoly pakietow: patrz deliverables.md*
