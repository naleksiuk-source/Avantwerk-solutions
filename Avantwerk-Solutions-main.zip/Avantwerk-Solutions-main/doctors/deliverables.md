# Doctors / Medical Practice — Deliverables by Package Tier

## Ignite AI — £1,999 / 8,999 zł
**Delivery: 14 days | Hypercare: 7 days**

### Website (3 pages)
- Homepage (hero, specialties overview, booking CTA, doctor credentials, testimonials)
- Services page (consultation types, diagnostics, treatments with price ranges)
- Booking page (embedded GHL calendar widget with doctor/specialty selection)

### Workflows (2)
- **Appointment reminder**: booking confirmed → 24h email with preparation instructions → 2h SMS → post-visit thank you
- **Review request**: 48h after appointment → email asking for Google/Doctify review → 5-day follow-up

### Emails/SMS (3)
- Appointment confirmation with doctor name + preparation notes (email)
- 24h reminder (SMS)
- Review request (email)

### AI Chatbot
- FAQ bot: opening hours, location, parking, accepted insurance, specialties available
- Booking redirect: guides to online booking page with specialty matching
- Urgent care: directs to A&E/emergency number when appropriate

---

## Elevate AI — £2,499 / 11,499 zł
**Delivery: 21 days | Hypercare: 14 days**

### Website (5 pages)
- Everything in Ignite AI, plus:
- About page (practice history, doctor profiles with qualifications, accreditations)
- Contact page (form, map, phone, email, WhatsApp)

### Workflows (4)
- Everything in Ignite AI, plus:
- **New patient registration**: enquiry → welcome email + digital registration form → form completed → booking prompt
- **Follow-up reminder**: doctor flags follow-up needed → X weeks later → email reminder to book

### Emails/SMS (6)
- Everything in Ignite AI, plus:
- New patient welcome + registration form link (email)
- Follow-up reminder (email + SMS)

### AI Chatbot
- Everything in Ignite AI, plus:
- Service matching: "I need a dermatologist" → routes to right doctor
- New patient guidance: what to bring, insurance details, first visit expectations
- Basic symptom triage: questions to determine urgency and specialty

---

## Momentum AI ★ — £2,999 / 13,999 zł (Most Popular)
**Delivery: 30 days | Hypercare: 21 days**

### Website (7+ pages)
- Everything in Elevate AI, plus:
- Individual specialty pages (top 3 by revenue — e.g., dermatology, orthopaedics, health screening)
- Patient testimonials page
- Blog/health advice section (3 seed articles)
- Pre-visit information page (preparation guides per procedure type)

### Workflows (7)
- Everything in Elevate AI, plus:
- **Referral nurture**: GP referral received → welcome email with specialist info → 3-day booking prompt → 7-day "we're here to help"
- **Cancellation recovery**: cancelled → 2h SMS with rebooking link → 24h email
- **Post-consultation follow-up**: visit completed + follow-up flag → automated check-in sequence

### Emails/SMS (11)
- Everything in Elevate AI, plus:
- Referral nurture sequence (3 emails)
- Cancellation recovery (1 email + 1 SMS)
- Post-consultation check-in (email)

### AI Chatbot
- Everything in Elevate AI, plus:
- Full patient journey: booking, rescheduling, cancellation with doctor preference
- Insurance/payment questions: "do you accept Bupa?", "how much is a consultation?"
- Preparation guidance: "what should I do before my blood test?"
- Multi-specialty routing with intelligent triage

---

## Apex AI — £3,999 / 17,999 zł
**Delivery: 45-60 days | Hypercare: 30 days**

### Website (10+ pages)
- Everything in Momentum AI, plus:
- All specialty/service pages
- Individual doctor profile pages with booking links
- FAQ page (structured for SEO, per specialty)
- Health screening packages page
- Patient resources / health library
- Multi-location support (if applicable)

### Workflows (10+)
- Everything in Momentum AI, plus:
- **Health screening recall**: annual/biannual screening due → email invitation → booking prompt → follow-up
- **Prescription renewal reminder**: repeat prescription approaching → email → booking for review appointment
- **Referral program**: patient referred someone → thank you + loyalty benefit
- **Test results notification**: results available → notification email → booking for follow-up if needed

### Emails/SMS (16+)
- Everything in Momentum AI, plus:
- Health screening invitation (email)
- Prescription renewal reminder (email + SMS)
- Referral thank you (email)
- Test results notification (email)

### AI Chatbot
- Everything in Momentum AI, plus:
- Multi-language support (if multi-market practice)
- Telehealth booking integration (video consultation option)
- Post-treatment check-in surveys via chat
- Handoff to specific departments/doctors based on triage outcome
- Integration with PMS for real-time availability

### Additional
- Custom reporting dashboard setup in GHL
- Priority 30-day hypercare with dedicated support
- Staff training session (1h video call)
- GDPR/clinical governance compliance review of all automated communications

---

## Standard Legal Pages (ALL tiers)

The following 4 legal/footer pages are included with EVERY package tier at no additional page count. They are required for GDPR/RODO compliance and proper business disclosure.

### Pages
1. **Polityka Prywatności** (`/polityka-prywatnosci/`) — Privacy Policy, GDPR/RODO compliant, covers patient data + medical records (special category data under GDPR Art. 9)
2. **Warunki Użytkowania** (`/warunki-uzytkowania/`) — Terms of Use, covers website use, online booking rules, cancellation policy, intellectual property
3. **Polityka Cookies** (`/polityka-cookies/`) — Cookie Policy, detailed cookie inventory (essential, analytics, functional, marketing), consent mechanism
4. **Podmiot Odpowiedzialny** (`/podmiot-odpowiedzialny/`) — Legal Entity / Impressum, business registration, Izba Lekarska, insurance, hosting info (GHL), copyright (Avantwerk)

### Notes
- These pages are NOT counted toward the package page quota (e.g., Ignite "3 pages" means 3 functional pages + 4 legal pages)
- All pages cross-link to each other
- Set to `noindex, follow` in meta robots (except podmiot-odpowiedzialny which can be indexed)
- Podmiot Odpowiedzialny must include: Avantwerk credit (copyright section) + GHL hosting disclosure (GDPR requirement for US-based data processor)
- Placeholder fields: [NIP], [REGON], [NUMER WPISU], [UBEZPIECZYCIEL], [NUMER POLISY], [DATA OD], [DATA DO]
- Medical regulatory bodies (PL): Okręgowa Izba Lekarska, Wojewódzki Inspektor Sanitarny, Rzecznik Praw Pacjenta, UODO
- Medical regulatory bodies (UK): GMC, CQC, ICO
- Medical records retention: 20 years (PL), 10 years after last treatment (UK)
