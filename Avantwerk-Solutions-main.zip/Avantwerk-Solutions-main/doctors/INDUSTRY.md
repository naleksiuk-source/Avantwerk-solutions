# Doctors / Medical Practice Industry Brief

## Overview
Private medical practices (GPs, specialists, clinics) face mounting admin pressure, patient expectations for digital access, and competition from telehealth disruptors. NHS waiting lists drive patients to private options, creating opportunity. AI automation streamlines patient journeys from booking to follow-up while maintaining clinical governance.

## Target Niches
- Private GP practices
- Specialist clinics (dermatology, orthopaedics, ENT, cardiology)
- Aesthetic / cosmetic medicine
- Physiotherapy & sports medicine
- Private mental health / counselling
- Occupational health
- Telehealth / online consultations

## Common Pain Points
| Pain Point | Impact | Avantwerk Solution |
|-----------|--------|-------------------|
| No-shows | £150-500 lost per empty specialist slot | Multi-channel reminders (SMS + email + WhatsApp) |
| Booking complexity | Multiple doctors, specialties, room availability | Online booking with smart calendar integration |
| Patient intake forms | Paper forms at reception = delays, errors | Digital pre-visit forms with auto-population |
| Referral follow-up | Patients lost between GP referral and specialist | Automated referral nurture sequence |
| Prescription reminders | Chronic patients miss repeat appointments | Automated recall by condition/medication cycle |
| Review & reputation | Medical practices slow to collect reviews | Timed review requests after positive consultations |
| After-hours enquiries | Calls go to voicemail, patients go elsewhere | AI chatbot for booking, FAQ, triage guidance |
| Test result communication | Manual calls to patients for results | Automated notification with booking for follow-up |

## Key Services (for website/chatbot)

### UK
- Private GP Consultation: £80-150
- Specialist Consultation: £150-350
- Health Check / Screening: £200-500
- Blood Tests (panel): £100-300
- Minor Surgery: £300-800
- Skin Check / Mole Mapping: £150-250
- Physiotherapy Session: £50-80
- Mental Health Assessment: £150-300
- Aesthetic Consultation: £50-100 (redeemable against treatment)
- Travel Vaccinations: £30-80 per vaccine

### Poland (PL)
- Wizyta u lekarza pierwszego kontaktu: 150-300 zł
- Konsultacja specjalistyczna: 200-500 zł
- Badania profilaktyczne (pakiet): 300-1,000 zł
- Badania krwi (panel): 100-400 zł
- Mały zabieg chirurgiczny: 500-2,000 zł
- Badanie znamion / dermatoskopia: 150-300 zł
- Fizjoterapia (sesja): 100-200 zł
- Konsultacja psychologiczna: 150-350 zł
- Konsultacja medycyny estetycznej: 100-200 zł
- Szczepienia podróżne: 80-200 zł / szczepionka

## Industry Terminology

### UK English
| Term | Usage |
|------|-------|
| Practice / Surgery | The medical clinic |
| Consultation | Doctor appointment |
| GP | General Practitioner |
| Referral | Sent to specialist |
| FTA / DNA | Failed to attend / Did not attend |
| Private vs NHS | Payment model distinction |
| Treatment plan | Proposed care pathway |
| CQC | Care Quality Commission (regulator) |
| GMC | General Medical Council (doctor regulator) |
| Repeat prescription | Ongoing medication renewal |

### Polish
| Term | Usage |
|------|-------|
| Gabinet lekarski / Przychodnia | Medical clinic |
| Wizyta / Konsultacja | Appointment / consultation |
| Lekarz pierwszego kontaktu | GP equivalent |
| Skierowanie | Referral |
| NFZ / Prywatnie | Public health vs private |
| Plan leczenia | Treatment plan |
| Recepta | Prescription |
| Izba Lekarska | Medical Chamber (regulator) |
| Teleporada | Telemedicine consultation |
| Badanie okresowe | Periodic health check |

## Compliance Notes
- **UK**: CQC registration mandatory, GMC standards, Clinical governance, Caldicott Principles for patient data
- **PL**: NFZ contracts (public), Izba Lekarska, Ustawa o prawach pacjenta (Patient Rights Act)
- Medical data is **special category data** under GDPR — highest protection level
- AI chatbot MUST NOT provide medical diagnoses or treatment advice — only triage and booking
- Marketing claims about medical outcomes are strictly regulated (ASA/CAP Code UK, UOKiK + Izba Lekarska PL)
- Cannot advertise prescription medicines to the public

## Competitive Landscape
- Main PMS: EMIS, SystmOne (NHS); Doctify, Cliniko, WriteUpp (private UK); mMedica, Mediporta (PL)
- Doctify and TopDoctors growing as review/booking platforms
- Telehealth explosion (Babylon, Push Doctor UK; Telemedico, Medme PL)
- Private practices increasingly need digital presence to compete with aggregator platforms
- AI chatbot is a major differentiator — very few private practices have one
